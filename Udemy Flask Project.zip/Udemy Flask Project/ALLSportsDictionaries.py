import NBADictionary
import MLBDictionary
import NCAABDictionary
import NFLDictionary
import NHLDictionary
import operator

AllSportsDict = { **NBADictionary.NBADict, **MLBDictionary.MLBDict, **NCAABDictionary.NCAABDict, **NFLDictionary.NFLDict, **NHLDictionary.NHLDict}

OrderedSportsDict = sorted(AllSportsDict.items(), key=operator.itemgetter(1), reverse = True)[:5]

#Remember to reverse the order in order to see if the Under % is top 5

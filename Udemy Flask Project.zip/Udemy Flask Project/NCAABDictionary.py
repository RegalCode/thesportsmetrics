import NCAAB
import operator

#American East Teams

VermontCatamountsDict = {
'VermontCatamountsCover' : NCAAB.VermontCatamountsCover,
'VermontCatamountsML' : NCAAB.VermontCatamountsML,
'VermontCatamountsOU' : NCAAB.VermontCatamountsOU,
'VermontCatamountsSoloOU' : NCAAB.VermontCatamountsSoloOU,
'VermontCatamountsHalftime' : NCAAB.VermontCatamountsHalftime,
'VermontCatamountsHalftimeOU' : NCAAB.VermontCatamountsHalftimeOU,
}

AlbanyGreatDanesDict = {
'AlbanyGreatDanesCover' : NCAAB.AlbanyGreatDanesCover,
'AlbanyGreatDanesML' : NCAAB.AlbanyGreatDanesML,
'AlbanyGreatDanesOU' : NCAAB.AlbanyGreatDanesOU,
'AlbanyGreatDanesSoloOU' : NCAAB.AlbanyGreatDanesSoloOU,
'AlbanyGreatDanesHalftime' : NCAAB.AlbanyGreatDanesHalftime,
'AlbanyGreatDanesHalftimeOU' : NCAAB.AlbanyGreatDanesHalftimeOU,
}

BinghamtonBearcatsDict = {
'BinghamtonBearcatsCover' : NCAAB.BinghamtonBearcatsCover,
'BinghamtonBearcatsML' : NCAAB.BinghamtonBearcatsML,
'BinghamtonBearcatsOU' : NCAAB.BinghamtonBearcatsOU,
'BinghamtonBearcatsSoloOU' : NCAAB.BinghamtonBearcatsSoloOU,
'BinghamtonBearcatsHalftime' : NCAAB.BinghamtonBearcatsHalftime,
'BinghamtonBearcatsHalftimeOU' : NCAAB.BinghamtonBearcatsHalftimeOU,
}

HartfordHawksDict = {
'HartfordHawksCover' : NCAAB.HartfordHawksCover,
'HartfordHawksML' : NCAAB.HartfordHawksML,
'HartfordHawksOU' : NCAAB.HartfordHawksOU,
'HartfordHawksSoloOU' : NCAAB.HartfordHawksSoloOU,
'HartfordHawksHalftime' : NCAAB.HartfordHawksHalftime,
'HartfordHawksHalftimeOU' : NCAAB.HartfordHawksHalftimeOU,
}

MaineBlackBearssDict = {
'MaineBlackBearsCover' : NCAAB.MaineBlackBearsCover,
'MaineBlackBearsML' : NCAAB.MaineBlackBearsML,
'MaineBlackBearsOU' : NCAAB.MaineBlackBearsOU,
'MaineBlackBearsSoloOU' : NCAAB.MaineBlackBearsSoloOU,
'MaineBlackBearsHalftime' : NCAAB.MaineBlackBearsHalftime,
'MaineBlackBearsHalftimeOU' : NCAAB.MaineBlackBearsHalftimeOU,
}

UMassLowellRiverHawkssDict = {
'UMassLowellRiverHawksCover' : NCAAB.UMassLowellRiverHawksCover,
'UMassLowellRiverHawksML' : NCAAB.UMassLowellRiverHawksML,
'UMassLowellRiverHawksOU' : NCAAB.UMassLowellRiverHawksOU,
'UMassLowellRiverHawksSoloOU' : NCAAB.UMassLowellRiverHawksSoloOU,
'UMassLowellRiverHawksHalftime' : NCAAB.UMassLowellRiverHawksHalftime,
'UMassLowellRiverHawksHalftimeOU' : NCAAB.UMassLowellRiverHawksHalftimeOU,
}

NewHampshireWildcatssDict = {
'NewHampshireWildcatsCover' : NCAAB.NewHampshireWildcatsCover,
'NewHampshireWildcatsML' : NCAAB.NewHampshireWildcatsML,
'NewHampshireWildcatsOU' : NCAAB.NewHampshireWildcatsOU,
'NewHampshireWildcatsSoloOU' : NCAAB.NewHampshireWildcatsSoloOU,
'NewHampshireWildcatsHalftime' : NCAAB.NewHampshireWildcatsHalftime,
'NewHampshireWildcatsHalftimeOU' : NCAAB.NewHampshireWildcatsHalftimeOU,
}

StonyBrookSeawolvessDict = {
'StonyBrookSeawolvesCover' : NCAAB.StonyBrookSeawolvesCover,
'StonyBrookSeawolvesML' : NCAAB.StonyBrookSeawolvesML,
'StonyBrookSeawolvesOU' : NCAAB.StonyBrookSeawolvesOU,
'StonyBrookSeawolvesSoloOU' : NCAAB.StonyBrookSeawolvesSoloOU,
'StonyBrookSeawolvesHalftime' : NCAAB.StonyBrookSeawolvesHalftime,
'StonyBrookSeawolvesHalftimeOU' : NCAAB.StonyBrookSeawolvesHalftimeOU,
}

UMBCRetrieverssDict = {
'UMBCRetrieversCover' : NCAAB.UMBCRetrieversCover,
'UMBCRetrieversML' : NCAAB.UMBCRetrieversML,
'UMBCRetrieversOU' : NCAAB.UMBCRetrieversOU,
'UMBCRetrieversSoloOU' : NCAAB.UMBCRetrieversSoloOU,
'UMBCRetrieversHalftime' : NCAAB.UMBCRetrieversHalftime,
'UMBCRetrieversHalftimeOU' : NCAAB.UMBCRetrieversHalftimeOU,
}

#American Athletic Teams

HoustonCougarsDict = {
'HoustonCougarsCover' : NCAAB.HoustonCougarsCover,
'HoustonCougarsML' : NCAAB.HoustonCougarsML,
'HoustonCougarsOU' : NCAAB.HoustonCougarsOU,
'HoustonCougarsSoloOU' : NCAAB.HoustonCougarsSoloOU,
'HoustonCougarsHalftime' : NCAAB.HoustonCougarsHalftime,
'HoustonCougarsHalftimeOU' : NCAAB.HoustonCougarsHalftimeOU,
}

CincinnatiBearcatsDict = {
'CincinnatiBearcatsCover' : NCAAB.CincinnatiBearcatsCover,
'CincinnatiBearcatsML' : NCAAB.CincinnatiBearcatsML,
'CincinnatiBearcatsOU' : NCAAB.CincinnatiBearcatsOU,
'CincinnatiBearcatsSoloOU' : NCAAB.CincinnatiBearcatsSoloOU,
'CincinnatiBearcatsHalftime' : NCAAB.CincinnatiBearcatsHalftime,
'CincinnatiBearcatsHalftimeOU' : NCAAB.CincinnatiBearcatsHalftimeOU,
}

TulsaGoldenHurricaneDict = {
'TulsaGoldenHurricaneCover' : NCAAB.TulsaGoldenHurricaneCover,
'TulsaGoldenHurricaneML' : NCAAB.TulsaGoldenHurricaneML,
'TulsaGoldenHurricaneOU' : NCAAB.TulsaGoldenHurricaneOU,
'TulsaGoldenHurricaneSoloOU' : NCAAB.TulsaGoldenHurricaneSoloOU,
'TulsaGoldenHurricaneHalftime' : NCAAB.TulsaGoldenHurricaneHalftime,
'TulsaGoldenHurricaneHalftimeOU' : NCAAB.TulsaGoldenHurricaneHalftimeOU,
}

WichitaStateShockersDict = {
'WichitaStateShockersCover' : NCAAB.WichitaStateShockersCover,
'WichitaStateShockersML' : NCAAB.WichitaStateShockersML,
'WichitaStateShockersOU' : NCAAB.WichitaStateShockersOU,
'WichitaStateShockersSoloOU' : NCAAB.WichitaStateShockersSoloOU,
'WichitaStateShockersHalftime' : NCAAB.WichitaStateShockersHalftime,
'WichitaStateShockersHalftimeOU' : NCAAB.WichitaStateShockersHalftimeOU,
}

MemphisTigersDict = {
'MemphisTigersCover' : NCAAB.MemphisTigersCover,
'MemphisTigersML' : NCAAB.MemphisTigersML,
'MemphisTigersOU' : NCAAB.MemphisTigersOU,
'MemphisTigersSoloOU' : NCAAB.MemphisTigersSoloOU,
'MemphisTigersHalftime' : NCAAB.MemphisTigersHalftime,
'MemphisTigersHalftimeOU' : NCAAB.MemphisTigersHalftimeOU,
}

UConnHuskiesDict = {
'UConnHuskiesCover' : NCAAB.UConnHuskiesCover,
'UConnHuskiesML' : NCAAB.UConnHuskiesML,
'UConnHuskiesOU' : NCAAB.UConnHuskiesOU,
'UConnHuskiesSoloOU' : NCAAB.UConnHuskiesSoloOU,
'UConnHuskiesHalftime' : NCAAB.UConnHuskiesHalftime,
'UConnHuskiesHalftimeOU' : NCAAB.UConnHuskiesHalftimeOU,
}

SMUMustangsDict = {
'SMUMustangsCover' : NCAAB.SMUMustangsCover,
'SMUMustangsML' : NCAAB.SMUMustangsML,
'SMUMustangsOU' : NCAAB.SMUMustangsOU,
'SMUMustangsSoloOU' : NCAAB.SMUMustangsSoloOU,
'SMUMustangsHalftime' : NCAAB.SMUMustangsHalftime,
'SMUMustangsHalftimeOU' : NCAAB.SMUMustangsHalftimeOU,
}

UCFKnightsDict = {
'UCFKnightsCover' : NCAAB.UCFKnightsCover,
'UCFKnightsML' : NCAAB.UCFKnightsML,
'UCFKnightsOU' : NCAAB.UCFKnightsOU,
'UCFKnightsSoloOU' : NCAAB.UCFKnightsSoloOU,
'UCFKnightsHalftime' : NCAAB.UCFKnightsHalftime,
'UCFKnightsHalftimeOU' : NCAAB.UCFKnightsHalftimeOU,
}

SouthFloridaBullsDict = {
'SouthFloridaBullsCover' : NCAAB.SouthFloridaBullsCover,
'SouthFloridaBullsML' : NCAAB.SouthFloridaBullsML,
'SouthFloridaBullsOU' : NCAAB.SouthFloridaBullsOU,
'SouthFloridaBullsSoloOU' : NCAAB.SouthFloridaBullsSoloOU,
'SouthFloridaBullsHalftime' : NCAAB.SouthFloridaBullsHalftime,
'SouthFloridaBullsHalftimeOU' : NCAAB.SouthFloridaBullsHalftimeOU,
}

TempleOwlsDict = {
'TempleOwlsCover' : NCAAB.TempleOwlsCover,
'TempleOwlsML' : NCAAB.TempleOwlsML,
'TempleOwlsOU' : NCAAB.TempleOwlsOU,
'TempleOwlsSoloOU' : NCAAB.TempleOwlsSoloOU,
'TempleOwlsHalftime' : NCAAB.TempleOwlsHalftime,
'TempleOwlsHalftimeOU' : NCAAB.TempleOwlsHalftimeOU,
}

EastCarolinaPiratesDict = {
'EastCarolinaPiratesCover' : NCAAB.EastCarolinaPiratesCover,
'EastCarolinaPiratesML' : NCAAB.EastCarolinaPiratesML,
'EastCarolinaPiratesOU' : NCAAB.EastCarolinaPiratesOU,
'EastCarolinaPiratesSoloOU' : NCAAB.EastCarolinaPiratesSoloOU,
'EastCarolinaPiratesHalftime' : NCAAB.EastCarolinaPiratesHalftime,
'EastCarolinaPiratesHalftimeOU' : NCAAB.EastCarolinaPiratesHalftimeOU,
}

TulaneGreenWaveDict = {
'TulaneGreenWaveCover' : NCAAB.TulaneGreenWaveCover,
'TulaneGreenWaveML' : NCAAB.TulaneGreenWaveML,
'TulaneGreenWaveOU' : NCAAB.TulaneGreenWaveOU,
'TulaneGreenWaveSoloOU' : NCAAB.TulaneGreenWaveSoloOU,
'TulaneGreenWaveHalftime' : NCAAB.TulaneGreenWaveHalftime,
'TulaneGreenWaveHalftimeOU' : NCAAB.TulaneGreenWaveHalftimeOU,
}

#ASUN Teams

LibertyFlamesDict = {
'LibertyFlamesCover' : NCAAB.LibertyFlamesCover,
'LibertyFlamesML' : NCAAB.LibertyFlamesML,
'LibertyFlamesOU' : NCAAB.LibertyFlamesOU,
'LibertyFlamesSoloOU' : NCAAB.LibertyFlamesSoloOU,
'LibertyFlamesHalftime' : NCAAB.LibertyFlamesHalftime,
'LibertyFlamesHalftimeOU' : NCAAB.LibertyFlamesHalftimeOU,
}

NorthFloridaOspreysDict = {
'NorthFloridaOspreysCover' : NCAAB.NorthFloridaOspreysCover,
'NorthFloridaOspreysML' : NCAAB.NorthFloridaOspreysML,
'NorthFloridaOspreysOU' : NCAAB.NorthFloridaOspreysOU,
'NorthFloridaOspreysSoloOU' : NCAAB.NorthFloridaOspreysSoloOU,
'NorthFloridaOspreysHalftime' : NCAAB.NorthFloridaOspreysHalftime,
'NorthFloridaOspreysHalftimeOU' : NCAAB.NorthFloridaOspreysHalftimeOU,
}

LipscombBisonsDict = {
'LipscombBisonsCover' : NCAAB.LipscombBisonsCover,
'LipscombBisonsML' : NCAAB.LipscombBisonsML,
'LipscombBisonsOU' : NCAAB.LipscombBisonsOU,
'LipscombBisonsSoloOU' : NCAAB.LipscombBisonsSoloOU,
'LipscombBisonsHalftime' : NCAAB.LipscombBisonsHalftime,
'LipscombBisonsHalftimeOU' : NCAAB.LipscombBisonsHalftimeOU,
}

StetsonHattersDict = {
'StetsonHattersCover' : NCAAB.StetsonHattersCover,
'StetsonHattersML' : NCAAB.StetsonHattersML,
'StetsonHattersOU' : NCAAB.StetsonHattersOU,
'StetsonHattersSoloOU' : NCAAB.StetsonHattersSoloOU,
'StetsonHattersHalftime' : NCAAB.StetsonHattersHalftime,
'StetsonHattersHalftimeOU' : NCAAB.StetsonHattersHalftimeOU,
}

NorthAlabamaLionsDict = {
'NorthAlabamaLionsCover' : NCAAB.NorthAlabamaLionsCover,
'NorthAlabamaLionsML' : NCAAB.NorthAlabamaLionsML,
'NorthAlabamaLionsOU' : NCAAB.NorthAlabamaLionsOU,
'NorthAlabamaLionsSoloOU' : NCAAB.NorthAlabamaLionsSoloOU,
'NorthAlabamaLionsHalftime' : NCAAB.NorthAlabamaLionsHalftime,
'NorthAlabamaLionsHalftimeOU' : NCAAB.NorthAlabamaLionsHalftimeOU,
}

FloridaGulfCoastEaglesDict = {
'FloridaGulfCoastEaglesCover' : NCAAB.FloridaGulfCoastEaglesCover,
'FloridaGulfCoastEaglesML' : NCAAB.FloridaGulfCoastEaglesML,
'FloridaGulfCoastEaglesOU' : NCAAB.FloridaGulfCoastEaglesOU,
'FloridaGulfCoastEaglesSoloOU' : NCAAB.FloridaGulfCoastEaglesSoloOU,
'FloridaGulfCoastEaglesHalftime' : NCAAB.FloridaGulfCoastEaglesHalftime,
'FloridaGulfCoastEaglesHalftimeOU' : NCAAB.FloridaGulfCoastEaglesHalftimeOU,
}

JacksonvilleDolphinsDict = {
'JacksonvilleDolphinsCover' : NCAAB.JacksonvilleDolphinsCover,
'JacksonvilleDolphinsML' : NCAAB.JacksonvilleDolphinsML,
'JacksonvilleDolphinsOU' : NCAAB.JacksonvilleDolphinsOU,
'JacksonvilleDolphinsSoloOU' : NCAAB.JacksonvilleDolphinsSoloOU,
'JacksonvilleDolphinsHalftime' : NCAAB.JacksonvilleDolphinsHalftime,
'JacksonvilleDolphinsHalftimeOU' : NCAAB.JacksonvilleDolphinsHalftimeOU,
}

NJITHighlandersDict = {
'NJITHighlandersCover' : NCAAB.NJITHighlandersCover,
'NJITHighlandersML' : NCAAB.NJITHighlandersML,
'NJITHighlandersOU' : NCAAB.NJITHighlandersOU,
'NJITHighlandersSoloOU' : NCAAB.NJITHighlandersSoloOU,
'NJITHighlandersHalftime' : NCAAB.NJITHighlandersHalftime,
'NJITHighlandersHalftimeOU' : NCAAB.NJITHighlandersHalftimeOU,
}

KennesawStateOwlsDict = {
'KennesawStateOwlsCover' : NCAAB.KennesawStateOwlsCover,
'KennesawStateOwlsML' : NCAAB.KennesawStateOwlsML,
'KennesawStateOwlsOU' : NCAAB.KennesawStateOwlsOU,
'KennesawStateOwlsSoloOU' : NCAAB.KennesawStateOwlsSoloOU,
'KennesawStateOwlsHalftime' : NCAAB.KennesawStateOwlsHalftime,
'KennesawStateOwlsHalftimeOU' : NCAAB.KennesawStateOwlsHalftimeOU,
}

#Atlantic 10 Teams

DaytonFlyersDict = {
'DaytonFlyersCover' : NCAAB.DaytonFlyersCover,
'DaytonFlyersML' : NCAAB.DaytonFlyersML,
'DaytonFlyersOU' : NCAAB.DaytonFlyersOU,
'DaytonFlyersSoloOU' : NCAAB.DaytonFlyersSoloOU,
'DaytonFlyersHalftime' : NCAAB.DaytonFlyersHalftime,
'DaytonFlyersHalftimeOU' : NCAAB.DaytonFlyersHalftimeOU,
}

RichmondSpidersDict = {
'RichmondSpidersCover' : NCAAB.RichmondSpidersCover,
'RichmondSpidersML' : NCAAB.RichmondSpidersML,
'RichmondSpidersOU' : NCAAB.RichmondSpidersOU,
'RichmondSpidersSoloOU' : NCAAB.RichmondSpidersSoloOU,
'RichmondSpidersHalftime' : NCAAB.RichmondSpidersHalftime,
'RichmondSpidersHalftimeOU' : NCAAB.RichmondSpidersHalftimeOU,
}

RhodeIslandRamsDict = {
'RhodeIslandRamsCover' : NCAAB.RhodeIslandRamsCover,
'RhodeIslandRamsML' : NCAAB.RhodeIslandRamsML,
'RhodeIslandRamsOU' : NCAAB.RhodeIslandRamsOU,
'RhodeIslandRamsSoloOU' : NCAAB.RhodeIslandRamsSoloOU,
'RhodeIslandRamsHalftime' : NCAAB.RhodeIslandRamsHalftime,
'RhodeIslandRamsHalftimeOU' : NCAAB.RhodeIslandRamsHalftimeOU,
}

SaintLouisBillikensDict = {
'SaintLouisBillikensCover' : NCAAB.SaintLouisBillikensCover,
'SaintLouisBillikensML' : NCAAB.SaintLouisBillikensML,
'SaintLouisBillikensOU' : NCAAB.SaintLouisBillikensOU,
'SaintLouisBillikensSoloOU' : NCAAB.SaintLouisBillikensSoloOU,
'SaintLouisBillikensHalftime' : NCAAB.SaintLouisBillikensHalftime,
'SaintLouisBillikensHalftimeOU' : NCAAB.SaintLouisBillikensHalftimeOU,
}

StBonaventureBonniesDict = {
'StBonaventureBonniesCover' : NCAAB.StBonaventureBonniesCover,
'StBonaventureBonniesML' : NCAAB.StBonaventureBonniesML,
'StBonaventureBonniesOU' : NCAAB.StBonaventureBonniesOU,
'StBonaventureBonniesSoloOU' : NCAAB.StBonaventureBonniesSoloOU,
'StBonaventureBonniesHalftime' : NCAAB.StBonaventureBonniesHalftime,
'StBonaventureBonniesHalftimeOU' : NCAAB.StBonaventureBonniesHalftimeOU,
}

DuquesneDukesDict = {
'DuquesneDukesCover' : NCAAB.DuquesneDukesCover,
'DuquesneDukesML' : NCAAB.DuquesneDukesML,
'DuquesneDukesOU' : NCAAB.DuquesneDukesOU,
'DuquesneDukesSoloOU' : NCAAB.DuquesneDukesSoloOU,
'DuquesneDukesHalftime' : NCAAB.DuquesneDukesHalftime,
'DuquesneDukesHalftimeOU' : NCAAB.DuquesneDukesHalftimeOU,
}

DavidsonWildcatsDict = {
'DavidsonWildcatsCover' : NCAAB.DavidsonWildcatsCover,
'DavidsonWildcatsML' : NCAAB.DavidsonWildcatsML,
'DavidsonWildcatsOU' : NCAAB.DavidsonWildcatsOU,
'DavidsonWildcatsSoloOU' : NCAAB.DavidsonWildcatsSoloOU,
'DavidsonWildcatsHalftime' : NCAAB.DavidsonWildcatsHalftime,
'DavidsonWildcatsHalftimeOU' : NCAAB.DavidsonWildcatsHalftimeOU,
}

UMassMinutemenDict = {
'UMassMinutemenCover' : NCAAB.UMassMinutemenCover,
'UMassMinutemenML' : NCAAB.UMassMinutemenML,
'UMassMinutemenOU' : NCAAB.UMassMinutemenOU,
'UMassMinutemenSoloOU' : NCAAB.UMassMinutemenSoloOU,
'UMassMinutemenHalftime' : NCAAB.UMassMinutemenHalftime,
'UMassMinutemenHalftimeOU' : NCAAB.UMassMinutemenHalftimeOU,
}

VCURamsDict = {
'VCURamsCover' : NCAAB.VCURamsCover,
'VCURamsML' : NCAAB.VCURamsML,
'VCURamsOU' : NCAAB.VCURamsOU,
'VCURamsSoloOU' : NCAAB.VCURamsSoloOU,
'VCURamsHalftime' : NCAAB.VCURamsHalftime,
'VCURamsHalftimeOU' : NCAAB.VCURamsHalftimeOU,
}

GeorgeWashingtonColonialsDict = {
'GeorgeWashingtonColonialsCover' : NCAAB.GeorgeWashingtonColonialsCover,
'GeorgeWashingtonColonialsML' : NCAAB.GeorgeWashingtonColonialsML,
'GeorgeWashingtonColonialsOU' : NCAAB.GeorgeWashingtonColonialsOU,
'GeorgeWashingtonColonialsSoloOU' : NCAAB.GeorgeWashingtonColonialsSoloOU,
'GeorgeWashingtonColonialsHalftime' : NCAAB.GeorgeWashingtonColonialsHalftime,
'GeorgeWashingtonColonialsHalftimeOU' : NCAAB.GeorgeWashingtonColonialsHalftimeOU,
}

LaSalleExplorersDict = {
'LaSalleExplorersCover' : NCAAB.LaSalleExplorersCover,
'LaSalleExplorersML' : NCAAB.LaSalleExplorersML,
'LaSalleExplorersOU' : NCAAB.LaSalleExplorersOU,
'LaSalleExplorersSoloOU' : NCAAB.LaSalleExplorersSoloOU,
'LaSalleExplorersHalftime' : NCAAB.LaSalleExplorersHalftime,
'LaSalleExplorersHalftimeOU' : NCAAB.LaSalleExplorersHalftimeOU,
}

GeorgeMasonPatriotsDict = {
'GeorgeMasonPatriotsCover' : NCAAB.GeorgeMasonPatriotsCover,
'GeorgeMasonPatriotsML' : NCAAB.GeorgeMasonPatriotsML,
'GeorgeMasonPatriotsOU' : NCAAB.GeorgeMasonPatriotsOU,
'GeorgeMasonPatriotsSoloOU' : NCAAB.GeorgeMasonPatriotsSoloOU,
'GeorgeMasonPatriotsHalftime' : NCAAB.GeorgeMasonPatriotsHalftime,
'GeorgeMasonPatriotsHalftimeOU' : NCAAB.GeorgeMasonPatriotsHalftimeOU,
}

SaintJosephsHawksDict = {
'SaintJosephsHawksCover' : NCAAB.SaintJosephsHawksCover,
'SaintJosephsHawksML' : NCAAB.SaintJosephsHawksML,
'SaintJosephsHawksOU' : NCAAB.SaintJosephsHawksOU,
'SaintJosephsHawksSoloOU' : NCAAB.SaintJosephsHawksSoloOU,
'SaintJosephsHawksHalftime' : NCAAB.SaintJosephsHawksHalftime,
'SaintJosephsHawksHalftimeOU' : NCAAB.SaintJosephsHawksHalftimeOU,
}

FordhamRamsDict = {
'FordhamRamsCover' : NCAAB.FordhamRamsCover,
'FordhamRamsML' : NCAAB.FordhamRamsML,
'FordhamRamsOU' : NCAAB.FordhamRamsOU,
'FordhamRamsSoloOU' : NCAAB.FordhamRamsSoloOU,
'FordhamRamsHalftime' : NCAAB.FordhamRamsHalftime,
'FordhamRamsHalftimeOU' : NCAAB.FordhamRamsHalftimeOU,
}

#Atlantic Coast Teams

FloridaStateSeminolesDict = {
'FloridaStateSeminolesCover' : NCAAB.FloridaStateSeminolesCover,
'FloridaStateSeminolesML' : NCAAB.FloridaStateSeminolesML,
'FloridaStateSeminolesOU' : NCAAB.FloridaStateSeminolesOU,
'FloridaStateSeminolesSoloOU' : NCAAB.FloridaStateSeminolesSoloOU,
'FloridaStateSeminolesHalftime' : NCAAB.FloridaStateSeminolesHalftime,
'FloridaStateSeminolesHalftimeOU' : NCAAB.FloridaStateSeminolesHalftimeOU,
}

VirginiaCavaliersDict = {
'VirginiaCavaliersCover' : NCAAB.VirginiaCavaliersCover,
'VirginiaCavaliersML' : NCAAB.VirginiaCavaliersML,
'VirginiaCavaliersOU' : NCAAB.VirginiaCavaliersOU,
'VirginiaCavaliersSoloOU' : NCAAB.VirginiaCavaliersSoloOU,
'VirginiaCavaliersHalftime' : NCAAB.VirginiaCavaliersHalftime,
'VirginiaCavaliersHalftimeOU' : NCAAB.VirginiaCavaliersHalftimeOU,
}

LouisvilleCardinalsDict = {
'LouisvilleCardinalsCover' : NCAAB.LouisvilleCardinalsCover,
'LouisvilleCardinalsML' : NCAAB.LouisvilleCardinalsML,
'LouisvilleCardinalsOU' : NCAAB.LouisvilleCardinalsOU,
'LouisvilleCardinalsSoloOU' : NCAAB.LouisvilleCardinalsSoloOU,
'LouisvilleCardinalsHalftime' : NCAAB.LouisvilleCardinalsHalftime,
'LouisvilleCardinalsHalftimeOU' : NCAAB.LouisvilleCardinalsHalftimeOU,
}

DukeBlueDevilsDict = {
'DukeBlueDevilsCover' : NCAAB.DukeBlueDevilsCover,
'DukeBlueDevilsML' : NCAAB.DukeBlueDevilsML,
'DukeBlueDevilsOU' : NCAAB.DukeBlueDevilsOU,
'DukeBlueDevilsSoloOU' : NCAAB.DukeBlueDevilsSoloOU,
'DukeBlueDevilsHalftime' : NCAAB.DukeBlueDevilsHalftime,
'DukeBlueDevilsHalftimeOU' : NCAAB.DukeBlueDevilsHalftimeOU,
}

GeorgiaTechYellowJacketsDict = {
'GeorgiaTechYellowJacketsCover' : NCAAB.GeorgiaTechYellowJacketsCover,
'GeorgiaTechYellowJacketsML' : NCAAB.GeorgiaTechYellowJacketsML,
'GeorgiaTechYellowJacketsOU' : NCAAB.GeorgiaTechYellowJacketsOU,
'GeorgiaTechYellowJacketsSoloOU' : NCAAB.GeorgiaTechYellowJacketsSoloOU,
'GeorgiaTechYellowJacketsHalftime' : NCAAB.GeorgiaTechYellowJacketsHalftime,
'GeorgiaTechYellowJacketsHalftimeOU' : NCAAB.GeorgiaTechYellowJacketsHalftimeOU,
}

NCStateWolfpackDict = {
'NCStateWolfpackCover' : NCAAB.NCStateWolfpackCover,
'NCStateWolfpackML' : NCAAB.NCStateWolfpackML,
'NCStateWolfpackOU' : NCAAB.NCStateWolfpackOU,
'NCStateWolfpackSoloOU' : NCAAB.NCStateWolfpackSoloOU,
'NCStateWolfpackHalftime' : NCAAB.NCStateWolfpackHalftime,
'NCStateWolfpackHalftimeOU' : NCAAB.NCStateWolfpackHalftimeOU,
}

NotreDameFightingIrishDict = {
'NotreDameFightingIrishCover' : NCAAB.NotreDameFightingIrishCover,
'NotreDameFightingIrishML' : NCAAB.NotreDameFightingIrishML,
'NotreDameFightingIrishOU' : NCAAB.NotreDameFightingIrishOU,
'NotreDameFightingIrishSoloOU' : NCAAB.NotreDameFightingIrishSoloOU,
'NotreDameFightingIrishHalftime' : NCAAB.NotreDameFightingIrishHalftime,
'NotreDameFightingIrishHalftimeOU' : NCAAB.NotreDameFightingIrishHalftimeOU,
}

SyracuseOrangeDict = {
'SyracuseOrangeCover' : NCAAB.SyracuseOrangeCover,
'SyracuseOrangeML' : NCAAB.SyracuseOrangeML,
'SyracuseOrangeOU' : NCAAB.SyracuseOrangeOU,
'SyracuseOrangeSoloOU' : NCAAB.SyracuseOrangeSoloOU,
'SyracuseOrangeHalftime' : NCAAB.SyracuseOrangeHalftime,
'SyracuseOrangeHalftimeOU' : NCAAB.SyracuseOrangeHalftimeOU,
}

ClemsonTigersDict = {
'ClemsonTigersCover' : NCAAB.ClemsonTigersCover,
'ClemsonTigersML' : NCAAB.ClemsonTigersML,
'ClemsonTigersOU' : NCAAB.ClemsonTigersOU,
'ClemsonTigersSoloOU' : NCAAB.ClemsonTigersSoloOU,
'ClemsonTigersHalftime' : NCAAB.ClemsonTigersHalftime,
'ClemsonTigersHalftimeOU' : NCAAB.ClemsonTigersHalftimeOU,
}

MiamiHurricanesDict = {
'MiamiHurricanesCover' : NCAAB.MiamiHurricanesCover,
'MiamiHurricanesML' : NCAAB.MiamiHurricanesML,
'MiamiHurricanesOU' : NCAAB.MiamiHurricanesOU,
'MiamiHurricanesSoloOU' : NCAAB.MiamiHurricanesSoloOU,
'MiamiHurricanesHalftime' : NCAAB.MiamiHurricanesHalftime,
'MiamiHurricanesHalftimeOU' : NCAAB.MiamiHurricanesHalftimeOU,
}

BostonCollegeEaglesDict = {
'BostonCollegeEaglesCover' : NCAAB.BostonCollegeEaglesCover,
'BostonCollegeEaglesML' : NCAAB.BostonCollegeEaglesML,
'BostonCollegeEaglesOU' : NCAAB.BostonCollegeEaglesOU,
'BostonCollegeEaglesSoloOU' : NCAAB.BostonCollegeEaglesSoloOU,
'BostonCollegeEaglesHalftime' : NCAAB.BostonCollegeEaglesHalftime,
'BostonCollegeEaglesHalftimeOU' : NCAAB.BostonCollegeEaglesHalftimeOU,
}

VirginiaTechHokiesDict = {
'VirginiaTechHokiesCover' : NCAAB.VirginiaTechHokiesCover,
'VirginiaTechHokiesML' : NCAAB.VirginiaTechHokiesML,
'VirginiaTechHokiesOU' : NCAAB.VirginiaTechHokiesOU,
'VirginiaTechHokiesSoloOU' : NCAAB.VirginiaTechHokiesSoloOU,
'VirginiaTechHokiesHalftime' : NCAAB.VirginiaTechHokiesHalftime,
'VirginiaTechHokiesHalftimeOU' : NCAAB.VirginiaTechHokiesHalftimeOU,
}

PittsburghPanthersDict = {
'PittsburghPanthersCover' : NCAAB.PittsburghPanthersCover,
'PittsburghPanthersML' : NCAAB.PittsburghPanthersML,
'PittsburghPanthersOU' : NCAAB.PittsburghPanthersOU,
'PittsburghPanthersSoloOU' : NCAAB.PittsburghPanthersSoloOU,
'PittsburghPanthersHalftime' : NCAAB.PittsburghPanthersHalftime,
'PittsburghPanthersHalftimeOU' : NCAAB.PittsburghPanthersHalftimeOU,
}

NorthCarolinaTarHeelsDict = {
'NorthCarolinaTarHeelsCover' : NCAAB.NorthCarolinaTarHeelsCover,
'NorthCarolinaTarHeelsML' : NCAAB.NorthCarolinaTarHeelsML,
'NorthCarolinaTarHeelsOU' : NCAAB.NorthCarolinaTarHeelsOU,
'NorthCarolinaTarHeelsSoloOU' : NCAAB.NorthCarolinaTarHeelsSoloOU,
'NorthCarolinaTarHeelsHalftime' : NCAAB.NorthCarolinaTarHeelsHalftime,
'NorthCarolinaTarHeelsHalftimeOU' : NCAAB.NorthCarolinaTarHeelsHalftimeOU,
}

WakeForestDemonDeaconsDict = {
'WakeForestDemonDeaconsCover' : NCAAB.WakeForestDemonDeaconsCover,
'WakeForestDemonDeaconsML' : NCAAB.WakeForestDemonDeaconsML,
'WakeForestDemonDeaconsOU' : NCAAB.WakeForestDemonDeaconsOU,
'WakeForestDemonDeaconsSoloOU' : NCAAB.WakeForestDemonDeaconsSoloOU,
'WakeForestDemonDeaconsHalftime' : NCAAB.WakeForestDemonDeaconsHalftime,
'WakeForestDemonDeaconsHalftimeOU' : NCAAB.WakeForestDemonDeaconsHalftimeOU,
}

#Big12 Teams

KansasJayhawksDict = {
'KansasJayhawksCover' : NCAAB.KansasJayhawksCover,
'KansasJayhawksML' : NCAAB.KansasJayhawksML,
'KansasJayhawksOU' : NCAAB.KansasJayhawksOU,
'KansasJayhawksSoloOU' : NCAAB.KansasJayhawksSoloOU,
'KansasJayhawksHalftime' : NCAAB.KansasJayhawksHalftime,
'KansasJayhawksHalftimeOU' : NCAAB.KansasJayhawksHalftimeOU,
}

BaylorBearsDict = {
'BaylorBearsCover' : NCAAB.BaylorBearsCover,
'BaylorBearsML' : NCAAB.BaylorBearsML,
'BaylorBearsOU' : NCAAB.BaylorBearsOU,
'BaylorBearsSoloOU' : NCAAB.BaylorBearsSoloOU,
'BaylorBearsHalftime' : NCAAB.BaylorBearsHalftime,
'BaylorBearsHalftimeOU' : NCAAB.BaylorBearsHalftimeOU,
}

OklahomaSoonersDict = {
'OklahomaSoonersCover' : NCAAB.OklahomaSoonersCover,
'OklahomaSoonersML' : NCAAB.OklahomaSoonersML,
'OklahomaSoonersOU' : NCAAB.OklahomaSoonersOU,
'OklahomaSoonersSoloOU' : NCAAB.OklahomaSoonersSoloOU,
'OklahomaSoonersHalftime' : NCAAB.OklahomaSoonersHalftime,
'OklahomaSoonersHalftimeOU' : NCAAB.OklahomaSoonersHalftimeOU,
}

TexasLonghornsDict = {
'TexasLonghornsCover' : NCAAB.TexasLonghornsCover,
'TexasLonghornsML' : NCAAB.TexasLonghornsML,
'TexasLonghornsOU' : NCAAB.TexasLonghornsOU,
'TexasLonghornsSoloOU' : NCAAB.TexasLonghornsSoloOU,
'TexasLonghornsHalftime' : NCAAB.TexasLonghornsHalftime,
'TexasLonghornsHalftimeOU' : NCAAB.TexasLonghornsHalftimeOU,
}

TexasTechRedRaidersDict = {
'TexasTechRedRaidersCover' : NCAAB.TexasTechRedRaidersCover,
'TexasTechRedRaidersML' : NCAAB.TexasTechRedRaidersML,
'TexasTechRedRaidersOU' : NCAAB.TexasTechRedRaidersOU,
'TexasTechRedRaidersSoloOU' : NCAAB.TexasTechRedRaidersSoloOU,
'TexasTechRedRaidersHalftime' : NCAAB.TexasTechRedRaidersHalftime,
'TexasTechRedRaidersHalftimeOU' : NCAAB.TexasTechRedRaidersHalftimeOU,
}

WestVirginiaMountaineersDict = {
'WestVirginiaMountaineersCover' : NCAAB.WestVirginiaMountaineersCover,
'WestVirginiaMountaineersML' : NCAAB.WestVirginiaMountaineersML,
'WestVirginiaMountaineersOU' : NCAAB.WestVirginiaMountaineersOU,
'WestVirginiaMountaineersSoloOU' : NCAAB.WestVirginiaMountaineersSoloOU,
'WestVirginiaMountaineersHalftime' : NCAAB.WestVirginiaMountaineersHalftime,
'WestVirginiaMountaineersHalftimeOU' : NCAAB.WestVirginiaMountaineersHalftimeOU,
}

OklahomaStateCowboysDict = {
'OklahomaStateCowboysCover' : NCAAB.OklahomaStateCowboysCover,
'OklahomaStateCowboysML' : NCAAB.OklahomaStateCowboysML,
'OklahomaStateCowboysOU' : NCAAB.OklahomaStateCowboysOU,
'OklahomaStateCowboysSoloOU' : NCAAB.OklahomaStateCowboysSoloOU,
'OklahomaStateCowboysHalftime' : NCAAB.OklahomaStateCowboysHalftime,
'OklahomaStateCowboysHalftimeOU' : NCAAB.OklahomaStateCowboysHalftimeOU,
}

TCUHornedFrogsDict = {
'TCUHornedFrogsCover' : NCAAB.TCUHornedFrogsCover,
'TCUHornedFrogsML' : NCAAB.TCUHornedFrogsML,
'TCUHornedFrogsOU' : NCAAB.TCUHornedFrogsOU,
'TCUHornedFrogsSoloOU' : NCAAB.TCUHornedFrogsSoloOU,
'TCUHornedFrogsHalftime' : NCAAB.TCUHornedFrogsHalftime,
'TCUHornedFrogsHalftimeOU' : NCAAB.TCUHornedFrogsHalftimeOU,
}

IowaStateCyclonesDict = {
'IowaStateCyclonesCover' : NCAAB.IowaStateCyclonesCover,
'IowaStateCyclonesML' : NCAAB.IowaStateCyclonesML,
'IowaStateCyclonesOU' : NCAAB.IowaStateCyclonesOU,
'IowaStateCyclonesSoloOU' : NCAAB.IowaStateCyclonesSoloOU,
'IowaStateCyclonesHalftime' : NCAAB.IowaStateCyclonesHalftime,
'IowaStateCyclonesHalftimeOU' : NCAAB.IowaStateCyclonesHalftimeOU,
}

KansasStateWildcatsDict = {
'KansasStateWildcatsCover' : NCAAB.KansasStateWildcatsCover,
'KansasStateWildcatsML' : NCAAB.KansasStateWildcatsML,
'KansasStateWildcatsOU' : NCAAB.KansasStateWildcatsOU,
'KansasStateWildcatsSoloOU' : NCAAB.KansasStateWildcatsSoloOU,
'KansasStateWildcatsHalftime' : NCAAB.KansasStateWildcatsHalftime,
'KansasStateWildcatsHalftimeOU' : NCAAB.KansasStateWildcatsHalftimeOU,
}

#Big East Teams

CreightonBluejaysDict = {
'CreightonBluejaysCover' : NCAAB.CreightonBluejaysCover,
'CreightonBluejaysML' : NCAAB.CreightonBluejaysML,
'CreightonBluejaysOU' : NCAAB.CreightonBluejaysOU,
'CreightonBluejaysSoloOU' : NCAAB.CreightonBluejaysSoloOU,
'CreightonBluejaysHalftime' : NCAAB.CreightonBluejaysHalftime,
'CreightonBluejaysHalftimeOU' : NCAAB.CreightonBluejaysHalftimeOU,
}

VillanovaWildcatsDict = {
'VillanovaWildcatsCover' : NCAAB.VillanovaWildcatsCover,
'VillanovaWildcatsML' : NCAAB.VillanovaWildcatsML,
'VillanovaWildcatsOU' : NCAAB.VillanovaWildcatsOU,
'VillanovaWildcatsSoloOU' : NCAAB.VillanovaWildcatsSoloOU,
'VillanovaWildcatsHalftime' : NCAAB.VillanovaWildcatsHalftime,
'VillanovaWildcatsHalftimeOU' : NCAAB.VillanovaWildcatsHalftimeOU,
}

SetonHallPiratesDict = {
'SetonHallPiratesCover' : NCAAB.SetonHallPiratesCover,
'SetonHallPiratesML' : NCAAB.SetonHallPiratesML,
'SetonHallPiratesOU' : NCAAB.SetonHallPiratesOU,
'SetonHallPiratesSoloOU' : NCAAB.SetonHallPiratesSoloOU,
'SetonHallPiratesHalftime' : NCAAB.SetonHallPiratesHalftime,
'SetonHallPiratesHalftimeOU' : NCAAB.SetonHallPiratesHalftimeOU,
}

ProvidenceFriarsDict = {
'ProvidenceFriarsCover' : NCAAB.ProvidenceFriarsCover,
'ProvidenceFriarsML' : NCAAB.ProvidenceFriarsML,
'ProvidenceFriarsOU' : NCAAB.ProvidenceFriarsOU,
'ProvidenceFriarsSoloOU' : NCAAB.ProvidenceFriarsSoloOU,
'ProvidenceFriarsHalftime' : NCAAB.ProvidenceFriarsHalftime,
'ProvidenceFriarsHalftimeOU' : NCAAB.ProvidenceFriarsHalftimeOU,
}

ButlerBulldogsDict = {
'ButlerBulldogsCover' : NCAAB.ButlerBulldogsCover,
'ButlerBulldogsML' : NCAAB.ButlerBulldogsML,
'ButlerBulldogsOU' : NCAAB.ButlerBulldogsOU,
'ButlerBulldogsSoloOU' : NCAAB.ButlerBulldogsSoloOU,
'ButlerBulldogsHalftime' : NCAAB.ButlerBulldogsHalftime,
'ButlerBulldogsHalftimeOU' : NCAAB.ButlerBulldogsHalftimeOU,
}

MarquetteGoldenEaglesDict = {
'MarquetteGoldenEaglesCover' : NCAAB.MarquetteGoldenEaglesCover,
'MarquetteGoldenEaglesML' : NCAAB.MarquetteGoldenEaglesML,
'MarquetteGoldenEaglesOU' : NCAAB.MarquetteGoldenEaglesOU,
'MarquetteGoldenEaglesSoloOU' : NCAAB.MarquetteGoldenEaglesSoloOU,
'MarquetteGoldenEaglesHalftime' : NCAAB.MarquetteGoldenEaglesHalftime,
'MarquetteGoldenEaglesHalftimeOU' : NCAAB.MarquetteGoldenEaglesHalftimeOU,
}

XavierMusketeersDict = {
'XavierMusketeersCover' : NCAAB.XavierMusketeersCover,
'XavierMusketeersML' : NCAAB.XavierMusketeersML,
'XavierMusketeersOU' : NCAAB.XavierMusketeersOU,
'XavierMusketeersSoloOU' : NCAAB.XavierMusketeersSoloOU,
'XavierMusketeersHalftime' : NCAAB.XavierMusketeersHalftime,
'XavierMusketeersHalftimeOU' : NCAAB.XavierMusketeersHalftimeOU,
}

StJohnsRedStormDict = {
'StJohnsRedStormCover' : NCAAB.StJohnsRedStormCover,
'StJohnsRedStormML' : NCAAB.StJohnsRedStormML,
'StJohnsRedStormOU' : NCAAB.StJohnsRedStormOU,
'StJohnsRedStormSoloOU' : NCAAB.StJohnsRedStormSoloOU,
'StJohnsRedStormHalftime' : NCAAB.StJohnsRedStormHalftime,
'StJohnsRedStormHalftimeOU' : NCAAB.StJohnsRedStormHalftimeOU,
}

GeorgetownHoyasDict = {
'GeorgetownHoyasCover' : NCAAB.GeorgetownHoyasCover,
'GeorgetownHoyasML' : NCAAB.GeorgetownHoyasML,
'GeorgetownHoyasOU' : NCAAB.GeorgetownHoyasOU,
'GeorgetownHoyasSoloOU' : NCAAB.GeorgetownHoyasSoloOU,
'GeorgetownHoyasHalftime' : NCAAB.GeorgetownHoyasHalftime,
'GeorgetownHoyasHalftimeOU' : NCAAB.GeorgetownHoyasHalftimeOU,
}

DePaulBlueDemonsDict = {
'DePaulBlueDemonsCover' : NCAAB.DePaulBlueDemonsCover,
'DePaulBlueDemonsML' : NCAAB.DePaulBlueDemonsML,
'DePaulBlueDemonsOU' : NCAAB.DePaulBlueDemonsOU,
'DePaulBlueDemonsSoloOU' : NCAAB.DePaulBlueDemonsSoloOU,
'DePaulBlueDemonsHalftime' : NCAAB.DePaulBlueDemonsHalftime,
'DePaulBlueDemonsHalftimeOU' : NCAAB.DePaulBlueDemonsHalftimeOU,
}

#Big Sky Teams

EasternWashingtonEaglesDict = {
'EasternWashingtonEaglesCover' : NCAAB.EasternWashingtonEaglesCover,
'EasternWashingtonEaglesML' : NCAAB.EasternWashingtonEaglesML,
'EasternWashingtonEaglesOU' : NCAAB.EasternWashingtonEaglesOU,
'EasternWashingtonEaglesSoloOU' : NCAAB.EasternWashingtonEaglesSoloOU,
'EasternWashingtonEaglesHalftime' : NCAAB.EasternWashingtonEaglesHalftime,
'EasternWashingtonEaglesHalftimeOU' : NCAAB.EasternWashingtonEaglesHalftimeOU,
}

NorthernColoradoBearsDict = {
'NorthernColoradoBearsCover' : NCAAB.NorthernColoradoBearsCover,
'NorthernColoradoBearsML' : NCAAB.NorthernColoradoBearsML,
'NorthernColoradoBearsOU' : NCAAB.NorthernColoradoBearsOU,
'NorthernColoradoBearsSoloOU' : NCAAB.NorthernColoradoBearsSoloOU,
'NorthernColoradoBearsHalftime' : NCAAB.NorthernColoradoBearsHalftime,
'NorthernColoradoBearsHalftimeOU' : NCAAB.NorthernColoradoBearsHalftimeOU,
}

MontanaGrizzliesDict = {
'MontanaGrizzliesCover' : NCAAB.MontanaGrizzliesCover,
'MontanaGrizzliesML' : NCAAB.MontanaGrizzliesML,
'MontanaGrizzliesOU' : NCAAB.MontanaGrizzliesOU,
'MontanaGrizzliesSoloOU' : NCAAB.MontanaGrizzliesSoloOU,
'MontanaGrizzliesHalftime' : NCAAB.MontanaGrizzliesHalftime,
'MontanaGrizzliesHalftimeOU' : NCAAB.MontanaGrizzliesHalftimeOU,
}

PortlandStateVikingsDict = {
'PortlandStateVikingsCover' : NCAAB.PortlandStateVikingsCover,
'PortlandStateVikingsML' : NCAAB.PortlandStateVikingsML,
'PortlandStateVikingsOU' : NCAAB.PortlandStateVikingsOU,
'PortlandStateVikingsSoloOU' : NCAAB.PortlandStateVikingsSoloOU,
'PortlandStateVikingsHalftime' : NCAAB.PortlandStateVikingsHalftime,
'PortlandStateVikingsHalftimeOU' : NCAAB.PortlandStateVikingsHalftimeOU,
}

MontanaStateBobcatsDict = {
'MontanaStateBobcatsCover' : NCAAB.MontanaStateBobcatsCover,
'MontanaStateBobcatsML' : NCAAB.MontanaStateBobcatsML,
'MontanaStateBobcatsOU' : NCAAB.MontanaStateBobcatsOU,
'MontanaStateBobcatsSoloOU' : NCAAB.MontanaStateBobcatsSoloOU,
'MontanaStateBobcatsHalftime' : NCAAB.MontanaStateBobcatsHalftime,
'MontanaStateBobcatsHalftimeOU' : NCAAB.MontanaStateBobcatsHalftimeOU,
}

NorthernArizonaLumberjacksDict = {
'NorthernArizonaLumberjacksCover' : NCAAB.NorthernArizonaLumberjacksCover,
'NorthernArizonaLumberjacksML' : NCAAB.NorthernArizonaLumberjacksML,
'NorthernArizonaLumberjacksOU' : NCAAB.NorthernArizonaLumberjacksOU,
'NorthernArizonaLumberjacksSoloOU' : NCAAB.NorthernArizonaLumberjacksSoloOU,
'NorthernArizonaLumberjacksHalftime' : NCAAB.NorthernArizonaLumberjacksHalftime,
'NorthernArizonaLumberjacksHalftimeOU' : NCAAB.NorthernArizonaLumberjacksHalftimeOU,
}

SouthernUtahThunderbirdsDict = {
'SouthernUtahThunderbirdsCover' : NCAAB.SouthernUtahThunderbirdsCover,
'SouthernUtahThunderbirdsML' : NCAAB.SouthernUtahThunderbirdsML,
'SouthernUtahThunderbirdsOU' : NCAAB.SouthernUtahThunderbirdsOU,
'SouthernUtahThunderbirdsSoloOU' : NCAAB.SouthernUtahThunderbirdsSoloOU,
'SouthernUtahThunderbirdsHalftime' : NCAAB.SouthernUtahThunderbirdsHalftime,
'SouthernUtahThunderbirdsHalftimeOU' : NCAAB.SouthernUtahThunderbirdsHalftimeOU,
}

SacramentoStateHornetsDict = {
'SacramentoStateHornetsCover' : NCAAB.SacramentoStateHornetsCover,
'SacramentoStateHornetsML' : NCAAB.SacramentoStateHornetsML,
'SacramentoStateHornetsOU' : NCAAB.SacramentoStateHornetsOU,
'SacramentoStateHornetsSoloOU' : NCAAB.SacramentoStateHornetsSoloOU,
'SacramentoStateHornetsHalftime' : NCAAB.SacramentoStateHornetsHalftime,
'SacramentoStateHornetsHalftimeOU' : NCAAB.SacramentoStateHornetsHalftimeOU,
}

WeberStateWildcatsDict = {
'WeberStateWildcatsCover' : NCAAB.WeberStateWildcatsCover,
'WeberStateWildcatsML' : NCAAB.WeberStateWildcatsML,
'WeberStateWildcatsOU' : NCAAB.WeberStateWildcatsOU,
'WeberStateWildcatsSoloOU' : NCAAB.WeberStateWildcatsSoloOU,
'WeberStateWildcatsHalftime' : NCAAB.WeberStateWildcatsHalftime,
'WeberStateWildcatsHalftimeOU' : NCAAB.WeberStateWildcatsHalftimeOU,
}

IdahoStateBengalsDict = {
'IdahoStateBengalsCover' : NCAAB.IdahoStateBengalsCover,
'IdahoStateBengalsML' : NCAAB.IdahoStateBengalsML,
'IdahoStateBengalsOU' : NCAAB.IdahoStateBengalsOU,
'IdahoStateBengalsSoloOU' : NCAAB.IdahoStateBengalsSoloOU,
'IdahoStateBengalsHalftime' : NCAAB.IdahoStateBengalsHalftime,
'IdahoStateBengalsHalftimeOU' : NCAAB.IdahoStateBengalsHalftimeOU,
}

IdahoVandalsDict = {
'IdahoVandalsCover' : NCAAB.IdahoVandalsCover,
'IdahoVandalsML' : NCAAB.IdahoVandalsML,
'IdahoVandalsOU' : NCAAB.IdahoVandalsOU,
'IdahoVandalsSoloOU' : NCAAB.IdahoVandalsSoloOU,
'IdahoVandalsHalftime' : NCAAB.IdahoVandalsHalftime,
'IdahoVandalsHalftimeOU' : NCAAB.IdahoVandalsHalftimeOU,
}

#Big South Teams

WinthropEaglesDict = {
'WinthropEaglesCover' : NCAAB.WinthropEaglesCover,
'WinthropEaglesML' : NCAAB.WinthropEaglesML,
'WinthropEaglesOU' : NCAAB.WinthropEaglesOU,
'WinthropEaglesSoloOU' : NCAAB.WinthropEaglesSoloOU,
'WinthropEaglesHalftime' : NCAAB.WinthropEaglesHalftime,
'WinthropEaglesHalftimeOU' : NCAAB.WinthropEaglesHalftimeOU,
}

RadfordHighlandersDict = {
'RadfordHighlandersCover' : NCAAB.RadfordHighlandersCover,
'RadfordHighlandersML' : NCAAB.RadfordHighlandersML,
'RadfordHighlandersOU' : NCAAB.RadfordHighlandersOU,
'RadfordHighlandersSoloOU' : NCAAB.RadfordHighlandersSoloOU,
'RadfordHighlandersHalftime' : NCAAB.RadfordHighlandersHalftime,
'RadfordHighlandersHalftimeOU' : NCAAB.RadfordHighlandersHalftimeOU,
}

GardnerWebbBulldogsDict = {
'GardnerWebbBulldogsCover' : NCAAB.GardnerWebbBulldogsCover,
'GardnerWebbBulldogsML' : NCAAB.GardnerWebbBulldogsML,
'GardnerWebbBulldogsOU' : NCAAB.GardnerWebbBulldogsOU,
'GardnerWebbBulldogsSoloOU' : NCAAB.GardnerWebbBulldogsSoloOU,
'GardnerWebbBulldogsHalftime' : NCAAB.GardnerWebbBulldogsHalftime,
'GardnerWebbBulldogsHalftimeOU' : NCAAB.GardnerWebbBulldogsHalftimeOU,
}

LongwoodLancersDict = {
'LongwoodLancersCover' : NCAAB.LongwoodLancersCover,
'LongwoodLancersML' : NCAAB.LongwoodLancersML,
'LongwoodLancersOU' : NCAAB.LongwoodLancersOU,
'LongwoodLancersSoloOU' : NCAAB.LongwoodLancersSoloOU,
'LongwoodLancersHalftime' : NCAAB.LongwoodLancersHalftime,
'LongwoodLancersHalftimeOU' : NCAAB.LongwoodLancersHalftimeOU,
}

HamptonPiratesDict = {
'HamptonPiratesCover' : NCAAB.HamptonPiratesCover,
'HamptonPiratesML' : NCAAB.HamptonPiratesML,
'HamptonPiratesOU' : NCAAB.HamptonPiratesOU,
'HamptonPiratesSoloOU' : NCAAB.HamptonPiratesSoloOU,
'HamptonPiratesHalftime' : NCAAB.HamptonPiratesHalftime,
'HamptonPiratesHalftimeOU' : NCAAB.HamptonPiratesHalftimeOU,
}

UNCAshevilleBulldogsDict = {
'UNCAshevilleBulldogsCover' : NCAAB.UNCAshevilleBulldogsCover,
'UNCAshevilleBulldogsML' : NCAAB.UNCAshevilleBulldogsML,
'UNCAshevilleBulldogsOU' : NCAAB.UNCAshevilleBulldogsOU,
'UNCAshevilleBulldogsSoloOU' : NCAAB.UNCAshevilleBulldogsSoloOU,
'UNCAshevilleBulldogsHalftime' : NCAAB.UNCAshevilleBulldogsHalftime,
'UNCAshevilleBulldogsHalftimeOU' : NCAAB.UNCAshevilleBulldogsHalftimeOU,
}

SouthCarolinaUpstateSpartansDict = {
'SouthCarolinaUpstateSpartansCover' : NCAAB.SouthCarolinaUpstateSpartansCover,
'SouthCarolinaUpstateSpartansML' : NCAAB.SouthCarolinaUpstateSpartansML,
'SouthCarolinaUpstateSpartansOU' : NCAAB.SouthCarolinaUpstateSpartansOU,
'SouthCarolinaUpstateSpartansSoloOU' : NCAAB.SouthCarolinaUpstateSpartansSoloOU,
'SouthCarolinaUpstateSpartansHalftime' : NCAAB.SouthCarolinaUpstateSpartansHalftime,
'SouthCarolinaUpstateSpartansHalftimeOU' : NCAAB.SouthCarolinaUpstateSpartansHalftimeOU,
}

CharlestonSouthernBuccaneersDict = {
'CharlestonSouthernBuccaneersCover' : NCAAB.CharlestonSouthernBuccaneersCover,
'CharlestonSouthernBuccaneersML' : NCAAB.CharlestonSouthernBuccaneersML,
'CharlestonSouthernBuccaneersOU' : NCAAB.CharlestonSouthernBuccaneersOU,
'CharlestonSouthernBuccaneersSoloOU' : NCAAB.CharlestonSouthernBuccaneersSoloOU,
'CharlestonSouthernBuccaneersHalftime' : NCAAB.CharlestonSouthernBuccaneersHalftime,
'CharlestonSouthernBuccaneersHalftimeOU' : NCAAB.CharlestonSouthernBuccaneersHalftimeOU,
}

PresbyterianBlueHoseDict = {
'PresbyterianBlueHoseCover' : NCAAB.PresbyterianBlueHoseCover,
'PresbyterianBlueHoseML' : NCAAB.PresbyterianBlueHoseML,
'PresbyterianBlueHoseOU' : NCAAB.PresbyterianBlueHoseOU,
'PresbyterianBlueHoseSoloOU' : NCAAB.PresbyterianBlueHoseSoloOU,
'PresbyterianBlueHoseHalftime' : NCAAB.PresbyterianBlueHoseHalftime,
'PresbyterianBlueHoseHalftimeOU' : NCAAB.PresbyterianBlueHoseHalftimeOU,
}

HighPointPanthersDict = {
'HighPointPanthersCover' : NCAAB.HighPointPanthersCover,
'HighPointPanthersML' : NCAAB.HighPointPanthersML,
'HighPointPanthersOU' : NCAAB.HighPointPanthersOU,
'HighPointPanthersSoloOU' : NCAAB.HighPointPanthersSoloOU,
'HighPointPanthersHalftime' : NCAAB.HighPointPanthersHalftime,
'HighPointPanthersHalftimeOU' : NCAAB.HighPointPanthersHalftimeOU,
}

CampbellFightingCamelsDict = {
'CampbellFightingCamelsCover' : NCAAB.CampbellFightingCamelsCover,
'CampbellFightingCamelsML' : NCAAB.CampbellFightingCamelsML,
'CampbellFightingCamelsOU' : NCAAB.CampbellFightingCamelsOU,
'CampbellFightingCamelsSoloOU' : NCAAB.CampbellFightingCamelsSoloOU,
'CampbellFightingCamelsHalftime' : NCAAB.CampbellFightingCamelsHalftime,
'CampbellFightingCamelsHalftimeOU' : NCAAB.CampbellFightingCamelsHalftimeOU,
}

# Big10 Teams

WisconsinBadgersDict = {
'WisconsinBadgersCover' : NCAAB.WisconsinBadgersCover,
'WisconsinBadgersML' : NCAAB.WisconsinBadgersML,
'WisconsinBadgersOU' : NCAAB.WisconsinBadgersOU,
'WisconsinBadgersSoloOU' : NCAAB.WisconsinBadgersSoloOU,
'WisconsinBadgersHalftime' : NCAAB.WisconsinBadgersHalftime,
'WisconsinBadgersHalftimeOU' : NCAAB.WisconsinBadgersHalftimeOU,
}

MarylandTerrapinsDict = {
'MarylandTerrapinsCover' : NCAAB.MarylandTerrapinsCover,
'MarylandTerrapinsML' : NCAAB.MarylandTerrapinsML,
'MarylandTerrapinsOU' : NCAAB.MarylandTerrapinsOU,
'MarylandTerrapinsSoloOU' : NCAAB.MarylandTerrapinsSoloOU,
'MarylandTerrapinsHalftime' : NCAAB.MarylandTerrapinsHalftime,
'MarylandTerrapinsHalftimeOU' : NCAAB.MarylandTerrapinsHalftimeOU,
}

MichiganStateSpartansDict = {
'MichiganStateSpartansCover' : NCAAB.MichiganStateSpartansCover,
'MichiganStateSpartansML' : NCAAB.MichiganStateSpartansML,
'MichiganStateSpartansOU' : NCAAB.MichiganStateSpartansOU,
'MichiganStateSpartansSoloOU' : NCAAB.MichiganStateSpartansSoloOU,
'MichiganStateSpartansHalftime' : NCAAB.MichiganStateSpartansHalftime,
'MichiganStateSpartansHalftimeOU' : NCAAB.MichiganStateSpartansHalftimeOU,
}

IllinoisFightingIlliniDict = {
'IllinoisFightingIlliniCover' : NCAAB.IllinoisFightingIlliniCover,
'IllinoisFightingIlliniML' : NCAAB.IllinoisFightingIlliniML,
'IllinoisFightingIlliniOU' : NCAAB.IllinoisFightingIlliniOU,
'IllinoisFightingIlliniSoloOU' : NCAAB.IllinoisFightingIlliniSoloOU,
'IllinoisFightingIlliniHalftime' : NCAAB.IllinoisFightingIlliniHalftime,
'IllinoisFightingIlliniHalftimeOU' : NCAAB.IllinoisFightingIlliniHalftimeOU,
}

IowaHawkeyesDict = {
'IowaHawkeyesCover' : NCAAB.IowaHawkeyesCover,
'IowaHawkeyesML' : NCAAB.IowaHawkeyesML,
'IowaHawkeyesOU' : NCAAB.IowaHawkeyesOU,
'IowaHawkeyesSoloOU' : NCAAB.IowaHawkeyesSoloOU,
'IowaHawkeyesHalftime' : NCAAB.IowaHawkeyesHalftime,
'IowaHawkeyesHalftimeOU' : NCAAB.IowaHawkeyesHalftimeOU,
}

OhioStateBuckeyesDict = {
'OhioStateBuckeyesCover' : NCAAB.OhioStateBuckeyesCover,
'OhioStateBuckeyesML' : NCAAB.OhioStateBuckeyesML,
'OhioStateBuckeyesOU' : NCAAB.OhioStateBuckeyesOU,
'OhioStateBuckeyesSoloOU' : NCAAB.OhioStateBuckeyesSoloOU,
'OhioStateBuckeyesHalftime' : NCAAB.OhioStateBuckeyesHalftime,
'OhioStateBuckeyesHalftimeOU' : NCAAB.OhioStateBuckeyesHalftimeOU,
}

PennStateNittanyLionsDict = {
'PennStateNittanyLionsCover' : NCAAB.PennStateNittanyLionsCover,
'PennStateNittanyLionsML' : NCAAB.PennStateNittanyLionsML,
'PennStateNittanyLionsOU' : NCAAB.PennStateNittanyLionsOU,
'PennStateNittanyLionsSoloOU' : NCAAB.PennStateNittanyLionsSoloOU,
'PennStateNittanyLionsHalftime' : NCAAB.PennStateNittanyLionsHalftime,
'PennStateNittanyLionsHalftimeOU' : NCAAB.PennStateNittanyLionsHalftimeOU,
}

RutgersScarletKnightsDict = {
'RutgersScarletKnightsCover' : NCAAB.RutgersScarletKnightsCover,
'RutgersScarletKnightsML' : NCAAB.RutgersScarletKnightsML,
'RutgersScarletKnightsOU' : NCAAB.RutgersScarletKnightsOU,
'RutgersScarletKnightsSoloOU' : NCAAB.RutgersScarletKnightsSoloOU,
'RutgersScarletKnightsHalftime' : NCAAB.RutgersScarletKnightsHalftime,
'RutgersScarletKnightsHalftimeOU' : NCAAB.RutgersScarletKnightsHalftimeOU,
}

MichiganWolverinesDict = {
'MichiganWolverinesCover' : NCAAB.MichiganWolverinesCover,
'MichiganWolverinesML' : NCAAB.MichiganWolverinesML,
'MichiganWolverinesOU' : NCAAB.MichiganWolverinesOU,
'MichiganWolverinesSoloOU' : NCAAB.MichiganWolverinesSoloOU,
'MichiganWolverinesHalftime' : NCAAB.MichiganWolverinesHalftime,
'MichiganWolverinesHalftimeOU' : NCAAB.MichiganWolverinesHalftimeOU,
}

PurdueBoilermakersDict = {
'PurdueBoilermakersCover' : NCAAB.PurdueBoilermakersCover,
'PurdueBoilermakersML' : NCAAB.PurdueBoilermakersML,
'PurdueBoilermakersOU' : NCAAB.PurdueBoilermakersOU,
'PurdueBoilermakersSoloOU' : NCAAB.PurdueBoilermakersSoloOU,
'PurdueBoilermakersHalftime' : NCAAB.PurdueBoilermakersHalftime,
'PurdueBoilermakersHalftimeOU' : NCAAB.PurdueBoilermakersHalftimeOU,
}

IndianaHoosiersDict = {
'IndianaHoosiersCover' : NCAAB.IndianaHoosiersCover,
'IndianaHoosiersML' : NCAAB.IndianaHoosiersML,
'IndianaHoosiersOU' : NCAAB.IndianaHoosiersOU,
'IndianaHoosiersSoloOU' : NCAAB.IndianaHoosiersSoloOU,
'IndianaHoosiersHalftime' : NCAAB.IndianaHoosiersHalftime,
'IndianaHoosiersHalftimeOU' : NCAAB.IndianaHoosiersHalftimeOU,
}

MinnesotaGoldenGophersDict = {
'MinnesotaGoldenGophersCover' : NCAAB.MinnesotaGoldenGophersCover,
'MinnesotaGoldenGophersML' : NCAAB.MinnesotaGoldenGophersML,
'MinnesotaGoldenGophersOU' : NCAAB.MinnesotaGoldenGophersOU,
'MinnesotaGoldenGophersSoloOU' : NCAAB.MinnesotaGoldenGophersSoloOU,
'MinnesotaGoldenGophersHalftime' : NCAAB.MinnesotaGoldenGophersHalftime,
'MinnesotaGoldenGophersHalftimeOU' : NCAAB.MinnesotaGoldenGophersHalftimeOU,
}

NorthwesternWildcatsDict = {
'NorthwesternWildcatsCover' : NCAAB.NorthwesternWildcatsCover,
'NorthwesternWildcatsML' : NCAAB.NorthwesternWildcatsML,
'NorthwesternWildcatsOU' : NCAAB.NorthwesternWildcatsOU,
'NorthwesternWildcatsSoloOU' : NCAAB.NorthwesternWildcatsSoloOU,
'NorthwesternWildcatsHalftime' : NCAAB.NorthwesternWildcatsHalftime,
'NorthwesternWildcatsHalftimeOU' : NCAAB.NorthwesternWildcatsHalftimeOU,
}

NebraskaCornhuskersDict = {
'NebraskaCornhuskersCover' : NCAAB.NebraskaCornhuskersCover,
'NebraskaCornhuskersML' : NCAAB.NebraskaCornhuskersML,
'NebraskaCornhuskersOU' : NCAAB.NebraskaCornhuskersOU,
'NebraskaCornhuskersSoloOU' : NCAAB.NebraskaCornhuskersSoloOU,
'NebraskaCornhuskersHalftime' : NCAAB.NebraskaCornhuskersHalftime,
'NebraskaCornhuskersHalftimeOU' : NCAAB.NebraskaCornhuskersHalftimeOU,
}

#Big West Teams

UCIrvineAnteatersDict = {
'UCIrvineAnteatersCover' : NCAAB.UCIrvineAnteatersCover,
'UCIrvineAnteatersML' : NCAAB.UCIrvineAnteatersML,
'UCIrvineAnteatersOU' : NCAAB.UCIrvineAnteatersOU,
'UCIrvineAnteatersSoloOU' : NCAAB.UCIrvineAnteatersSoloOU,
'UCIrvineAnteatersHalftime' : NCAAB.UCIrvineAnteatersHalftime,
'UCIrvineAnteatersHalftimeOU' : NCAAB.UCIrvineAnteatersHalftimeOU,
}

UCSantaBarbaraGauchosDict = {
'UCSantaBarbaraGauchosCover' : NCAAB.UCSantaBarbaraGauchosCover,
'UCSantaBarbaraGauchosML' : NCAAB.UCSantaBarbaraGauchosML,
'UCSantaBarbaraGauchosOU' : NCAAB.UCSantaBarbaraGauchosOU,
'UCSantaBarbaraGauchosSoloOU' : NCAAB.UCSantaBarbaraGauchosSoloOU,
'UCSantaBarbaraGauchosHalftime' : NCAAB.UCSantaBarbaraGauchosHalftime,
'UCSantaBarbaraGauchosHalftimeOU' : NCAAB.UCSantaBarbaraGauchosHalftimeOU,
}

CSUNorthridgeMatadorsDict = {
'CSUNorthridgeMatadorsCover' : NCAAB.CSUNorthridgeMatadorsCover,
'CSUNorthridgeMatadorsML' : NCAAB.CSUNorthridgeMatadorsML,
'CSUNorthridgeMatadorsOU' : NCAAB.CSUNorthridgeMatadorsOU,
'CSUNorthridgeMatadorsSoloOU' : NCAAB.CSUNorthridgeMatadorsSoloOU,
'CSUNorthridgeMatadorsHalftime' : NCAAB.CSUNorthridgeMatadorsHalftime,
'CSUNorthridgeMatadorsHalftimeOU' : NCAAB.CSUNorthridgeMatadorsHalftimeOU,
}

HawaiiRainbowWarriorsDict = {
'HawaiiRainbowWarriorsCover' : NCAAB.HawaiiRainbowWarriorsCover,
'HawaiiRainbowWarriorsML' : NCAAB.HawaiiRainbowWarriorsML,
'HawaiiRainbowWarriorsOU' : NCAAB.HawaiiRainbowWarriorsOU,
'HawaiiRainbowWarriorsSoloOU' : NCAAB.HawaiiRainbowWarriorsSoloOU,
'HawaiiRainbowWarriorsHalftime' : NCAAB.HawaiiRainbowWarriorsHalftime,
'HawaiiRainbowWarriorsHalftimeOU' : NCAAB.HawaiiRainbowWarriorsHalftimeOU,
}

UCDavisAggiesDict = {
'UCDavisAggiesCover' : NCAAB.UCDavisAggiesCover,
'UCDavisAggiesML' : NCAAB.UCDavisAggiesML,
'UCDavisAggiesOU' : NCAAB.UCDavisAggiesOU,
'UCDavisAggiesSoloOU' : NCAAB.UCDavisAggiesSoloOU,
'UCDavisAggiesHalftime' : NCAAB.UCDavisAggiesHalftime,
'UCDavisAggiesHalftimeOU' : NCAAB.UCDavisAggiesHalftimeOU,
}

UCRiversideHighlandersDict = {
'UCRiversideHighlandersCover' : NCAAB.UCRiversideHighlandersCover,
'UCRiversideHighlandersML' : NCAAB.UCRiversideHighlandersML,
'UCRiversideHighlandersOU' : NCAAB.UCRiversideHighlandersOU,
'UCRiversideHighlandersSoloOU' : NCAAB.UCRiversideHighlandersSoloOU,
'UCRiversideHighlandersHalftime' : NCAAB.UCRiversideHighlandersHalftime,
'UCRiversideHighlandersHalftimeOU' : NCAAB.UCRiversideHighlandersHalftimeOU,
}

CSUFullertonTitansDict = {
'CSUFullertonTitansCover' : NCAAB.CSUFullertonTitansCover,
'CSUFullertonTitansML' : NCAAB.CSUFullertonTitansML,
'CSUFullertonTitansOU' : NCAAB.CSUFullertonTitansOU,
'CSUFullertonTitansSoloOU' : NCAAB.CSUFullertonTitansSoloOU,
'CSUFullertonTitansHalftime' : NCAAB.CSUFullertonTitansHalftime,
'CSUFullertonTitansHalftimeOU' : NCAAB.CSUFullertonTitansHalftimeOU,
}

LongBeachState49ersDict = {
'LongBeachState49ersCover' : NCAAB.LongBeachState49ersCover,
'LongBeachState49ersML' : NCAAB.LongBeachState49ersML,
'LongBeachState49ersOU' : NCAAB.LongBeachState49ersOU,
'LongBeachState49ersSoloOU' : NCAAB.LongBeachState49ersSoloOU,
'LongBeachState49ersHalftime' : NCAAB.LongBeachState49ersHalftime,
'LongBeachState49ersHalftimeOU' : NCAAB.LongBeachState49ersHalftimeOU,
}

CalPolyMustangsDict = {
'CalPolyMustangsCover' : NCAAB.CalPolyMustangsCover,
'CalPolyMustangsML' : NCAAB.CalPolyMustangsML,
'CalPolyMustangsOU' : NCAAB.CalPolyMustangsOU,
'CalPolyMustangsSoloOU' : NCAAB.CalPolyMustangsSoloOU,
'CalPolyMustangsHalftime' : NCAAB.CalPolyMustangsHalftime,
'CalPolyMustangsHalftimeOU' : NCAAB.CalPolyMustangsHalftimeOU,
}

#Colonial Teams

HofstraPrideDict = {
'HofstraPrideCover' : NCAAB.HofstraPrideCover,
'HofstraPrideML' : NCAAB.HofstraPrideML,
'HofstraPrideOU' : NCAAB.HofstraPrideOU,
'HofstraPrideSoloOU' : NCAAB.HofstraPrideSoloOU,
'HofstraPrideHalftime' : NCAAB.HofstraPrideHalftime,
'HofstraPrideHalftimeOU' : NCAAB.HofstraPrideHalftimeOU,
}

WilliamandMaryTribeDict = {
'WilliamandMaryTribeCover' : NCAAB.WilliamandMaryTribeCover,
'WilliamandMaryTribeML' : NCAAB.WilliamandMaryTribeML,
'WilliamandMaryTribeOU' : NCAAB.WilliamandMaryTribeOU,
'WilliamandMaryTribeSoloOU' : NCAAB.WilliamandMaryTribeSoloOU,
'WilliamandMaryTribeHalftime' : NCAAB.WilliamandMaryTribeHalftime,
'WilliamandMaryTribeHalftimeOU' : NCAAB.WilliamandMaryTribeHalftimeOU,
}

TowsonTigersDict = {
'TowsonTigersCover' : NCAAB.TowsonTigersCover,
'TowsonTigersML' : NCAAB.TowsonTigersML,
'TowsonTigersOU' : NCAAB.TowsonTigersOU,
'TowsonTigersSoloOU' : NCAAB.TowsonTigersSoloOU,
'TowsonTigersHalftime' : NCAAB.TowsonTigersHalftime,
'TowsonTigersHalftimeOU' : NCAAB.TowsonTigersHalftimeOU,
}

DelawareBlueHensDict = {
'DelawareBlueHensCover' : NCAAB.DelawareBlueHensCover,
'DelawareBlueHensML' : NCAAB.DelawareBlueHensML,
'DelawareBlueHensOU' : NCAAB.DelawareBlueHensOU,
'DelawareBlueHensSoloOU' : NCAAB.DelawareBlueHensSoloOU,
'DelawareBlueHensHalftime' : NCAAB.DelawareBlueHensHalftime,
'DelawareBlueHensHalftimeOU' : NCAAB.DelawareBlueHensHalftimeOU,
}

CharlestonCougarsDict = {
'CharlestonCougarsCover' : NCAAB.CharlestonCougarsCover,
'CharlestonCougarsML' : NCAAB.CharlestonCougarsML,
'CharlestonCougarsOU' : NCAAB.CharlestonCougarsOU,
'CharlestonCougarsSoloOU' : NCAAB.CharlestonCougarsSoloOU,
'CharlestonCougarsHalftime' : NCAAB.CharlestonCougarsHalftime,
'CharlestonCougarsHalftimeOU' : NCAAB.CharlestonCougarsHalftimeOU,
}

NortheasternHuskiesDict = {
'NortheasternHuskiesCover' : NCAAB.NortheasternHuskiesCover,
'NortheasternHuskiesML' : NCAAB.NortheasternHuskiesML,
'NortheasternHuskiesOU' : NCAAB.NortheasternHuskiesOU,
'NortheasternHuskiesSoloOU' : NCAAB.NortheasternHuskiesSoloOU,
'NortheasternHuskiesHalftime' : NCAAB.NortheasternHuskiesHalftime,
'NortheasternHuskiesHalftimeOU' : NCAAB.NortheasternHuskiesHalftimeOU,
}

ElonPhoenixDict = {
'ElonPhoenixCover' : NCAAB.ElonPhoenixCover,
'ElonPhoenixML' : NCAAB.ElonPhoenixML,
'ElonPhoenixOU' : NCAAB.ElonPhoenixOU,
'ElonPhoenixSoloOU' : NCAAB.ElonPhoenixSoloOU,
'ElonPhoenixHalftime' : NCAAB.ElonPhoenixHalftime,
'ElonPhoenixHalftimeOU' : NCAAB.ElonPhoenixHalftimeOU,
}

DrexelDragonsDict = {
'DrexelDragonsCover' : NCAAB.DrexelDragonsCover,
'DrexelDragonsML' : NCAAB.DrexelDragonsML,
'DrexelDragonsOU' : NCAAB.DrexelDragonsOU,
'DrexelDragonsSoloOU' : NCAAB.DrexelDragonsSoloOU,
'DrexelDragonsHalftime' : NCAAB.DrexelDragonsHalftime,
'DrexelDragonsHalftimeOU' : NCAAB.DrexelDragonsHalftimeOU,
}

UNCWilmingtonSeahawksDict = {
'UNCWilmingtonSeahawksCover' : NCAAB.UNCWilmingtonSeahawksCover,
'UNCWilmingtonSeahawksML' : NCAAB.UNCWilmingtonSeahawksML,
'UNCWilmingtonSeahawksOU' : NCAAB.UNCWilmingtonSeahawksOU,
'UNCWilmingtonSeahawksSoloOU' : NCAAB.UNCWilmingtonSeahawksSoloOU,
'UNCWilmingtonSeahawksHalftime' : NCAAB.UNCWilmingtonSeahawksHalftime,
'UNCWilmingtonSeahawksHalftimeOU' : NCAAB.UNCWilmingtonSeahawksHalftimeOU,
}

JamesMadisonDukesDict = {
'JamesMadisonDukesCover' : NCAAB.JamesMadisonDukesCover,
'JamesMadisonDukesML' : NCAAB.JamesMadisonDukesML,
'JamesMadisonDukesOU' : NCAAB.JamesMadisonDukesOU,
'JamesMadisonDukesSoloOU' : NCAAB.JamesMadisonDukesSoloOU,
'JamesMadisonDukesHalftime' : NCAAB.JamesMadisonDukesHalftime,
'JamesMadisonDukesHalftimeOU' : NCAAB.JamesMadisonDukesHalftimeOU,
}

#Conference USA Teams

NorthTexasMeanGreenDict = {
'NorthTexasMeanGreenCover' : NCAAB.NorthTexasMeanGreenCover,
'NorthTexasMeanGreenML' : NCAAB.NorthTexasMeanGreenML,
'NorthTexasMeanGreenOU' : NCAAB.NorthTexasMeanGreenOU,
'NorthTexasMeanGreenSoloOU' : NCAAB.NorthTexasMeanGreenSoloOU,
'NorthTexasMeanGreenHalftime' : NCAAB.NorthTexasMeanGreenHalftime,
'NorthTexasMeanGreenHalftimeOU' : NCAAB.NorthTexasMeanGreenHalftimeOU,
}

LouisianaTechBulldogsDict = {
'LouisianaTechBulldogsCover' : NCAAB.LouisianaTechBulldogsCover,
'LouisianaTechBulldogsML' : NCAAB.LouisianaTechBulldogsML,
'LouisianaTechBulldogsOU' : NCAAB.LouisianaTechBulldogsOU,
'LouisianaTechBulldogsSoloOU' : NCAAB.LouisianaTechBulldogsSoloOU,
'LouisianaTechBulldogsHalftime' : NCAAB.LouisianaTechBulldogsHalftime,
'LouisianaTechBulldogsHalftimeOU' : NCAAB.LouisianaTechBulldogsHalftimeOU,
}

WesternKentuckyHilltoppersDict = {
'WesternKentuckyHilltoppersCover' : NCAAB.WesternKentuckyHilltoppersCover,
'WesternKentuckyHilltoppersML' : NCAAB.WesternKentuckyHilltoppersML,
'WesternKentuckyHilltoppersOU' : NCAAB.WesternKentuckyHilltoppersOU,
'WesternKentuckyHilltoppersSoloOU' : NCAAB.WesternKentuckyHilltoppersSoloOU,
'WesternKentuckyHilltoppersHalftime' : NCAAB.WesternKentuckyHilltoppersHalftime,
'WesternKentuckyHilltoppersHalftimeOU' : NCAAB.WesternKentuckyHilltoppersHalftimeOU,
}

Charlotte49ersDict = {
'Charlotte49ersCover' : NCAAB.Charlotte49ersCover,
'Charlotte49ersML' : NCAAB.Charlotte49ersML,
'Charlotte49ersOU' : NCAAB.Charlotte49ersOU,
'Charlotte49ersSoloOU' : NCAAB.Charlotte49ersSoloOU,
'Charlotte49ersHalftime' : NCAAB.Charlotte49ersHalftime,
'Charlotte49ersHalftimeOU' : NCAAB.Charlotte49ersHalftimeOU,
}

MarshallThunderingHerdDict = {
'MarshallThunderingHerdCover' : NCAAB.MarshallThunderingHerdCover,
'MarshallThunderingHerdML' : NCAAB.MarshallThunderingHerdML,
'MarshallThunderingHerdOU' : NCAAB.MarshallThunderingHerdOU,
'MarshallThunderingHerdSoloOU' : NCAAB.MarshallThunderingHerdSoloOU,
'MarshallThunderingHerdHalftime' : NCAAB.MarshallThunderingHerdHalftime,
'MarshallThunderingHerdHalftimeOU' : NCAAB.MarshallThunderingHerdHalftimeOU,
}

FloridaInternationalPanthersDict = {
'FloridaInternationalPanthersCover' : NCAAB.FloridaInternationalPanthersCover,
'FloridaInternationalPanthersML' : NCAAB.FloridaInternationalPanthersML,
'FloridaInternationalPanthersOU' : NCAAB.FloridaInternationalPanthersOU,
'FloridaInternationalPanthersSoloOU' : NCAAB.FloridaInternationalPanthersSoloOU,
'FloridaInternationalPanthersHalftime' : NCAAB.FloridaInternationalPanthersHalftime,
'FloridaInternationalPanthersHalftimeOU' : NCAAB.FloridaInternationalPanthersHalftimeOU,
}

UABBlazersDict = {
'UABBlazersCover' : NCAAB.UABBlazersCover,
'UABBlazersML' : NCAAB.UABBlazersML,
'UABBlazersOU' : NCAAB.UABBlazersOU,
'UABBlazersSoloOU' : NCAAB.UABBlazersSoloOU,
'UABBlazersHalftime' : NCAAB.UABBlazersHalftime,
'UABBlazersHalftimeOU' : NCAAB.UABBlazersHalftimeOU,
}

OldDominionMonarchsDict = {
'OldDominionMonarchsCover' : NCAAB.OldDominionMonarchsCover,
'OldDominionMonarchsML' : NCAAB.OldDominionMonarchsML,
'OldDominionMonarchsOU' : NCAAB.OldDominionMonarchsOU,
'OldDominionMonarchsSoloOU' : NCAAB.OldDominionMonarchsSoloOU,
'OldDominionMonarchsHalftime' : NCAAB.OldDominionMonarchsHalftime,
'OldDominionMonarchsHalftimeOU' : NCAAB.OldDominionMonarchsHalftimeOU,
}

FloridaAtlanticOwlsDict = {
'FloridaAtlanticOwlsCover' : NCAAB.FloridaAtlanticOwlsCover,
'FloridaAtlanticOwlsML' : NCAAB.FloridaAtlanticOwlsML,
'FloridaAtlanticOwlsOU' : NCAAB.FloridaAtlanticOwlsOU,
'FloridaAtlanticOwlsSoloOU' : NCAAB.FloridaAtlanticOwlsSoloOU,
'FloridaAtlanticOwlsHalftime' : NCAAB.FloridaAtlanticOwlsHalftime,
'FloridaAtlanticOwlsHalftimeOU' : NCAAB.FloridaAtlanticOwlsHalftimeOU,
}

UTEPMinersDict = {
'UTEPMinersCover' : NCAAB.UTEPMinersCover,
'UTEPMinersML' : NCAAB.UTEPMinersML,
'UTEPMinersOU' : NCAAB.UTEPMinersOU,
'UTEPMinersSoloOU' : NCAAB.UTEPMinersSoloOU,
'UTEPMinersHalftime' : NCAAB.UTEPMinersHalftime,
'UTEPMinersHalftimeOU' : NCAAB.UTEPMinersHalftimeOU,
}

UTSARoadrunnersDict = {
'UTSARoadrunnersCover' : NCAAB.UTSARoadrunnersCover,
'UTSARoadrunnersML' : NCAAB.UTSARoadrunnersML,
'UTSARoadrunnersOU' : NCAAB.UTSARoadrunnersOU,
'UTSARoadrunnersSoloOU' : NCAAB.UTSARoadrunnersSoloOU,
'UTSARoadrunnersHalftime' : NCAAB.UTSARoadrunnersHalftime,
'UTSARoadrunnersHalftimeOU' : NCAAB.UTSARoadrunnersHalftimeOU,
}

RiceOwlsDict = {
'RiceOwlsCover' : NCAAB.RiceOwlsCover,
'RiceOwlsML' : NCAAB.RiceOwlsML,
'RiceOwlsOU' : NCAAB.RiceOwlsOU,
'RiceOwlsSoloOU' : NCAAB.RiceOwlsSoloOU,
'RiceOwlsHalftime' : NCAAB.RiceOwlsHalftime,
'RiceOwlsHalftimeOU' : NCAAB.RiceOwlsHalftimeOU,
}

SouthernMissGoldenEaglesDict = {
'SouthernMissGoldenEaglesCover' : NCAAB.SouthernMissGoldenEaglesCover,
'SouthernMissGoldenEaglesML' : NCAAB.SouthernMissGoldenEaglesML,
'SouthernMissGoldenEaglesOU' : NCAAB.SouthernMissGoldenEaglesOU,
'SouthernMissGoldenEaglesSoloOU' : NCAAB.SouthernMissGoldenEaglesSoloOU,
'SouthernMissGoldenEaglesHalftime' : NCAAB.SouthernMissGoldenEaglesHalftime,
'SouthernMissGoldenEaglesHalftimeOU' : NCAAB.SouthernMissGoldenEaglesHalftimeOU,
}

MiddleTennesseeBlueRaidersDict = {
'MiddleTennesseeBlueRaidersCover' : NCAAB.MiddleTennesseeBlueRaidersCover,
'MiddleTennesseeBlueRaidersML' : NCAAB.MiddleTennesseeBlueRaidersML,
'MiddleTennesseeBlueRaidersOU' : NCAAB.MiddleTennesseeBlueRaidersOU,
'MiddleTennesseeBlueRaidersSoloOU' : NCAAB.MiddleTennesseeBlueRaidersSoloOU,
'MiddleTennesseeBlueRaidersHalftime' : NCAAB.MiddleTennesseeBlueRaidersHalftime,
'MiddleTennesseeBlueRaidersHalftimeOU' : NCAAB.MiddleTennesseeBlueRaidersHalftimeOU,
}

#Horizon Teams

WrightStateRaidersDict = {
'WrightStateRaidersCover' : NCAAB.WrightStateRaidersCover,
'WrightStateRaidersML' : NCAAB.WrightStateRaidersML,
'WrightStateRaidersOU' : NCAAB.WrightStateRaidersOU,
'WrightStateRaidersSoloOU' : NCAAB.WrightStateRaidersSoloOU,
'WrightStateRaidersHalftime' : NCAAB.WrightStateRaidersHalftime,
'WrightStateRaidersHalftimeOU' : NCAAB.WrightStateRaidersHalftimeOU,
}

NorthernKentuckyNorseDict = {
'NorthernKentuckyNorseCover' : NCAAB.NorthernKentuckyNorseCover,
'NorthernKentuckyNorseML' : NCAAB.NorthernKentuckyNorseML,
'NorthernKentuckyNorseOU' : NCAAB.NorthernKentuckyNorseOU,
'NorthernKentuckyNorseSoloOU' : NCAAB.NorthernKentuckyNorseSoloOU,
'NorthernKentuckyNorseHalftime' : NCAAB.NorthernKentuckyNorseHalftime,
'NorthernKentuckyNorseHalftimeOU' : NCAAB.NorthernKentuckyNorseHalftimeOU,
}

GreenBayPhoenixDict = {
'GreenBayPhoenixCover' : NCAAB.GreenBayPhoenixCover,
'GreenBayPhoenixML' : NCAAB.GreenBayPhoenixML,
'GreenBayPhoenixOU' : NCAAB.GreenBayPhoenixOU,
'GreenBayPhoenixSoloOU' : NCAAB.GreenBayPhoenixSoloOU,
'GreenBayPhoenixHalftime' : NCAAB.GreenBayPhoenixHalftime,
'GreenBayPhoenixHalftimeOU' : NCAAB.GreenBayPhoenixHalftimeOU,
}

YoungstownStPenguinsDict = {
'YoungstownStPenguinsCover' : NCAAB.YoungstownStPenguinsCover,
'YoungstownStPenguinsML' : NCAAB.YoungstownStPenguinsML,
'YoungstownStPenguinsOU' : NCAAB.YoungstownStPenguinsOU,
'YoungstownStPenguinsSoloOU' : NCAAB.YoungstownStPenguinsSoloOU,
'YoungstownStPenguinsHalftime' : NCAAB.YoungstownStPenguinsHalftime,
'YoungstownStPenguinsHalftimeOU' : NCAAB.YoungstownStPenguinsHalftimeOU,
}

UICFlamesDict = {
'UICFlamesCover' : NCAAB.UICFlamesCover,
'UICFlamesML' : NCAAB.UICFlamesML,
'UICFlamesOU' : NCAAB.UICFlamesOU,
'UICFlamesSoloOU' : NCAAB.UICFlamesSoloOU,
'UICFlamesHalftime' : NCAAB.UICFlamesHalftime,
'UICFlamesHalftimeOU' : NCAAB.UICFlamesHalftimeOU,
}

OaklandGoldenGrizzliesDict = {
'OaklandGoldenGrizzliesCover' : NCAAB.OaklandGoldenGrizzliesCover,
'OaklandGoldenGrizzliesML' : NCAAB.OaklandGoldenGrizzliesML,
'OaklandGoldenGrizzliesOU' : NCAAB.OaklandGoldenGrizzliesOU,
'OaklandGoldenGrizzliesSoloOU' : NCAAB.OaklandGoldenGrizzliesSoloOU,
'OaklandGoldenGrizzliesHalftime' : NCAAB.OaklandGoldenGrizzliesHalftime,
'OaklandGoldenGrizzliesHalftimeOU' : NCAAB.OaklandGoldenGrizzliesHalftimeOU,
}

ClevelandStateVikingsDict = {
'ClevelandStateVikingsCover' : NCAAB.ClevelandStateVikingsCover,
'ClevelandStateVikingsML' : NCAAB.ClevelandStateVikingsML,
'ClevelandStateVikingsOU' : NCAAB.ClevelandStateVikingsOU,
'ClevelandStateVikingsSoloOU' : NCAAB.ClevelandStateVikingsSoloOU,
'ClevelandStateVikingsHalftime' : NCAAB.ClevelandStateVikingsHalftime,
'ClevelandStateVikingsHalftimeOU' : NCAAB.ClevelandStateVikingsHalftimeOU,
}

MilwaukeePanthersDict = {
'MilwaukeePanthersCover' : NCAAB.MilwaukeePanthersCover,
'MilwaukeePanthersML' : NCAAB.MilwaukeePanthersML,
'MilwaukeePanthersOU' : NCAAB.MilwaukeePanthersOU,
'MilwaukeePanthersSoloOU' : NCAAB.MilwaukeePanthersSoloOU,
'MilwaukeePanthersHalftime' : NCAAB.MilwaukeePanthersHalftime,
'MilwaukeePanthersHalftimeOU' : NCAAB.MilwaukeePanthersHalftimeOU,
}

DetroitMercyTitansDict = {
'DetroitMercyTitansCover' : NCAAB.DetroitMercyTitansCover,
'DetroitMercyTitansML' : NCAAB.DetroitMercyTitansML,
'DetroitMercyTitansOU' : NCAAB.DetroitMercyTitansOU,
'DetroitMercyTitansSoloOU' : NCAAB.DetroitMercyTitansSoloOU,
'DetroitMercyTitansHalftime' : NCAAB.DetroitMercyTitansHalftime,
'DetroitMercyTitansHalftimeOU' : NCAAB.DetroitMercyTitansHalftimeOU,
}

IUPUIJaguarsDict = {
'IUPUIJaguarsCover' : NCAAB.IUPUIJaguarsCover,
'IUPUIJaguarsML' : NCAAB.IUPUIJaguarsML,
'IUPUIJaguarsOU' : NCAAB.IUPUIJaguarsOU,
'IUPUIJaguarsSoloOU' : NCAAB.IUPUIJaguarsSoloOU,
'IUPUIJaguarsHalftime' : NCAAB.IUPUIJaguarsHalftime,
'IUPUIJaguarsHalftimeOU' : NCAAB.IUPUIJaguarsHalftimeOU,
}

#Ivy League Teams

YaleBulldogsDict = {
'YaleBulldogsCover' : NCAAB.YaleBulldogsCover,
'YaleBulldogsML' : NCAAB.YaleBulldogsML,
'YaleBulldogsOU' : NCAAB.YaleBulldogsOU,
'YaleBulldogsSoloOU' : NCAAB.YaleBulldogsSoloOU,
'YaleBulldogsHalftime' : NCAAB.YaleBulldogsHalftime,
'YaleBulldogsHalftimeOU' : NCAAB.YaleBulldogsHalftimeOU,
}

HarvardCrimsonDict = {
'HarvardCrimsonCover' : NCAAB.HarvardCrimsonCover,
'HarvardCrimsonML' : NCAAB.HarvardCrimsonML,
'HarvardCrimsonOU' : NCAAB.HarvardCrimsonOU,
'HarvardCrimsonSoloOU' : NCAAB.HarvardCrimsonSoloOU,
'HarvardCrimsonHalftime' : NCAAB.HarvardCrimsonHalftime,
'HarvardCrimsonHalftimeOU' : NCAAB.HarvardCrimsonHalftimeOU,
}

PrincetonTigersDict = {
'PrincetonTigersCover' : NCAAB.PrincetonTigersCover,
'PrincetonTigersML' : NCAAB.PrincetonTigersML,
'PrincetonTigersOU' : NCAAB.PrincetonTigersOU,
'PrincetonTigersSoloOU' : NCAAB.PrincetonTigersSoloOU,
'PrincetonTigersHalftime' : NCAAB.PrincetonTigersHalftime,
'PrincetonTigersHalftimeOU' : NCAAB.PrincetonTigersHalftimeOU,
}

PennsylvaniaQuakersDict = {
'PennsylvaniaQuakersCover' : NCAAB.PennsylvaniaQuakersCover,
'PennsylvaniaQuakersML' : NCAAB.PennsylvaniaQuakersML,
'PennsylvaniaQuakersOU' : NCAAB.PennsylvaniaQuakersOU,
'PennsylvaniaQuakersSoloOU' : NCAAB.PennsylvaniaQuakersSoloOU,
'PennsylvaniaQuakersHalftime' : NCAAB.PennsylvaniaQuakersHalftime,
'PennsylvaniaQuakersHalftimeOU' : NCAAB.PennsylvaniaQuakersHalftimeOU,
}

BrownBearsDict = {
'BrownBearsCover' : NCAAB.BrownBearsCover,
'BrownBearsML' : NCAAB.BrownBearsML,
'BrownBearsOU' : NCAAB.BrownBearsOU,
'BrownBearsSoloOU' : NCAAB.BrownBearsSoloOU,
'BrownBearsHalftime' : NCAAB.BrownBearsHalftime,
'BrownBearsHalftimeOU' : NCAAB.BrownBearsHalftimeOU,
}

DartmouthBigGreenDict = {
'DartmouthBigGreenCover' : NCAAB.DartmouthBigGreenCover,
'DartmouthBigGreenML' : NCAAB.DartmouthBigGreenML,
'DartmouthBigGreenOU' : NCAAB.DartmouthBigGreenOU,
'DartmouthBigGreenSoloOU' : NCAAB.DartmouthBigGreenSoloOU,
'DartmouthBigGreenHalftime' : NCAAB.DartmouthBigGreenHalftime,
'DartmouthBigGreenHalftimeOU' : NCAAB.DartmouthBigGreenHalftimeOU,
}

CornellBigRedDict = {
'CornellBigRedCover' : NCAAB.CornellBigRedCover,
'CornellBigRedML' : NCAAB.CornellBigRedML,
'CornellBigRedOU' : NCAAB.CornellBigRedOU,
'CornellBigRedSoloOU' : NCAAB.CornellBigRedSoloOU,
'CornellBigRedHalftime' : NCAAB.CornellBigRedHalftime,
'CornellBigRedHalftimeOU' : NCAAB.CornellBigRedHalftimeOU,
}

ColumbiaLionsDict = {
'ColumbiaLionsCover' : NCAAB.ColumbiaLionsCover,
'ColumbiaLionsML' : NCAAB.ColumbiaLionsML,
'ColumbiaLionsOU' : NCAAB.ColumbiaLionsOU,
'ColumbiaLionsSoloOU' : NCAAB.ColumbiaLionsSoloOU,
'ColumbiaLionsHalftime' : NCAAB.ColumbiaLionsHalftime,
'ColumbiaLionsHalftimeOU' : NCAAB.ColumbiaLionsHalftimeOU,
}

#MAAC Teams

SienaSaintsDict = {
'SienaSaintsCover' : NCAAB.SienaSaintsCover,
'SienaSaintsML' : NCAAB.SienaSaintsML,
'SienaSaintsOU' : NCAAB.SienaSaintsOU,
'SienaSaintsSoloOU' : NCAAB.SienaSaintsSoloOU,
'SienaSaintsHalftime' : NCAAB.SienaSaintsHalftime,
'SienaSaintsHalftimeOU' : NCAAB.SienaSaintsHalftimeOU,
}

SaintPetersPeacocksDict = {
'SaintPetersPeacocksCover' : NCAAB.SaintPetersPeacocksCover,
'SaintPetersPeacocksML' : NCAAB.SaintPetersPeacocksML,
'SaintPetersPeacocksOU' : NCAAB.SaintPetersPeacocksOU,
'SaintPetersPeacocksSoloOU' : NCAAB.SaintPetersPeacocksSoloOU,
'SaintPetersPeacocksHalftime' : NCAAB.SaintPetersPeacocksHalftime,
'SaintPetersPeacocksHalftimeOU' : NCAAB.SaintPetersPeacocksHalftimeOU,
}

MonmouthHawksDict = {
'MonmouthHawksCover' : NCAAB.MonmouthHawksCover,
'MonmouthHawksML' : NCAAB.MonmouthHawksML,
'MonmouthHawksOU' : NCAAB.MonmouthHawksOU,
'MonmouthHawksSoloOU' : NCAAB.MonmouthHawksSoloOU,
'MonmouthHawksHalftime' : NCAAB.MonmouthHawksHalftime,
'MonmouthHawksHalftimeOU' : NCAAB.MonmouthHawksHalftimeOU,
}

RiderBroncsDict = {
'RiderBroncsCover' : NCAAB.RiderBroncsCover,
'RiderBroncsML' : NCAAB.RiderBroncsML,
'RiderBroncsOU' : NCAAB.RiderBroncsOU,
'RiderBroncsSoloOU' : NCAAB.RiderBroncsSoloOU,
'RiderBroncsHalftime' : NCAAB.RiderBroncsHalftime,
'RiderBroncsHalftimeOU' : NCAAB.RiderBroncsHalftimeOU,
}

QuinnipiacBobcatsDict = {
'QuinnipiacBobcatsCover' : NCAAB.QuinnipiacBobcatsCover,
'QuinnipiacBobcatsML' : NCAAB.QuinnipiacBobcatsML,
'QuinnipiacBobcatsOU' : NCAAB.QuinnipiacBobcatsOU,
'QuinnipiacBobcatsSoloOU' : NCAAB.QuinnipiacBobcatsSoloOU,
'QuinnipiacBobcatsHalftime' : NCAAB.QuinnipiacBobcatsHalftime,
'QuinnipiacBobcatsHalftimeOU' : NCAAB.QuinnipiacBobcatsHalftimeOU,
}

NiagaraPurpleEaglesDict = {
'NiagaraPurpleEaglesCover' : NCAAB.NiagaraPurpleEaglesCover,
'NiagaraPurpleEaglesML' : NCAAB.NiagaraPurpleEaglesML,
'NiagaraPurpleEaglesOU' : NCAAB.NiagaraPurpleEaglesOU,
'NiagaraPurpleEaglesSoloOU' : NCAAB.NiagaraPurpleEaglesSoloOU,
'NiagaraPurpleEaglesHalftime' : NCAAB.NiagaraPurpleEaglesHalftime,
'NiagaraPurpleEaglesHalftimeOU' : NCAAB.NiagaraPurpleEaglesHalftimeOU,
}

IonaGaelsDict = {
'IonaGaelsCover' : NCAAB.IonaGaelsCover,
'IonaGaelsML' : NCAAB.IonaGaelsML,
'IonaGaelsOU' : NCAAB.IonaGaelsOU,
'IonaGaelsSoloOU' : NCAAB.IonaGaelsSoloOU,
'IonaGaelsHalftime' : NCAAB.IonaGaelsHalftime,
'IonaGaelsHalftimeOU' : NCAAB.IonaGaelsHalftimeOU,
}

ManhattanJaspersDict = {
'ManhattanJaspersCover' : NCAAB.ManhattanJaspersCover,
'ManhattanJaspersML' : NCAAB.ManhattanJaspersML,
'ManhattanJaspersOU' : NCAAB.ManhattanJaspersOU,
'ManhattanJaspersSoloOU' : NCAAB.ManhattanJaspersSoloOU,
'ManhattanJaspersHalftime' : NCAAB.ManhattanJaspersHalftime,
'ManhattanJaspersHalftimeOU' : NCAAB.ManhattanJaspersHalftimeOU,
}

FairfieldStagsDict = {
'FairfieldStagsCover' : NCAAB.FairfieldStagsCover,
'FairfieldStagsML' : NCAAB.FairfieldStagsML,
'FairfieldStagsOU' : NCAAB.FairfieldStagsOU,
'FairfieldStagsSoloOU' : NCAAB.FairfieldStagsSoloOU,
'FairfieldStagsHalftime' : NCAAB.FairfieldStagsHalftime,
'FairfieldStagsHalftimeOU' : NCAAB.FairfieldStagsHalftimeOU,
}

CanisiusGoldenGriffinsDict = {
'CanisiusGoldenGriffinsCover' : NCAAB.CanisiusGoldenGriffinsCover,
'CanisiusGoldenGriffinsML' : NCAAB.CanisiusGoldenGriffinsML,
'CanisiusGoldenGriffinsOU' : NCAAB.CanisiusGoldenGriffinsOU,
'CanisiusGoldenGriffinsSoloOU' : NCAAB.CanisiusGoldenGriffinsSoloOU,
'CanisiusGoldenGriffinsHalftime' : NCAAB.CanisiusGoldenGriffinsHalftime,
'CanisiusGoldenGriffinsHalftimeOU' : NCAAB.CanisiusGoldenGriffinsHalftimeOU,
}

MaristRedFoxesDict = {
'MaristRedFoxesCover' : NCAAB.MaristRedFoxesCover,
'MaristRedFoxesML' : NCAAB.MaristRedFoxesML,
'MaristRedFoxesOU' : NCAAB.MaristRedFoxesOU,
'MaristRedFoxesSoloOU' : NCAAB.MaristRedFoxesSoloOU,
'MaristRedFoxesHalftime' : NCAAB.MaristRedFoxesHalftime,
'MaristRedFoxesHalftimeOU' : NCAAB.MaristRedFoxesHalftimeOU,
}

#MidAmericanEast Teams

AkronZipsDict = {
'AkronZipsCover' : NCAAB.AkronZipsCover,
'AkronZipsML' : NCAAB.AkronZipsML,
'AkronZipsOU' : NCAAB.AkronZipsOU,
'AkronZipsSoloOU' : NCAAB.AkronZipsSoloOU,
'AkronZipsHalftime' : NCAAB.AkronZipsHalftime,
'AkronZipsHalftimeOU' : NCAAB.AkronZipsHalftimeOU,
}

BowlingGreenFalconsDict = {
'BowlingGreenFalconsCover' : NCAAB.BowlingGreenFalconsCover,
'BowlingGreenFalconsML' : NCAAB.BowlingGreenFalconsML,
'BowlingGreenFalconsOU' : NCAAB.BowlingGreenFalconsOU,
'BowlingGreenFalconsSoloOU' : NCAAB.BowlingGreenFalconsSoloOU,
'BowlingGreenFalconsHalftime' : NCAAB.BowlingGreenFalconsHalftime,
'BowlingGreenFalconsHalftimeOU' : NCAAB.BowlingGreenFalconsHalftimeOU,
}

BuffaloBullsDict = {
'BuffaloBullsCover' : NCAAB.BuffaloBullsCover,
'BuffaloBullsML' : NCAAB.BuffaloBullsML,
'BuffaloBullsOU' : NCAAB.BuffaloBullsOU,
'BuffaloBullsSoloOU' : NCAAB.BuffaloBullsSoloOU,
'BuffaloBullsHalftime' : NCAAB.BuffaloBullsHalftime,
'BuffaloBullsHalftimeOU' : NCAAB.BuffaloBullsHalftimeOU,
}

KentStateGoldenFlashesDict = {
'KentStateGoldenFlashesCover' : NCAAB.KentStateGoldenFlashesCover,
'KentStateGoldenFlashesML' : NCAAB.KentStateGoldenFlashesML,
'KentStateGoldenFlashesOU' : NCAAB.KentStateGoldenFlashesOU,
'KentStateGoldenFlashesSoloOU' : NCAAB.KentStateGoldenFlashesSoloOU,
'KentStateGoldenFlashesHalftime' : NCAAB.KentStateGoldenFlashesHalftime,
'KentStateGoldenFlashesHalftimeOU' : NCAAB.KentStateGoldenFlashesHalftimeOU,
}

OhioBobcatsDict = {
'OhioBobcatsCover' : NCAAB.OhioBobcatsCover,
'OhioBobcatsML' : NCAAB.OhioBobcatsML,
'OhioBobcatsOU' : NCAAB.OhioBobcatsOU,
'OhioBobcatsSoloOU' : NCAAB.OhioBobcatsSoloOU,
'OhioBobcatsHalftime' : NCAAB.OhioBobcatsHalftime,
'OhioBobcatsHalftimeOU' : NCAAB.OhioBobcatsHalftimeOU,
}

MiamiOHRedHawksDict = {
'MiamiOHRedHawksCover' : NCAAB.MiamiOHRedHawksCover,
'MiamiOHRedHawksML' : NCAAB.MiamiOHRedHawksML,
'MiamiOHRedHawksOU' : NCAAB.MiamiOHRedHawksOU,
'MiamiOHRedHawksSoloOU' : NCAAB.MiamiOHRedHawksSoloOU,
'MiamiOHRedHawksHalftime' : NCAAB.MiamiOHRedHawksHalftime,
'MiamiOHRedHawksHalftimeOU' : NCAAB.MiamiOHRedHawksHalftimeOU,
}

#MidAmericanWest Teams

BallStateCardinalsDict = {
'BallStateCardinalsCover' : NCAAB.BallStateCardinalsCover,
'BallStateCardinalsML' : NCAAB.BallStateCardinalsML,
'BallStateCardinalsOU' : NCAAB.BallStateCardinalsOU,
'BallStateCardinalsSoloOU' : NCAAB.BallStateCardinalsSoloOU,
'BallStateCardinalsHalftime' : NCAAB.BallStateCardinalsHalftime,
'BallStateCardinalsHalftimeOU' : NCAAB.BallStateCardinalsHalftimeOU,
}

NorthernIllinoisHuskiesDict = {
'NorthernIllinoisHuskiesCover' : NCAAB.NorthernIllinoisHuskiesCover,
'NorthernIllinoisHuskiesML' : NCAAB.NorthernIllinoisHuskiesML,
'NorthernIllinoisHuskiesOU' : NCAAB.NorthernIllinoisHuskiesOU,
'NorthernIllinoisHuskiesSoloOU' : NCAAB.NorthernIllinoisHuskiesSoloOU,
'NorthernIllinoisHuskiesHalftime' : NCAAB.NorthernIllinoisHuskiesHalftime,
'NorthernIllinoisHuskiesHalftimeOU' : NCAAB.NorthernIllinoisHuskiesHalftimeOU,
}

ToledoRocketsDict = {
'ToledoRocketsCover' : NCAAB.ToledoRocketsCover,
'ToledoRocketsML' : NCAAB.ToledoRocketsML,
'ToledoRocketsOU' : NCAAB.ToledoRocketsOU,
'ToledoRocketsSoloOU' : NCAAB.ToledoRocketsSoloOU,
'ToledoRocketsHalftime' : NCAAB.ToledoRocketsHalftime,
'ToledoRocketsHalftimeOU' : NCAAB.ToledoRocketsHalftimeOU,
}

CentralMichiganChippewasDict = {
'CentralMichiganChippewasCover' : NCAAB.CentralMichiganChippewasCover,
'CentralMichiganChippewasML' : NCAAB.CentralMichiganChippewasML,
'CentralMichiganChippewasOU' : NCAAB.CentralMichiganChippewasOU,
'CentralMichiganChippewasSoloOU' : NCAAB.CentralMichiganChippewasSoloOU,
'CentralMichiganChippewasHalftime' : NCAAB.CentralMichiganChippewasHalftime,
'CentralMichiganChippewasHalftimeOU' : NCAAB.CentralMichiganChippewasHalftimeOU,
}

EasternMichiganEaglesDict = {
'EasternMichiganEaglesCover' : NCAAB.EasternMichiganEaglesCover,
'EasternMichiganEaglesML' : NCAAB.EasternMichiganEaglesML,
'EasternMichiganEaglesOU' : NCAAB.EasternMichiganEaglesOU,
'EasternMichiganEaglesSoloOU' : NCAAB.EasternMichiganEaglesSoloOU,
'EasternMichiganEaglesHalftime' : NCAAB.EasternMichiganEaglesHalftime,
'EasternMichiganEaglesHalftimeOU' : NCAAB.EasternMichiganEaglesHalftimeOU,
}

WesternMichiganBroncosDict = {
'WesternMichiganBroncosCover' : NCAAB.WesternMichiganBroncosCover,
'WesternMichiganBroncosML' : NCAAB.WesternMichiganBroncosML,
'WesternMichiganBroncosOU' : NCAAB.WesternMichiganBroncosOU,
'WesternMichiganBroncosSoloOU' : NCAAB.WesternMichiganBroncosSoloOU,
'WesternMichiganBroncosHalftime' : NCAAB.WesternMichiganBroncosHalftime,
'WesternMichiganBroncosHalftimeOU' : NCAAB.WesternMichiganBroncosHalftimeOU,
}

#MidEasternAthletic Teams

NorthCarolinaCentralEaglesDict = {
'NorthCarolinaCentralEaglesCover' : NCAAB.NorthCarolinaCentralEaglesCover,
'NorthCarolinaCentralEaglesML' : NCAAB.NorthCarolinaCentralEaglesML,
'NorthCarolinaCentralEaglesOU' : NCAAB.NorthCarolinaCentralEaglesOU,
'NorthCarolinaCentralEaglesSoloOU' : NCAAB.NorthCarolinaCentralEaglesSoloOU,
'NorthCarolinaCentralEaglesHalftime' : NCAAB.NorthCarolinaCentralEaglesHalftime,
'NorthCarolinaCentralEaglesHalftimeOU' : NCAAB.NorthCarolinaCentralEaglesHalftimeOU,
}

NorthCarolinaAandTAggiesDict = {
'NorthCarolinaAandTAggiesCover' : NCAAB.NorthCarolinaAandTAggiesCover,
'NorthCarolinaAandTAggiesML' : NCAAB.NorthCarolinaAandTAggiesML,
'NorthCarolinaAandTAggiesOU' : NCAAB.NorthCarolinaAandTAggiesOU,
'NorthCarolinaAandTAggiesSoloOU' : NCAAB.NorthCarolinaAandTAggiesSoloOU,
'NorthCarolinaAandTAggiesHalftime' : NCAAB.NorthCarolinaAandTAggiesHalftime,
'NorthCarolinaAandTAggiesHalftimeOU' : NCAAB.NorthCarolinaAandTAggiesHalftimeOU,
}

NorfolkStateSpartansDict = {
'NorfolkStateSpartansCover' : NCAAB.NorfolkStateSpartansCover,
'NorfolkStateSpartansML' : NCAAB.NorfolkStateSpartansML,
'NorfolkStateSpartansOU' : NCAAB.NorfolkStateSpartansOU,
'NorfolkStateSpartansSoloOU' : NCAAB.NorfolkStateSpartansSoloOU,
'NorfolkStateSpartansHalftime' : NCAAB.NorfolkStateSpartansHalftime,
'NorfolkStateSpartansHalftimeOU' : NCAAB.NorfolkStateSpartansHalftimeOU,
}

BethuneCookmanWildcatsDict = {
'BethuneCookmanWildcatsCover' : NCAAB.BethuneCookmanWildcatsCover,
'BethuneCookmanWildcatsML' : NCAAB.BethuneCookmanWildcatsML,
'BethuneCookmanWildcatsOU' : NCAAB.BethuneCookmanWildcatsOU,
'BethuneCookmanWildcatsSoloOU' : NCAAB.BethuneCookmanWildcatsSoloOU,
'BethuneCookmanWildcatsHalftime' : NCAAB.BethuneCookmanWildcatsHalftime,
'BethuneCookmanWildcatsHalftimeOU' : NCAAB.BethuneCookmanWildcatsHalftimeOU,
}

FloridaAandMRattlersDict = {
'FloridaAandMRattlersCover' : NCAAB.FloridaAandMRattlersCover,
'FloridaAandMRattlersML' : NCAAB.FloridaAandMRattlersML,
'FloridaAandMRattlersOU' : NCAAB.FloridaAandMRattlersOU,
'FloridaAandMRattlersSoloOU' : NCAAB.FloridaAandMRattlersSoloOU,
'FloridaAandMRattlersHalftime' : NCAAB.FloridaAandMRattlersHalftime,
'FloridaAandMRattlersHalftimeOU' : NCAAB.FloridaAandMRattlersHalftimeOU,
}

MorganStateBearsDict = {
'MorganStateBearsCover' : NCAAB.MorganStateBearsCover,
'MorganStateBearsML' : NCAAB.MorganStateBearsML,
'MorganStateBearsOU' : NCAAB.MorganStateBearsOU,
'MorganStateBearsSoloOU' : NCAAB.MorganStateBearsSoloOU,
'MorganStateBearsHalftime' : NCAAB.MorganStateBearsHalftime,
'MorganStateBearsHalftimeOU' : NCAAB.MorganStateBearsHalftimeOU,
}

CoppinStateEaglesDict = {
'CoppinStateEaglesCover' : NCAAB.CoppinStateEaglesCover,
'CoppinStateEaglesML' : NCAAB.CoppinStateEaglesML,
'CoppinStateEaglesOU' : NCAAB.CoppinStateEaglesOU,
'CoppinStateEaglesSoloOU' : NCAAB.CoppinStateEaglesSoloOU,
'CoppinStateEaglesHalftime' : NCAAB.CoppinStateEaglesHalftime,
'CoppinStateEaglesHalftimeOU' : NCAAB.CoppinStateEaglesHalftimeOU,
}

SouthCarolinaStateBulldogsDict = {
'SouthCarolinaStateBulldogsCover' : NCAAB.SouthCarolinaStateBulldogsCover,
'SouthCarolinaStateBulldogsML' : NCAAB.SouthCarolinaStateBulldogsML,
'SouthCarolinaStateBulldogsOU' : NCAAB.SouthCarolinaStateBulldogsOU,
'SouthCarolinaStateBulldogsSoloOU' : NCAAB.SouthCarolinaStateBulldogsSoloOU,
'SouthCarolinaStateBulldogsHalftime' : NCAAB.SouthCarolinaStateBulldogsHalftime,
'SouthCarolinaStateBulldogsHalftimeOU' : NCAAB.SouthCarolinaStateBulldogsHalftimeOU,
}

DelawareStateHornetsDict = {
'DelawareStateHornetsCover' : NCAAB.DelawareStateHornetsCover,
'DelawareStateHornetsML' : NCAAB.DelawareStateHornetsML,
'DelawareStateHornetsOU' : NCAAB.DelawareStateHornetsOU,
'DelawareStateHornetsSoloOU' : NCAAB.DelawareStateHornetsSoloOU,
'DelawareStateHornetsHalftime' : NCAAB.DelawareStateHornetsHalftime,
'DelawareStateHornetsHalftimeOU' : NCAAB.DelawareStateHornetsHalftimeOU,
}

MarylandEasternShoreHawksDict = {
'MarylandEasternShoreHawksCover' : NCAAB.MarylandEasternShoreHawksCover,
'MarylandEasternShoreHawksML' : NCAAB.MarylandEasternShoreHawksML,
'MarylandEasternShoreHawksOU' : NCAAB.MarylandEasternShoreHawksOU,
'MarylandEasternShoreHawksSoloOU' : NCAAB.MarylandEasternShoreHawksSoloOU,
'MarylandEasternShoreHawksHalftime' : NCAAB.MarylandEasternShoreHawksHalftime,
'MarylandEasternShoreHawksHalftimeOU' : NCAAB.MarylandEasternShoreHawksHalftimeOU,
}

HowardBisonDict = {
'HowardBisonCover' : NCAAB.HowardBisonCover,
'HowardBisonML' : NCAAB.HowardBisonML,
'HowardBisonOU' : NCAAB.HowardBisonOU,
'HowardBisonSoloOU' : NCAAB.HowardBisonSoloOU,
'HowardBisonHalftime' : NCAAB.HowardBisonHalftime,
'HowardBisonHalftimeOU' : NCAAB.HowardBisonHalftimeOU,
}

#Missouri Valley Teams

NorthernIowaPanthersDict = {
'NorthernIowaPanthersCover' : NCAAB.NorthernIowaPanthersCover,
'NorthernIowaPanthersML' : NCAAB.NorthernIowaPanthersML,
'NorthernIowaPanthersOU' : NCAAB.NorthernIowaPanthersOU,
'NorthernIowaPanthersSoloOU' : NCAAB.NorthernIowaPanthersSoloOU,
'NorthernIowaPanthersHalftime' : NCAAB.NorthernIowaPanthersHalftime,
'NorthernIowaPanthersHalftimeOU' : NCAAB.NorthernIowaPanthersHalftimeOU,
}

LoyolaChicagoRamblersDict = {
'LoyolaChicagoRamblersCover' : NCAAB.LoyolaChicagoRamblersCover,
'LoyolaChicagoRamblersML' : NCAAB.LoyolaChicagoRamblersML,
'LoyolaChicagoRamblersOU' : NCAAB.LoyolaChicagoRamblersOU,
'LoyolaChicagoRamblersSoloOU' : NCAAB.LoyolaChicagoRamblersSoloOU,
'LoyolaChicagoRamblersHalftime' : NCAAB.LoyolaChicagoRamblersHalftime,
'LoyolaChicagoRamblersHalftimeOU' : NCAAB.LoyolaChicagoRamblersHalftimeOU,
}

BradleyBravesDict = {
'BradleyBravesCover' : NCAAB.BradleyBravesCover,
'BradleyBravesML' : NCAAB.BradleyBravesML,
'BradleyBravesOU' : NCAAB.BradleyBravesOU,
'BradleyBravesSoloOU' : NCAAB.BradleyBravesSoloOU,
'BradleyBravesHalftime' : NCAAB.BradleyBravesHalftime,
'BradleyBravesHalftimeOU' : NCAAB.BradleyBravesHalftimeOU,
}

IndianaStateSycamoresDict = {
'IndianaStateSycamoresCover' : NCAAB.IndianaStateSycamoresCover,
'IndianaStateSycamoresML' : NCAAB.IndianaStateSycamoresML,
'IndianaStateSycamoresOU' : NCAAB.IndianaStateSycamoresOU,
'IndianaStateSycamoresSoloOU' : NCAAB.IndianaStateSycamoresSoloOU,
'IndianaStateSycamoresHalftime' : NCAAB.IndianaStateSycamoresHalftime,
'IndianaStateSycamoresHalftimeOU' : NCAAB.IndianaStateSycamoresHalftimeOU,
}

SouthernIllinoisSalukisDict = {
'SouthernIllinoisSalukisCover' : NCAAB.SouthernIllinoisSalukisCover,
'SouthernIllinoisSalukisML' : NCAAB.SouthernIllinoisSalukisML,
'SouthernIllinoisSalukisOU' : NCAAB.SouthernIllinoisSalukisOU,
'SouthernIllinoisSalukisSoloOU' : NCAAB.SouthernIllinoisSalukisSoloOU,
'SouthernIllinoisSalukisHalftime' : NCAAB.SouthernIllinoisSalukisHalftime,
'SouthernIllinoisSalukisHalftimeOU' : NCAAB.SouthernIllinoisSalukisHalftimeOU,
}

ValparaisoCrusadersDict = {
'ValparaisoCrusadersCover' : NCAAB.ValparaisoCrusadersCover,
'ValparaisoCrusadersML' : NCAAB.ValparaisoCrusadersML,
'ValparaisoCrusadersOU' : NCAAB.ValparaisoCrusadersOU,
'ValparaisoCrusadersSoloOU' : NCAAB.ValparaisoCrusadersSoloOU,
'ValparaisoCrusadersHalftime' : NCAAB.ValparaisoCrusadersHalftime,
'ValparaisoCrusadersHalftimeOU' : NCAAB.ValparaisoCrusadersHalftimeOU,
}

MissouriStateBearsDict = {
'MissouriStateBearsCover' : NCAAB.MissouriStateBearsCover,
'MissouriStateBearsML' : NCAAB.MissouriStateBearsML,
'MissouriStateBearsOU' : NCAAB.MissouriStateBearsOU,
'MissouriStateBearsSoloOU' : NCAAB.MissouriStateBearsSoloOU,
'MissouriStateBearsHalftime' : NCAAB.MissouriStateBearsHalftime,
'MissouriStateBearsHalftimeOU' : NCAAB.MissouriStateBearsHalftimeOU,
}

DrakeBulldogsDict = {
'DrakeBulldogsCover' : NCAAB.DrakeBulldogsCover,
'DrakeBulldogsML' : NCAAB.DrakeBulldogsML,
'DrakeBulldogsOU' : NCAAB.DrakeBulldogsOU,
'DrakeBulldogsSoloOU' : NCAAB.DrakeBulldogsSoloOU,
'DrakeBulldogsHalftime' : NCAAB.DrakeBulldogsHalftime,
'DrakeBulldogsHalftimeOU' : NCAAB.DrakeBulldogsHalftimeOU,
}

IllinoisStateRedbirdsDict = {
'IllinoisStateRedbirdsCover' : NCAAB.IllinoisStateRedbirdsCover,
'IllinoisStateRedbirdsML' : NCAAB.IllinoisStateRedbirdsML,
'IllinoisStateRedbirdsOU' : NCAAB.IllinoisStateRedbirdsOU,
'IllinoisStateRedbirdsSoloOU' : NCAAB.IllinoisStateRedbirdsSoloOU,
'IllinoisStateRedbirdsHalftime' : NCAAB.IllinoisStateRedbirdsHalftime,
'IllinoisStateRedbirdsHalftimeOU' : NCAAB.IllinoisStateRedbirdsHalftimeOU,
}

EvansvillePurpleAcesDict = {
'EvansvillePurpleAcesCover' : NCAAB.EvansvillePurpleAcesCover,
'EvansvillePurpleAcesML' : NCAAB.EvansvillePurpleAcesML,
'EvansvillePurpleAcesOU' : NCAAB.EvansvillePurpleAcesOU,
'EvansvillePurpleAcesSoloOU' : NCAAB.EvansvillePurpleAcesSoloOU,
'EvansvillePurpleAcesHalftime' : NCAAB.EvansvillePurpleAcesHalftime,
'EvansvillePurpleAcesHalftimeOU' : NCAAB.EvansvillePurpleAcesHalftimeOU,
}

#Mountain West Teams

SanDiegoStateAztecsDict = {
'SanDiegoStateAztecsCover' : NCAAB.SanDiegoStateAztecsCover,
'SanDiegoStateAztecsML' : NCAAB.SanDiegoStateAztecsML,
'SanDiegoStateAztecsOU' : NCAAB.SanDiegoStateAztecsOU,
'SanDiegoStateAztecsSoloOU' : NCAAB.SanDiegoStateAztecsSoloOU,
'SanDiegoStateAztecsHalftime' : NCAAB.SanDiegoStateAztecsHalftime,
'SanDiegoStateAztecsHalftimeOU' : NCAAB.SanDiegoStateAztecsHalftimeOU,
}

UtahStateAggiesDict = {
'UtahStateAggiesCover' : NCAAB.UtahStateAggiesCover,
'UtahStateAggiesML' : NCAAB.UtahStateAggiesML,
'UtahStateAggiesOU' : NCAAB.UtahStateAggiesOU,
'UtahStateAggiesSoloOU' : NCAAB.UtahStateAggiesSoloOU,
'UtahStateAggiesHalftime' : NCAAB.UtahStateAggiesHalftime,
'UtahStateAggiesHalftimeOU' : NCAAB.UtahStateAggiesHalftimeOU,
}

NevadaWolfPackDict = {
'NevadaWolfPackCover' : NCAAB.NevadaWolfPackCover,
'NevadaWolfPackML' : NCAAB.NevadaWolfPackML,
'NevadaWolfPackOU' : NCAAB.NevadaWolfPackOU,
'NevadaWolfPackSoloOU' : NCAAB.NevadaWolfPackSoloOU,
'NevadaWolfPackHalftime' : NCAAB.NevadaWolfPackHalftime,
'NevadaWolfPackHalftimeOU' : NCAAB.NevadaWolfPackHalftimeOU,
}

UNLVRebelsDict = {
'UNLVRebelsCover' : NCAAB.UNLVRebelsCover,
'UNLVRebelsML' : NCAAB.UNLVRebelsML,
'UNLVRebelsOU' : NCAAB.UNLVRebelsOU,
'UNLVRebelsSoloOU' : NCAAB.UNLVRebelsSoloOU,
'UNLVRebelsHalftime' : NCAAB.UNLVRebelsHalftime,
'UNLVRebelsHalftimeOU' : NCAAB.UNLVRebelsHalftimeOU,
}

BoiseStateBroncosDict = {
'BoiseStateBroncosCover' : NCAAB.BoiseStateBroncosCover,
'BoiseStateBroncosML' : NCAAB.BoiseStateBroncosML,
'BoiseStateBroncosOU' : NCAAB.BoiseStateBroncosOU,
'BoiseStateBroncosSoloOU' : NCAAB.BoiseStateBroncosSoloOU,
'BoiseStateBroncosHalftime' : NCAAB.BoiseStateBroncosHalftime,
'BoiseStateBroncosHalftimeOU' : NCAAB.BoiseStateBroncosHalftimeOU,
}

ColoradoStateRamsDict = {
'ColoradoStateRamsCover' : NCAAB.ColoradoStateRamsCover,
'ColoradoStateRamsML' : NCAAB.ColoradoStateRamsML,
'ColoradoStateRamsOU' : NCAAB.ColoradoStateRamsOU,
'ColoradoStateRamsSoloOU' : NCAAB.ColoradoStateRamsSoloOU,
'ColoradoStateRamsHalftime' : NCAAB.ColoradoStateRamsHalftime,
'ColoradoStateRamsHalftimeOU' : NCAAB.ColoradoStateRamsHalftimeOU,
}

NewMexicoLobosDict = {
'NewMexicoLobosCover' : NCAAB.NewMexicoLobosCover,
'NewMexicoLobosML' : NCAAB.NewMexicoLobosML,
'NewMexicoLobosOU' : NCAAB.NewMexicoLobosOU,
'NewMexicoLobosSoloOU' : NCAAB.NewMexicoLobosSoloOU,
'NewMexicoLobosHalftime' : NCAAB.NewMexicoLobosHalftime,
'NewMexicoLobosHalftimeOU' : NCAAB.NewMexicoLobosHalftimeOU,
}

FresnoStateBulldogsDict = {
'FresnoStateBulldogsCover' : NCAAB.FresnoStateBulldogsCover,
'FresnoStateBulldogsML' : NCAAB.FresnoStateBulldogsML,
'FresnoStateBulldogsOU' : NCAAB.FresnoStateBulldogsOU,
'FresnoStateBulldogsSoloOU' : NCAAB.FresnoStateBulldogsSoloOU,
'FresnoStateBulldogsHalftime' : NCAAB.FresnoStateBulldogsHalftime,
'FresnoStateBulldogsHalftimeOU' : NCAAB.FresnoStateBulldogsHalftimeOU,
}

AirForceFalconsDict = {
'AirForceFalconsCover' : NCAAB.AirForceFalconsCover,
'AirForceFalconsML' : NCAAB.AirForceFalconsML,
'AirForceFalconsOU' : NCAAB.AirForceFalconsOU,
'AirForceFalconsSoloOU' : NCAAB.AirForceFalconsSoloOU,
'AirForceFalconsHalftime' : NCAAB.AirForceFalconsHalftime,
'AirForceFalconsHalftimeOU' : NCAAB.AirForceFalconsHalftimeOU,
}

SanJoseStateSpartansDict = {
'SanJoseStateSpartansCover' : NCAAB.SanJoseStateSpartansCover,
'SanJoseStateSpartansML' : NCAAB.SanJoseStateSpartansML,
'SanJoseStateSpartansOU' : NCAAB.SanJoseStateSpartansOU,
'SanJoseStateSpartansSoloOU' : NCAAB.SanJoseStateSpartansSoloOU,
'SanJoseStateSpartansHalftime' : NCAAB.SanJoseStateSpartansHalftime,
'SanJoseStateSpartansHalftimeOU' : NCAAB.SanJoseStateSpartansHalftimeOU,
}

WyomingCowboysDict = {
'WyomingCowboysCover' : NCAAB.WyomingCowboysCover,
'WyomingCowboysML' : NCAAB.WyomingCowboysML,
'WyomingCowboysOU' : NCAAB.WyomingCowboysOU,
'WyomingCowboysSoloOU' : NCAAB.WyomingCowboysSoloOU,
'WyomingCowboysHalftime' : NCAAB.WyomingCowboysHalftime,
'WyomingCowboysHalftimeOU' : NCAAB.WyomingCowboysHalftimeOU,
}

#North East Teams

MerrimackWarriorsDict = {
'MerrimackWarriorsCover' : NCAAB.MerrimackWarriorsCover,
'MerrimackWarriorsML' : NCAAB.MerrimackWarriorsML,
'MerrimackWarriorsOU' : NCAAB.MerrimackWarriorsOU,
'MerrimackWarriorsSoloOU' : NCAAB.MerrimackWarriorsSoloOU,
'MerrimackWarriorsHalftime' : NCAAB.MerrimackWarriorsHalftime,
'MerrimackWarriorsHalftimeOU' : NCAAB.MerrimackWarriorsHalftimeOU,
}

StFrancisPARedFlashDict = {
'StFrancisPARedFlashCover' : NCAAB.StFrancisPARedFlashCover,
'StFrancisPARedFlashML' : NCAAB.StFrancisPARedFlashML,
'StFrancisPARedFlashOU' : NCAAB.StFrancisPARedFlashOU,
'StFrancisPARedFlashSoloOU' : NCAAB.StFrancisPARedFlashSoloOU,
'StFrancisPARedFlashHalftime' : NCAAB.StFrancisPARedFlashHalftime,
'StFrancisPARedFlashHalftimeOU' : NCAAB.StFrancisPARedFlashHalftimeOU,
}

RobertMorrisColonialsDict = {
'RobertMorrisColonialsCover' : NCAAB.RobertMorrisColonialsCover,
'RobertMorrisColonialsML' : NCAAB.RobertMorrisColonialsML,
'RobertMorrisColonialsOU' : NCAAB.RobertMorrisColonialsOU,
'RobertMorrisColonialsSoloOU' : NCAAB.RobertMorrisColonialsSoloOU,
'RobertMorrisColonialsHalftime' : NCAAB.RobertMorrisColonialsHalftime,
'RobertMorrisColonialsHalftimeOU' : NCAAB.RobertMorrisColonialsHalftimeOU,
}

SacredHeartPioneersDict = {
'SacredHeartPioneersCover' : NCAAB.SacredHeartPioneersCover,
'SacredHeartPioneersML' : NCAAB.SacredHeartPioneersML,
'SacredHeartPioneersOU' : NCAAB.SacredHeartPioneersOU,
'SacredHeartPioneersSoloOU' : NCAAB.SacredHeartPioneersSoloOU,
'SacredHeartPioneersHalftime' : NCAAB.SacredHeartPioneersHalftime,
'SacredHeartPioneersHalftimeOU' : NCAAB.SacredHeartPioneersHalftimeOU,
}

LongIslandUniversitySharksDict = {
'LongIslandUniversitySharksCover' : NCAAB.LongIslandUniversitySharksCover,
'LongIslandUniversitySharksML' : NCAAB.LongIslandUniversitySharksML,
'LongIslandUniversitySharksOU' : NCAAB.LongIslandUniversitySharksOU,
'LongIslandUniversitySharksSoloOU' : NCAAB.LongIslandUniversitySharksSoloOU,
'LongIslandUniversitySharksHalftime' : NCAAB.LongIslandUniversitySharksHalftime,
'LongIslandUniversitySharksHalftimeOU' : NCAAB.LongIslandUniversitySharksHalftimeOU,
}

FairleighDickinsonKnightsDict = {
'FairleighDickinsonKnightsCover' : NCAAB.FairleighDickinsonKnightsCover,
'FairleighDickinsonKnightsML' : NCAAB.FairleighDickinsonKnightsML,
'FairleighDickinsonKnightsOU' : NCAAB.FairleighDickinsonKnightsOU,
'FairleighDickinsonKnightsSoloOU' : NCAAB.FairleighDickinsonKnightsSoloOU,
'FairleighDickinsonKnightsHalftime' : NCAAB.FairleighDickinsonKnightsHalftime,
'FairleighDickinsonKnightsHalftimeOU' : NCAAB.FairleighDickinsonKnightsHalftimeOU,
}

MtStMarysMountaineersDict = {
'MtStMarysMountaineersCover' : NCAAB.MtStMarysMountaineersCover,
'MtStMarysMountaineersML' : NCAAB.MtStMarysMountaineersML,
'MtStMarysMountaineersOU' : NCAAB.MtStMarysMountaineersOU,
'MtStMarysMountaineersSoloOU' : NCAAB.MtStMarysMountaineersSoloOU,
'MtStMarysMountaineersHalftime' : NCAAB.MtStMarysMountaineersHalftime,
'MtStMarysMountaineersHalftimeOU' : NCAAB.MtStMarysMountaineersHalftimeOU,
}

BryantBulldogsDict = {
'BryantBulldogsCover' : NCAAB.BryantBulldogsCover,
'BryantBulldogsML' : NCAAB.BryantBulldogsML,
'BryantBulldogsOU' : NCAAB.BryantBulldogsOU,
'BryantBulldogsSoloOU' : NCAAB.BryantBulldogsSoloOU,
'BryantBulldogsHalftime' : NCAAB.BryantBulldogsHalftime,
'BryantBulldogsHalftimeOU' : NCAAB.BryantBulldogsHalftimeOU,
}

StFrancisBKNTerriersDict = {
'StFrancisBKNTerriersCover' : NCAAB.StFrancisBKNTerriersCover,
'StFrancisBKNTerriersML' : NCAAB.StFrancisBKNTerriersML,
'StFrancisBKNTerriersOU' : NCAAB.StFrancisBKNTerriersOU,
'StFrancisBKNTerriersSoloOU' : NCAAB.StFrancisBKNTerriersSoloOU,
'StFrancisBKNTerriersHalftime' : NCAAB.StFrancisBKNTerriersHalftime,
'StFrancisBKNTerriersHalftimeOU' : NCAAB.StFrancisBKNTerriersHalftimeOU,
}

WagnerSeahawksDict = {
'WagnerSeahawksCover' : NCAAB.WagnerSeahawksCover,
'WagnerSeahawksML' : NCAAB.WagnerSeahawksML,
'WagnerSeahawksOU' : NCAAB.WagnerSeahawksOU,
'WagnerSeahawksSoloOU' : NCAAB.WagnerSeahawksSoloOU,
'WagnerSeahawksHalftime' : NCAAB.WagnerSeahawksHalftime,
'WagnerSeahawksHalftimeOU' : NCAAB.WagnerSeahawksHalftimeOU,
}

CentralConnecticutBlueDevilsDict = {
'CentralConnecticutBlueDevilsCover' : NCAAB.CentralConnecticutBlueDevilsCover,
'CentralConnecticutBlueDevilsML' : NCAAB.CentralConnecticutBlueDevilsML,
'CentralConnecticutBlueDevilsOU' : NCAAB.CentralConnecticutBlueDevilsOU,
'CentralConnecticutBlueDevilsSoloOU' : NCAAB.CentralConnecticutBlueDevilsSoloOU,
'CentralConnecticutBlueDevilsHalftime' : NCAAB.CentralConnecticutBlueDevilsHalftime,
'CentralConnecticutBlueDevilsHalftimeOU' : NCAAB.CentralConnecticutBlueDevilsHalftimeOU,
}

#Ohio Valley Teams

BelmontBruinsDict = {
'BelmontBruinsCover' : NCAAB.BelmontBruinsCover,
'BelmontBruinsML' : NCAAB.BelmontBruinsML,
'BelmontBruinsOU' : NCAAB.BelmontBruinsOU,
'BelmontBruinsSoloOU' : NCAAB.BelmontBruinsSoloOU,
'BelmontBruinsHalftime' : NCAAB.BelmontBruinsHalftime,
'BelmontBruinsHalftimeOU' : NCAAB.BelmontBruinsHalftimeOU,
}

MurrayStateRacersDict = {
'MurrayStateRacersCover' : NCAAB.MurrayStateRacersCover,
'MurrayStateRacersML' : NCAAB.MurrayStateRacersML,
'MurrayStateRacersOU' : NCAAB.MurrayStateRacersOU,
'MurrayStateRacersSoloOU' : NCAAB.MurrayStateRacersSoloOU,
'MurrayStateRacersHalftime' : NCAAB.MurrayStateRacersHalftime,
'MurrayStateRacersHalftimeOU' : NCAAB.MurrayStateRacersHalftimeOU,
}

AustinPeayGovernorsDict = {
'AustinPeayGovernorsCover' : NCAAB.AustinPeayGovernorsCover,
'AustinPeayGovernorsML' : NCAAB.AustinPeayGovernorsML,
'AustinPeayGovernorsOU' : NCAAB.AustinPeayGovernorsOU,
'AustinPeayGovernorsSoloOU' : NCAAB.AustinPeayGovernorsSoloOU,
'AustinPeayGovernorsHalftime' : NCAAB.AustinPeayGovernorsHalftime,
'AustinPeayGovernorsHalftimeOU' : NCAAB.AustinPeayGovernorsHalftimeOU,
}

EasternKentuckyColonelsDict = {
'EasternKentuckyColonelsCover' : NCAAB.EasternKentuckyColonelsCover,
'EasternKentuckyColonelsML' : NCAAB.EasternKentuckyColonelsML,
'EasternKentuckyColonelsOU' : NCAAB.EasternKentuckyColonelsOU,
'EasternKentuckyColonelsSoloOU' : NCAAB.EasternKentuckyColonelsSoloOU,
'EasternKentuckyColonelsHalftime' : NCAAB.EasternKentuckyColonelsHalftime,
'EasternKentuckyColonelsHalftimeOU' : NCAAB.EasternKentuckyColonelsHalftimeOU,
}

TennesseeStateTigersDict = {
'TennesseeStateTigersCover' : NCAAB.TennesseeStateTigersCover,
'TennesseeStateTigersML' : NCAAB.TennesseeStateTigersML,
'TennesseeStateTigersOU' : NCAAB.TennesseeStateTigersOU,
'TennesseeStateTigersSoloOU' : NCAAB.TennesseeStateTigersSoloOU,
'TennesseeStateTigersHalftime' : NCAAB.TennesseeStateTigersHalftime,
'TennesseeStateTigersHalftimeOU' : NCAAB.TennesseeStateTigersHalftimeOU,
}

EasternIllinoisPanthersDict = {
'EasternIllinoisPanthersCover' : NCAAB.EasternIllinoisPanthersCover,
'EasternIllinoisPanthersML' : NCAAB.EasternIllinoisPanthersML,
'EasternIllinoisPanthersOU' : NCAAB.EasternIllinoisPanthersOU,
'EasternIllinoisPanthersSoloOU' : NCAAB.EasternIllinoisPanthersSoloOU,
'EasternIllinoisPanthersHalftime' : NCAAB.EasternIllinoisPanthersHalftime,
'EasternIllinoisPanthersHalftimeOU' : NCAAB.EasternIllinoisPanthersHalftimeOU,
}

JacksonvilleStateGamecocksDict = {
'JacksonvilleStateGamecocksCover' : NCAAB.JacksonvilleStateGamecocksCover,
'JacksonvilleStateGamecocksML' : NCAAB.JacksonvilleStateGamecocksML,
'JacksonvilleStateGamecocksOU' : NCAAB.JacksonvilleStateGamecocksOU,
'JacksonvilleStateGamecocksSoloOU' : NCAAB.JacksonvilleStateGamecocksSoloOU,
'JacksonvilleStateGamecocksHalftime' : NCAAB.JacksonvilleStateGamecocksHalftime,
'JacksonvilleStateGamecocksHalftimeOU' : NCAAB.JacksonvilleStateGamecocksHalftimeOU,
}

MoreheadStateEaglesDict = {
'MoreheadStateEaglesCover' : NCAAB.MoreheadStateEaglesCover,
'MoreheadStateEaglesML' : NCAAB.MoreheadStateEaglesML,
'MoreheadStateEaglesOU' : NCAAB.MoreheadStateEaglesOU,
'MoreheadStateEaglesSoloOU' : NCAAB.MoreheadStateEaglesSoloOU,
'MoreheadStateEaglesHalftime' : NCAAB.MoreheadStateEaglesHalftime,
'MoreheadStateEaglesHalftimeOU' : NCAAB.MoreheadStateEaglesHalftimeOU,
}

TennesseeTechGoldenEaglesDict = {
'TennesseeTechGoldenEaglesCover' : NCAAB.TennesseeTechGoldenEaglesCover,
'TennesseeTechGoldenEaglesML' : NCAAB.TennesseeTechGoldenEaglesML,
'TennesseeTechGoldenEaglesOU' : NCAAB.TennesseeTechGoldenEaglesOU,
'TennesseeTechGoldenEaglesSoloOU' : NCAAB.TennesseeTechGoldenEaglesSoloOU,
'TennesseeTechGoldenEaglesHalftime' : NCAAB.TennesseeTechGoldenEaglesHalftime,
'TennesseeTechGoldenEaglesHalftimeOU' : NCAAB.TennesseeTechGoldenEaglesHalftimeOU,
}

UTMartinSkyhawksDict = {
'UTMartinSkyhawksCover' : NCAAB.UTMartinSkyhawksCover,
'UTMartinSkyhawksML' : NCAAB.UTMartinSkyhawksML,
'UTMartinSkyhawksOU' : NCAAB.UTMartinSkyhawksOU,
'UTMartinSkyhawksSoloOU' : NCAAB.UTMartinSkyhawksSoloOU,
'UTMartinSkyhawksHalftime' : NCAAB.UTMartinSkyhawksHalftime,
'UTMartinSkyhawksHalftimeOU' : NCAAB.UTMartinSkyhawksHalftimeOU,
}

SIUEdwardsvilleCougarsDict = {
'SIUEdwardsvilleCougarsCover' : NCAAB.SIUEdwardsvilleCougarsCover,
'SIUEdwardsvilleCougarsML' : NCAAB.SIUEdwardsvilleCougarsML,
'SIUEdwardsvilleCougarsOU' : NCAAB.SIUEdwardsvilleCougarsOU,
'SIUEdwardsvilleCougarsSoloOU' : NCAAB.SIUEdwardsvilleCougarsSoloOU,
'SIUEdwardsvilleCougarsHalftime' : NCAAB.SIUEdwardsvilleCougarsHalftime,
'SIUEdwardsvilleCougarsHalftimeOU' : NCAAB.SIUEdwardsvilleCougarsHalftimeOU,
}

SEMissouriStRedhawksDict = {
'SEMissouriStRedhawksCover' : NCAAB.SEMissouriStRedhawksCover,
'SEMissouriStRedhawksML' : NCAAB.SEMissouriStRedhawksML,
'SEMissouriStRedhawksOU' : NCAAB.SEMissouriStRedhawksOU,
'SEMissouriStRedhawksSoloOU' : NCAAB.SEMissouriStRedhawksSoloOU,
'SEMissouriStRedhawksHalftime' : NCAAB.SEMissouriStRedhawksHalftime,
'SEMissouriStRedhawksHalftimeOU' : NCAAB.SEMissouriStRedhawksHalftimeOU,
}

#Pac-12 Teams

OregonDucksDict = {
'OregonDucksCover' : NCAAB.OregonDucksCover,
'OregonDucksML' : NCAAB.OregonDucksML,
'OregonDucksOU' : NCAAB.OregonDucksOU,
'OregonDucksSoloOU' : NCAAB.OregonDucksSoloOU,
'OregonDucksHalftime' : NCAAB.OregonDucksHalftime,
'OregonDucksHalftimeOU' : NCAAB.OregonDucksHalftimeOU,
}

UCLABruinsDict = {
'UCLABruinsCover' : NCAAB.UCLABruinsCover,
'UCLABruinsML' : NCAAB.UCLABruinsML,
'UCLABruinsOU' : NCAAB.UCLABruinsOU,
'UCLABruinsSoloOU' : NCAAB.UCLABruinsSoloOU,
'UCLABruinsHalftime' : NCAAB.UCLABruinsHalftime,
'UCLABruinsHalftimeOU' : NCAAB.UCLABruinsHalftimeOU,
}

USCTrojansDict = {
'USCTrojansCover' : NCAAB.USCTrojansCover,
'USCTrojansML' : NCAAB.USCTrojansML,
'USCTrojansOU' : NCAAB.USCTrojansOU,
'USCTrojansSoloOU' : NCAAB.USCTrojansSoloOU,
'USCTrojansHalftime' : NCAAB.USCTrojansHalftime,
'USCTrojansHalftimeOU' : NCAAB.USCTrojansHalftimeOU,
}

ArizonaStateSunDevilsDict = {
'ArizonaStateSunDevilsCover' : NCAAB.ArizonaStateSunDevilsCover,
'ArizonaStateSunDevilsML' : NCAAB.ArizonaStateSunDevilsML,
'ArizonaStateSunDevilsOU' : NCAAB.ArizonaStateSunDevilsOU,
'ArizonaStateSunDevilsSoloOU' : NCAAB.ArizonaStateSunDevilsSoloOU,
'ArizonaStateSunDevilsHalftime' : NCAAB.ArizonaStateSunDevilsHalftime,
'ArizonaStateSunDevilsHalftimeOU' : NCAAB.ArizonaStateSunDevilsHalftimeOU,
}

ArizonaWildcatsDict = {
'ArizonaWildcatsCover' : NCAAB.ArizonaWildcatsCover,
'ArizonaWildcatsML' : NCAAB.ArizonaWildcatsML,
'ArizonaWildcatsOU' : NCAAB.ArizonaWildcatsOU,
'ArizonaWildcatsSoloOU' : NCAAB.ArizonaWildcatsSoloOU,
'ArizonaWildcatsHalftime' : NCAAB.ArizonaWildcatsHalftime,
'ArizonaWildcatsHalftimeOU' : NCAAB.ArizonaWildcatsHalftimeOU,
}

ColoradoBuffaloesDict = {
'ColoradoBuffaloesCover' : NCAAB.ColoradoBuffaloesCover,
'ColoradoBuffaloesML' : NCAAB.ColoradoBuffaloesML,
'ColoradoBuffaloesOU' : NCAAB.ColoradoBuffaloesOU,
'ColoradoBuffaloesSoloOU' : NCAAB.ColoradoBuffaloesSoloOU,
'ColoradoBuffaloesHalftime' : NCAAB.ColoradoBuffaloesHalftime,
'ColoradoBuffaloesHalftimeOU' : NCAAB.ColoradoBuffaloesHalftimeOU,
}

StanfordCardinalsDict = {
'StanfordCardinalsCover' : NCAAB.StanfordCardinalsCover,
'StanfordCardinalsML' : NCAAB.StanfordCardinalsML,
'StanfordCardinalsOU' : NCAAB.StanfordCardinalsOU,
'StanfordCardinalsSoloOU' : NCAAB.StanfordCardinalsSoloOU,
'StanfordCardinalsHalftime' : NCAAB.StanfordCardinalsHalftime,
'StanfordCardinalsHalftimeOU' : NCAAB.StanfordCardinalsHalftimeOU,
}

OregonStateBeaversDict = {
'OregonStateBeaversCover' : NCAAB.OregonStateBeaversCover,
'OregonStateBeaversML' : NCAAB.OregonStateBeaversML,
'OregonStateBeaversOU' : NCAAB.OregonStateBeaversOU,
'OregonStateBeaversSoloOU' : NCAAB.OregonStateBeaversSoloOU,
'OregonStateBeaversHalftime' : NCAAB.OregonStateBeaversHalftime,
'OregonStateBeaversHalftimeOU' : NCAAB.OregonStateBeaversHalftimeOU,
}

UtahUtesDict = {
'UtahUtesCover' : NCAAB.UtahUtesCover,
'UtahUtesML' : NCAAB.UtahUtesML,
'UtahUtesOU' : NCAAB.UtahUtesOU,
'UtahUtesSoloOU' : NCAAB.UtahUtesSoloOU,
'UtahUtesHalftime' : NCAAB.UtahUtesHalftime,
'UtahUtesHalftimeOU' : NCAAB.UtahUtesHalftimeOU,
}

CaliforniaGoldenBearsDict = {
'CaliforniaGoldenBearsCover' : NCAAB.CaliforniaGoldenBearsCover,
'CaliforniaGoldenBearsML' : NCAAB.CaliforniaGoldenBearsML,
'CaliforniaGoldenBearsOU' : NCAAB.CaliforniaGoldenBearsOU,
'CaliforniaGoldenBearsSoloOU' : NCAAB.CaliforniaGoldenBearsSoloOU,
'CaliforniaGoldenBearsHalftime' : NCAAB.CaliforniaGoldenBearsHalftime,
'CaliforniaGoldenBearsHalftimeOU' : NCAAB.CaliforniaGoldenBearsHalftimeOU,
}

WashingtonStateCougarsDict = {
'WashingtonStateCougarsCover' : NCAAB.WashingtonStateCougarsCover,
'WashingtonStateCougarsML' : NCAAB.WashingtonStateCougarsML,
'WashingtonStateCougarsOU' : NCAAB.WashingtonStateCougarsOU,
'WashingtonStateCougarsSoloOU' : NCAAB.WashingtonStateCougarsSoloOU,
'WashingtonStateCougarsHalftime' : NCAAB.WashingtonStateCougarsHalftime,
'WashingtonStateCougarsHalftimeOU' : NCAAB.WashingtonStateCougarsHalftimeOU,
}

WashingtonHuskiesDict = {
'WashingtonHuskiesCover' : NCAAB.WashingtonHuskiesCover,
'WashingtonHuskiesML' : NCAAB.WashingtonHuskiesML,
'WashingtonHuskiesOU' : NCAAB.WashingtonHuskiesOU,
'WashingtonHuskiesSoloOU' : NCAAB.WashingtonHuskiesSoloOU,
'WashingtonHuskiesHalftime' : NCAAB.WashingtonHuskiesHalftime,
'WashingtonHuskiesHalftimeOU' : NCAAB.WashingtonHuskiesHalftimeOU,
}

#Patriot Teams

ColgateRaidersDict = {
'ColgateRaidersCover' : NCAAB.ColgateRaidersCover,
'ColgateRaidersML' : NCAAB.ColgateRaidersML,
'ColgateRaidersOU' : NCAAB.ColgateRaidersOU,
'ColgateRaidersSoloOU' : NCAAB.ColgateRaidersSoloOU,
'ColgateRaidersHalftime' : NCAAB.ColgateRaidersHalftime,
'ColgateRaidersHalftimeOU' : NCAAB.ColgateRaidersHalftimeOU,
}

BostonUnivTerriersDict = {
'BostonUnivTerriersCover' : NCAAB.BostonUnivTerriersCover,
'BostonUnivTerriersML' : NCAAB.BostonUnivTerriersML,
'BostonUnivTerriersOU' : NCAAB.BostonUnivTerriersOU,
'BostonUnivTerriersSoloOU' : NCAAB.BostonUnivTerriersSoloOU,
'BostonUnivTerriersHalftime' : NCAAB.BostonUnivTerriersHalftime,
'BostonUnivTerriersHalftimeOU' : NCAAB.BostonUnivTerriersHalftimeOU,
}

AmericanEaglesDict = {
'AmericanEaglesCover' : NCAAB.AmericanEaglesCover,
'AmericanEaglesML' : NCAAB.AmericanEaglesML,
'AmericanEaglesOU' : NCAAB.AmericanEaglesOU,
'AmericanEaglesSoloOU' : NCAAB.AmericanEaglesSoloOU,
'AmericanEaglesHalftime' : NCAAB.AmericanEaglesHalftime,
'AmericanEaglesHalftimeOU' : NCAAB.AmericanEaglesHalftimeOU,
}

LafayetteLeopardsDict = {
'LafayetteLeopardsCover' : NCAAB.LafayetteLeopardsCover,
'LafayetteLeopardsML' : NCAAB.LafayetteLeopardsML,
'LafayetteLeopardsOU' : NCAAB.LafayetteLeopardsOU,
'LafayetteLeopardsSoloOU' : NCAAB.LafayetteLeopardsSoloOU,
'LafayetteLeopardsHalftime' : NCAAB.LafayetteLeopardsHalftime,
'LafayetteLeopardsHalftimeOU' : NCAAB.LafayetteLeopardsHalftimeOU,
}

ArmyBlackKnightsDict = {
'ArmyBlackKnightsCover' : NCAAB.ArmyBlackKnightsCover,
'ArmyBlackKnightsML' : NCAAB.ArmyBlackKnightsML,
'ArmyBlackKnightsOU' : NCAAB.ArmyBlackKnightsOU,
'ArmyBlackKnightsSoloOU' : NCAAB.ArmyBlackKnightsSoloOU,
'ArmyBlackKnightsHalftime' : NCAAB.ArmyBlackKnightsHalftime,
'ArmyBlackKnightsHalftimeOU' : NCAAB.ArmyBlackKnightsHalftimeOU,
}

NavyMidshipmenDict = {
'NavyMidshipmenCover' : NCAAB.NavyMidshipmenCover,
'NavyMidshipmenML' : NCAAB.NavyMidshipmenML,
'NavyMidshipmenOU' : NCAAB.NavyMidshipmenOU,
'NavyMidshipmenSoloOU' : NCAAB.NavyMidshipmenSoloOU,
'NavyMidshipmenHalftime' : NCAAB.NavyMidshipmenHalftime,
'NavyMidshipmenHalftimeOU' : NCAAB.NavyMidshipmenHalftimeOU,
}

BucknellBisonDict = {
'BucknellBisonCover' : NCAAB.BucknellBisonCover,
'BucknellBisonML' : NCAAB.BucknellBisonML,
'BucknellBisonOU' : NCAAB.BucknellBisonOU,
'BucknellBisonSoloOU' : NCAAB.BucknellBisonSoloOU,
'BucknellBisonHalftime' : NCAAB.BucknellBisonHalftime,
'BucknellBisonHalftimeOU' : NCAAB.BucknellBisonHalftimeOU,
}

LehighMountainHawksDict = {
'LehighMountainHawksCover' : NCAAB.LehighMountainHawksCover,
'LehighMountainHawksML' : NCAAB.LehighMountainHawksML,
'LehighMountainHawksOU' : NCAAB.LehighMountainHawksOU,
'LehighMountainHawksSoloOU' : NCAAB.LehighMountainHawksSoloOU,
'LehighMountainHawksHalftime' : NCAAB.LehighMountainHawksHalftime,
'LehighMountainHawksHalftimeOU' : NCAAB.LehighMountainHawksHalftimeOU,
}

LoyolaMDGreyhoundsDict = {
'LoyolaMDGreyhoundsCover' : NCAAB.LoyolaMDGreyhoundsCover,
'LoyolaMDGreyhoundsML' : NCAAB.LoyolaMDGreyhoundsML,
'LoyolaMDGreyhoundsOU' : NCAAB.LoyolaMDGreyhoundsOU,
'LoyolaMDGreyhoundsSoloOU' : NCAAB.LoyolaMDGreyhoundsSoloOU,
'LoyolaMDGreyhoundsHalftime' : NCAAB.LoyolaMDGreyhoundsHalftime,
'LoyolaMDGreyhoundsHalftimeOU' : NCAAB.LoyolaMDGreyhoundsHalftimeOU,
}

HolyCrossCrusadersDict = {
'HolyCrossCrusadersCover' : NCAAB.HolyCrossCrusadersCover,
'HolyCrossCrusadersML' : NCAAB.HolyCrossCrusadersML,
'HolyCrossCrusadersOU' : NCAAB.HolyCrossCrusadersOU,
'HolyCrossCrusadersSoloOU' : NCAAB.HolyCrossCrusadersSoloOU,
'HolyCrossCrusadersHalftime' : NCAAB.HolyCrossCrusadersHalftime,
'HolyCrossCrusadersHalftimeOU' : NCAAB.HolyCrossCrusadersHalftimeOU,
}

#Southeastern Teams

KentuckyWildcatsDict = {
'KentuckyWildcatsCover' : NCAAB.KentuckyWildcatsCover,
'KentuckyWildcatsML' : NCAAB.KentuckyWildcatsML,
'KentuckyWildcatsOU' : NCAAB.KentuckyWildcatsOU,
'KentuckyWildcatsSoloOU' : NCAAB.KentuckyWildcatsSoloOU,
'KentuckyWildcatsHalftime' : NCAAB.KentuckyWildcatsHalftime,
'KentuckyWildcatsHalftimeOU' : NCAAB.KentuckyWildcatsHalftimeOU,
}

AuburnTigersDict = {
'AuburnTigersCover' : NCAAB.AuburnTigersCover,
'AuburnTigersML' : NCAAB.AuburnTigersML,
'AuburnTigersOU' : NCAAB.AuburnTigersOU,
'AuburnTigersSoloOU' : NCAAB.AuburnTigersSoloOU,
'AuburnTigersHalftime' : NCAAB.AuburnTigersHalftime,
'AuburnTigersHalftimeOU' : NCAAB.AuburnTigersHalftimeOU,
}

LSUTigersDict = {
'LSUTigersCover' : NCAAB.LSUTigersCover,
'LSUTigersML' : NCAAB.LSUTigersML,
'LSUTigersOU' : NCAAB.LSUTigersOU,
'LSUTigersSoloOU' : NCAAB.LSUTigersSoloOU,
'LSUTigersHalftime' : NCAAB.LSUTigersHalftime,
'LSUTigersHalftimeOU' : NCAAB.LSUTigersHalftimeOU,
}

MississippiStateBulldogsDict = {
'MississippiStateBulldogsCover' : NCAAB.MississippiStateBulldogsCover,
'MississippiStateBulldogsML' : NCAAB.MississippiStateBulldogsML,
'MississippiStateBulldogsOU' : NCAAB.MississippiStateBulldogsOU,
'MississippiStateBulldogsSoloOU' : NCAAB.MississippiStateBulldogsSoloOU,
'MississippiStateBulldogsHalftime' : NCAAB.MississippiStateBulldogsHalftime,
'MississippiStateBulldogsHalftimeOU' : NCAAB.MississippiStateBulldogsHalftimeOU,
}

FloridaGatorsDict = {
'FloridaGatorsCover' : NCAAB.FloridaGatorsCover,
'FloridaGatorsML' : NCAAB.FloridaGatorsML,
'FloridaGatorsOU' : NCAAB.FloridaGatorsOU,
'FloridaGatorsSoloOU' : NCAAB.FloridaGatorsSoloOU,
'FloridaGatorsHalftime' : NCAAB.FloridaGatorsHalftime,
'FloridaGatorsHalftimeOU' : NCAAB.FloridaGatorsHalftimeOU,
}

SouthCarolinaGamecocksDict = {
'SouthCarolinaGamecocksCover' : NCAAB.SouthCarolinaGamecocksCover,
'SouthCarolinaGamecocksML' : NCAAB.SouthCarolinaGamecocksML,
'SouthCarolinaGamecocksOU' : NCAAB.SouthCarolinaGamecocksOU,
'SouthCarolinaGamecocksSoloOU' : NCAAB.SouthCarolinaGamecocksSoloOU,
'SouthCarolinaGamecocksHalftime' : NCAAB.SouthCarolinaGamecocksHalftime,
'SouthCarolinaGamecocksHalftimeOU' : NCAAB.SouthCarolinaGamecocksHalftimeOU,
}

TexasAandMAggiesDict = {
'TexasAandMAggiesCover' : NCAAB.TexasAandMAggiesCover,
'TexasAandMAggiesML' : NCAAB.TexasAandMAggiesML,
'TexasAandMAggiesOU' : NCAAB.TexasAandMAggiesOU,
'TexasAandMAggiesSoloOU' : NCAAB.TexasAandMAggiesSoloOU,
'TexasAandMAggiesHalftime' : NCAAB.TexasAandMAggiesHalftime,
'TexasAandMAggiesHalftimeOU' : NCAAB.TexasAandMAggiesHalftimeOU,
}

TennesseeVolunteersDict = {
'TennesseeVolunteersCover' : NCAAB.TennesseeVolunteersCover,
'TennesseeVolunteersML' : NCAAB.TennesseeVolunteersML,
'TennesseeVolunteersOU' : NCAAB.TennesseeVolunteersOU,
'TennesseeVolunteersSoloOU' : NCAAB.TennesseeVolunteersSoloOU,
'TennesseeVolunteersHalftime' : NCAAB.TennesseeVolunteersHalftime,
'TennesseeVolunteersHalftimeOU' : NCAAB.TennesseeVolunteersHalftimeOU,
}

AlabamaCrimsonTideDict = {
'AlabamaCrimsonTideCover' : NCAAB.AlabamaCrimsonTideCover,
'AlabamaCrimsonTideML' : NCAAB.AlabamaCrimsonTideML,
'AlabamaCrimsonTideOU' : NCAAB.AlabamaCrimsonTideOU,
'AlabamaCrimsonTideSoloOU' : NCAAB.AlabamaCrimsonTideSoloOU,
'AlabamaCrimsonTideHalftime' : NCAAB.AlabamaCrimsonTideHalftime,
'AlabamaCrimsonTideHalftimeOU' : NCAAB.AlabamaCrimsonTideHalftimeOU,
}

ArkansasRazorbacksDict = {
'ArkansasRazorbacksCover' : NCAAB.ArkansasRazorbacksCover,
'ArkansasRazorbacksML' : NCAAB.ArkansasRazorbacksML,
'ArkansasRazorbacksOU' : NCAAB.ArkansasRazorbacksOU,
'ArkansasRazorbacksSoloOU' : NCAAB.ArkansasRazorbacksSoloOU,
'ArkansasRazorbacksHalftime' : NCAAB.ArkansasRazorbacksHalftime,
'ArkansasRazorbacksHalftimeOU' : NCAAB.ArkansasRazorbacksHalftimeOU,
}

MissouriTigersDict = {
'MissouriTigersCover' : NCAAB.MissouriTigersCover,
'MissouriTigersML' : NCAAB.MissouriTigersML,
'MissouriTigersOU' : NCAAB.MissouriTigersOU,
'MissouriTigersSoloOU' : NCAAB.MissouriTigersSoloOU,
'MissouriTigersHalftime' : NCAAB.MissouriTigersHalftime,
'MissouriTigersHalftimeOU' : NCAAB.MissouriTigersHalftimeOU,
}

OleMissRebelsDict = {
'OleMissRebelsCover' : NCAAB.OleMissRebelsCover,
'OleMissRebelsML' : NCAAB.OleMissRebelsML,
'OleMissRebelsOU' : NCAAB.OleMissRebelsOU,
'OleMissRebelsSoloOU' : NCAAB.OleMissRebelsSoloOU,
'OleMissRebelsHalftime' : NCAAB.OleMissRebelsHalftime,
'OleMissRebelsHalftimeOU' : NCAAB.OleMissRebelsHalftimeOU,
}

GeorgiaBulldogsDict = {
'GeorgiaBulldogsCover' : NCAAB.GeorgiaBulldogsCover,
'GeorgiaBulldogsML' : NCAAB.GeorgiaBulldogsML,
'GeorgiaBulldogsOU' : NCAAB.GeorgiaBulldogsOU,
'GeorgiaBulldogsSoloOU' : NCAAB.GeorgiaBulldogsSoloOU,
'GeorgiaBulldogsHalftime' : NCAAB.GeorgiaBulldogsHalftime,
'GeorgiaBulldogsHalftimeOU' : NCAAB.GeorgiaBulldogsHalftimeOU,
}

VanderbiltCommodoresDict = {
'VanderbiltCommodoresCover' : NCAAB.VanderbiltCommodoresCover,
'VanderbiltCommodoresML' : NCAAB.VanderbiltCommodoresML,
'VanderbiltCommodoresOU' : NCAAB.VanderbiltCommodoresOU,
'VanderbiltCommodoresSoloOU' : NCAAB.VanderbiltCommodoresSoloOU,
'VanderbiltCommodoresHalftime' : NCAAB.VanderbiltCommodoresHalftime,
'VanderbiltCommodoresHalftimeOU' : NCAAB.VanderbiltCommodoresHalftimeOU,
}

#Southern Teams

EastTennesseeStateBuccaneersDict = {
'EastTennesseeStateBuccaneersCover' : NCAAB.EastTennesseeStateBuccaneersCover,
'EastTennesseeStateBuccaneersML' : NCAAB.EastTennesseeStateBuccaneersML,
'EastTennesseeStateBuccaneersOU' : NCAAB.EastTennesseeStateBuccaneersOU,
'EastTennesseeStateBuccaneersSoloOU' : NCAAB.EastTennesseeStateBuccaneersSoloOU,
'EastTennesseeStateBuccaneersHalftime' : NCAAB.EastTennesseeStateBuccaneersHalftime,
'EastTennesseeStateBuccaneersHalftimeOU' : NCAAB.EastTennesseeStateBuccaneersHalftimeOU,
}

FurmanPaladinsDict = {
'FurmanPaladinsCover' : NCAAB.FurmanPaladinsCover,
'FurmanPaladinsML' : NCAAB.FurmanPaladinsML,
'FurmanPaladinsOU' : NCAAB.FurmanPaladinsOU,
'FurmanPaladinsSoloOU' : NCAAB.FurmanPaladinsSoloOU,
'FurmanPaladinsHalftime' : NCAAB.FurmanPaladinsHalftime,
'FurmanPaladinsHalftimeOU' : NCAAB.FurmanPaladinsHalftimeOU,
}

UNCGreensboroSpartansDict = {
'UNCGreensboroSpartansCover' : NCAAB.UNCGreensboroSpartansCover,
'UNCGreensboroSpartansML' : NCAAB.UNCGreensboroSpartansML,
'UNCGreensboroSpartansOU' : NCAAB.UNCGreensboroSpartansOU,
'UNCGreensboroSpartansSoloOU' : NCAAB.UNCGreensboroSpartansSoloOU,
'UNCGreensboroSpartansHalftime' : NCAAB.UNCGreensboroSpartansHalftime,
'UNCGreensboroSpartansHalftimeOU' : NCAAB.UNCGreensboroSpartansHalftimeOU,
}

MercerBearsDict = {
'MercerBearsCover' : NCAAB.MercerBearsCover,
'MercerBearsML' : NCAAB.MercerBearsML,
'MercerBearsOU' : NCAAB.MercerBearsOU,
'MercerBearsSoloOU' : NCAAB.MercerBearsSoloOU,
'MercerBearsHalftime' : NCAAB.MercerBearsHalftime,
'MercerBearsHalftimeOU' : NCAAB.MercerBearsHalftimeOU,
}

WesternCarolinaCatamountsDict = {
'WesternCarolinaCatamountsCover' : NCAAB.WesternCarolinaCatamountsCover,
'WesternCarolinaCatamountsML' : NCAAB.WesternCarolinaCatamountsML,
'WesternCarolinaCatamountsOU' : NCAAB.WesternCarolinaCatamountsOU,
'WesternCarolinaCatamountsSoloOU' : NCAAB.WesternCarolinaCatamountsSoloOU,
'WesternCarolinaCatamountsHalftime' : NCAAB.WesternCarolinaCatamountsHalftime,
'WesternCarolinaCatamountsHalftimeOU' : NCAAB.WesternCarolinaCatamountsHalftimeOU,
}

ChattanoogaMocsDict = {
'ChattanoogaMocsCover' : NCAAB.ChattanoogaMocsCover,
'ChattanoogaMocsML' : NCAAB.ChattanoogaMocsML,
'ChattanoogaMocsOU' : NCAAB.ChattanoogaMocsOU,
'ChattanoogaMocsSoloOU' : NCAAB.ChattanoogaMocsSoloOU,
'ChattanoogaMocsHalftime' : NCAAB.ChattanoogaMocsHalftime,
'ChattanoogaMocsHalftimeOU' : NCAAB.ChattanoogaMocsHalftimeOU,
}

WoffordTerriersDict = {
'WoffordTerriersCover' : NCAAB.WoffordTerriersCover,
'WoffordTerriersML' : NCAAB.WoffordTerriersML,
'WoffordTerriersOU' : NCAAB.WoffordTerriersOU,
'WoffordTerriersSoloOU' : NCAAB.WoffordTerriersSoloOU,
'WoffordTerriersHalftime' : NCAAB.WoffordTerriersHalftime,
'WoffordTerriersHalftimeOU' : NCAAB.WoffordTerriersHalftimeOU,
}

SamfordBulldogsDict = {
'SamfordBulldogsCover' : NCAAB.SamfordBulldogsCover,
'SamfordBulldogsML' : NCAAB.SamfordBulldogsML,
'SamfordBulldogsOU' : NCAAB.SamfordBulldogsOU,
'SamfordBulldogsSoloOU' : NCAAB.SamfordBulldogsSoloOU,
'SamfordBulldogsHalftime' : NCAAB.SamfordBulldogsHalftime,
'SamfordBulldogsHalftimeOU' : NCAAB.SamfordBulldogsHalftimeOU,
}

VMIKeydetsDict = {
'VMIKeydetsCover' : NCAAB.VMIKeydetsCover,
'VMIKeydetsML' : NCAAB.VMIKeydetsML,
'VMIKeydetsOU' : NCAAB.VMIKeydetsOU,
'VMIKeydetsSoloOU' : NCAAB.VMIKeydetsSoloOU,
'VMIKeydetsHalftime' : NCAAB.VMIKeydetsHalftime,
'VMIKeydetsHalftimeOU' : NCAAB.VMIKeydetsHalftimeOU,
}

TheCitadelBulldogsDict = {
'TheCitadelBulldogsCover' : NCAAB.TheCitadelBulldogsCover,
'TheCitadelBulldogsML' : NCAAB.TheCitadelBulldogsML,
'TheCitadelBulldogsOU' : NCAAB.TheCitadelBulldogsOU,
'TheCitadelBulldogsSoloOU' : NCAAB.TheCitadelBulldogsSoloOU,
'TheCitadelBulldogsHalftime' : NCAAB.TheCitadelBulldogsHalftime,
'TheCitadelBulldogsHalftimeOU' : NCAAB.TheCitadelBulldogsHalftimeOU,
}

#Southland Teams

StephenFAustinLumberjacksDict = {
'StephenFAustinLumberjacksCover' : NCAAB.StephenFAustinLumberjacksCover,
'StephenFAustinLumberjacksML' : NCAAB.StephenFAustinLumberjacksML,
'StephenFAustinLumberjacksOU' : NCAAB.StephenFAustinLumberjacksOU,
'StephenFAustinLumberjacksSoloOU' : NCAAB.StephenFAustinLumberjacksSoloOU,
'StephenFAustinLumberjacksHalftime' : NCAAB.StephenFAustinLumberjacksHalftime,
'StephenFAustinLumberjacksHalftimeOU' : NCAAB.StephenFAustinLumberjacksHalftimeOU,
}

NichollsColonelsDict = {
'NichollsColonelsCover' : NCAAB.NichollsColonelsCover,
'NichollsColonelsML' : NCAAB.NichollsColonelsML,
'NichollsColonelsOU' : NCAAB.NichollsColonelsOU,
'NichollsColonelsSoloOU' : NCAAB.NichollsColonelsSoloOU,
'NichollsColonelsHalftime' : NCAAB.NichollsColonelsHalftime,
'NichollsColonelsHalftimeOU' : NCAAB.NichollsColonelsHalftimeOU,
}

AbileneChristianWildcatsDict = {
'AbileneChristianWildcatsCover' : NCAAB.AbileneChristianWildcatsCover,
'AbileneChristianWildcatsML' : NCAAB.AbileneChristianWildcatsML,
'AbileneChristianWildcatsOU' : NCAAB.AbileneChristianWildcatsOU,
'AbileneChristianWildcatsSoloOU' : NCAAB.AbileneChristianWildcatsSoloOU,
'AbileneChristianWildcatsHalftime' : NCAAB.AbileneChristianWildcatsHalftime,
'AbileneChristianWildcatsHalftimeOU' : NCAAB.AbileneChristianWildcatsHalftimeOU,
}

SamHoustonStateBearkatsDict = {
'SamHoustonStateBearkatsCover' : NCAAB.SamHoustonStateBearkatsCover,
'SamHoustonStateBearkatsML' : NCAAB.SamHoustonStateBearkatsML,
'SamHoustonStateBearkatsOU' : NCAAB.SamHoustonStateBearkatsOU,
'SamHoustonStateBearkatsSoloOU' : NCAAB.SamHoustonStateBearkatsSoloOU,
'SamHoustonStateBearkatsHalftime' : NCAAB.SamHoustonStateBearkatsHalftime,
'SamHoustonStateBearkatsHalftimeOU' : NCAAB.SamHoustonStateBearkatsHalftimeOU,
}

NorthwesternStateDemonsDict = {
'NorthwesternStateDemonsCover' : NCAAB.NorthwesternStateDemonsCover,
'NorthwesternStateDemonsML' : NCAAB.NorthwesternStateDemonsML,
'NorthwesternStateDemonsOU' : NCAAB.NorthwesternStateDemonsOU,
'NorthwesternStateDemonsSoloOU' : NCAAB.NorthwesternStateDemonsSoloOU,
'NorthwesternStateDemonsHalftime' : NCAAB.NorthwesternStateDemonsHalftime,
'NorthwesternStateDemonsHalftimeOU' : NCAAB.NorthwesternStateDemonsHalftimeOU,
}

TexasAandMCCIslandersDict = {
'TexasAandMCCIslandersCover' : NCAAB.TexasAandMCCIslandersCover,
'TexasAandMCCIslandersML' : NCAAB.TexasAandMCCIslandersML,
'TexasAandMCCIslandersOU' : NCAAB.TexasAandMCCIslandersOU,
'TexasAandMCCIslandersSoloOU' : NCAAB.TexasAandMCCIslandersSoloOU,
'TexasAandMCCIslandersHalftime' : NCAAB.TexasAandMCCIslandersHalftime,
'TexasAandMCCIslandersHalftimeOU' : NCAAB.TexasAandMCCIslandersHalftimeOU,
}

LamarCardinalsDict = {
'LamarCardinalsCover' : NCAAB.LamarCardinalsCover,
'LamarCardinalsML' : NCAAB.LamarCardinalsML,
'LamarCardinalsOU' : NCAAB.LamarCardinalsOU,
'LamarCardinalsSoloOU' : NCAAB.LamarCardinalsSoloOU,
'LamarCardinalsHalftime' : NCAAB.LamarCardinalsHalftime,
'LamarCardinalsHalftimeOU' : NCAAB.LamarCardinalsHalftimeOU,
}

McNeeseStateCowboysDict = {
'McNeeseStateCowboysCover' : NCAAB.McNeeseStateCowboysCover,
'McNeeseStateCowboysML' : NCAAB.McNeeseStateCowboysML,
'McNeeseStateCowboysOU' : NCAAB.McNeeseStateCowboysOU,
'McNeeseStateCowboysSoloOU' : NCAAB.McNeeseStateCowboysSoloOU,
'McNeeseStateCowboysHalftime' : NCAAB.McNeeseStateCowboysHalftime,
'McNeeseStateCowboysHalftimeOU' : NCAAB.McNeeseStateCowboysHalftimeOU,
}

CentralArkansasBearsDict = {
'CentralArkansasBearsCover' : NCAAB.CentralArkansasBearsCover,
'CentralArkansasBearsML' : NCAAB.CentralArkansasBearsML,
'CentralArkansasBearsOU' : NCAAB.CentralArkansasBearsOU,
'CentralArkansasBearsSoloOU' : NCAAB.CentralArkansasBearsSoloOU,
'CentralArkansasBearsHalftime' : NCAAB.CentralArkansasBearsHalftime,
'CentralArkansasBearsHalftimeOU' : NCAAB.CentralArkansasBearsHalftimeOU,
}

IncarnateWordCardinalsDict = {
'IncarnateWordCardinalsCover' : NCAAB.IncarnateWordCardinalsCover,
'IncarnateWordCardinalsML' : NCAAB.IncarnateWordCardinalsML,
'IncarnateWordCardinalsOU' : NCAAB.IncarnateWordCardinalsOU,
'IncarnateWordCardinalsSoloOU' : NCAAB.IncarnateWordCardinalsSoloOU,
'IncarnateWordCardinalsHalftime' : NCAAB.IncarnateWordCardinalsHalftime,
'IncarnateWordCardinalsHalftimeOU' : NCAAB.IncarnateWordCardinalsHalftimeOU,
}

NewOrleansPrivateersDict = {
'NewOrleansPrivateersCover' : NCAAB.NewOrleansPrivateersCover,
'NewOrleansPrivateersML' : NCAAB.NewOrleansPrivateersML,
'NewOrleansPrivateersOU' : NCAAB.NewOrleansPrivateersOU,
'NewOrleansPrivateersSoloOU' : NCAAB.NewOrleansPrivateersSoloOU,
'NewOrleansPrivateersHalftime' : NCAAB.NewOrleansPrivateersHalftime,
'NewOrleansPrivateersHalftimeOU' : NCAAB.NewOrleansPrivateersHalftimeOU,
}

SELouisianaLionsDict = {
'SELouisianaLionsCover' : NCAAB.SELouisianaLionsCover,
'SELouisianaLionsML' : NCAAB.SELouisianaLionsML,
'SELouisianaLionsOU' : NCAAB.SELouisianaLionsOU,
'SELouisianaLionsSoloOU' : NCAAB.SELouisianaLionsSoloOU,
'SELouisianaLionsHalftime' : NCAAB.SELouisianaLionsHalftime,
'SELouisianaLionsHalftimeOU' : NCAAB.SELouisianaLionsHalftimeOU,
}

HoustonBaptistHuskiesDict = {
'HoustonBaptistHuskiesCover' : NCAAB.HoustonBaptistHuskiesCover,
'HoustonBaptistHuskiesML' : NCAAB.HoustonBaptistHuskiesML,
'HoustonBaptistHuskiesOU' : NCAAB.HoustonBaptistHuskiesOU,
'HoustonBaptistHuskiesSoloOU' : NCAAB.HoustonBaptistHuskiesSoloOU,
'HoustonBaptistHuskiesHalftime' : NCAAB.HoustonBaptistHuskiesHalftime,
'HoustonBaptistHuskiesHalftimeOU' : NCAAB.HoustonBaptistHuskiesHalftimeOU,
}

#SWAC Teams

PrairieViewAandMPanthersDict = {
'PrairieViewAandMPanthersCover' : NCAAB.PrairieViewAandMPanthersCover,
'PrairieViewAandMPanthersML' : NCAAB.PrairieViewAandMPanthersML,
'PrairieViewAandMPanthersOU' : NCAAB.PrairieViewAandMPanthersOU,
'PrairieViewAandMPanthersSoloOU' : NCAAB.PrairieViewAandMPanthersSoloOU,
'PrairieViewAandMPanthersHalftime' : NCAAB.PrairieViewAandMPanthersHalftime,
'PrairieViewAandMPanthersHalftimeOU' : NCAAB.PrairieViewAandMPanthersHalftimeOU,
}

SouthernJaguarsDict = {
'SouthernJaguarsCover' : NCAAB.SouthernJaguarsCover,
'SouthernJaguarsML' : NCAAB.SouthernJaguarsML,
'SouthernJaguarsOU' : NCAAB.SouthernJaguarsOU,
'SouthernJaguarsSoloOU' : NCAAB.SouthernJaguarsSoloOU,
'SouthernJaguarsHalftime' : NCAAB.SouthernJaguarsHalftime,
'SouthernJaguarsHalftimeOU' : NCAAB.SouthernJaguarsHalftimeOU,
}

TexasSouthernTigersDict = {
'TexasSouthernTigersCover' : NCAAB.TexasSouthernTigersCover,
'TexasSouthernTigersML' : NCAAB.TexasSouthernTigersML,
'TexasSouthernTigersOU' : NCAAB.TexasSouthernTigersOU,
'TexasSouthernTigersSoloOU' : NCAAB.TexasSouthernTigersSoloOU,
'TexasSouthernTigersHalftime' : NCAAB.TexasSouthernTigersHalftime,
'TexasSouthernTigersHalftimeOU' : NCAAB.TexasSouthernTigersHalftimeOU,
}

JacksonStateTigersDict = {
'JacksonStateTigersCover' : NCAAB.JacksonStateTigersCover,
'JacksonStateTigersML' : NCAAB.JacksonStateTigersML,
'JacksonStateTigersOU' : NCAAB.JacksonStateTigersOU,
'JacksonStateTigersSoloOU' : NCAAB.JacksonStateTigersSoloOU,
'JacksonStateTigersHalftime' : NCAAB.JacksonStateTigersHalftime,
'JacksonStateTigersHalftimeOU' : NCAAB.JacksonStateTigersHalftimeOU,
}

GramblingTigersDict = {
'GramblingTigersCover' : NCAAB.GramblingTigersCover,
'GramblingTigersML' : NCAAB.GramblingTigersML,
'GramblingTigersOU' : NCAAB.GramblingTigersOU,
'GramblingTigersSoloOU' : NCAAB.GramblingTigersSoloOU,
'GramblingTigersHalftime' : NCAAB.GramblingTigersHalftime,
'GramblingTigersHalftimeOU' : NCAAB.GramblingTigersHalftimeOU,
}

AlcornStateBravesDict = {
'AlcornStateBravesCover' : NCAAB.AlcornStateBravesCover,
'AlcornStateBravesML' : NCAAB.AlcornStateBravesML,
'AlcornStateBravesOU' : NCAAB.AlcornStateBravesOU,
'AlcornStateBravesSoloOU' : NCAAB.AlcornStateBravesSoloOU,
'AlcornStateBravesHalftime' : NCAAB.AlcornStateBravesHalftime,
'AlcornStateBravesHalftimeOU' : NCAAB.AlcornStateBravesHalftimeOU,
}

AlabamaStateHornetsDict = {
'AlabamaStateHornetsCover' : NCAAB.AlabamaStateHornetsCover,
'AlabamaStateHornetsML' : NCAAB.AlabamaStateHornetsML,
'AlabamaStateHornetsOU' : NCAAB.AlabamaStateHornetsOU,
'AlabamaStateHornetsSoloOU' : NCAAB.AlabamaStateHornetsSoloOU,
'AlabamaStateHornetsHalftime' : NCAAB.AlabamaStateHornetsHalftime,
'AlabamaStateHornetsHalftimeOU' : NCAAB.AlabamaStateHornetsHalftimeOU,
}

AlabamaAandMBulldogsDict = {
'AlabamaAandMBulldogsCover' : NCAAB.AlabamaAandMBulldogsCover,
'AlabamaAandMBulldogsML' : NCAAB.AlabamaAandMBulldogsML,
'AlabamaAandMBulldogsOU' : NCAAB.AlabamaAandMBulldogsOU,
'AlabamaAandMBulldogsSoloOU' : NCAAB.AlabamaAandMBulldogsSoloOU,
'AlabamaAandMBulldogsHalftime' : NCAAB.AlabamaAandMBulldogsHalftime,
'AlabamaAandMBulldogsHalftimeOU' : NCAAB.AlabamaAandMBulldogsHalftimeOU,
}

ArkansasPineBluffGoldenLionsDict = {
'ArkansasPineBluffGoldenLionsCover' : NCAAB.ArkansasPineBluffGoldenLionsCover,
'ArkansasPineBluffGoldenLionsML' : NCAAB.ArkansasPineBluffGoldenLionsML,
'ArkansasPineBluffGoldenLionsOU' : NCAAB.ArkansasPineBluffGoldenLionsOU,
'ArkansasPineBluffGoldenLionsSoloOU' : NCAAB.ArkansasPineBluffGoldenLionsSoloOU,
'ArkansasPineBluffGoldenLionsHalftime' : NCAAB.ArkansasPineBluffGoldenLionsHalftime,
'ArkansasPineBluffGoldenLionsHalftimeOU' : NCAAB.ArkansasPineBluffGoldenLionsHalftimeOU,
}

MississippiValleyStateDeltaDevilsDict = {
'MississippiValleyStateDeltaDevilsCover' : NCAAB.MississippiValleyStateDeltaDevilsCover,
'MississippiValleyStateDeltaDevilsML' : NCAAB.MississippiValleyStateDeltaDevilsML,
'MississippiValleyStateDeltaDevilsOU' : NCAAB.MississippiValleyStateDeltaDevilsOU,
'MississippiValleyStateDeltaDevilsSoloOU' : NCAAB.MississippiValleyStateDeltaDevilsSoloOU,
'MississippiValleyStateDeltaDevilsHalftime' : NCAAB.MississippiValleyStateDeltaDevilsHalftime,
'MississippiValleyStateDeltaDevilsHalftimeOU' : NCAAB.MississippiValleyStateDeltaDevilsHalftimeOU,
}

#Summit Teams

NorthDakotaStateBisonDict = {
'NorthDakotaStateBisonCover' : NCAAB.NorthDakotaStateBisonCover,
'NorthDakotaStateBisonML' : NCAAB.NorthDakotaStateBisonML,
'NorthDakotaStateBisonOU' : NCAAB.NorthDakotaStateBisonOU,
'NorthDakotaStateBisonSoloOU' : NCAAB.NorthDakotaStateBisonSoloOU,
'NorthDakotaStateBisonHalftime' : NCAAB.NorthDakotaStateBisonHalftime,
'NorthDakotaStateBisonHalftimeOU' : NCAAB.NorthDakotaStateBisonHalftimeOU,
}

SouthDakotaStateJackrabbitsDict = {
'SouthDakotaStateJackrabbitsCover' : NCAAB.SouthDakotaStateJackrabbitsCover,
'SouthDakotaStateJackrabbitsML' : NCAAB.SouthDakotaStateJackrabbitsML,
'SouthDakotaStateJackrabbitsOU' : NCAAB.SouthDakotaStateJackrabbitsOU,
'SouthDakotaStateJackrabbitsSoloOU' : NCAAB.SouthDakotaStateJackrabbitsSoloOU,
'SouthDakotaStateJackrabbitsHalftime' : NCAAB.SouthDakotaStateJackrabbitsHalftime,
'SouthDakotaStateJackrabbitsHalftimeOU' : NCAAB.SouthDakotaStateJackrabbitsHalftimeOU,
}

SouthDakotaCoyotesDict = {
'SouthDakotaCoyotesCover' : NCAAB.SouthDakotaCoyotesCover,
'SouthDakotaCoyotesML' : NCAAB.SouthDakotaCoyotesML,
'SouthDakotaCoyotesOU' : NCAAB.SouthDakotaCoyotesOU,
'SouthDakotaCoyotesSoloOU' : NCAAB.SouthDakotaCoyotesSoloOU,
'SouthDakotaCoyotesHalftime' : NCAAB.SouthDakotaCoyotesHalftime,
'SouthDakotaCoyotesHalftimeOU' : NCAAB.SouthDakotaCoyotesHalftimeOU,
}

OralRobertsGoldenEaglesDict = {
'OralRobertsGoldenEaglesCover' : NCAAB.OralRobertsGoldenEaglesCover,
'OralRobertsGoldenEaglesML' : NCAAB.OralRobertsGoldenEaglesML,
'OralRobertsGoldenEaglesOU' : NCAAB.OralRobertsGoldenEaglesOU,
'OralRobertsGoldenEaglesSoloOU' : NCAAB.OralRobertsGoldenEaglesSoloOU,
'OralRobertsGoldenEaglesHalftime' : NCAAB.OralRobertsGoldenEaglesHalftime,
'OralRobertsGoldenEaglesHalftimeOU' : NCAAB.OralRobertsGoldenEaglesHalftimeOU,
}

OmahaMavericksDict = {
'OmahaMavericksCover' : NCAAB.OmahaMavericksCover,
'OmahaMavericksML' : NCAAB.OmahaMavericksML,
'OmahaMavericksOU' : NCAAB.OmahaMavericksOU,
'OmahaMavericksSoloOU' : NCAAB.OmahaMavericksSoloOU,
'OmahaMavericksHalftime' : NCAAB.OmahaMavericksHalftime,
'OmahaMavericksHalftimeOU' : NCAAB.OmahaMavericksHalftimeOU,
}

NorthDakotaFightingHawksDict = {
'NorthDakotaFightingHawksCover' : NCAAB.NorthDakotaFightingHawksCover,
'NorthDakotaFightingHawksML' : NCAAB.NorthDakotaFightingHawksML,
'NorthDakotaFightingHawksOU' : NCAAB.NorthDakotaFightingHawksOU,
'NorthDakotaFightingHawksSoloOU' : NCAAB.NorthDakotaFightingHawksSoloOU,
'NorthDakotaFightingHawksHalftime' : NCAAB.NorthDakotaFightingHawksHalftime,
'NorthDakotaFightingHawksHalftimeOU' : NCAAB.NorthDakotaFightingHawksHalftimeOU,
}

PurdueFortWayneMastodonsDict = {
'PurdueFortWayneMastodonsCover' : NCAAB.PurdueFortWayneMastodonsCover,
'PurdueFortWayneMastodonsML' : NCAAB.PurdueFortWayneMastodonsML,
'PurdueFortWayneMastodonsOU' : NCAAB.PurdueFortWayneMastodonsOU,
'PurdueFortWayneMastodonsSoloOU' : NCAAB.PurdueFortWayneMastodonsSoloOU,
'PurdueFortWayneMastodonsHalftime' : NCAAB.PurdueFortWayneMastodonsHalftime,
'PurdueFortWayneMastodonsHalftimeOU' : NCAAB.PurdueFortWayneMastodonsHalftimeOU,
}

DenverPioneersDict = {
'DenverPioneersCover' : NCAAB.DenverPioneersCover,
'DenverPioneersML' : NCAAB.DenverPioneersML,
'DenverPioneersOU' : NCAAB.DenverPioneersOU,
'DenverPioneersSoloOU' : NCAAB.DenverPioneersSoloOU,
'DenverPioneersHalftime' : NCAAB.DenverPioneersHalftime,
'DenverPioneersHalftimeOU' : NCAAB.DenverPioneersHalftimeOU,
}

WesternIllinoisLeathernecksDict = {
'WesternIllinoisLeathernecksCover' : NCAAB.WesternIllinoisLeathernecksCover,
'WesternIllinoisLeathernecksML' : NCAAB.WesternIllinoisLeathernecksML,
'WesternIllinoisLeathernecksOU' : NCAAB.WesternIllinoisLeathernecksOU,
'WesternIllinoisLeathernecksSoloOU' : NCAAB.WesternIllinoisLeathernecksSoloOU,
'WesternIllinoisLeathernecksHalftime' : NCAAB.WesternIllinoisLeathernecksHalftime,
'WesternIllinoisLeathernecksHalftimeOU' : NCAAB.WesternIllinoisLeathernecksHalftimeOU,
}

#Sun Belt Teams

LittleRockTrojansDict = {
'LittleRockTrojansCover' : NCAAB.LittleRockTrojansCover,
'LittleRockTrojansML' : NCAAB.LittleRockTrojansML,
'LittleRockTrojansOU' : NCAAB.LittleRockTrojansOU,
'LittleRockTrojansSoloOU' : NCAAB.LittleRockTrojansSoloOU,
'LittleRockTrojansHalftime' : NCAAB.LittleRockTrojansHalftime,
'LittleRockTrojansHalftimeOU' : NCAAB.LittleRockTrojansHalftimeOU,
}

SouthAlabamaJaguarsDict = {
'SouthAlabamaJaguarsCover' : NCAAB.SouthAlabamaJaguarsCover,
'SouthAlabamaJaguarsML' : NCAAB.SouthAlabamaJaguarsML,
'SouthAlabamaJaguarsOU' : NCAAB.SouthAlabamaJaguarsOU,
'SouthAlabamaJaguarsSoloOU' : NCAAB.SouthAlabamaJaguarsSoloOU,
'SouthAlabamaJaguarsHalftime' : NCAAB.SouthAlabamaJaguarsHalftime,
'SouthAlabamaJaguarsHalftimeOU' : NCAAB.SouthAlabamaJaguarsHalftimeOU,
}

TexasStateBobcatsDict = {
'TexasStateBobcatsCover' : NCAAB.TexasStateBobcatsCover,
'TexasStateBobcatsML' : NCAAB.TexasStateBobcatsML,
'TexasStateBobcatsOU' : NCAAB.TexasStateBobcatsOU,
'TexasStateBobcatsSoloOU' : NCAAB.TexasStateBobcatsSoloOU,
'TexasStateBobcatsHalftime' : NCAAB.TexasStateBobcatsHalftime,
'TexasStateBobcatsHalftimeOU' : NCAAB.TexasStateBobcatsHalftimeOU,
}

GeorgiaSouthernEaglesDict = {
'GeorgiaSouthernEaglesCover' : NCAAB.GeorgiaSouthernEaglesCover,
'GeorgiaSouthernEaglesML' : NCAAB.GeorgiaSouthernEaglesML,
'GeorgiaSouthernEaglesOU' : NCAAB.GeorgiaSouthernEaglesOU,
'GeorgiaSouthernEaglesSoloOU' : NCAAB.GeorgiaSouthernEaglesSoloOU,
'GeorgiaSouthernEaglesHalftime' : NCAAB.GeorgiaSouthernEaglesHalftime,
'GeorgiaSouthernEaglesHalftimeOU' : NCAAB.GeorgiaSouthernEaglesHalftimeOU,
}

GeorgiaStatePanthersDict = {
'GeorgiaStatePanthersCover' : NCAAB.GeorgiaStatePanthersCover,
'GeorgiaStatePanthersML' : NCAAB.GeorgiaStatePanthersML,
'GeorgiaStatePanthersOU' : NCAAB.GeorgiaStatePanthersOU,
'GeorgiaStatePanthersSoloOU' : NCAAB.GeorgiaStatePanthersSoloOU,
'GeorgiaStatePanthersHalftime' : NCAAB.GeorgiaStatePanthersHalftime,
'GeorgiaStatePanthersHalftimeOU' : NCAAB.GeorgiaStatePanthersHalftimeOU,
}

AppalachianStateMountaineersDict = {
'AppalachianStateMountaineersCover' : NCAAB.AppalachianStateMountaineersCover,
'AppalachianStateMountaineersML' : NCAAB.AppalachianStateMountaineersML,
'AppalachianStateMountaineersOU' : NCAAB.AppalachianStateMountaineersOU,
'AppalachianStateMountaineersSoloOU' : NCAAB.AppalachianStateMountaineersSoloOU,
'AppalachianStateMountaineersHalftime' : NCAAB.AppalachianStateMountaineersHalftime,
'AppalachianStateMountaineersHalftimeOU' : NCAAB.AppalachianStateMountaineersHalftimeOU,
}

UTArlingtonMavericksDict = {
'UTArlingtonMavericksCover' : NCAAB.UTArlingtonMavericksCover,
'UTArlingtonMavericksML' : NCAAB.UTArlingtonMavericksML,
'UTArlingtonMavericksOU' : NCAAB.UTArlingtonMavericksOU,
'UTArlingtonMavericksSoloOU' : NCAAB.UTArlingtonMavericksSoloOU,
'UTArlingtonMavericksHalftime' : NCAAB.UTArlingtonMavericksHalftime,
'UTArlingtonMavericksHalftimeOU' : NCAAB.UTArlingtonMavericksHalftimeOU,
}

LouisianaRaginCajunsDict = {
'LouisianaRaginCajunsCover' : NCAAB.LouisianaRaginCajunsCover,
'LouisianaRaginCajunsML' : NCAAB.LouisianaRaginCajunsML,
'LouisianaRaginCajunsOU' : NCAAB.LouisianaRaginCajunsOU,
'LouisianaRaginCajunsSoloOU' : NCAAB.LouisianaRaginCajunsSoloOU,
'LouisianaRaginCajunsHalftime' : NCAAB.LouisianaRaginCajunsHalftime,
'LouisianaRaginCajunsHalftimeOU' : NCAAB.LouisianaRaginCajunsHalftimeOU,
}

ArkansasStRedWolvesDict = {
'ArkansasStRedWolvesCover' : NCAAB.ArkansasStRedWolvesCover,
'ArkansasStRedWolvesML' : NCAAB.ArkansasStRedWolvesML,
'ArkansasStRedWolvesOU' : NCAAB.ArkansasStRedWolvesOU,
'ArkansasStRedWolvesSoloOU' : NCAAB.ArkansasStRedWolvesSoloOU,
'ArkansasStRedWolvesHalftime' : NCAAB.ArkansasStRedWolvesHalftime,
'ArkansasStRedWolvesHalftimeOU' : NCAAB.ArkansasStRedWolvesHalftimeOU,
}

CoastalCarolinaChanticleersDict = {
'CoastalCarolinaChanticleersCover' : NCAAB.CoastalCarolinaChanticleersCover,
'CoastalCarolinaChanticleersML' : NCAAB.CoastalCarolinaChanticleersML,
'CoastalCarolinaChanticleersOU' : NCAAB.CoastalCarolinaChanticleersOU,
'CoastalCarolinaChanticleersSoloOU' : NCAAB.CoastalCarolinaChanticleersSoloOU,
'CoastalCarolinaChanticleersHalftime' : NCAAB.CoastalCarolinaChanticleersHalftime,
'CoastalCarolinaChanticleersHalftimeOU' : NCAAB.CoastalCarolinaChanticleersHalftimeOU,
}

ULMonroeWarhawksDict = {
'ULMonroeWarhawksCover' : NCAAB.ULMonroeWarhawksCover,
'ULMonroeWarhawksML' : NCAAB.ULMonroeWarhawksML,
'ULMonroeWarhawksOU' : NCAAB.ULMonroeWarhawksOU,
'ULMonroeWarhawksSoloOU' : NCAAB.ULMonroeWarhawksSoloOU,
'ULMonroeWarhawksHalftime' : NCAAB.ULMonroeWarhawksHalftime,
'ULMonroeWarhawksHalftimeOU' : NCAAB.ULMonroeWarhawksHalftimeOU,
}

TroyTrojansDict = {
'TroyTrojansCover' : NCAAB.TroyTrojansCover,
'TroyTrojansML' : NCAAB.TroyTrojansML,
'TroyTrojansOU' : NCAAB.TroyTrojansOU,
'TroyTrojansSoloOU' : NCAAB.TroyTrojansSoloOU,
'TroyTrojansHalftime' : NCAAB.TroyTrojansHalftime,
'TroyTrojansHalftimeOU' : NCAAB.TroyTrojansHalftimeOU,
}

#West Coast

GonzagaBulldogsDict = {
'GonzagaBulldogsCover' : NCAAB.GonzagaBulldogsCover,
'GonzagaBulldogsML' : NCAAB.GonzagaBulldogsML,
'GonzagaBulldogsOU' : NCAAB.GonzagaBulldogsOU,
'GonzagaBulldogsSoloOU' : NCAAB.GonzagaBulldogsSoloOU,
'GonzagaBulldogsHalftime' : NCAAB.GonzagaBulldogsHalftime,
'GonzagaBulldogsHalftimeOU' : NCAAB.GonzagaBulldogsHalftimeOU,
}

BYUCougarsDict = {
'BYUCougarsCover' : NCAAB.BYUCougarsCover,
'BYUCougarsML' : NCAAB.BYUCougarsML,
'BYUCougarsOU' : NCAAB.BYUCougarsOU,
'BYUCougarsSoloOU' : NCAAB.BYUCougarsSoloOU,
'BYUCougarsHalftime' : NCAAB.BYUCougarsHalftime,
'BYUCougarsHalftimeOU' : NCAAB.BYUCougarsHalftimeOU,
}

SaintMarysGaelsDict = {
'SaintMarysGaelsCover' : NCAAB.SaintMarysGaelsCover,
'SaintMarysGaelsML' : NCAAB.SaintMarysGaelsML,
'SaintMarysGaelsOU' : NCAAB.SaintMarysGaelsOU,
'SaintMarysGaelsSoloOU' : NCAAB.SaintMarysGaelsSoloOU,
'SaintMarysGaelsHalftime' : NCAAB.SaintMarysGaelsHalftime,
'SaintMarysGaelsHalftimeOU' : NCAAB.SaintMarysGaelsHalftimeOU,
}

PacificTigersDict = {
'PacificTigersCover' : NCAAB.PacificTigersCover,
'PacificTigersML' : NCAAB.PacificTigersML,
'PacificTigersOU' : NCAAB.PacificTigersOU,
'PacificTigersSoloOU' : NCAAB.PacificTigersSoloOU,
'PacificTigersHalftime' : NCAAB.PacificTigersHalftime,
'PacificTigersHalftimeOU' : NCAAB.PacificTigersHalftimeOU,
}

SanFranciscoDonsDict = {
'SanFranciscoDonsCover' : NCAAB.SanFranciscoDonsCover,
'SanFranciscoDonsML' : NCAAB.SanFranciscoDonsML,
'SanFranciscoDonsOU' : NCAAB.SanFranciscoDonsOU,
'SanFranciscoDonsSoloOU' : NCAAB.SanFranciscoDonsSoloOU,
'SanFranciscoDonsHalftime' : NCAAB.SanFranciscoDonsHalftime,
'SanFranciscoDonsHalftimeOU' : NCAAB.SanFranciscoDonsHalftimeOU,
}

PepperdineWavesDict = {
'PepperdineWavesCover' : NCAAB.PepperdineWavesCover,
'PepperdineWavesML' : NCAAB.PepperdineWavesML,
'PepperdineWavesOU' : NCAAB.PepperdineWavesOU,
'PepperdineWavesSoloOU' : NCAAB.PepperdineWavesSoloOU,
'PepperdineWavesHalftime' : NCAAB.PepperdineWavesHalftime,
'PepperdineWavesHalftimeOU' : NCAAB.PepperdineWavesHalftimeOU,
}

SantaClaraBroncosDict = {
'SantaClaraBroncosCover' : NCAAB.SantaClaraBroncosCover,
'SantaClaraBroncosML' : NCAAB.SantaClaraBroncosML,
'SantaClaraBroncosOU' : NCAAB.SantaClaraBroncosOU,
'SantaClaraBroncosSoloOU' : NCAAB.SantaClaraBroncosSoloOU,
'SantaClaraBroncosHalftime' : NCAAB.SantaClaraBroncosHalftime,
'SantaClaraBroncosHalftimeOU' : NCAAB.SantaClaraBroncosHalftimeOU,
}

LoyolaMarymountLionsDict = {
'LoyolaMarymountLionsCover' : NCAAB.LoyolaMarymountLionsCover,
'LoyolaMarymountLionsML' : NCAAB.LoyolaMarymountLionsML,
'LoyolaMarymountLionsOU' : NCAAB.LoyolaMarymountLionsOU,
'LoyolaMarymountLionsSoloOU' : NCAAB.LoyolaMarymountLionsSoloOU,
'LoyolaMarymountLionsHalftime' : NCAAB.LoyolaMarymountLionsHalftime,
'LoyolaMarymountLionsHalftimeOU' : NCAAB.LoyolaMarymountLionsHalftimeOU,
}

SanDiegoTorerosDict = {
'SanDiegoTorerosCover' : NCAAB.SanDiegoTorerosCover,
'SanDiegoTorerosML' : NCAAB.SanDiegoTorerosML,
'SanDiegoTorerosOU' : NCAAB.SanDiegoTorerosOU,
'SanDiegoTorerosSoloOU' : NCAAB.SanDiegoTorerosSoloOU,
'SanDiegoTorerosHalftime' : NCAAB.SanDiegoTorerosHalftime,
'SanDiegoTorerosHalftimeOU' : NCAAB.SanDiegoTorerosHalftimeOU,
}

PortlandPilotsDict = {
'PortlandPilotsCover' : NCAAB.PortlandPilotsCover,
'PortlandPilotsML' : NCAAB.PortlandPilotsML,
'PortlandPilotsOU' : NCAAB.PortlandPilotsOU,
'PortlandPilotsSoloOU' : NCAAB.PortlandPilotsSoloOU,
'PortlandPilotsHalftime' : NCAAB.PortlandPilotsHalftime,
'PortlandPilotsHalftimeOU' : NCAAB.PortlandPilotsHalftimeOU,
}

#WAC Teams

NewMexicoStateAggiesDict = {
'NewMexicoStateAggiesCover' : NCAAB.NewMexicoStateAggiesCover,
'NewMexicoStateAggiesML' : NCAAB.NewMexicoStateAggiesML,
'NewMexicoStateAggiesOU' : NCAAB.NewMexicoStateAggiesOU,
'NewMexicoStateAggiesSoloOU' : NCAAB.NewMexicoStateAggiesSoloOU,
'NewMexicoStateAggiesHalftime' : NCAAB.NewMexicoStateAggiesHalftime,
'NewMexicoStateAggiesHalftimeOU' : NCAAB.NewMexicoStateAggiesHalftimeOU,
}

CaliforniaBaptistLancersDict = {
'CaliforniaBaptistLancersCover' : NCAAB.CaliforniaBaptistLancersCover,
'CaliforniaBaptistLancersML' : NCAAB.CaliforniaBaptistLancersML,
'CaliforniaBaptistLancersOU' : NCAAB.CaliforniaBaptistLancersOU,
'CaliforniaBaptistLancersSoloOU' : NCAAB.CaliforniaBaptistLancersSoloOU,
'CaliforniaBaptistLancersHalftime' : NCAAB.CaliforniaBaptistLancersHalftime,
'CaliforniaBaptistLancersHalftimeOU' : NCAAB.CaliforniaBaptistLancersHalftimeOU,
}

UTRioGrandeValleyVaquerosDict = {
'UTRioGrandeValleyVaquerosCover' : NCAAB.UTRioGrandeValleyVaquerosCover,
'UTRioGrandeValleyVaquerosML' : NCAAB.UTRioGrandeValleyVaquerosML,
'UTRioGrandeValleyVaquerosOU' : NCAAB.UTRioGrandeValleyVaquerosOU,
'UTRioGrandeValleyVaquerosSoloOU' : NCAAB.UTRioGrandeValleyVaquerosSoloOU,
'UTRioGrandeValleyVaquerosHalftime' : NCAAB.UTRioGrandeValleyVaquerosHalftime,
'UTRioGrandeValleyVaquerosHalftimeOU' : NCAAB.UTRioGrandeValleyVaquerosHalftimeOU,
}

UMKCKangaroosDict = {
'UMKCKangaroosCover' : NCAAB.UMKCKangaroosCover,
'UMKCKangaroosML' : NCAAB.UMKCKangaroosML,
'UMKCKangaroosOU' : NCAAB.UMKCKangaroosOU,
'UMKCKangaroosSoloOU' : NCAAB.UMKCKangaroosSoloOU,
'UMKCKangaroosHalftime' : NCAAB.UMKCKangaroosHalftime,
'UMKCKangaroosHalftimeOU' : NCAAB.UMKCKangaroosHalftimeOU,
}

GrandCanyonAntelopesDict = {
'GrandCanyonAntelopesCover' : NCAAB.GrandCanyonAntelopesCover,
'GrandCanyonAntelopesML' : NCAAB.GrandCanyonAntelopesML,
'GrandCanyonAntelopesOU' : NCAAB.GrandCanyonAntelopesOU,
'GrandCanyonAntelopesSoloOU' : NCAAB.GrandCanyonAntelopesSoloOU,
'GrandCanyonAntelopesHalftime' : NCAAB.GrandCanyonAntelopesHalftime,
'GrandCanyonAntelopesHalftimeOU' : NCAAB.GrandCanyonAntelopesHalftimeOU,
}

SeattleRedhawksDict = {
'SeattleRedhawksCover' : NCAAB.SeattleRedhawksCover,
'SeattleRedhawksML' : NCAAB.SeattleRedhawksML,
'SeattleRedhawksOU' : NCAAB.SeattleRedhawksOU,
'SeattleRedhawksSoloOU' : NCAAB.SeattleRedhawksSoloOU,
'SeattleRedhawksHalftime' : NCAAB.SeattleRedhawksHalftime,
'SeattleRedhawksHalftimeOU' : NCAAB.SeattleRedhawksHalftimeOU,
}

CSUBakersfieldRoadrunnersDict = {
'CSUBakersfieldRoadrunnersCover' : NCAAB.CSUBakersfieldRoadrunnersCover,
'CSUBakersfieldRoadrunnersML' : NCAAB.CSUBakersfieldRoadrunnersML,
'CSUBakersfieldRoadrunnersOU' : NCAAB.CSUBakersfieldRoadrunnersOU,
'CSUBakersfieldRoadrunnersSoloOU' : NCAAB.CSUBakersfieldRoadrunnersSoloOU,
'CSUBakersfieldRoadrunnersHalftime' : NCAAB.CSUBakersfieldRoadrunnersHalftime,
'CSUBakersfieldRoadrunnersHalftimeOU' : NCAAB.CSUBakersfieldRoadrunnersHalftimeOU,
}

UtahValleyWolverinesDict = {
'UtahValleyWolverinesCover' : NCAAB.UtahValleyWolverinesCover,
'UtahValleyWolverinesML' : NCAAB.UtahValleyWolverinesML,
'UtahValleyWolverinesOU' : NCAAB.UtahValleyWolverinesOU,
'UtahValleyWolverinesSoloOU' : NCAAB.UtahValleyWolverinesSoloOU,
'UtahValleyWolverinesHalftime' : NCAAB.UtahValleyWolverinesHalftime,
'UtahValleyWolverinesHalftimeOU' : NCAAB.UtahValleyWolverinesHalftimeOU,
}

ChicagoStateCougarsDict = {
'ChicagoStateCougarsCover' : NCAAB.ChicagoStateCougarsCover,
'ChicagoStateCougarsML' : NCAAB.ChicagoStateCougarsML,
'ChicagoStateCougarsOU' : NCAAB.ChicagoStateCougarsOU,
'ChicagoStateCougarsSoloOU' : NCAAB.ChicagoStateCougarsSoloOU,
'ChicagoStateCougarsHalftime' : NCAAB.ChicagoStateCougarsHalftime,
'ChicagoStateCougarsHalftimeOU' : NCAAB.ChicagoStateCougarsHalftimeOU,
}

A10Dict = {**DavidsonWildcatsDict, **DaytonFlyersDict, **DuquesneDukesDict,**FordhamRamsDict,**GeorgeMasonPatriotsDict,**GeorgeWashingtonColonialsDict,**LaSalleExplorersDict,**UMassMinutemenDict,**RhodeIslandRamsDict,**RichmondSpidersDict,**SaintJosephsHawksDict,**SaintLouisBillikensDict,**StBonaventureBonniesDict,**VCURamsDict}

AmericanAthleticDict = {**CincinnatiBearcatsDict, **UConnHuskiesDict, **EastCarolinaPiratesDict, **HoustonCougarsDict, **MemphisTigersDict, **SMUMustangsDict, **SouthFloridaBullsDict, **TempleOwlsDict, **TulaneGreenWaveDict, **TulsaGoldenHurricaneDict, **UCFKnightsDict, **WichitaStateShockersDict}

AtlanticCoastDict = {**FloridaStateSeminolesDict, **BostonCollegeEaglesDict, **ClemsonTigersDict, **DukeBlueDevilsDict, **GeorgiaTechYellowJacketsDict, **LouisvilleCardinalsDict, **NorthCarolinaTarHeelsDict, **NCStateWolfpackDict, **NotreDameFightingIrishDict, **PittsburghPanthersDict, **SyracuseOrangeDict, **VirginiaCavaliersDict, **VirginiaTechHokiesDict, **WakeForestDemonDeaconsDict}

AmericanEastDict = {**AlbanyGreatDanesDict, **BinghamtonBearcatsDict, **HartfordHawksDict, **MaineBlackBearssDict, **UMassLowellRiverHawkssDict, **NewHampshireWildcatssDict, **StonyBrookSeawolvessDict, **UMBCRetrieverssDict, **VermontCatamountsDict}

ASUNDict = {**FloridaGulfCoastEaglesDict, **JacksonvilleDolphinsDict, **KennesawStateOwlsDict, **LibertyFlamesDict, **LipscombBisonsDict, **NJITHighlandersDict, **NorthAlabamaLionsDict, **NorthFloridaOspreysDict, **StetsonHattersDict}

Big12Dict = {**BaylorBearsDict, **IowaStateCyclonesDict, **KansasJayhawksDict, **KansasStateWildcatsDict, **OklahomaSoonersDict, **OklahomaStateCowboysDict, **TCUHornedFrogsDict, **TexasLonghornsDict, **TexasTechRedRaidersDict, **WestVirginiaMountaineersDict}

BigEastDict = {**ButlerBulldogsDict, **CreightonBluejaysDict, **DePaulBlueDemonsDict, **GeorgetownHoyasDict, **MarquetteGoldenEaglesDict, **ProvidenceFriarsDict, **SetonHallPiratesDict, **StJohnsRedStormDict, **VillanovaWildcatsDict, **XavierMusketeersDict}

BigSkyDict = {**EasternWashingtonEaglesDict, **IdahoVandalsDict, **IdahoStateBengalsDict, **MontanaGrizzliesDict, **MontanaStateBobcatsDict, **NorthernArizonaLumberjacksDict, **NorthernColoradoBearsDict, **PortlandStateVikingsDict, **SacramentoStateHornetsDict, **SouthernUtahThunderbirdsDict, **WeberStateWildcatsDict}

BigSouthDict = {**CampbellFightingCamelsDict, **CharlestonSouthernBuccaneersDict, **GardnerWebbBulldogsDict, **HamptonPiratesDict, **HighPointPanthersDict, **LongwoodLancersDict, **PresbyterianBlueHoseDict, **RadfordHighlandersDict, **UNCAshevilleBulldogsDict, **SouthCarolinaUpstateSpartansDict, **WinthropEaglesDict}

Big10Dict = {**IllinoisFightingIlliniDict, **IndianaHoosiersDict, **IowaHawkeyesDict, **MarylandTerrapinsDict, **MichiganStateSpartansDict, **MinnesotaGoldenGophersDict, **NebraskaCornhuskersDict, **NorthwesternWildcatsDict, **OhioStateBuckeyesDict, **PennStateNittanyLionsDict, **PurdueBoilermakersDict, **RutgersScarletKnightsDict, **WisconsinBadgersDict}

BigWestDict = {**CalPolyMustangsDict, **CSUFullertonTitansDict, **CSUNorthridgeMatadorsDict, **HawaiiRainbowWarriorsDict, **LongBeachState49ersDict, **UCDavisAggiesDict, **UCIrvineAnteatersDict, **UCRiversideHighlandersDict, **UCSantaBarbaraGauchosDict}

ColonialDict = {**CharlestonCougarsDict, **DelawareBlueHensDict, **DrexelDragonsDict, **ElonPhoenixDict, **HofstraPrideDict, **JamesMadisonDukesDict, **UNCWilmingtonSeahawksDict, **NortheasternHuskiesDict, **TowsonTigersDict, **WilliamandMaryTribeDict}

ConferenceUSADict = {**Charlotte49ersDict, **RiceOwlsDict, **FloridaInternationalPanthersDict, **LouisianaTechBulldogsDict, **MarshallThunderingHerdDict, **MiddleTennesseeBlueRaidersDict, **NorthTexasMeanGreenDict, **OldDominionMonarchsDict, **FloridaAtlanticOwlsDict, **SouthernMissGoldenEaglesDict, **UABBlazersDict, **UTEPMinersDict, **UTSARoadrunnersDict, **WesternKentuckyHilltoppersDict}

HorizonDict = {**ClevelandStateVikingsDict, **DetroitMercyTitansDict, **GreenBayPhoenixDict, **UICFlamesDict, **IUPUIJaguarsDict, **MilwaukeePanthersDict, **NorthernKentuckyNorseDict, **OaklandGoldenGrizzliesDict, **WrightStateRaidersDict, **YoungstownStPenguinsDict}

IvyDict = {**BrownBearsDict, **ColumbiaLionsDict, **CornellBigRedDict, **DartmouthBigGreenDict, **HarvardCrimsonDict, **PennsylvaniaQuakersDict, **PrincetonTigersDict, **YaleBulldogsDict}

MAACDict = {**CanisiusGoldenGriffinsDict, **FairfieldStagsDict, **IonaGaelsDict, **ManhattanJaspersDict, **MaristRedFoxesDict, **MonmouthHawksDict, **NiagaraPurpleEaglesDict, **QuinnipiacBobcatsDict, **RiderBroncsDict, **SienaSaintsDict, **SaintPetersPeacocksDict}

MidAmericanDict = {**AkronZipsDict, **BallStateCardinalsDict, **BowlingGreenFalconsDict, **BuffaloBullsDict, **CentralMichiganChippewasDict, **EasternMichiganEaglesDict, **KentStateGoldenFlashesDict, **MiamiOHRedHawksDict, **NorthernIllinoisHuskiesDict, **OhioBobcatsDict, **ToledoRocketsDict, **WesternMichiganBroncosDict}

MidEasternAthleticDict = {**BethuneCookmanWildcatsDict, **CoppinStateEaglesDict, **DelawareStateHornetsDict, **FloridaAandMRattlersDict, **HowardBisonDict, **MarylandEasternShoreHawksDict, **MorganStateBearsDict, **NorfolkStateSpartansDict, **NorthCarolinaAandTAggiesDict, **NorthCarolinaCentralEaglesDict, **SouthCarolinaStateBulldogsDict}

MissouriValleyDict = {**BradleyBravesDict, **DrakeBulldogsDict, **EvansvillePurpleAcesDict, **IllinoisStateRedbirdsDict, **IndianaStateSycamoresDict, **LoyolaChicagoRamblersDict, **MissouriStateBearsDict, **NorthernIowaPanthersDict, **SouthernIllinoisSalukisDict, **ValparaisoCrusadersDict}

MountainWestDict = {**AirForceFalconsDict, **BoiseStateBroncosDict, **ColoradoStateRamsDict, **FresnoStateBulldogsDict, **NevadaWolfPackDict, **NewMexicoLobosDict, **SanDiegoStateAztecsDict, **SanJoseStateSpartansDict, **UNLVRebelsDict, **UtahStateAggiesDict, **WyomingCowboysDict}

NorthEastDict = {**BryantBulldogsDict, **CentralConnecticutBlueDevilsDict, **FairleighDickinsonKnightsDict, **LongIslandUniversitySharksDict, **MerrimackWarriorsDict, **MtStMarysMountaineersDict, **RobertMorrisColonialsDict, **SacredHeartPioneersDict, **StFrancisBKNTerriersDict, **StFrancisPARedFlashDict, **WagnerSeahawksDict}

OhioValleyDict = {**AustinPeayGovernorsDict, **BelmontBruinsDict, **EasternIllinoisPanthersDict, **EasternKentuckyColonelsDict, **JacksonvilleStateGamecocksDict, **MoreheadStateEaglesDict, **MurrayStateRacersDict, **SIUEdwardsvilleCougarsDict, **SEMissouriStRedhawksDict, **TennesseeStateTigersDict, **TennesseeTechGoldenEaglesDict, **UTMartinSkyhawksDict}

Pac12Dict = {**ArizonaWildcatsDict, **ArizonaStateSunDevilsDict, **CaliforniaGoldenBearsDict, **ColoradoBuffaloesDict, **OregonDucksDict, **OregonStateBeaversDict, **StanfordCardinalsDict, **UCLABruinsDict, **USCTrojansDict, **UtahUtesDict, **WashingtonHuskiesDict, **WashingtonStateCougarsDict}

PatriotDict = {**AmericanEaglesDict, **ArmyBlackKnightsDict, **BostonUnivTerriersDict, **BucknellBisonDict, **ColgateRaidersDict, **HolyCrossCrusadersDict, **LafayetteLeopardsDict, **LehighMountainHawksDict, **LoyolaMDGreyhoundsDict, **NavyMidshipmenDict}

SouthEasternDict = {**AlabamaCrimsonTideDict, **ArkansasRazorbacksDict, **AuburnTigersDict, **FloridaGatorsDict, **GeorgiaBulldogsDict, **KentuckyWildcatsDict, **LSUTigersDict, **MississippiStateBulldogsDict, **MissouriTigersDict, **OleMissRebelsDict, **SouthCarolinaGamecocksDict, **TennesseeVolunteersDict, **TexasAandMAggiesDict, **VanderbiltCommodoresDict}

SouthernDict = {**ChattanoogaMocsDict, **TheCitadelBulldogsDict, **EastTennesseeStateBuccaneersDict, **FurmanPaladinsDict, **MercerBearsDict, **SamfordBulldogsDict, **UNCGreensboroSpartansDict, **VMIKeydetsDict, **WesternCarolinaCatamountsDict, **WoffordTerriersDict}

SouthlandDict = {**AbileneChristianWildcatsDict, **CentralArkansasBearsDict, **HoustonBaptistHuskiesDict, **IncarnateWordCardinalsDict, **LamarCardinalsDict, **McNeeseCowboysDict, **NewOrleansPrivateersDict, **NichollsColonelsDict, **NorthwesternStateDemonsDict, **SamHoustonStateBearkatsDict, **SELouisianaLionsDict, **StephenFAustinLumberjacksDict, **TexasAandMCCIslandersDict}

SummitDict = {**DenverPioneersDict, **OmahaMavericksDict, **NorthDakotaFightingHawksDict, **NorthDakotaStateBisonDict, **OralRobertsGoldenEaglesDict, **PurdueFortWayneMastodonsDict, **SouthDakotaCoyotesDict, **SouthDakotaStateJackrabbitsDict, **WesternIllinoisLeathernecksDict}

SunBeltDict = {**AppalachianStateMountaineersDict, **ArkansasStRedWolvesDict, **LittleRockTrojansDict, **CoastalCarolinaChanticleersDict, **GeorgiaSouthernEaglesDict, **GeorgiaStatePanthersDict, **LouisianaRaginCajunsDict, **ULMonroeWarhawksDict, **SouthAlabamaJaguarsDict, **TexasStateBobcatsDict, **UTArlingtonMavericksDict, **TroyTrojansDict}

SWACDict = {**AlabamaAandMBulldogsDict, **AlabamaStateHornetsDict, **AlcornStateBravesDict, **ArkansasPineBluffGoldenLionsDict, **GramblingTigersDict, **JacksonStateTigersDict, **MississippiValleyStateDeltaDevilsDict, **PrairieViewAandMPanthersDict, **SouthernJaguarsDict, **TexasSouthernTigersDict}

WACDict = {**CSUBakersfieldRoadrunnersDict, **CaliforniaBaptistLancersDict, **ChicagoStateCougarsDict, **GrandCanyonAntelopesDict, **UMKCKangaroosDict, **NewMexicoStateAggiesDict, **SeattleRedhawksDict, **UTRioGrandeValleyVaquerosDict, **UtahValleyWolverinesDict}

WestCoastDict = {**BYUCougarsDict, **GonzagaBulldogsDict, **LoyolaMarymountLionsDict, **PacificTigersDict, **PepperdineWavesDict, **PortlandPilotsDict, **SaintMarysGaelsDict, **SanDiegoTorerosDict, **SanFranciscoDonsDict, **SantaClaraBroncosDict}

NCAABDict = {**A10Dict, **AmericanAthleticDict, **AtlanticCoastDict, **AmericanEastDict,**ASUNDict, **Big12Dict, **BigEastDict, **BigSkyDict, **BigSouthDict, **Big10Dict, **BigWestDict, **ColonialDict, **ConferenceUSADict, **HorizonDict, **IvyDict, **MAACDict, **MidAmericanDict, **MidEasternAthleticDict, **MissouriValleyDict, **MountainWestDict, **NorthEastDict, **OhioValleyDict, **Pac12Dict, **PatriotDict, **SouthEasternDict, **SouthernDict, **SouthlandDict, **SummitDict, **SunBeltDict, **SWACDict, **WACDict, **WestCoastDict}

OrderedNCAABDict = sorted(NCAABDict.items(), key=operator.itemgetter(1), reverse = True)[:5]

#Remember to reverse the order in order to see if the Under % is top 5

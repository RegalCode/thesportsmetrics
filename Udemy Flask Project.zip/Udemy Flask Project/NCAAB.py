import gspread
from oauth2client.service_account import ServiceAccountCredentials
import operator

# use creds to create a client to interact with the Google Drive API
scope = ['https://spreadsheets.google.com/feeds','https://www.googleapis.com/auth/drive']
creds = ServiceAccountCredentials.from_json_keyfile_name('Team_Analytics.json', scope)
client = gspread.authorize(creds)

# Find a workbook by name and open the first sheet
# Make sure you use the right name here.
AmericaEast = client.open("America East Conference Team Analytics")
AmericanAthletic = client.open("American Athletic Conference Team Analytics")
ASUN = client.open("ASUN Conference Team Analytics")
Atlantic10 = client.open("Atlantic 10 Conference Team Analytics")
AtlanticCoast = client.open("Atlantic Coast Conference Team Analytics")
Big12 = client.open("Big 12 Conference Team Analytics")
BigEast = client.open("Big East Conference Team Analytics")
BigSky = client.open("Big Sky Conference Team Analytics")
BigSouth = client.open("Big South Conference Team Analytics")
Big10 = client.open("Big Ten Conference Team Analytics")
BigWest = client.open("Big West Conference Team Analytics")
ColonialAthletic = client.open("Colonial Athletic Association Team Analytics")
ConferenceUSA = client.open("Conference USA Team Analytics")
Horizon = client.open("Horizon League Team Analytics")
Ivy = client.open("Ivy League Team Analytics")
MAAC = client.open("Metro Atlantic Athletic Conference Team Analytics")
MidAmericanEast = client.open("Mid-America East Conference Team Analytics")
MidAmericanWest = client.open("Mid-America West Conference Team Analytics")
MidEasternAthletic = client.open("Mid-Eastern Athletic Conference Team Analytics")
MissouriValley = client.open("Missouri Valley Conference Team Analytics")
MountainWest = client.open("Mountain West Conference Team Analytics")
NorthEast = client.open("Northeast Conference Team Analytics")
OhioValley = client.open("Ohio Valley Conference Team Analytics")
Pac12 = client.open("Pac-12 Conference Team Analytics")
Patriot = client.open("Patriot League Team Analytics")
SouthEastern = client.open("Southeastern Conference Team Analytics")
Southern = client.open("Southern Conference Team Analytics")
SouthLand = client.open("Southland Conference Team Analytics")
SWAC = client.open("Southwestern Athletic Conference Team Analytics")
Summit = client.open("Summit League Team Analytics")
SunBelt = client.open("Sun Belt Conference Team Analytics")
WestCoast = client.open("West Coast Conference Team Analytics")
WAC = client.open("Western Athletic Conference Team Analytics")

#America East Teams

VermontCatamountsList = AmericaEast.worksheet("Vermont Catamounts").get_all_values()
VermontCatamounts = VermontCatamountsList[1]
VermontCatamountsCover = VermontCatamounts[5]
VermontCatamountsML = VermontCatamounts[6]
VermontCatamountsOU = VermontCatamounts[8]
VermontCatamountsSoloOU = VermontCatamounts[10]
VermontCatamountsHalftime = VermontCatamounts[14]
VermontCatamountsHalftimeOU = VermontCatamounts[16]

StonyBrookSeawolvesList = AmericaEast.worksheet("Stony Brook Seawolves").get_all_values()
StonyBrookSeawolves = StonyBrookSeawolvesList[1]
StonyBrookSeawolvesCover = StonyBrookSeawolves[5]
StonyBrookSeawolvesML = StonyBrookSeawolves[6]
StonyBrookSeawolvesOU = StonyBrookSeawolves[8]
StonyBrookSeawolvesSoloOU = StonyBrookSeawolves[10]
StonyBrookSeawolvesHalftime = StonyBrookSeawolves[14]
StonyBrookSeawolvesHalftimeOU = StonyBrookSeawolves[16]

HartfordHawksList = AmericaEast.worksheet("Hartford Hawks").get_all_values()
HartfordHawks = HartfordHawksList[1]
HartfordHawksCover = HartfordHawks[5]
HartfordHawksML = HartfordHawks[6]
HartfordHawksOU = HartfordHawks[8]
HartfordHawksSoloOU = HartfordHawks[10]
HartfordHawksHalftime = HartfordHawks[14]
HartfordHawksHalftimeOU = HartfordHawks[16]

NewHampshireWildcatsList = AmericaEast.worksheet("New Hampshire Wildcats").get_all_values()
NewHampshireWildcats = NewHampshireWildcatsList[1]
NewHampshireWildcatsCover = NewHampshireWildcats[5]
NewHampshireWildcatsML = NewHampshireWildcats[6]
NewHampshireWildcatsOU = NewHampshireWildcats[8]
NewHampshireWildcatsSoloOU = NewHampshireWildcats[10]
NewHampshireWildcatsHalftime = NewHampshireWildcats[14]
NewHampshireWildcatsHalftimeOU = NewHampshireWildcats[16]

UMBCRetrieversList = AmericaEast.worksheet("UMBC Retrievers").get_all_values()
UMBCRetrievers = UMBCRetrieversList[1]
UMBCRetrieversCover = UMBCRetrievers[5]
UMBCRetrieversML = UMBCRetrievers[6]
UMBCRetrieversOU = UMBCRetrievers[8]
UMBCRetrieversSoloOU = UMBCRetrievers[10]
UMBCRetrieversHalftime = UMBCRetrievers[14]
UMBCRetrieversHalftimeOU = UMBCRetrievers[16]

AlbanyGreatDanesList = AmericaEast.worksheet("Albany Great Danes").get_all_values()
AlbanyGreatDanes = AlbanyGreatDanesList[1]
AlbanyGreatDanesCover = AlbanyGreatDanes[5]
AlbanyGreatDanesML = AlbanyGreatDanes[6]
AlbanyGreatDanesOU = AlbanyGreatDanes[8]
AlbanyGreatDanesSoloOU = AlbanyGreatDanes[10]
AlbanyGreatDanesHalftime = AlbanyGreatDanes[14]
AlbanyGreatDanesHalftimeOU = AlbanyGreatDanes[16]

UMassLowellRiverHawksList = AmericaEast.worksheet("UMass Lowell River Hawks").get_all_values()
UMassLowellRiverHawks = UMassLowellRiverHawksList[1]
UMassLowellRiverHawksCover = UMassLowellRiverHawks[5]
UMassLowellRiverHawksML = UMassLowellRiverHawks[6]
UMassLowellRiverHawksOU = UMassLowellRiverHawks[8]
UMassLowellRiverHawksSoloOU = UMassLowellRiverHawks[10]
UMassLowellRiverHawksHalftime = UMassLowellRiverHawks[14]
UMassLowellRiverHawksHalftimeOU = UMassLowellRiverHawks[16]

MaineBlackBearsList = AmericaEast.worksheet("Maine Black Bears").get_all_values()
MaineBlackBears = MaineBlackBearsList[1]
MaineBlackBearsCover = MaineBlackBears[5]
MaineBlackBearsML = MaineBlackBears[6]
MaineBlackBearsOU = MaineBlackBears[8]
MaineBlackBearsSoloOU = MaineBlackBears[10]
MaineBlackBearsHalftime = MaineBlackBears[14]
MaineBlackBearsHalftimeOU = MaineBlackBears[16]

BinghamtonBearcatsList = AmericaEast.worksheet("Binghamton Bearcats").get_all_values()
BinghamtonBearcats = BinghamtonBearcatsList[1]
BinghamtonBearcatsCover = BinghamtonBearcats[5]
BinghamtonBearcatsML = BinghamtonBearcats[6]
BinghamtonBearcatsOU = BinghamtonBearcats[8]
BinghamtonBearcatsSoloOU = BinghamtonBearcats[10]
BinghamtonBearcatsHalftime = BinghamtonBearcats[14]
BinghamtonBearcatsHalftimeOU = BinghamtonBearcats[16]

#American Athletic Teams

HoustonCougarsList = AmericanAthletic.worksheet("Houston Cougars").get_all_values()
HoustonCougars = HoustonCougarsList[1]
HoustonCougarsCover = HoustonCougars[5]
HoustonCougarsML = HoustonCougars[6]
HoustonCougarsOU = HoustonCougars[8]
HoustonCougarsSoloOU = HoustonCougars[10]
HoustonCougarsHalftime = HoustonCougars[14]
HoustonCougarsHalftimeOU = HoustonCougars[16]

CincinnatiBearcatsList = AmericanAthletic.worksheet("Cincinnati Bearcats").get_all_values()
CincinnatiBearcats = CincinnatiBearcatsList[1]
CincinnatiBearcatsCover = CincinnatiBearcats[5]
CincinnatiBearcatsML = CincinnatiBearcats[6]
CincinnatiBearcatsOU = CincinnatiBearcats[8]
CincinnatiBearcatsSoloOU = CincinnatiBearcats[10]
CincinnatiBearcatsHalftime = CincinnatiBearcats[14]
CincinnatiBearcatsHalftimeOU = CincinnatiBearcats[16]

TulsaGoldenHurricaneList = AmericanAthletic.worksheet("Tulsa Golden Hurricane").get_all_values()
TulsaGoldenHurricane = TulsaGoldenHurricaneList[1]
TulsaGoldenHurricaneCover = TulsaGoldenHurricane[5]
TulsaGoldenHurricaneML = TulsaGoldenHurricane[6]
TulsaGoldenHurricaneOU = TulsaGoldenHurricane[8]
TulsaGoldenHurricaneSoloOU = TulsaGoldenHurricane[10]
TulsaGoldenHurricaneHalftime = TulsaGoldenHurricane[14]
TulsaGoldenHurricaneHalftimeOU = TulsaGoldenHurricane[16]

WichitaStateShockersList = AmericanAthletic.worksheet("Wichita State Shockers").get_all_values()
WichitaStateShockers = WichitaStateShockersList[1]
WichitaStateShockersCover = WichitaStateShockers[5]
WichitaStateShockersML = WichitaStateShockers[6]
WichitaStateShockersOU = WichitaStateShockers[8]
WichitaStateShockersSoloOU = WichitaStateShockers[10]
WichitaStateShockersHalftime = WichitaStateShockers[14]
WichitaStateShockersHalftimeOU = WichitaStateShockers[16]

MemphisTigersList = AmericanAthletic.worksheet("Memphis Tigers").get_all_values()
MemphisTigers = MemphisTigersList[1]
MemphisTigersCover = MemphisTigers[5]
MemphisTigersML = MemphisTigers[6]
MemphisTigersOU = MemphisTigers[8]
MemphisTigersSoloOU = MemphisTigers[10]
MemphisTigersHalftime = MemphisTigers[14]
MemphisTigersHalftimeOU = MemphisTigers[16]

UConnHuskiesList = AmericanAthletic.worksheet("UConn Huskies").get_all_values()
UConnHuskies = UConnHuskiesList[1]
UConnHuskiesCover = UConnHuskies[5]
UConnHuskiesML = UConnHuskies[6]
UConnHuskiesOU = UConnHuskies[8]
UConnHuskiesSoloOU = UConnHuskies[10]
UConnHuskiesHalftime = UConnHuskies[14]
UConnHuskiesHalftimeOU = UConnHuskies[16]

SMUMustangsList = AmericanAthletic.worksheet("SMU Mustangs").get_all_values()
SMUMustangs = SMUMustangsList[1]
SMUMustangsCover = SMUMustangs[5]
SMUMustangsML = SMUMustangs[6]
SMUMustangsOU = SMUMustangs[8]
SMUMustangsSoloOU = SMUMustangs[10]
SMUMustangsHalftime = SMUMustangs[14]
SMUMustangsHalftimeOU = SMUMustangs[16]

UCFKnightsList = AmericanAthletic.worksheet("UCF Knights").get_all_values()
UCFKnights = UCFKnightsList[1]
UCFKnightsCover = UCFKnights[5]
UCFKnightsML = UCFKnights[6]
UCFKnightsOU = UCFKnights[8]
UCFKnightsSoloOU = UCFKnights[10]
UCFKnightsHalftime = UCFKnights[14]
UCFKnightsHalftimeOU = UCFKnights[16]

SouthFloridaBullsList = AmericanAthletic.worksheet("South Florida Bulls").get_all_values()
SouthFloridaBulls = SouthFloridaBullsList[1]
SouthFloridaBullsCover = SouthFloridaBulls[5]
SouthFloridaBullsML = SouthFloridaBulls[6]
SouthFloridaBullsOU = SouthFloridaBulls[8]
SouthFloridaBullsSoloOU = SouthFloridaBulls[10]
SouthFloridaBullsHalftime = SouthFloridaBulls[14]
SouthFloridaBullsHalftimeOU = SouthFloridaBulls[16]

TempleOwlsList = AmericanAthletic.worksheet("Temple Owls").get_all_values()
TempleOwls = TempleOwlsList[1]
TempleOwlsCover = TempleOwls[5]
TempleOwlsML = TempleOwls[6]
TempleOwlsOU = TempleOwls[8]
TempleOwlsSoloOU = TempleOwls[10]
TempleOwlsHalftime = TempleOwls[14]
TempleOwlsHalftimeOU = TempleOwls[16]

EastCarolinaPiratesList = AmericanAthletic.worksheet("East Carolina Pirates").get_all_values()
EastCarolinaPirates = EastCarolinaPiratesList[1]
EastCarolinaPiratesCover = EastCarolinaPirates[5]
EastCarolinaPiratesML = EastCarolinaPirates[6]
EastCarolinaPiratesOU = EastCarolinaPirates[8]
EastCarolinaPiratesSoloOU = EastCarolinaPirates[10]
EastCarolinaPiratesHalftime = EastCarolinaPirates[14]
EastCarolinaPiratesHalftimeOU = EastCarolinaPirates[16]

TulaneGreenWaveList = AmericanAthletic.worksheet("Tulane Green Wave").get_all_values()
TulaneGreenWave = TulaneGreenWaveList[1]
TulaneGreenWaveCover = TulaneGreenWave[5]
TulaneGreenWaveML = TulaneGreenWave[6]
TulaneGreenWaveOU = TulaneGreenWave[8]
TulaneGreenWaveSoloOU = TulaneGreenWave[10]
TulaneGreenWaveHalftime = TulaneGreenWave[14]
TulaneGreenWaveHalftimeOU = TulaneGreenWave[16]

#ASUN Teams

LibertyFlamesList = ASUN.worksheet("Liberty Flames").get_all_values()
LibertyFlames = LibertyFlamesList[1]
LibertyFlamesCover = LibertyFlames[5]
LibertyFlamesML = LibertyFlames[6]
LibertyFlamesOU = LibertyFlames[8]
LibertyFlamesSoloOU = LibertyFlames[10]
LibertyFlamesHalftime = LibertyFlames[14]
LibertyFlamesHalftimeOU = LibertyFlames[16]

NorthFloridaOspreysList = ASUN.worksheet("North Florida Ospreys").get_all_values()
NorthFloridaOspreys = NorthFloridaOspreysList[1]
NorthFloridaOspreysCover = NorthFloridaOspreys[5]
NorthFloridaOspreysML = NorthFloridaOspreys[6]
NorthFloridaOspreysOU = NorthFloridaOspreys[8]
NorthFloridaOspreysSoloOU = NorthFloridaOspreys[10]
NorthFloridaOspreysHalftime = NorthFloridaOspreys[14]
NorthFloridaOspreysHalftimeOU = NorthFloridaOspreys[16]

LipscombBisonsList = ASUN.worksheet("Lipscomb Bisons").get_all_values()
LipscombBisons = LipscombBisonsList[1]
LipscombBisonsCover = LipscombBisons[5]
LipscombBisonsML = LipscombBisons[6]
LipscombBisonsOU = LipscombBisons[8]
LipscombBisonsSoloOU = LipscombBisons[10]
LipscombBisonsHalftime = LipscombBisons[14]
LipscombBisonsHalftimeOU = LipscombBisons[16]

StetsonHattersList = ASUN.worksheet("Stetson Hatters").get_all_values()
StetsonHatters = StetsonHattersList[1]
StetsonHattersCover = StetsonHatters[5]
StetsonHattersML = StetsonHatters[6]
StetsonHattersOU = StetsonHatters[8]
StetsonHattersSoloOU = StetsonHatters[10]
StetsonHattersHalftime = StetsonHatters[14]
StetsonHattersHalftimeOU = StetsonHatters[16]

NorthAlabamaLionsList = ASUN.worksheet("North Alabama Lions").get_all_values()
NorthAlabamaLions = NorthAlabamaLionsList[1]
NorthAlabamaLionsCover = NorthAlabamaLions[5]
NorthAlabamaLionsML = NorthAlabamaLions[6]
NorthAlabamaLionsOU = NorthAlabamaLions[8]
NorthAlabamaLionsSoloOU = NorthAlabamaLions[10]
NorthAlabamaLionsHalftime = NorthAlabamaLions[14]
NorthAlabamaLionsHalftimeOU = NorthAlabamaLions[16]

FloridaGulfCoastEaglesList = ASUN.worksheet("Florida Gulf Coast Eagles").get_all_values()
FloridaGulfCoastEagles = FloridaGulfCoastEaglesList[1]
FloridaGulfCoastEaglesCover = FloridaGulfCoastEagles[5]
FloridaGulfCoastEaglesML = FloridaGulfCoastEagles[6]
FloridaGulfCoastEaglesOU = FloridaGulfCoastEagles[8]
FloridaGulfCoastEaglesSoloOU = FloridaGulfCoastEagles[10]
FloridaGulfCoastEaglesHalftime = FloridaGulfCoastEagles[14]
FloridaGulfCoastEaglesHalftimeOU = FloridaGulfCoastEagles[16]

JacksonvilleDolphinsList = ASUN.worksheet("Jacksonville Dolphins").get_all_values()
JacksonvilleDolphins = JacksonvilleDolphinsList[1]
JacksonvilleDolphinsCover = JacksonvilleDolphins[5]
JacksonvilleDolphinsML = JacksonvilleDolphins[6]
JacksonvilleDolphinsOU = JacksonvilleDolphins[8]
JacksonvilleDolphinsSoloOU = JacksonvilleDolphins[10]
JacksonvilleDolphinsHalftime = JacksonvilleDolphins[14]
JacksonvilleDolphinsHalftimeOU = JacksonvilleDolphins[16]

NJITHighlandersList = ASUN.worksheet("NJIT Highlanders").get_all_values()
NJITHighlanders = NJITHighlandersList[1]
NJITHighlandersCover = NJITHighlanders[5]
NJITHighlandersML = NJITHighlanders[6]
NJITHighlandersOU = NJITHighlanders[8]
NJITHighlandersSoloOU = NJITHighlanders[10]
NJITHighlandersHalftime = NJITHighlanders[14]
NJITHighlandersHalftimeOU = NJITHighlanders[16]

KennesawStateOwlsList = ASUN.worksheet("Kennesaw State Owls").get_all_values()
KennesawStateOwls = KennesawStateOwlsList[1]
KennesawStateOwlsCover = KennesawStateOwls[5]
KennesawStateOwlsML = KennesawStateOwls[6]
KennesawStateOwlsOU = KennesawStateOwls[8]
KennesawStateOwlsSoloOU = KennesawStateOwls[10]
KennesawStateOwlsHalftime = KennesawStateOwls[14]
KennesawStateOwlsHalftimeOU = KennesawStateOwls[16]

#Atlantic 10 Teams

DaytonFlyersList = Atlantic10.worksheet("Dayton Flyers").get_all_values()
DaytonFlyers = DaytonFlyersList[1]
DaytonFlyersCover = DaytonFlyers[5]
DaytonFlyersML = DaytonFlyers[6]
DaytonFlyersOU = DaytonFlyers[8]
DaytonFlyersSoloOU = DaytonFlyers[10]
DaytonFlyersHalftime = DaytonFlyers[14]
DaytonFlyersHalftimeOU = DaytonFlyers[16]

RichmondSpidersList = Atlantic10.worksheet("Richmond Spiders").get_all_values()
RichmondSpiders = RichmondSpidersList[1]
RichmondSpidersCover = RichmondSpiders[5]
RichmondSpidersML = RichmondSpiders[6]
RichmondSpidersOU = RichmondSpiders[8]
RichmondSpidersSoloOU = RichmondSpiders[10]
RichmondSpidersHalftime = RichmondSpiders[14]
RichmondSpidersHalftimeOU = RichmondSpiders[16]

RhodeIslandRamsList = Atlantic10.worksheet("Rhode Island Rams").get_all_values()
RhodeIslandRams = RhodeIslandRamsList[1]
RhodeIslandRamsCover = RhodeIslandRams[5]
RhodeIslandRamsML = RhodeIslandRams[6]
RhodeIslandRamsOU = RhodeIslandRams[8]
RhodeIslandRamsSoloOU = RhodeIslandRams[10]
RhodeIslandRamsHalftime = RhodeIslandRams[14]
RhodeIslandRamsHalftimeOU = RhodeIslandRams[16]

SaintLouisBillikensList = Atlantic10.worksheet("Saint Louis Billikens").get_all_values()
SaintLouisBillikens = SaintLouisBillikensList[1]
SaintLouisBillikensCover = SaintLouisBillikens[5]
SaintLouisBillikensML = SaintLouisBillikens[6]
SaintLouisBillikensOU = SaintLouisBillikens[8]
SaintLouisBillikensSoloOU = SaintLouisBillikens[10]
SaintLouisBillikensHalftime = SaintLouisBillikens[14]
SaintLouisBillikensHalftimeOU = SaintLouisBillikens[16]

StBonaventureBonniesList = Atlantic10.worksheet("St. Bonaventure Bonnies").get_all_values()
StBonaventureBonnies = StBonaventureBonniesList[1]
StBonaventureBonniesCover = StBonaventureBonnies[5]
StBonaventureBonniesML = StBonaventureBonnies[6]
StBonaventureBonniesOU = StBonaventureBonnies[8]
StBonaventureBonniesSoloOU = StBonaventureBonnies[10]
StBonaventureBonniesHalftime = StBonaventureBonnies[14]
StBonaventureBonniesHalftimeOU = StBonaventureBonnies[16]

DuquesneDukesList = Atlantic10.worksheet("Duquesne Dukes").get_all_values()
DuquesneDukes = DuquesneDukesList[1]
DuquesneDukesCover = DuquesneDukes[5]
DuquesneDukesML = DuquesneDukes[6]
DuquesneDukesOU = DuquesneDukes[8]
DuquesneDukesSoloOU = DuquesneDukes[10]
DuquesneDukesHalftime = DuquesneDukes[14]
DuquesneDukesHalftimeOU = DuquesneDukes[16]

DavidsonWildcatsList = Atlantic10.worksheet("Davidson Wildcats").get_all_values()
DavidsonWildcats = DavidsonWildcatsList[1]
DavidsonWildcatsCover = DavidsonWildcats[5]
DavidsonWildcatsML = DavidsonWildcats[6]
DavidsonWildcatsOU = DavidsonWildcats[8]
DavidsonWildcatsSoloOU = DavidsonWildcats[10]
DavidsonWildcatsHalftime = DavidsonWildcats[14]
DavidsonWildcatsHalftimeOU = DavidsonWildcats[16]

UMassMinutemenList = Atlantic10.worksheet("UMass Minutemen").get_all_values()
UMassMinutemen = UMassMinutemenList[1]
UMassMinutemenCover = UMassMinutemen[5]
UMassMinutemenML = UMassMinutemen[6]
UMassMinutemenOU = UMassMinutemen[8]
UMassMinutemenSoloOU = UMassMinutemen[10]
UMassMinutemenHalftime = UMassMinutemen[14]
UMassMinutemenHalftimeOU = UMassMinutemen[16]

VCURamsList = Atlantic10.worksheet("VCU Rams").get_all_values()
VCURams = VCURamsList[1]
VCURamsCover = VCURams[5]
VCURamsML = VCURams[6]
VCURamsOU = VCURams[8]
VCURamsSoloOU = VCURams[10]
VCURamsHalftime = VCURams[14]
VCURamsHalftimeOU = VCURams[16]

GeorgeWashingtonColonialsList = Atlantic10.worksheet("George Washington Colonials").get_all_values()
GeorgeWashingtonColonials = GeorgeWashingtonColonialsList[1]
GeorgeWashingtonColonialsCover = GeorgeWashingtonColonials[5]
GeorgeWashingtonColonialsML = GeorgeWashingtonColonials[6]
GeorgeWashingtonColonialsOU = GeorgeWashingtonColonials[8]
GeorgeWashingtonColonialsSoloOU = GeorgeWashingtonColonials[10]
GeorgeWashingtonColonialsHalftime = GeorgeWashingtonColonials[14]
GeorgeWashingtonColonialsHalftimeOU = GeorgeWashingtonColonials[16]

LaSalleExplorersList = Atlantic10.worksheet("La Salle Explorers").get_all_values()
LaSalleExplorers = LaSalleExplorersList[1]
LaSalleExplorersCover = LaSalleExplorers[5]
LaSalleExplorersML = LaSalleExplorers[6]
LaSalleExplorersOU = LaSalleExplorers[8]
LaSalleExplorersSoloOU = LaSalleExplorers[10]
LaSalleExplorersHalftime = LaSalleExplorers[14]
LaSalleExplorersHalftimeOU = LaSalleExplorers[16]

GeorgeMasonPatriotsList = Atlantic10.worksheet("George Mason Patriots").get_all_values()
GeorgeMasonPatriots = GeorgeMasonPatriotsList[1]
GeorgeMasonPatriotsCover = GeorgeMasonPatriots[5]
GeorgeMasonPatriotsML = GeorgeMasonPatriots[6]
GeorgeMasonPatriotsOU = GeorgeMasonPatriots[8]
GeorgeMasonPatriotsSoloOU = GeorgeMasonPatriots[10]
GeorgeMasonPatriotsHalftime = GeorgeMasonPatriots[14]
GeorgeMasonPatriotsHalftimeOU = GeorgeMasonPatriots[16]

SaintJosephsHawksList = Atlantic10.worksheet("Saint Joseph's Hawks").get_all_values()
SaintJosephsHawks = SaintJosephsHawksList[1]
SaintJosephsHawksCover = SaintJosephsHawks[5]
SaintJosephsHawksML = SaintJosephsHawks[6]
SaintJosephsHawksOU = SaintJosephsHawks[8]
SaintJosephsHawksSoloOU = SaintJosephsHawks[10]
SaintJosephsHawksHalftime = SaintJosephsHawks[14]
SaintJosephsHawksHalftimeOU = SaintJosephsHawks[16]

FordhamRamsList = Atlantic10.worksheet("Fordham Rams").get_all_values()
FordhamRams = FordhamRamsList[1]
FordhamRamsCover = FordhamRams[5]
FordhamRamsML = FordhamRams[6]
FordhamRamsOU = FordhamRams[8]
FordhamRamsSoloOU = FordhamRams[10]
FordhamRamsHalftime = FordhamRams[14]
FordhamRamsHalftimeOU = FordhamRams[16]

#Atlantic Coast Teams

FloridaStateSeminolesList = AtlanticCoast.worksheet("Florida State Seminoles").get_all_values()
FloridaStateSeminoles = FloridaStateSeminolesList[1]
FloridaStateSeminolesCover = FloridaStateSeminoles[5]
FloridaStateSeminolesML = FloridaStateSeminoles[6]
FloridaStateSeminolesOU = FloridaStateSeminoles[8]
FloridaStateSeminolesSoloOU = FloridaStateSeminoles[10]
FloridaStateSeminolesHalftime = FloridaStateSeminoles[14]
FloridaStateSeminolesHalftimeOU = FloridaStateSeminoles[16]

VirginiaCavaliersList = AtlanticCoast.worksheet("Virginia Cavaliers").get_all_values()
VirginiaCavaliers = VirginiaCavaliersList[1]
VirginiaCavaliersCover = VirginiaCavaliers[5]
VirginiaCavaliersML = VirginiaCavaliers[6]
VirginiaCavaliersOU = VirginiaCavaliers[8]
VirginiaCavaliersSoloOU = VirginiaCavaliers[10]
VirginiaCavaliersHalftime = VirginiaCavaliers[14]
VirginiaCavaliersHalftimeOU = VirginiaCavaliers[16]

LouisvilleCardinalsList = AtlanticCoast.worksheet("Louisville Cardinals").get_all_values()
LouisvilleCardinals = LouisvilleCardinalsList[1]
LouisvilleCardinalsCover = LouisvilleCardinals[5]
LouisvilleCardinalsML = LouisvilleCardinals[6]
LouisvilleCardinalsOU = LouisvilleCardinals[8]
LouisvilleCardinalsSoloOU = LouisvilleCardinals[10]
LouisvilleCardinalsHalftime = LouisvilleCardinals[14]
LouisvilleCardinalsHalftimeOU = LouisvilleCardinals[16]

DukeBlueDevilsList = AtlanticCoast.worksheet("Duke Blue Devils").get_all_values()
DukeBlueDevils = DukeBlueDevilsList[1]
DukeBlueDevilsCover = DukeBlueDevils[5]
DukeBlueDevilsML = DukeBlueDevils[6]
DukeBlueDevilsOU = DukeBlueDevils[8]
DukeBlueDevilsSoloOU = DukeBlueDevils[10]
DukeBlueDevilsHalftime = DukeBlueDevils[14]
DukeBlueDevilsHalftimeOU = DukeBlueDevils[16]

GeorgiaTechYellowJacketsList = AtlanticCoast.worksheet("Georgia Tech Yellow Jackets").get_all_values()
GeorgiaTechYellowJackets = GeorgiaTechYellowJacketsList[1]
GeorgiaTechYellowJacketsCover = GeorgiaTechYellowJackets[5]
GeorgiaTechYellowJacketsML = GeorgiaTechYellowJackets[6]
GeorgiaTechYellowJacketsOU = GeorgiaTechYellowJackets[8]
GeorgiaTechYellowJacketsSoloOU = GeorgiaTechYellowJackets[10]
GeorgiaTechYellowJacketsHalftime = GeorgiaTechYellowJackets[14]
GeorgiaTechYellowJacketsHalftimeOU = GeorgiaTechYellowJackets[16]

NCStateWolfpackList = AtlanticCoast.worksheet("NC State Wolfpack").get_all_values()
NCStateWolfpack = NCStateWolfpackList[1]
NCStateWolfpackCover = NCStateWolfpack[5]
NCStateWolfpackML = NCStateWolfpack[6]
NCStateWolfpackOU = NCStateWolfpack[8]
NCStateWolfpackSoloOU = NCStateWolfpack[10]
NCStateWolfpackHalftime = NCStateWolfpack[14]
NCStateWolfpackHalftimeOU = NCStateWolfpack[16]

NotreDameFightingIrishList = AtlanticCoast.worksheet("Notre Dame Fighting Irish").get_all_values()
NotreDameFightingIrish = NotreDameFightingIrishList[1]
NotreDameFightingIrishCover = NotreDameFightingIrish[5]
NotreDameFightingIrishML = NotreDameFightingIrish[6]
NotreDameFightingIrishOU = NotreDameFightingIrish[8]
NotreDameFightingIrishSoloOU = NotreDameFightingIrish[10]
NotreDameFightingIrishHalftime = NotreDameFightingIrish[14]
NotreDameFightingIrishHalftimeOU = NotreDameFightingIrish[16]

SyracuseOrangeList = AtlanticCoast.worksheet("Syracuse Orange").get_all_values()
SyracuseOrange = SyracuseOrangeList[1]
SyracuseOrangeCover = SyracuseOrange[5]
SyracuseOrangeML = SyracuseOrange[6]
SyracuseOrangeOU = SyracuseOrange[8]
SyracuseOrangeSoloOU = SyracuseOrange[10]
SyracuseOrangeHalftime = SyracuseOrange[14]
SyracuseOrangeHalftimeOU = SyracuseOrange[16]

ClemsonTigersList = AtlanticCoast.worksheet("Clemson Tigers").get_all_values()
ClemsonTigers = ClemsonTigersList[1]
ClemsonTigersCover = ClemsonTigers[5]
ClemsonTigersML = ClemsonTigers[6]
ClemsonTigersOU = ClemsonTigers[8]
ClemsonTigersSoloOU = ClemsonTigers[10]
ClemsonTigersHalftime = ClemsonTigers[14]
ClemsonTigersHalftimeOU = ClemsonTigers[16]

MiamiHurricanesList = AtlanticCoast.worksheet("Miami Hurricanes").get_all_values()
MiamiHurricanes = MiamiHurricanesList[1]
MiamiHurricanesCover = MiamiHurricanes[5]
MiamiHurricanesML = MiamiHurricanes[6]
MiamiHurricanesOU = MiamiHurricanes[8]
MiamiHurricanesSoloOU = MiamiHurricanes[10]
MiamiHurricanesHalftime = MiamiHurricanes[14]
MiamiHurricanesHalftimeOU = MiamiHurricanes[16]

BostonCollegeEaglesList = AtlanticCoast.worksheet("Boston College Eagles").get_all_values()
BostonCollegeEagles = BostonCollegeEaglesList[1]
BostonCollegeEaglesCover = BostonCollegeEagles[5]
BostonCollegeEaglesML = BostonCollegeEagles[6]
BostonCollegeEaglesOU = BostonCollegeEagles[8]
BostonCollegeEaglesSoloOU = BostonCollegeEagles[10]
BostonCollegeEaglesHalftime = BostonCollegeEagles[14]
BostonCollegeEaglesHalftimeOU = BostonCollegeEagles[16]

VirginiaTechHokiesList = AtlanticCoast.worksheet("Virginia Tech Hokies").get_all_values()
VirginiaTechHokies = VirginiaTechHokiesList[1]
VirginiaTechHokiesCover = VirginiaTechHokies[5]
VirginiaTechHokiesML = VirginiaTechHokies[6]
VirginiaTechHokiesOU = VirginiaTechHokies[8]
VirginiaTechHokiesSoloOU = VirginiaTechHokies[10]
VirginiaTechHokiesHalftime = VirginiaTechHokies[14]
VirginiaTechHokiesHalftimeOU = VirginiaTechHokies[16]

PittsburghPanthersList = AtlanticCoast.worksheet("Pittsburgh Panthers").get_all_values()
PittsburghPanthers = PittsburghPanthersList[1]
PittsburghPanthersCover = PittsburghPanthers[5]
PittsburghPanthersML = PittsburghPanthers[6]
PittsburghPanthersOU = PittsburghPanthers[8]
PittsburghPanthersSoloOU = PittsburghPanthers[10]
PittsburghPanthersHalftime = PittsburghPanthers[14]
PittsburghPanthersHalftimeOU = PittsburghPanthers[16]

NorthCarolinaTarHeelsList = AtlanticCoast.worksheet("North Carolina Tar Heels").get_all_values()
NorthCarolinaTarHeels = NorthCarolinaTarHeelsList[1]
NorthCarolinaTarHeelsCover = NorthCarolinaTarHeels[5]
NorthCarolinaTarHeelsML = NorthCarolinaTarHeels[6]
NorthCarolinaTarHeelsOU = NorthCarolinaTarHeels[8]
NorthCarolinaTarHeelsSoloOU = NorthCarolinaTarHeels[10]
NorthCarolinaTarHeelsHalftime = NorthCarolinaTarHeels[14]
NorthCarolinaTarHeelsHalftimeOU = NorthCarolinaTarHeels[16]

WakeForestDemonDeaconsList = AtlanticCoast.worksheet("Wake Forest Demon Deacons").get_all_values()
WakeForestDemonDeacons = WakeForestDemonDeaconsList[1]
WakeForestDemonDeaconsCover = WakeForestDemonDeacons[5]
WakeForestDemonDeaconsML = WakeForestDemonDeacons[6]
WakeForestDemonDeaconsOU = WakeForestDemonDeacons[8]
WakeForestDemonDeaconsSoloOU = WakeForestDemonDeacons[10]
WakeForestDemonDeaconsHalftime = WakeForestDemonDeacons[14]
WakeForestDemonDeaconsHalftimeOU = WakeForestDemonDeacons[16]

#Big12 Teams

KansasJayhawksList = Big12.worksheet("Kansas Jayhawks").get_all_values()
KansasJayhawks = KansasJayhawksList[1]
KansasJayhawksCover = KansasJayhawks[5]
KansasJayhawksML = KansasJayhawks[6]
KansasJayhawksOU = KansasJayhawks[8]
KansasJayhawksSoloOU = KansasJayhawks[10]
KansasJayhawksHalftime = KansasJayhawks[14]
KansasJayhawksHalftimeOU = KansasJayhawks[16]

BaylorBearsList = Big12.worksheet("Baylor Bears").get_all_values()
BaylorBears = BaylorBearsList[1]
BaylorBearsCover = BaylorBears[5]
BaylorBearsML = BaylorBears[6]
BaylorBearsOU = BaylorBears[8]
BaylorBearsSoloOU = BaylorBears[10]
BaylorBearsHalftime = BaylorBears[14]
BaylorBearsHalftimeOU = BaylorBears[16]

OklahomaSoonersList = Big12.worksheet("Oklahoma Sooners").get_all_values()
OklahomaSooners = OklahomaSoonersList[1]
OklahomaSoonersCover = OklahomaSooners[5]
OklahomaSoonersML = OklahomaSooners[6]
OklahomaSoonersOU = OklahomaSooners[8]
OklahomaSoonersSoloOU = OklahomaSooners[10]
OklahomaSoonersHalftime = OklahomaSooners[14]
OklahomaSoonersHalftimeOU = OklahomaSooners[16]

TexasLonghornsList = Big12.worksheet("Texas Longhorns").get_all_values()
TexasLonghorns = TexasLonghornsList[1]
TexasLonghornsCover = TexasLonghorns[5]
TexasLonghornsML = TexasLonghorns[6]
TexasLonghornsOU = TexasLonghorns[8]
TexasLonghornsSoloOU = TexasLonghorns[10]
TexasLonghornsHalftime = TexasLonghorns[14]
TexasLonghornsHalftimeOU = TexasLonghorns[16]

TexasTechRedRaidersList = Big12.worksheet("Texas Tech Red Raiders").get_all_values()
TexasTechRedRaiders = TexasTechRedRaidersList[1]
TexasTechRedRaidersCover = TexasTechRedRaiders[5]
TexasTechRedRaidersML = TexasTechRedRaiders[6]
TexasTechRedRaidersOU = TexasTechRedRaiders[8]
TexasTechRedRaidersSoloOU = TexasTechRedRaiders[10]
TexasTechRedRaidersHalftime = TexasTechRedRaiders[14]
TexasTechRedRaidersHalftimeOU = TexasTechRedRaiders[16]

WestVirginiaMountaineersList = Big12.worksheet("West Virginia Mountaineers").get_all_values()
WestVirginiaMountaineers = WestVirginiaMountaineersList[1]
WestVirginiaMountaineersCover = WestVirginiaMountaineers[5]
WestVirginiaMountaineersML = WestVirginiaMountaineers[6]
WestVirginiaMountaineersOU = WestVirginiaMountaineers[8]
WestVirginiaMountaineersSoloOU = WestVirginiaMountaineers[10]
WestVirginiaMountaineersHalftime = WestVirginiaMountaineers[14]
WestVirginiaMountaineersHalftimeOU = WestVirginiaMountaineers[16]

OklahomaStateCowboysList = Big12.worksheet("Oklahoma State Cowboys").get_all_values()
OklahomaStateCowboys = OklahomaStateCowboysList[1]
OklahomaStateCowboysCover = OklahomaStateCowboys[5]
OklahomaStateCowboysML = OklahomaStateCowboys[6]
OklahomaStateCowboysOU = OklahomaStateCowboys[8]
OklahomaStateCowboysSoloOU = OklahomaStateCowboys[10]
OklahomaStateCowboysHalftime = OklahomaStateCowboys[14]
OklahomaStateCowboysHalftimeOU = OklahomaStateCowboys[16]

TCUHornedFrogsList = Big12.worksheet("TCU Horned Frogs").get_all_values()
TCUHornedFrogs = TCUHornedFrogsList[1]
TCUHornedFrogsCover = TCUHornedFrogs[5]
TCUHornedFrogsML = TCUHornedFrogs[6]
TCUHornedFrogsOU = TCUHornedFrogs[8]
TCUHornedFrogsSoloOU = TCUHornedFrogs[10]
TCUHornedFrogsHalftime = TCUHornedFrogs[14]
TCUHornedFrogsHalftimeOU = TCUHornedFrogs[16]

IowaStateCyclonesList = Big12.worksheet("Iowa State Cyclones").get_all_values()
IowaStateCyclones = IowaStateCyclonesList[1]
IowaStateCyclonesCover = IowaStateCyclones[5]
IowaStateCyclonesML = IowaStateCyclones[6]
IowaStateCyclonesOU = IowaStateCyclones[8]
IowaStateCyclonesSoloOU = IowaStateCyclones[10]
IowaStateCyclonesHalftime = IowaStateCyclones[14]
IowaStateCyclonesHalftimeOU = IowaStateCyclones[16]

KansasStateWildcatsList = Big12.worksheet("Kansas State Wildcats").get_all_values()
KansasStateWildcats = KansasStateWildcatsList[1]
KansasStateWildcatsCover = KansasStateWildcats[5]
KansasStateWildcatsML = KansasStateWildcats[6]
KansasStateWildcatsOU = KansasStateWildcats[8]
KansasStateWildcatsSoloOU = KansasStateWildcats[10]
KansasStateWildcatsHalftime = KansasStateWildcats[14]
KansasStateWildcatsHalftimeOU = KansasStateWildcats[16]

#Big East Teams

CreightonBluejaysList = BigEast.worksheet("Creighton Bluejays").get_all_values()
CreightonBluejays = CreightonBluejaysList[1]
CreightonBluejaysCover = CreightonBluejays[5]
CreightonBluejaysML = CreightonBluejays[6]
CreightonBluejaysOU = CreightonBluejays[8]
CreightonBluejaysSoloOU = CreightonBluejays[10]
CreightonBluejaysHalftime = CreightonBluejays[14]
CreightonBluejaysHalftimeOU = CreightonBluejays[16]

VillanovaWildcatsList = BigEast.worksheet("Villanova Wildcats").get_all_values()
VillanovaWildcats = VillanovaWildcatsList[1]
VillanovaWildcatsCover = VillanovaWildcats[5]
VillanovaWildcatsML = VillanovaWildcats[6]
VillanovaWildcatsOU = VillanovaWildcats[8]
VillanovaWildcatsSoloOU = VillanovaWildcats[10]
VillanovaWildcatsHalftime = VillanovaWildcats[14]
VillanovaWildcatsHalftimeOU = VillanovaWildcats[16]

SetonHallPiratesList = BigEast.worksheet("Seton Hall Pirates").get_all_values()
SetonHallPirates = SetonHallPiratesList[1]
SetonHallPiratesCover = SetonHallPirates[5]
SetonHallPiratesML = SetonHallPirates[6]
SetonHallPiratesOU = SetonHallPirates[8]
SetonHallPiratesSoloOU = SetonHallPirates[10]
SetonHallPiratesHalftime = SetonHallPirates[14]
SetonHallPiratesHalftimeOU = SetonHallPirates[16]

ProvidenceFriarsList = BigEast.worksheet("Providence Friars").get_all_values()
ProvidenceFriars = ProvidenceFriarsList[1]
ProvidenceFriarsCover = ProvidenceFriars[5]
ProvidenceFriarsML = ProvidenceFriars[6]
ProvidenceFriarsOU = ProvidenceFriars[8]
ProvidenceFriarsSoloOU = ProvidenceFriars[10]
ProvidenceFriarsHalftime = ProvidenceFriars[14]
ProvidenceFriarsHalftimeOU = ProvidenceFriars[16]

ButlerBulldogsList = BigEast.worksheet("Butler Bulldogs").get_all_values()
ButlerBulldogs = ButlerBulldogsList[1]
ButlerBulldogsCover = ButlerBulldogs[5]
ButlerBulldogsML = ButlerBulldogs[6]
ButlerBulldogsOU = ButlerBulldogs[8]
ButlerBulldogsSoloOU = ButlerBulldogs[10]
ButlerBulldogsHalftime = ButlerBulldogs[14]
ButlerBulldogsHalftimeOU = ButlerBulldogs[16]

MarquetteGoldenEaglesList = BigEast.worksheet("Marquette Golden Eagles").get_all_values()
MarquetteGoldenEagles = MarquetteGoldenEaglesList[1]
MarquetteGoldenEaglesCover = MarquetteGoldenEagles[5]
MarquetteGoldenEaglesML = MarquetteGoldenEagles[6]
MarquetteGoldenEaglesOU = MarquetteGoldenEagles[8]
MarquetteGoldenEaglesSoloOU = MarquetteGoldenEagles[10]
MarquetteGoldenEaglesHalftime = MarquetteGoldenEagles[14]
MarquetteGoldenEaglesHalftimeOU = MarquetteGoldenEagles[16]

XavierMusketeersList = BigEast.worksheet("Xavier Musketeers").get_all_values()
XavierMusketeers = XavierMusketeersList[1]
XavierMusketeersCover = XavierMusketeers[5]
XavierMusketeersML = XavierMusketeers[6]
XavierMusketeersOU = XavierMusketeers[8]
XavierMusketeersSoloOU = XavierMusketeers[10]
XavierMusketeersHalftime = XavierMusketeers[14]
XavierMusketeersHalftimeOU = XavierMusketeers[16]

StJohnsRedStormList = BigEast.worksheet("St. John's Red Storm").get_all_values()
StJohnsRedStorm = StJohnsRedStormList[1]
StJohnsRedStormCover = StJohnsRedStorm[5]
StJohnsRedStormML = StJohnsRedStorm[6]
StJohnsRedStormOU = StJohnsRedStorm[8]
StJohnsRedStormSoloOU = StJohnsRedStorm[10]
StJohnsRedStormHalftime = StJohnsRedStorm[14]
StJohnsRedStormHalftimeOU = StJohnsRedStorm[16]

GeorgetownHoyasList = BigEast.worksheet("Georgetown Hoyas").get_all_values()
GeorgetownHoyas = GeorgetownHoyasList[1]
GeorgetownHoyasCover = GeorgetownHoyas[5]
GeorgetownHoyasML = GeorgetownHoyas[6]
GeorgetownHoyasOU = GeorgetownHoyas[8]
GeorgetownHoyasSoloOU = GeorgetownHoyas[10]
GeorgetownHoyasHalftime = GeorgetownHoyas[14]
GeorgetownHoyasHalftimeOU = GeorgetownHoyas[16]

DePaulBlueDemonsList = BigEast.worksheet("DePaul Blue Demons").get_all_values()
DePaulBlueDemons = DePaulBlueDemonsList[1]
DePaulBlueDemonsCover = DePaulBlueDemons[5]
DePaulBlueDemonsML = DePaulBlueDemons[6]
DePaulBlueDemonsOU = DePaulBlueDemons[8]
DePaulBlueDemonsSoloOU = DePaulBlueDemons[10]
DePaulBlueDemonsHalftime = DePaulBlueDemons[14]
DePaulBlueDemonsHalftimeOU = DePaulBlueDemons[16]

#Big Sky Teams

EasternWashingtonEaglesList = BigSky.worksheet("Eastern Washington Eagles").get_all_values()
EasternWashingtonEagles = EasternWashingtonEaglesList[1]
EasternWashingtonEaglesCover = EasternWashingtonEagles[5]
EasternWashingtonEaglesML = EasternWashingtonEagles[6]
EasternWashingtonEaglesOU = EasternWashingtonEagles[8]
EasternWashingtonEaglesSoloOU = EasternWashingtonEagles[10]
EasternWashingtonEaglesHalftime = EasternWashingtonEagles[14]
EasternWashingtonEaglesHalftimeOU = EasternWashingtonEagles[16]

NorthernColoradoBearsList = BigSky.worksheet("Northern Colorado Bears").get_all_values()
NorthernColoradoBears = NorthernColoradoBearsList[1]
NorthernColoradoBearsCover = NorthernColoradoBears[5]
NorthernColoradoBearsML = NorthernColoradoBears[6]
NorthernColoradoBearsOU = NorthernColoradoBears[8]
NorthernColoradoBearsSoloOU = NorthernColoradoBears[10]
NorthernColoradoBearsHalftime = NorthernColoradoBears[14]
NorthernColoradoBearsHalftimeOU = NorthernColoradoBears[16]

MontanaGrizzliesList = BigSky.worksheet("Montana Grizzlies").get_all_values()
MontanaGrizzlies = MontanaGrizzliesList[1]
MontanaGrizzliesCover = MontanaGrizzlies[5]
MontanaGrizzliesML = MontanaGrizzlies[6]
MontanaGrizzliesOU = MontanaGrizzlies[8]
MontanaGrizzliesSoloOU = MontanaGrizzlies[10]
MontanaGrizzliesHalftime = MontanaGrizzlies[14]
MontanaGrizzliesHalftimeOU = MontanaGrizzlies[16]

PortlandStateVikingsList = BigSky.worksheet("Portland State Vikings").get_all_values()
PortlandStateVikings = PortlandStateVikingsList[1]
PortlandStateVikingsCover = PortlandStateVikings[5]
PortlandStateVikingsML = PortlandStateVikings[6]
PortlandStateVikingsOU = PortlandStateVikings[8]
PortlandStateVikingsSoloOU = PortlandStateVikings[10]
PortlandStateVikingsHalftime = PortlandStateVikings[14]
PortlandStateVikingsHalftimeOU = PortlandStateVikings[16]

MontanaStateBobcatsList = BigSky.worksheet("Montana State Bobcats").get_all_values()
MontanaStateBobcats = MontanaStateBobcatsList[1]
MontanaStateBobcatsCover = MontanaStateBobcats[5]
MontanaStateBobcatsML = MontanaStateBobcats[6]
MontanaStateBobcatsOU = MontanaStateBobcats[8]
MontanaStateBobcatsSoloOU = MontanaStateBobcats[10]
MontanaStateBobcatsHalftime = MontanaStateBobcats[14]
MontanaStateBobcatsHalftimeOU = MontanaStateBobcats[16]

NorthernArizonaLumberjacksList = BigSky.worksheet("Northern Arizona Lumberjacks").get_all_values()
NorthernArizonaLumberjacks = NorthernArizonaLumberjacksList[1]
NorthernArizonaLumberjacksCover = NorthernArizonaLumberjacks[5]
NorthernArizonaLumberjacksML = NorthernArizonaLumberjacks[6]
NorthernArizonaLumberjacksOU = NorthernArizonaLumberjacks[8]
NorthernArizonaLumberjacksSoloOU = NorthernArizonaLumberjacks[10]
NorthernArizonaLumberjacksHalftime = NorthernArizonaLumberjacks[14]
NorthernArizonaLumberjacksHalftimeOU = NorthernArizonaLumberjacks[16]

SouthernUtahThunderbirdsList = BigSky.worksheet("Southern Utah Thunderbirds").get_all_values()
SouthernUtahThunderbirds = SouthernUtahThunderbirdsList[1]
SouthernUtahThunderbirdsCover = SouthernUtahThunderbirds[5]
SouthernUtahThunderbirdsML = SouthernUtahThunderbirds[6]
SouthernUtahThunderbirdsOU = SouthernUtahThunderbirds[8]
SouthernUtahThunderbirdsSoloOU = SouthernUtahThunderbirds[10]
SouthernUtahThunderbirdsHalftime = SouthernUtahThunderbirds[14]
SouthernUtahThunderbirdsHalftimeOU = SouthernUtahThunderbirds[16]

SacramentoStateHornetsList = BigSky.worksheet("Sacramento State Hornets").get_all_values()
SacramentoStateHornets = SacramentoStateHornetsList[1]
SacramentoStateHornetsCover = SacramentoStateHornets[5]
SacramentoStateHornetsML = SacramentoStateHornets[6]
SacramentoStateHornetsOU = SacramentoStateHornets[8]
SacramentoStateHornetsSoloOU = SacramentoStateHornets[10]
SacramentoStateHornetsHalftime = SacramentoStateHornets[14]
SacramentoStateHornetsHalftimeOU = SacramentoStateHornets[16]

WeberStateWildcatsList = BigSky.worksheet("Weber State Wildcats").get_all_values()
WeberStateWildcats = WeberStateWildcatsList[1]
WeberStateWildcatsCover = WeberStateWildcats[5]
WeberStateWildcatsML = WeberStateWildcats[6]
WeberStateWildcatsOU = WeberStateWildcats[8]
WeberStateWildcatsSoloOU = WeberStateWildcats[10]
WeberStateWildcatsHalftime = WeberStateWildcats[14]
WeberStateWildcatsHalftimeOU = WeberStateWildcats[16]

IdahoStateBengalsList = BigSky.worksheet("Idaho State Bengals").get_all_values()
IdahoStateBengals = IdahoStateBengalsList[1]
IdahoStateBengalsCover = IdahoStateBengals[5]
IdahoStateBengalsML = IdahoStateBengals[6]
IdahoStateBengalsOU = IdahoStateBengals[8]
IdahoStateBengalsSoloOU = IdahoStateBengals[10]
IdahoStateBengalsHalftime = IdahoStateBengals[14]
IdahoStateBengalsHalftimeOU = IdahoStateBengals[16]

IdahoVandalsList = BigSky.worksheet("Idaho Vandals").get_all_values()
IdahoVandals = IdahoVandalsList[1]
IdahoVandalsCover = IdahoVandals[5]
IdahoVandalsML = IdahoVandals[6]
IdahoVandalsOU = IdahoVandals[8]
IdahoVandalsSoloOU = IdahoVandals[10]
IdahoVandalsHalftime = IdahoVandals[14]
IdahoVandalsHalftimeOU = IdahoVandals[16]

#Big South Teams

WinthropEaglesList = BigSouth.worksheet("Winthrop Eagles").get_all_values()
WinthropEagles = WinthropEaglesList[1]
WinthropEaglesCover = WinthropEagles[5]
WinthropEaglesML = WinthropEagles[6]
WinthropEaglesOU = WinthropEagles[8]
WinthropEaglesSoloOU = WinthropEagles[10]
WinthropEaglesHalftime = WinthropEagles[14]
WinthropEaglesHalftimeOU = WinthropEagles[16]

RadfordHighlandersList = BigSouth.worksheet("Radford Highlanders").get_all_values()
RadfordHighlanders = RadfordHighlandersList[1]
RadfordHighlandersCover = RadfordHighlanders[5]
RadfordHighlandersML = RadfordHighlanders[6]
RadfordHighlandersOU = RadfordHighlanders[8]
RadfordHighlandersSoloOU = RadfordHighlanders[10]
RadfordHighlandersHalftime = RadfordHighlanders[14]
RadfordHighlandersHalftimeOU = RadfordHighlanders[16]

GardnerWebbBulldogsList = BigSouth.worksheet("Gardner-Webb Bulldogs").get_all_values()
GardnerWebbBulldogs = GardnerWebbBulldogsList[1]
GardnerWebbBulldogsCover = GardnerWebbBulldogs[5]
GardnerWebbBulldogsML = GardnerWebbBulldogs[6]
GardnerWebbBulldogsOU = GardnerWebbBulldogs[8]
GardnerWebbBulldogsSoloOU = GardnerWebbBulldogs[10]
GardnerWebbBulldogsHalftime = GardnerWebbBulldogs[14]
GardnerWebbBulldogsHalftimeOU = GardnerWebbBulldogs[16]

LongwoodLancersList = BigSouth.worksheet("Longwood Lancers").get_all_values()
LongwoodLancers = LongwoodLancersList[1]
LongwoodLancersCover = LongwoodLancers[5]
LongwoodLancersML = LongwoodLancers[6]
LongwoodLancersOU = LongwoodLancers[8]
LongwoodLancersSoloOU = LongwoodLancers[10]
LongwoodLancersHalftime = LongwoodLancers[14]
LongwoodLancersHalftimeOU = LongwoodLancers[16]

HamptonPiratesList = BigSouth.worksheet("Hampton Pirates").get_all_values()
HamptonPirates = HamptonPiratesList[1]
HamptonPiratesCover = HamptonPirates[5]
HamptonPiratesML = HamptonPirates[6]
HamptonPiratesOU = HamptonPirates[8]
HamptonPiratesSoloOU = HamptonPirates[10]
HamptonPiratesHalftime = HamptonPirates[14]
HamptonPiratesHalftimeOU = HamptonPirates[16]

UNCAshevilleBulldogsList = BigSouth.worksheet("UNC Asheville Bulldogs").get_all_values()
UNCAshevilleBulldogs = UNCAshevilleBulldogsList[1]
UNCAshevilleBulldogsCover = UNCAshevilleBulldogs[5]
UNCAshevilleBulldogsML = UNCAshevilleBulldogs[6]
UNCAshevilleBulldogsOU = UNCAshevilleBulldogs[8]
UNCAshevilleBulldogsSoloOU = UNCAshevilleBulldogs[10]
UNCAshevilleBulldogsHalftime = UNCAshevilleBulldogs[14]
UNCAshevilleBulldogsHalftimeOU = UNCAshevilleBulldogs[16]

SouthCarolinaUpstateSpartansList = BigSouth.worksheet("South Carolina Upstate Spartans").get_all_values()
SouthCarolinaUpstateSpartans = SouthCarolinaUpstateSpartansList[1]
SouthCarolinaUpstateSpartansCover = SouthCarolinaUpstateSpartans[5]
SouthCarolinaUpstateSpartansML = SouthCarolinaUpstateSpartans[6]
SouthCarolinaUpstateSpartansOU = SouthCarolinaUpstateSpartans[8]
SouthCarolinaUpstateSpartansSoloOU = SouthCarolinaUpstateSpartans[10]
SouthCarolinaUpstateSpartansHalftime = SouthCarolinaUpstateSpartans[14]
SouthCarolinaUpstateSpartansHalftimeOU = SouthCarolinaUpstateSpartans[16]

CharlestonSouthernBuccaneersList = BigSouth.worksheet("Charleston Southern Buccaneers").get_all_values()
CharlestonSouthernBuccaneers = CharlestonSouthernBuccaneersList[1]
CharlestonSouthernBuccaneersCover = CharlestonSouthernBuccaneers[5]
CharlestonSouthernBuccaneersML = CharlestonSouthernBuccaneers[6]
CharlestonSouthernBuccaneersOU = CharlestonSouthernBuccaneers[8]
CharlestonSouthernBuccaneersSoloOU = CharlestonSouthernBuccaneers[10]
CharlestonSouthernBuccaneersHalftime = CharlestonSouthernBuccaneers[14]
CharlestonSouthernBuccaneersHalftimeOU = CharlestonSouthernBuccaneers[16]

PresbyterianBlueHoseList = BigSouth.worksheet("Presbyterian Blue Hose").get_all_values()
PresbyterianBlueHose = PresbyterianBlueHoseList[1]
PresbyterianBlueHoseCover = PresbyterianBlueHose[5]
PresbyterianBlueHoseML = PresbyterianBlueHose[6]
PresbyterianBlueHoseOU = PresbyterianBlueHose[8]
PresbyterianBlueHoseSoloOU = PresbyterianBlueHose[10]
PresbyterianBlueHoseHalftime = PresbyterianBlueHose[14]
PresbyterianBlueHoseHalftimeOU = PresbyterianBlueHose[16]

HighPointPanthersList = BigSouth.worksheet("High Point Panthers").get_all_values()
HighPointPanthers = HighPointPanthersList[1]
HighPointPanthersCover = HighPointPanthers[5]
HighPointPanthersML = HighPointPanthers[6]
HighPointPanthersOU = HighPointPanthers[8]
HighPointPanthersSoloOU = HighPointPanthers[10]
HighPointPanthersHalftime = HighPointPanthers[14]
HighPointPanthersHalftimeOU = HighPointPanthers[16]

CampbellFightingCamelsList = BigSouth.worksheet("Campbell Fighting Camels").get_all_values()
CampbellFightingCamels = CampbellFightingCamelsList[1]
CampbellFightingCamelsCover = CampbellFightingCamels[5]
CampbellFightingCamelsML = CampbellFightingCamels[6]
CampbellFightingCamelsOU = CampbellFightingCamels[8]
CampbellFightingCamelsSoloOU = CampbellFightingCamels[10]
CampbellFightingCamelsHalftime = CampbellFightingCamels[14]
CampbellFightingCamelsHalftimeOU = CampbellFightingCamels[16]

#Big10 Teams

WisconsinBadgersList = Big10.worksheet("Wisconsin Badgers").get_all_values()
WisconsinBadgers = WisconsinBadgersList[1]
WisconsinBadgersCover = WisconsinBadgers[5]
WisconsinBadgersML = WisconsinBadgers[6]
WisconsinBadgersOU = WisconsinBadgers[8]
WisconsinBadgersSoloOU = WisconsinBadgers[10]
WisconsinBadgersHalftime = WisconsinBadgers[14]
WisconsinBadgersHalftimeOU = WisconsinBadgers[16]

MarylandTerrapinsList = Big10.worksheet("Maryland Terrapins").get_all_values()
MarylandTerrapins = MarylandTerrapinsList[1]
MarylandTerrapinsCover = MarylandTerrapins[5]
MarylandTerrapinsML = MarylandTerrapins[6]
MarylandTerrapinsOU = MarylandTerrapins[8]
MarylandTerrapinsSoloOU = MarylandTerrapins[10]
MarylandTerrapinsHalftime = MarylandTerrapins[14]
MarylandTerrapinsHalftimeOU = MarylandTerrapins[16]

MichiganStateSpartansList = Big10.worksheet("Michigan State Spartans").get_all_values()
MichiganStateSpartans = MichiganStateSpartansList[1]
MichiganStateSpartansCover = MichiganStateSpartans[5]
MichiganStateSpartansML = MichiganStateSpartans[6]
MichiganStateSpartansOU = MichiganStateSpartans[8]
MichiganStateSpartansSoloOU = MichiganStateSpartans[10]
MichiganStateSpartansHalftime = MichiganStateSpartans[14]
MichiganStateSpartansHalftimeOU = MichiganStateSpartans[16]

IllinoisFightingIlliniList = Big10.worksheet("Illinois Fighting Illini").get_all_values()
IllinoisFightingIllini = IllinoisFightingIlliniList[1]
IllinoisFightingIlliniCover = IllinoisFightingIllini[5]
IllinoisFightingIlliniML = IllinoisFightingIllini[6]
IllinoisFightingIlliniOU = IllinoisFightingIllini[8]
IllinoisFightingIlliniSoloOU = IllinoisFightingIllini[10]
IllinoisFightingIlliniHalftime = IllinoisFightingIllini[14]
IllinoisFightingIlliniHalftimeOU = IllinoisFightingIllini[16]

IowaHawkeyesList = Big10.worksheet("Iowa Hawkeyes").get_all_values()
IowaHawkeyes = IowaHawkeyesList[1]
IowaHawkeyesCover = IowaHawkeyes[5]
IowaHawkeyesML = IowaHawkeyes[6]
IowaHawkeyesOU = IowaHawkeyes[8]
IowaHawkeyesSoloOU = IowaHawkeyes[10]
IowaHawkeyesHalftime = IowaHawkeyes[14]
IowaHawkeyesHalftimeOU = IowaHawkeyes[16]

OhioStateBuckeyesList = Big10.worksheet("Ohio State Buckeyes").get_all_values()
OhioStateBuckeyes = OhioStateBuckeyesList[1]
OhioStateBuckeyesCover = OhioStateBuckeyes[5]
OhioStateBuckeyesML = OhioStateBuckeyes[6]
OhioStateBuckeyesOU = OhioStateBuckeyes[8]
OhioStateBuckeyesSoloOU = OhioStateBuckeyes[10]
OhioStateBuckeyesHalftime = OhioStateBuckeyes[14]
OhioStateBuckeyesHalftimeOU = OhioStateBuckeyes[16]

PennStateNittanyLionsList = Big10.worksheet("Penn State Nittany Lions").get_all_values()
PennStateNittanyLions = PennStateNittanyLionsList[1]
PennStateNittanyLionsCover = PennStateNittanyLions[5]
PennStateNittanyLionsML = PennStateNittanyLions[6]
PennStateNittanyLionsOU = PennStateNittanyLions[8]
PennStateNittanyLionsSoloOU = PennStateNittanyLions[10]
PennStateNittanyLionsHalftime = PennStateNittanyLions[14]
PennStateNittanyLionsHalftimeOU = PennStateNittanyLions[16]

RutgersScarletKnightsList = Big10.worksheet("Rutgers Scarlet Knights").get_all_values()
RutgersScarletKnights = RutgersScarletKnightsList[1]
RutgersScarletKnightsCover = RutgersScarletKnights[5]
RutgersScarletKnightsML = RutgersScarletKnights[6]
RutgersScarletKnightsOU = RutgersScarletKnights[8]
RutgersScarletKnightsSoloOU = RutgersScarletKnights[10]
RutgersScarletKnightsHalftime = RutgersScarletKnights[14]
RutgersScarletKnightsHalftimeOU = RutgersScarletKnights[16]

MichiganWolverinesList = Big10.worksheet("Michigan Wolverines").get_all_values()
MichiganWolverines = MichiganWolverinesList[1]
MichiganWolverinesCover = MichiganWolverines[5]
MichiganWolverinesML = MichiganWolverines[6]
MichiganWolverinesOU = MichiganWolverines[8]
MichiganWolverinesSoloOU = MichiganWolverines[10]
MichiganWolverinesHalftime = MichiganWolverines[14]
MichiganWolverinesHalftimeOU = MichiganWolverines[16]

PurdueBoilermakersList = Big10.worksheet("Purdue Boilermakers").get_all_values()
PurdueBoilermakers = PurdueBoilermakersList[1]
PurdueBoilermakersCover = PurdueBoilermakers[5]
PurdueBoilermakersML = PurdueBoilermakers[6]
PurdueBoilermakersOU = PurdueBoilermakers[8]
PurdueBoilermakersSoloOU = PurdueBoilermakers[10]
PurdueBoilermakersHalftime = PurdueBoilermakers[14]
PurdueBoilermakersHalftimeOU = PurdueBoilermakers[16]

IndianaHoosiersList = Big10.worksheet("Indiana Hoosiers").get_all_values()
IndianaHoosiers = IndianaHoosiersList[1]
IndianaHoosiersCover = IndianaHoosiers[5]
IndianaHoosiersML = IndianaHoosiers[6]
IndianaHoosiersOU = IndianaHoosiers[8]
IndianaHoosiersSoloOU = IndianaHoosiers[10]
IndianaHoosiersHalftime = IndianaHoosiers[14]
IndianaHoosiersHalftimeOU = IndianaHoosiers[16]

MinnesotaGoldenGophersList = Big10.worksheet("Minnesota Golden Gophers").get_all_values()
MinnesotaGoldenGophers = MinnesotaGoldenGophersList[1]
MinnesotaGoldenGophersCover = MinnesotaGoldenGophers[5]
MinnesotaGoldenGophersML = MinnesotaGoldenGophers[6]
MinnesotaGoldenGophersOU = MinnesotaGoldenGophers[8]
MinnesotaGoldenGophersSoloOU = MinnesotaGoldenGophers[10]
MinnesotaGoldenGophersHalftime = MinnesotaGoldenGophers[14]
MinnesotaGoldenGophersHalftimeOU = MinnesotaGoldenGophers[16]

NorthwesternWildcatsList = Big10.worksheet("Northwestern Wildcats").get_all_values()
NorthwesternWildcats = NorthwesternWildcatsList[1]
NorthwesternWildcatsCover = NorthwesternWildcats[5]
NorthwesternWildcatsML = NorthwesternWildcats[6]
NorthwesternWildcatsOU = NorthwesternWildcats[8]
NorthwesternWildcatsSoloOU = NorthwesternWildcats[10]
NorthwesternWildcatsHalftime = NorthwesternWildcats[14]
NorthwesternWildcatsHalftimeOU = NorthwesternWildcats[16]

NebraskaCornhuskersList = Big10.worksheet("Nebraska Cornhuskers").get_all_values()
NebraskaCornhuskers = NebraskaCornhuskersList[1]
NebraskaCornhuskersCover = NebraskaCornhuskers[5]
NebraskaCornhuskersML = NebraskaCornhuskers[6]
NebraskaCornhuskersOU = NebraskaCornhuskers[8]
NebraskaCornhuskersSoloOU = NebraskaCornhuskers[10]
NebraskaCornhuskersHalftime = NebraskaCornhuskers[14]
NebraskaCornhuskersHalftimeOU = NebraskaCornhuskers[16]

#Big West Teams

UCIrvineAnteatersList = BigWest.worksheet("UC Irvine Anteaters").get_all_values()
UCIrvineAnteaters = UCIrvineAnteatersList[1]
UCIrvineAnteatersCover = UCIrvineAnteaters[5]
UCIrvineAnteatersML = UCIrvineAnteaters[6]
UCIrvineAnteatersOU = UCIrvineAnteaters[8]
UCIrvineAnteatersSoloOU = UCIrvineAnteaters[10]
UCIrvineAnteatersHalftime = UCIrvineAnteaters[14]
UCIrvineAnteatersHalftimeOU = UCIrvineAnteaters[16]

UCSantaBarbaraGauchosList = BigWest.worksheet("UC Santa Barbara Gauchos").get_all_values()
UCSantaBarbaraGauchos = UCSantaBarbaraGauchosList[1]
UCSantaBarbaraGauchosCover = UCSantaBarbaraGauchos[5]
UCSantaBarbaraGauchosML = UCSantaBarbaraGauchos[6]
UCSantaBarbaraGauchosOU = UCSantaBarbaraGauchos[8]
UCSantaBarbaraGauchosSoloOU = UCSantaBarbaraGauchos[10]
UCSantaBarbaraGauchosHalftime = UCSantaBarbaraGauchos[14]
UCSantaBarbaraGauchosHalftimeOU = UCSantaBarbaraGauchos[16]

CSUNorthridgeMatadorsList = BigWest.worksheet("CSU Northridge Matadors").get_all_values()
CSUNorthridgeMatadors = CSUNorthridgeMatadorsList[1]
CSUNorthridgeMatadorsCover = CSUNorthridgeMatadors[5]
CSUNorthridgeMatadorsML = CSUNorthridgeMatadors[6]
CSUNorthridgeMatadorsOU = CSUNorthridgeMatadors[8]
CSUNorthridgeMatadorsSoloOU = CSUNorthridgeMatadors[10]
CSUNorthridgeMatadorsHalftime = CSUNorthridgeMatadors[14]
CSUNorthridgeMatadorsHalftimeOU = CSUNorthridgeMatadors[16]

HawaiiRainbowWarriorsList = BigWest.worksheet("Hawaii Rainbow Warriors").get_all_values()
HawaiiRainbowWarriors = HawaiiRainbowWarriorsList[1]
HawaiiRainbowWarriorsCover = HawaiiRainbowWarriors[5]
HawaiiRainbowWarriorsML = HawaiiRainbowWarriors[6]
HawaiiRainbowWarriorsOU = HawaiiRainbowWarriors[8]
HawaiiRainbowWarriorsSoloOU = HawaiiRainbowWarriors[10]
HawaiiRainbowWarriorsHalftime = HawaiiRainbowWarriors[14]
HawaiiRainbowWarriorsHalftimeOU = HawaiiRainbowWarriors[16]

UCDavisAggiesList = BigWest.worksheet("UC Davis Aggies").get_all_values()
UCDavisAggies = UCDavisAggiesList[1]
UCDavisAggiesCover = UCDavisAggies[5]
UCDavisAggiesML = UCDavisAggies[6]
UCDavisAggiesOU = UCDavisAggies[8]
UCDavisAggiesSoloOU = UCDavisAggies[10]
UCDavisAggiesHalftime = UCDavisAggies[14]
UCDavisAggiesHalftimeOU = UCDavisAggies[16]

UCRiversideHighlandersList = BigWest.worksheet("UC Riverside Highlanders").get_all_values()
UCRiversideHighlanders = UCRiversideHighlandersList[1]
UCRiversideHighlandersCover = UCRiversideHighlanders[5]
UCRiversideHighlandersML = UCRiversideHighlanders[6]
UCRiversideHighlandersOU = UCRiversideHighlanders[8]
UCRiversideHighlandersSoloOU = UCRiversideHighlanders[10]
UCRiversideHighlandersHalftime = UCRiversideHighlanders[14]
UCRiversideHighlandersHalftimeOU = UCRiversideHighlanders[16]

CSUFullertonTitansList = BigWest.worksheet("CSU Fullerton Titans").get_all_values()
CSUFullertonTitans = CSUFullertonTitansList[1]
CSUFullertonTitansCover = CSUFullertonTitans[5]
CSUFullertonTitansML = CSUFullertonTitans[6]
CSUFullertonTitansOU = CSUFullertonTitans[8]
CSUFullertonTitansSoloOU = CSUFullertonTitans[10]
CSUFullertonTitansHalftime = CSUFullertonTitans[14]
CSUFullertonTitansHalftimeOU = CSUFullertonTitans[16]

LongBeachState49ersList = BigWest.worksheet("Long Beach State 49ers").get_all_values()
LongBeachState49ers = LongBeachState49ersList[1]
LongBeachState49ersCover = LongBeachState49ers[5]
LongBeachState49ersML = LongBeachState49ers[6]
LongBeachState49ersOU = LongBeachState49ers[8]
LongBeachState49ersSoloOU = LongBeachState49ers[10]
LongBeachState49ersHalftime = LongBeachState49ers[14]
LongBeachState49ersHalftimeOU = LongBeachState49ers[16]

CalPolyMustangsList = BigWest.worksheet("Cal Poly Mustangs").get_all_values()
CalPolyMustangs = CalPolyMustangsList[1]
CalPolyMustangsCover = CalPolyMustangs[5]
CalPolyMustangsML = CalPolyMustangs[6]
CalPolyMustangsOU = CalPolyMustangs[8]
CalPolyMustangsSoloOU = CalPolyMustangs[10]
CalPolyMustangsHalftime = CalPolyMustangs[14]
CalPolyMustangsHalftimeOU = CalPolyMustangs[16]

#Colonial Teams

HofstraPrideList = ColonialAthletic.worksheet("Hofstra Pride").get_all_values()
HofstraPride = HofstraPrideList[1]
HofstraPrideCover = HofstraPride[5]
HofstraPrideML = HofstraPride[6]
HofstraPrideOU = HofstraPride[8]
HofstraPrideSoloOU = HofstraPride[10]
HofstraPrideHalftime = HofstraPride[14]
HofstraPrideHalftimeOU = HofstraPride[16]

WilliamandMaryTribeList = ColonialAthletic.worksheet("William & Mary Tribe").get_all_values()
WilliamandMaryTribe = WilliamandMaryTribeList[1]
WilliamandMaryTribeCover = WilliamandMaryTribe[5]
WilliamandMaryTribeML = WilliamandMaryTribe[6]
WilliamandMaryTribeOU = WilliamandMaryTribe[8]
WilliamandMaryTribeSoloOU = WilliamandMaryTribe[10]
WilliamandMaryTribeHalftime = WilliamandMaryTribe[14]
WilliamandMaryTribeHalftimeOU = WilliamandMaryTribe[16]

TowsonTigersList = ColonialAthletic.worksheet("Towson Tigers").get_all_values()
TowsonTigers = TowsonTigersList[1]
TowsonTigersCover = TowsonTigers[5]
TowsonTigersML = TowsonTigers[6]
TowsonTigersOU = TowsonTigers[8]
TowsonTigersSoloOU = TowsonTigers[10]
TowsonTigersHalftime = TowsonTigers[14]
TowsonTigersHalftimeOU = TowsonTigers[16]

DelawareBlueHensList = ColonialAthletic.worksheet("Delaware Blue Hens").get_all_values()
DelawareBlueHens = DelawareBlueHensList[1]
DelawareBlueHensCover = DelawareBlueHens[5]
DelawareBlueHensML = DelawareBlueHens[6]
DelawareBlueHensOU = DelawareBlueHens[8]
DelawareBlueHensSoloOU = DelawareBlueHens[10]
DelawareBlueHensHalftime = DelawareBlueHens[14]
DelawareBlueHensHalftimeOU = DelawareBlueHens[16]

CharlestonCougarsList = ColonialAthletic.worksheet("Charleston Cougars").get_all_values()
CharlestonCougars = CharlestonCougarsList[1]
CharlestonCougarsCover = CharlestonCougars[5]
CharlestonCougarsML = CharlestonCougars[6]
CharlestonCougarsOU = CharlestonCougars[8]
CharlestonCougarsSoloOU = CharlestonCougars[10]
CharlestonCougarsHalftime = CharlestonCougars[14]
CharlestonCougarsHalftimeOU = CharlestonCougars[16]

NortheasternHuskiesList = ColonialAthletic.worksheet("Northeastern Huskies").get_all_values()
NortheasternHuskies = NortheasternHuskiesList[1]
NortheasternHuskiesCover = NortheasternHuskies[5]
NortheasternHuskiesML = NortheasternHuskies[6]
NortheasternHuskiesOU = NortheasternHuskies[8]
NortheasternHuskiesSoloOU = NortheasternHuskies[10]
NortheasternHuskiesHalftime = NortheasternHuskies[14]
NortheasternHuskiesHalftimeOU = NortheasternHuskies[16]

ElonPhoenixList = ColonialAthletic.worksheet("Elon Phoenix").get_all_values()
ElonPhoenix = ElonPhoenixList[1]
ElonPhoenixCover = ElonPhoenix[5]
ElonPhoenixML = ElonPhoenix[6]
ElonPhoenixOU = ElonPhoenix[8]
ElonPhoenixSoloOU = ElonPhoenix[10]
ElonPhoenixHalftime = ElonPhoenix[14]
ElonPhoenixHalftimeOU = ElonPhoenix[16]

DrexelDragonsList = ColonialAthletic.worksheet("Drexel Dragons").get_all_values()
DrexelDragons = DrexelDragonsList[1]
DrexelDragonsCover = DrexelDragons[5]
DrexelDragonsML = DrexelDragons[6]
DrexelDragonsOU = DrexelDragons[8]
DrexelDragonsSoloOU = DrexelDragons[10]
DrexelDragonsHalftime = DrexelDragons[14]
DrexelDragonsHalftimeOU = DrexelDragons[16]

UNCWilmingtonSeahawksList = ColonialAthletic.worksheet("UNC Wilmington Seahawks").get_all_values()
UNCWilmingtonSeahawks = UNCWilmingtonSeahawksList[1]
UNCWilmingtonSeahawksCover = UNCWilmingtonSeahawks[5]
UNCWilmingtonSeahawksML = UNCWilmingtonSeahawks[6]
UNCWilmingtonSeahawksOU = UNCWilmingtonSeahawks[8]
UNCWilmingtonSeahawksSoloOU = UNCWilmingtonSeahawks[10]
UNCWilmingtonSeahawksHalftime = UNCWilmingtonSeahawks[14]
UNCWilmingtonSeahawksHalftimeOU = UNCWilmingtonSeahawks[16]

JamesMadisonDukesList = ColonialAthletic.worksheet("James Madison Dukes").get_all_values()
JamesMadisonDukes = JamesMadisonDukesList[1]
JamesMadisonDukesCover = JamesMadisonDukes[5]
JamesMadisonDukesML = JamesMadisonDukes[6]
JamesMadisonDukesOU = JamesMadisonDukes[8]
JamesMadisonDukesSoloOU = JamesMadisonDukes[10]
JamesMadisonDukesHalftime = JamesMadisonDukes[14]
JamesMadisonDukesHalftimeOU = JamesMadisonDukes[16]

#ConferenceUSA Teams

NorthTexasMeanGreenList = ConferenceUSA.worksheet("North Texas Mean Green").get_all_values()
NorthTexasMeanGreen = NorthTexasMeanGreenList[1]
NorthTexasMeanGreenCover = NorthTexasMeanGreen[5]
NorthTexasMeanGreenML = NorthTexasMeanGreen[6]
NorthTexasMeanGreenOU = NorthTexasMeanGreen[8]
NorthTexasMeanGreenSoloOU = NorthTexasMeanGreen[10]
NorthTexasMeanGreenHalftime = NorthTexasMeanGreen[14]
NorthTexasMeanGreenHalftimeOU = NorthTexasMeanGreen[16]

LouisianaTechBulldogsList = ConferenceUSA.worksheet("Louisiana Tech Bulldogs").get_all_values()
LouisianaTechBulldogs = LouisianaTechBulldogsList[1]
LouisianaTechBulldogsCover = LouisianaTechBulldogs[5]
LouisianaTechBulldogsML = LouisianaTechBulldogs[6]
LouisianaTechBulldogsOU = LouisianaTechBulldogs[8]
LouisianaTechBulldogsSoloOU = LouisianaTechBulldogs[10]
LouisianaTechBulldogsHalftime = LouisianaTechBulldogs[14]
LouisianaTechBulldogsHalftimeOU = LouisianaTechBulldogs[16]

WesternKentuckyHilltoppersList = ConferenceUSA.worksheet("Western Kentucky Hilltoppers").get_all_values()
WesternKentuckyHilltoppers = WesternKentuckyHilltoppersList[1]
WesternKentuckyHilltoppersCover = WesternKentuckyHilltoppers[5]
WesternKentuckyHilltoppersML = WesternKentuckyHilltoppers[6]
WesternKentuckyHilltoppersOU = WesternKentuckyHilltoppers[8]
WesternKentuckyHilltoppersSoloOU = WesternKentuckyHilltoppers[10]
WesternKentuckyHilltoppersHalftime = WesternKentuckyHilltoppers[14]
WesternKentuckyHilltoppersHalftimeOU = WesternKentuckyHilltoppers[16]

Charlotte49ersList = ConferenceUSA.worksheet("Charlotte 49ers").get_all_values()
Charlotte49ers = Charlotte49ersList[1]
Charlotte49ersCover = Charlotte49ers[5]
Charlotte49ersML = Charlotte49ers[6]
Charlotte49ersOU = Charlotte49ers[8]
Charlotte49ersSoloOU = Charlotte49ers[10]
Charlotte49ersHalftime = Charlotte49ers[14]
Charlotte49ersHalftimeOU = Charlotte49ers[16]

MarshallThunderingHerdList = ConferenceUSA.worksheet("Marshall Thundering Herd").get_all_values()
MarshallThunderingHerd = MarshallThunderingHerdList[1]
MarshallThunderingHerdCover = MarshallThunderingHerd[5]
MarshallThunderingHerdML = MarshallThunderingHerd[6]
MarshallThunderingHerdOU = MarshallThunderingHerd[8]
MarshallThunderingHerdSoloOU = MarshallThunderingHerd[10]
MarshallThunderingHerdHalftime = MarshallThunderingHerd[14]
MarshallThunderingHerdHalftimeOU = MarshallThunderingHerd[16]

FloridaInternationalPanthersList = ConferenceUSA.worksheet("Florida International Panthers").get_all_values()
FloridaInternationalPanthers = FloridaInternationalPanthersList[1]
FloridaInternationalPanthersCover = FloridaInternationalPanthers[5]
FloridaInternationalPanthersML = FloridaInternationalPanthers[6]
FloridaInternationalPanthersOU = FloridaInternationalPanthers[8]
FloridaInternationalPanthersSoloOU = FloridaInternationalPanthers[10]
FloridaInternationalPanthersHalftime = FloridaInternationalPanthers[14]
FloridaInternationalPanthersHalftimeOU = FloridaInternationalPanthers[16]

UABBlazersList = ConferenceUSA.worksheet("UAB Blazers").get_all_values()
UABBlazers = UABBlazersList[1]
UABBlazersCover = UABBlazers[5]
UABBlazersML = UABBlazers[6]
UABBlazersOU = UABBlazers[8]
UABBlazersSoloOU = UABBlazers[10]
UABBlazersHalftime = UABBlazers[14]
UABBlazersHalftimeOU = UABBlazers[16]

OldDominionMonarchsList = ConferenceUSA.worksheet("Old Dominion Monarchs").get_all_values()
OldDominionMonarchs = OldDominionMonarchsList[1]
OldDominionMonarchsCover = OldDominionMonarchs[5]
OldDominionMonarchsML = OldDominionMonarchs[6]
OldDominionMonarchsOU = OldDominionMonarchs[8]
OldDominionMonarchsSoloOU = OldDominionMonarchs[10]
OldDominionMonarchsHalftime = OldDominionMonarchs[14]
OldDominionMonarchsHalftimeOU = OldDominionMonarchs[16]

FloridaAtlanticOwlsList = ConferenceUSA.worksheet("Florida Atlantic Owls").get_all_values()
FloridaAtlanticOwls = FloridaAtlanticOwlsList[1]
FloridaAtlanticOwlsCover = FloridaAtlanticOwls[5]
FloridaAtlanticOwlsML = FloridaAtlanticOwls[6]
FloridaAtlanticOwlsOU = FloridaAtlanticOwls[8]
FloridaAtlanticOwlsSoloOU = FloridaAtlanticOwls[10]
FloridaAtlanticOwlsHalftime = FloridaAtlanticOwls[14]
FloridaAtlanticOwlsHalftimeOU = FloridaAtlanticOwls[16]

UTEPMinersList = ConferenceUSA.worksheet("UTEP Miners").get_all_values()
UTEPMiners = UTEPMinersList[1]
UTEPMinersCover = UTEPMiners[5]
UTEPMinersML = UTEPMiners[6]
UTEPMinersOU = UTEPMiners[8]
UTEPMinersSoloOU = UTEPMiners[10]
UTEPMinersHalftime = UTEPMiners[14]
UTEPMinersHalftimeOU = UTEPMiners[16]

UTSARoadrunnersList = ConferenceUSA.worksheet("UTSA Roadrunners").get_all_values()
UTSARoadrunners = UTSARoadrunnersList[1]
UTSARoadrunnersCover = UTSARoadrunners[5]
UTSARoadrunnersML = UTSARoadrunners[6]
UTSARoadrunnersOU = UTSARoadrunners[8]
UTSARoadrunnersSoloOU = UTSARoadrunners[10]
UTSARoadrunnersHalftime = UTSARoadrunners[14]
UTSARoadrunnersHalftimeOU = UTSARoadrunners[16]

RiceOwlsList = ConferenceUSA.worksheet("Rice Owls").get_all_values()
RiceOwls = RiceOwlsList[1]
RiceOwlsCover = RiceOwls[5]
RiceOwlsML = RiceOwls[6]
RiceOwlsOU = RiceOwls[8]
RiceOwlsSoloOU = RiceOwls[10]
RiceOwlsHalftime = RiceOwls[14]
RiceOwlsHalftimeOU = RiceOwls[16]

SouthernMissGoldenEaglesList = ConferenceUSA.worksheet("Southern Miss Golden Eagles").get_all_values()
SouthernMissGoldenEagles = SouthernMissGoldenEaglesList[1]
SouthernMissGoldenEaglesCover = SouthernMissGoldenEagles[5]
SouthernMissGoldenEaglesML = SouthernMissGoldenEagles[6]
SouthernMissGoldenEaglesOU = SouthernMissGoldenEagles[8]
SouthernMissGoldenEaglesSoloOU = SouthernMissGoldenEagles[10]
SouthernMissGoldenEaglesHalftime = SouthernMissGoldenEagles[14]
SouthernMissGoldenEaglesHalftimeOU = SouthernMissGoldenEagles[16]

MiddleTennesseeBlueRaidersList = ConferenceUSA.worksheet("Middle Tennessee Blue Raiders").get_all_values()
MiddleTennesseeBlueRaiders = MiddleTennesseeBlueRaidersList[1]
MiddleTennesseeBlueRaidersCover = MiddleTennesseeBlueRaiders[5]
MiddleTennesseeBlueRaidersML = MiddleTennesseeBlueRaiders[6]
MiddleTennesseeBlueRaidersOU = MiddleTennesseeBlueRaiders[8]
MiddleTennesseeBlueRaidersSoloOU = MiddleTennesseeBlueRaiders[10]
MiddleTennesseeBlueRaidersHalftime = MiddleTennesseeBlueRaiders[14]
MiddleTennesseeBlueRaidersHalftimeOU = MiddleTennesseeBlueRaiders[16]

#Horizon Teams

WrightStateRaidersList = Horizon.worksheet("Wright State Raiders").get_all_values()
WrightStateRaiders = WrightStateRaidersList[1]
WrightStateRaidersCover = WrightStateRaiders[5]
WrightStateRaidersML = WrightStateRaiders[6]
WrightStateRaidersOU = WrightStateRaiders[8]
WrightStateRaidersSoloOU = WrightStateRaiders[10]
WrightStateRaidersHalftime = WrightStateRaiders[14]
WrightStateRaidersHalftimeOU = WrightStateRaiders[16]

NorthernKentuckyNorseList = Horizon.worksheet("Northern Kentucky Norse").get_all_values()
NorthernKentuckyNorse = NorthernKentuckyNorseList[1]
NorthernKentuckyNorseCover = NorthernKentuckyNorse[5]
NorthernKentuckyNorseML = NorthernKentuckyNorse[6]
NorthernKentuckyNorseOU = NorthernKentuckyNorse[8]
NorthernKentuckyNorseSoloOU = NorthernKentuckyNorse[10]
NorthernKentuckyNorseHalftime = NorthernKentuckyNorse[14]
NorthernKentuckyNorseHalftimeOU = NorthernKentuckyNorse[16]

GreenBayPhoenixList = Horizon.worksheet("Green Bay Phoenix").get_all_values()
GreenBayPhoenix = GreenBayPhoenixList[1]
GreenBayPhoenixCover = GreenBayPhoenix[5]
GreenBayPhoenixML = GreenBayPhoenix[6]
GreenBayPhoenixOU = GreenBayPhoenix[8]
GreenBayPhoenixSoloOU = GreenBayPhoenix[10]
GreenBayPhoenixHalftime = GreenBayPhoenix[14]
GreenBayPhoenixHalftimeOU = GreenBayPhoenix[16]

YoungstownStPenguinsList = Horizon.worksheet("Youngstown St Penguins").get_all_values()
YoungstownStPenguins = YoungstownStPenguinsList[1]
YoungstownStPenguinsCover = YoungstownStPenguins[5]
YoungstownStPenguinsML = YoungstownStPenguins[6]
YoungstownStPenguinsOU = YoungstownStPenguins[8]
YoungstownStPenguinsSoloOU = YoungstownStPenguins[10]
YoungstownStPenguinsHalftime = YoungstownStPenguins[14]
YoungstownStPenguinsHalftimeOU = YoungstownStPenguins[16]

UICFlamesList = Horizon.worksheet("UIC Flames").get_all_values()
UICFlames = UICFlamesList[1]
UICFlamesCover = UICFlames[5]
UICFlamesML = UICFlames[6]
UICFlamesOU = UICFlames[8]
UICFlamesSoloOU = UICFlames[10]
UICFlamesHalftime = UICFlames[14]
UICFlamesHalftimeOU = UICFlames[16]

OaklandGoldenGrizzliesList = Horizon.worksheet("Oakland Golden Grizzlies").get_all_values()
OaklandGoldenGrizzlies = OaklandGoldenGrizzliesList[1]
OaklandGoldenGrizzliesCover = OaklandGoldenGrizzlies[5]
OaklandGoldenGrizzliesML = OaklandGoldenGrizzlies[6]
OaklandGoldenGrizzliesOU = OaklandGoldenGrizzlies[8]
OaklandGoldenGrizzliesSoloOU = OaklandGoldenGrizzlies[10]
OaklandGoldenGrizzliesHalftime = OaklandGoldenGrizzlies[14]
OaklandGoldenGrizzliesHalftimeOU = OaklandGoldenGrizzlies[16]

ClevelandStateVikingsList = Horizon.worksheet("Cleveland State Vikings").get_all_values()
ClevelandStateVikings = ClevelandStateVikingsList[1]
ClevelandStateVikingsCover = ClevelandStateVikings[5]
ClevelandStateVikingsML = ClevelandStateVikings[6]
ClevelandStateVikingsOU = ClevelandStateVikings[8]
ClevelandStateVikingsSoloOU = ClevelandStateVikings[10]
ClevelandStateVikingsHalftime = ClevelandStateVikings[14]
ClevelandStateVikingsHalftimeOU = ClevelandStateVikings[16]

MilwaukeePanthersList = Horizon.worksheet("Milwaukee Panthers").get_all_values()
MilwaukeePanthers = MilwaukeePanthersList[1]
MilwaukeePanthersCover = MilwaukeePanthers[5]
MilwaukeePanthersML = MilwaukeePanthers[6]
MilwaukeePanthersOU = MilwaukeePanthers[8]
MilwaukeePanthersSoloOU = MilwaukeePanthers[10]
MilwaukeePanthersHalftime = MilwaukeePanthers[14]
MilwaukeePanthersHalftimeOU = MilwaukeePanthers[16]

DetroitMercyTitansList = Horizon.worksheet("Detroit Mercy Titans").get_all_values()
DetroitMercyTitans = DetroitMercyTitansList[1]
DetroitMercyTitansCover = DetroitMercyTitans[5]
DetroitMercyTitansML = DetroitMercyTitans[6]
DetroitMercyTitansOU = DetroitMercyTitans[8]
DetroitMercyTitansSoloOU = DetroitMercyTitans[10]
DetroitMercyTitansHalftime = DetroitMercyTitans[14]
DetroitMercyTitansHalftimeOU = DetroitMercyTitans[16]

IUPUIJaguarsList = Horizon.worksheet("IUPUI Jaguars").get_all_values()
IUPUIJaguars = IUPUIJaguarsList[1]
IUPUIJaguarsCover = IUPUIJaguars[5]
IUPUIJaguarsML = IUPUIJaguars[6]
IUPUIJaguarsOU = IUPUIJaguars[8]
IUPUIJaguarsSoloOU = IUPUIJaguars[10]
IUPUIJaguarsHalftime = IUPUIJaguars[14]
IUPUIJaguarsHalftimeOU = IUPUIJaguars[16]

#Ivy League Teams

YaleBulldogsList = Ivy.worksheet("Yale Bulldogs").get_all_values()
YaleBulldogs = YaleBulldogsList[1]
YaleBulldogsCover = YaleBulldogs[5]
YaleBulldogsML = YaleBulldogs[6]
YaleBulldogsOU = YaleBulldogs[8]
YaleBulldogsSoloOU = YaleBulldogs[10]
YaleBulldogsHalftime = YaleBulldogs[14]
YaleBulldogsHalftimeOU = YaleBulldogs[16]

HarvardCrimsonList = Ivy.worksheet("Harvard Crimson").get_all_values()
HarvardCrimson = HarvardCrimsonList[1]
HarvardCrimsonCover = HarvardCrimson[5]
HarvardCrimsonML = HarvardCrimson[6]
HarvardCrimsonOU = HarvardCrimson[8]
HarvardCrimsonSoloOU = HarvardCrimson[10]
HarvardCrimsonHalftime = HarvardCrimson[14]
HarvardCrimsonHalftimeOU = HarvardCrimson[16]

PrincetonTigersList = Ivy.worksheet("Princeton Tigers").get_all_values()
PrincetonTigers = PrincetonTigersList[1]
PrincetonTigersCover = PrincetonTigers[5]
PrincetonTigersML = PrincetonTigers[6]
PrincetonTigersOU = PrincetonTigers[8]
PrincetonTigersSoloOU = PrincetonTigers[10]
PrincetonTigersHalftime = PrincetonTigers[14]
PrincetonTigersHalftimeOU = PrincetonTigers[16]

PennsylvaniaQuakersList = Ivy.worksheet("Pennsylvania Quakers").get_all_values()
PennsylvaniaQuakers = PennsylvaniaQuakersList[1]
PennsylvaniaQuakersCover = PennsylvaniaQuakers[5]
PennsylvaniaQuakersML = PennsylvaniaQuakers[6]
PennsylvaniaQuakersOU = PennsylvaniaQuakers[8]
PennsylvaniaQuakersSoloOU = PennsylvaniaQuakers[10]
PennsylvaniaQuakersHalftime = PennsylvaniaQuakers[14]
PennsylvaniaQuakersHalftimeOU = PennsylvaniaQuakers[16]

BrownBearsList = Ivy.worksheet("Brown Bears").get_all_values()
BrownBears = BrownBearsList[1]
BrownBearsCover = BrownBears[5]
BrownBearsML = BrownBears[6]
BrownBearsOU = BrownBears[8]
BrownBearsSoloOU = BrownBears[10]
BrownBearsHalftime = BrownBears[14]
BrownBearsHalftimeOU = BrownBears[16]

DartmouthBigGreenList = Ivy.worksheet("Dartmouth Big Green").get_all_values()
DartmouthBigGreen = DartmouthBigGreenList[1]
DartmouthBigGreenCover = DartmouthBigGreen[5]
DartmouthBigGreenML = DartmouthBigGreen[6]
DartmouthBigGreenOU = DartmouthBigGreen[8]
DartmouthBigGreenSoloOU = DartmouthBigGreen[10]
DartmouthBigGreenHalftime = DartmouthBigGreen[14]
DartmouthBigGreenHalftimeOU = DartmouthBigGreen[16]

CornellBigRedList = Ivy.worksheet("Cornell Big Red").get_all_values()
CornellBigRed = CornellBigRedList[1]
CornellBigRedCover = CornellBigRed[5]
CornellBigRedML = CornellBigRed[6]
CornellBigRedOU = CornellBigRed[8]
CornellBigRedSoloOU = CornellBigRed[10]
CornellBigRedHalftime = CornellBigRed[14]
CornellBigRedHalftimeOU = CornellBigRed[16]

ColumbiaLionsList = Ivy.worksheet("Columbia Lions").get_all_values()
ColumbiaLions = ColumbiaLionsList[1]
ColumbiaLionsCover = ColumbiaLions[5]
ColumbiaLionsML = ColumbiaLions[6]
ColumbiaLionsOU = ColumbiaLions[8]
ColumbiaLionsSoloOU = ColumbiaLions[10]
ColumbiaLionsHalftime = ColumbiaLions[14]
ColumbiaLionsHalftimeOU = ColumbiaLions[16]

#MAAC Teams

SienaSaintsList = MAAC.worksheet("Siena Saints").get_all_values()
SienaSaints = SienaSaintsList[1]
SienaSaintsCover = SienaSaints[5]
SienaSaintsML = SienaSaints[6]
SienaSaintsOU = SienaSaints[8]
SienaSaintsSoloOU = SienaSaints[10]
SienaSaintsHalftime = SienaSaints[14]
SienaSaintsHalftimeOU = SienaSaints[16]

SaintPetersPeacocksList = MAAC.worksheet("Saint Peter's Peacocks").get_all_values()
SaintPetersPeacocks = SaintPetersPeacocksList[1]
SaintPetersPeacocksCover = SaintPetersPeacocks[5]
SaintPetersPeacocksML = SaintPetersPeacocks[6]
SaintPetersPeacocksOU = SaintPetersPeacocks[8]
SaintPetersPeacocksSoloOU = SaintPetersPeacocks[10]
SaintPetersPeacocksHalftime = SaintPetersPeacocks[14]
SaintPetersPeacocksHalftimeOU = SaintPetersPeacocks[16]

MonmouthHawksList = MAAC.worksheet("Monmouth Hawks").get_all_values()
MonmouthHawks = MonmouthHawksList[1]
MonmouthHawksCover = MonmouthHawks[5]
MonmouthHawksML = MonmouthHawks[6]
MonmouthHawksOU = MonmouthHawks[8]
MonmouthHawksSoloOU = MonmouthHawks[10]
MonmouthHawksHalftime = MonmouthHawks[14]
MonmouthHawksHalftimeOU = MonmouthHawks[16]

RiderBroncsList = MAAC.worksheet("Rider Broncs").get_all_values()
RiderBroncs = RiderBroncsList[1]
RiderBroncsCover = RiderBroncs[5]
RiderBroncsML = RiderBroncs[6]
RiderBroncsOU = RiderBroncs[8]
RiderBroncsSoloOU = RiderBroncs[10]
RiderBroncsHalftime = RiderBroncs[14]
RiderBroncsHalftimeOU = RiderBroncs[16]

QuinnipiacBobcatsList = MAAC.worksheet("Quinnipiac Bobcats").get_all_values()
QuinnipiacBobcats = QuinnipiacBobcatsList[1]
QuinnipiacBobcatsCover = QuinnipiacBobcats[5]
QuinnipiacBobcatsML = QuinnipiacBobcats[6]
QuinnipiacBobcatsOU = QuinnipiacBobcats[8]
QuinnipiacBobcatsSoloOU = QuinnipiacBobcats[10]
QuinnipiacBobcatsHalftime = QuinnipiacBobcats[14]
QuinnipiacBobcatsHalftimeOU = QuinnipiacBobcats[16]

NiagaraPurpleEaglesList = MAAC.worksheet("Niagara Purple Eagles").get_all_values()
NiagaraPurpleEagles = NiagaraPurpleEaglesList[1]
NiagaraPurpleEaglesCover = NiagaraPurpleEagles[5]
NiagaraPurpleEaglesML = NiagaraPurpleEagles[6]
NiagaraPurpleEaglesOU = NiagaraPurpleEagles[8]
NiagaraPurpleEaglesSoloOU = NiagaraPurpleEagles[10]
NiagaraPurpleEaglesHalftime = NiagaraPurpleEagles[14]
NiagaraPurpleEaglesHalftimeOU = NiagaraPurpleEagles[16]

IonaGaelsList = MAAC.worksheet("Iona Gaels").get_all_values()
IonaGaels = IonaGaelsList[1]
IonaGaelsCover = IonaGaels[5]
IonaGaelsML = IonaGaels[6]
IonaGaelsOU = IonaGaels[8]
IonaGaelsSoloOU = IonaGaels[10]
IonaGaelsHalftime = IonaGaels[14]
IonaGaelsHalftimeOU = IonaGaels[16]

ManhattanJaspersList = MAAC.worksheet("Manhattan Jaspers").get_all_values()
ManhattanJaspers = ManhattanJaspersList[1]
ManhattanJaspersCover = ManhattanJaspers[5]
ManhattanJaspersML = ManhattanJaspers[6]
ManhattanJaspersOU = ManhattanJaspers[8]
ManhattanJaspersSoloOU = ManhattanJaspers[10]
ManhattanJaspersHalftime = ManhattanJaspers[14]
ManhattanJaspersHalftimeOU = ManhattanJaspers[16]

FairfieldStagsList = MAAC.worksheet("Fairfield Stags").get_all_values()
FairfieldStags = FairfieldStagsList[1]
FairfieldStagsCover = FairfieldStags[5]
FairfieldStagsML = FairfieldStags[6]
FairfieldStagsOU = FairfieldStags[8]
FairfieldStagsSoloOU = FairfieldStags[10]
FairfieldStagsHalftime = FairfieldStags[14]
FairfieldStagsHalftimeOU = FairfieldStags[16]

CanisiusGoldenGriffinsList = MAAC.worksheet("Canisius Golden Griffins").get_all_values()
CanisiusGoldenGriffins = CanisiusGoldenGriffinsList[1]
CanisiusGoldenGriffinsCover = CanisiusGoldenGriffins[5]
CanisiusGoldenGriffinsML = CanisiusGoldenGriffins[6]
CanisiusGoldenGriffinsOU = CanisiusGoldenGriffins[8]
CanisiusGoldenGriffinsSoloOU = CanisiusGoldenGriffins[10]
CanisiusGoldenGriffinsHalftime = CanisiusGoldenGriffins[14]
CanisiusGoldenGriffinsHalftimeOU = CanisiusGoldenGriffins[16]

MaristRedFoxesList = MAAC.worksheet("Marist Red Foxes").get_all_values()
MaristRedFoxes = MaristRedFoxesList[1]
MaristRedFoxesCover = MaristRedFoxes[5]
MaristRedFoxesML = MaristRedFoxes[6]
MaristRedFoxesOU = MaristRedFoxes[8]
MaristRedFoxesSoloOU = MaristRedFoxes[10]
MaristRedFoxesHalftime = MaristRedFoxes[14]
MaristRedFoxesHalftimeOU = MaristRedFoxes[16]

#MidAmericanEast Teams

AkronZipsList = MidAmericanEast.worksheet("Akron Zips").get_all_values()
AkronZips = AkronZipsList[1]
AkronZipsCover = AkronZips[5]
AkronZipsML = AkronZips[6]
AkronZipsOU = AkronZips[8]
AkronZipsSoloOU = AkronZips[10]
AkronZipsHalftime = AkronZips[14]
AkronZipsHalftimeOU = AkronZips[16]

BowlingGreenFalconsList = MidAmericanEast.worksheet("Bowling Green Falcons").get_all_values()
BowlingGreenFalcons = BowlingGreenFalconsList[1]
BowlingGreenFalconsCover = BowlingGreenFalcons[5]
BowlingGreenFalconsML = BowlingGreenFalcons[6]
BowlingGreenFalconsOU = BowlingGreenFalcons[8]
BowlingGreenFalconsSoloOU = BowlingGreenFalcons[10]
BowlingGreenFalconsHalftime = BowlingGreenFalcons[14]
BowlingGreenFalconsHalftimeOU = BowlingGreenFalcons[16]

BuffaloBullsList = MidAmericanEast.worksheet("Buffalo Bulls").get_all_values()
BuffaloBulls = BuffaloBullsList[1]
BuffaloBullsCover = BuffaloBulls[5]
BuffaloBullsML = BuffaloBulls[6]
BuffaloBullsOU = BuffaloBulls[8]
BuffaloBullsSoloOU = BuffaloBulls[10]
BuffaloBullsHalftime = BuffaloBulls[14]
BuffaloBullsHalftimeOU = BuffaloBulls[16]

KentStateGoldenFlashesList = MidAmericanEast.worksheet("Kent State Golden Flashes").get_all_values()
KentStateGoldenFlashes = KentStateGoldenFlashesList[1]
KentStateGoldenFlashesCover = KentStateGoldenFlashes[5]
KentStateGoldenFlashesML = KentStateGoldenFlashes[6]
KentStateGoldenFlashesOU = KentStateGoldenFlashes[8]
KentStateGoldenFlashesSoloOU = KentStateGoldenFlashes[10]
KentStateGoldenFlashesHalftime = KentStateGoldenFlashes[14]
KentStateGoldenFlashesHalftimeOU = KentStateGoldenFlashes[16]

OhioBobcatsList = MidAmericanEast.worksheet("Ohio Bobcats").get_all_values()
OhioBobcats = OhioBobcatsList[1]
OhioBobcatsCover = OhioBobcats[5]
OhioBobcatsML = OhioBobcats[6]
OhioBobcatsOU = OhioBobcats[8]
OhioBobcatsSoloOU = OhioBobcats[10]
OhioBobcatsHalftime = OhioBobcats[14]
OhioBobcatsHalftimeOU = OhioBobcats[16]

MiamiOHRedHawksList = MidAmericanEast.worksheet("Miami (OH) RedHawks").get_all_values()
MiamiOHRedHawks = MiamiOHRedHawksList[1]
MiamiOHRedHawksCover = MiamiOHRedHawks[5]
MiamiOHRedHawksML = MiamiOHRedHawks[6]
MiamiOHRedHawksOU = MiamiOHRedHawks[8]
MiamiOHRedHawksSoloOU = MiamiOHRedHawks[10]
MiamiOHRedHawksHalftime = MiamiOHRedHawks[14]
MiamiOHRedHawksHalftimeOU = MiamiOHRedHawks[16]

#MidAmericanWest Teams

BallStateCardinalsList = MidAmericanWest.worksheet("Ball State Cardinals").get_all_values()
BallStateCardinals  = BallStateCardinalsList[1]
BallStateCardinalsCover = BallStateCardinals [5]
BallStateCardinalsML = BallStateCardinals [6]
BallStateCardinalsOU = BallStateCardinals [8]
BallStateCardinalsSoloOU = BallStateCardinals [10]
BallStateCardinalsHalftime = BallStateCardinals [14]
BallStateCardinalsHalftimeOU = BallStateCardinals [16]

NorthernIllinoisHuskiesList = MidAmericanWest.worksheet("Northern Illinois Huskies").get_all_values()
NorthernIllinoisHuskies = NorthernIllinoisHuskiesList[1]
NorthernIllinoisHuskiesCover = NorthernIllinoisHuskies[5]
NorthernIllinoisHuskiesML = NorthernIllinoisHuskies[6]
NorthernIllinoisHuskiesOU = NorthernIllinoisHuskies[8]
NorthernIllinoisHuskiesSoloOU = NorthernIllinoisHuskies[10]
NorthernIllinoisHuskiesHalftime = NorthernIllinoisHuskies[14]
NorthernIllinoisHuskiesHalftimeOU = NorthernIllinoisHuskies[16]

ToledoRocketsList = MidAmericanWest.worksheet("Toledo Rockets").get_all_values()
ToledoRockets = ToledoRocketsList[1]
ToledoRocketsCover = ToledoRockets[5]
ToledoRocketsML = ToledoRockets[6]
ToledoRocketsOU = ToledoRockets[8]
ToledoRocketsSoloOU = ToledoRockets[10]
ToledoRocketsHalftime = ToledoRockets[14]
ToledoRocketsHalftimeOU = ToledoRockets[16]

CentralMichiganChippewasList = MidAmericanWest.worksheet("Central Michigan Chippewas").get_all_values()
CentralMichiganChippewas = CentralMichiganChippewasList[1]
CentralMichiganChippewasCover = CentralMichiganChippewas[5]
CentralMichiganChippewasML = CentralMichiganChippewas[6]
CentralMichiganChippewasOU = CentralMichiganChippewas[8]
CentralMichiganChippewasSoloOU = CentralMichiganChippewas[10]
CentralMichiganChippewasHalftime = CentralMichiganChippewas[14]
CentralMichiganChippewasHalftimeOU = CentralMichiganChippewas[16]

EasternMichiganEaglesList = MidAmericanWest.worksheet("Eastern Michigan Eagles").get_all_values()
EasternMichiganEagles = EasternMichiganEaglesList[1]
EasternMichiganEaglesCover = EasternMichiganEagles[5]
EasternMichiganEaglesML = EasternMichiganEagles[6]
EasternMichiganEaglesOU = EasternMichiganEagles[8]
EasternMichiganEaglesSoloOU = EasternMichiganEagles[10]
EasternMichiganEaglesHalftime = EasternMichiganEagles[14]
EasternMichiganEaglesHalftimeOU = EasternMichiganEagles[16]

WesternMichiganBroncosList = MidAmericanWest.worksheet("Western Michigan Broncos").get_all_values()
WesternMichiganBroncos = WesternMichiganBroncosList[1]
WesternMichiganBroncosCover = WesternMichiganBroncos[5]
WesternMichiganBroncosML = WesternMichiganBroncos[6]
WesternMichiganBroncosOU = WesternMichiganBroncos[8]
WesternMichiganBroncosSoloOU = WesternMichiganBroncos[10]
WesternMichiganBroncosHalftime = WesternMichiganBroncos[14]
WesternMichiganBroncosHalftimeOU = WesternMichiganBroncos[16]

#MidEasternAthletic Teams

NorthCarolinaCentralEaglesList = MidEasternAthletic.worksheet("North Carolina Central Eagles").get_all_values()
NorthCarolinaCentralEagles = NorthCarolinaCentralEaglesList[1]
NorthCarolinaCentralEaglesCover = NorthCarolinaCentralEagles[5]
NorthCarolinaCentralEaglesML = NorthCarolinaCentralEagles[6]
NorthCarolinaCentralEaglesOU = NorthCarolinaCentralEagles[8]
NorthCarolinaCentralEaglesSoloOU = NorthCarolinaCentralEagles[10]
NorthCarolinaCentralEaglesHalftime = NorthCarolinaCentralEagles[14]
NorthCarolinaCentralEaglesHalftimeOU = NorthCarolinaCentralEagles[16]

NorthCarolinaAandTAggiesList = MidEasternAthletic.worksheet("North Carolina A&T Aggies").get_all_values()
NorthCarolinaAandTAggies = NorthCarolinaAandTAggiesList[1]
NorthCarolinaAandTAggiesCover = NorthCarolinaAandTAggies[5]
NorthCarolinaAandTAggiesML = NorthCarolinaAandTAggies[6]
NorthCarolinaAandTAggiesOU = NorthCarolinaAandTAggies[8]
NorthCarolinaAandTAggiesSoloOU = NorthCarolinaAandTAggies[10]
NorthCarolinaAandTAggiesHalftime = NorthCarolinaAandTAggies[14]
NorthCarolinaAandTAggiesHalftimeOU = NorthCarolinaAandTAggies[16]

NorfolkStateSpartansList = MidEasternAthletic.worksheet("Norfolk State Spartans").get_all_values()
NorfolkStateSpartans = NorfolkStateSpartansList[1]
NorfolkStateSpartansCover = NorfolkStateSpartans[5]
NorfolkStateSpartansML = NorfolkStateSpartans[6]
NorfolkStateSpartansOU = NorfolkStateSpartans[8]
NorfolkStateSpartansSoloOU = NorfolkStateSpartans[10]
NorfolkStateSpartansHalftime = NorfolkStateSpartans[14]
NorfolkStateSpartansHalftimeOU = NorfolkStateSpartans[16]

BethuneCookmanWildcatsList = MidEasternAthletic.worksheet("Bethune-Cookman Wildcats").get_all_values()
BethuneCookmanWildcats = BethuneCookmanWildcatsList[1]
BethuneCookmanWildcatsCover = BethuneCookmanWildcats[5]
BethuneCookmanWildcatsML = BethuneCookmanWildcats[6]
BethuneCookmanWildcatsOU = BethuneCookmanWildcats[8]
BethuneCookmanWildcatsSoloOU = BethuneCookmanWildcats[10]
BethuneCookmanWildcatsHalftime = BethuneCookmanWildcats[14]
BethuneCookmanWildcatsHalftimeOU = BethuneCookmanWildcats[16]

FloridaAandMRattlersList = MidEasternAthletic.worksheet("Florida A&M Rattlers").get_all_values()
FloridaAandMRattlers = FloridaAandMRattlersList[1]
FloridaAandMRattlersCover = FloridaAandMRattlers[5]
FloridaAandMRattlersML = FloridaAandMRattlers[6]
FloridaAandMRattlersOU = FloridaAandMRattlers[8]
FloridaAandMRattlersSoloOU = FloridaAandMRattlers[10]
FloridaAandMRattlersHalftime = FloridaAandMRattlers[14]
FloridaAandMRattlersHalftimeOU = FloridaAandMRattlers[16]

MorganStateBearsList = MidEasternAthletic.worksheet("Morgan State Bears").get_all_values()
MorganStateBears = MorganStateBearsList[1]
MorganStateBearsCover = MorganStateBears[5]
MorganStateBearsML = MorganStateBears[6]
MorganStateBearsOU = MorganStateBears[8]
MorganStateBearsSoloOU = MorganStateBears[10]
MorganStateBearsHalftime = MorganStateBears[14]
MorganStateBearsHalftimeOU = MorganStateBears[16]

CoppinStateEaglesList = MidEasternAthletic.worksheet("Coppin State Eagles").get_all_values()
CoppinStateEagles = CoppinStateEaglesList[1]
CoppinStateEaglesCover = CoppinStateEagles[5]
CoppinStateEaglesML = CoppinStateEagles[6]
CoppinStateEaglesOU = CoppinStateEagles[8]
CoppinStateEaglesSoloOU = CoppinStateEagles[10]
CoppinStateEaglesHalftime = CoppinStateEagles[14]
CoppinStateEaglesHalftimeOU = CoppinStateEagles[16]

SouthCarolinaStateBulldogsList = MidEasternAthletic.worksheet("South Carolina State Bulldogs").get_all_values()
SouthCarolinaStateBulldogs = SouthCarolinaStateBulldogsList[1]
SouthCarolinaStateBulldogsCover = SouthCarolinaStateBulldogs[5]
SouthCarolinaStateBulldogsML = SouthCarolinaStateBulldogs[6]
SouthCarolinaStateBulldogsOU = SouthCarolinaStateBulldogs[8]
SouthCarolinaStateBulldogsSoloOU = SouthCarolinaStateBulldogs[10]
SouthCarolinaStateBulldogsHalftime = SouthCarolinaStateBulldogs[14]
SouthCarolinaStateBulldogsHalftimeOU = SouthCarolinaStateBulldogs[16]

DelawareStateHornetsList = MidEasternAthletic.worksheet("Delaware State Hornets").get_all_values()
DelawareStateHornets = DelawareStateHornetsList[1]
DelawareStateHornetsCover = DelawareStateHornets[5]
DelawareStateHornetsML = DelawareStateHornets[6]
DelawareStateHornetsOU = DelawareStateHornets[8]
DelawareStateHornetsSoloOU = DelawareStateHornets[10]
DelawareStateHornetsHalftime = DelawareStateHornets[14]
DelawareStateHornetsHalftimeOU = DelawareStateHornets[16]

MarylandEasternShoreHawksList = MidEasternAthletic.worksheet("Maryland-Eastern Shore Hawks").get_all_values()
MarylandEasternShoreHawks = MarylandEasternShoreHawksList[1]
MarylandEasternShoreHawksCover = MarylandEasternShoreHawks[5]
MarylandEasternShoreHawksML = MarylandEasternShoreHawks[6]
MarylandEasternShoreHawksOU = MarylandEasternShoreHawks[8]
MarylandEasternShoreHawksSoloOU = MarylandEasternShoreHawks[10]
MarylandEasternShoreHawksHalftime = MarylandEasternShoreHawks[14]
MarylandEasternShoreHawksHalftimeOU = MarylandEasternShoreHawks[16]

HowardBisonList = MidEasternAthletic.worksheet("Howard Bison").get_all_values()
HowardBison = HowardBisonList[1]
HowardBisonCover = HowardBison[5]
HowardBisonML = HowardBison[6]
HowardBisonOU = HowardBison[8]
HowardBisonSoloOU = HowardBison[10]
HowardBisonHalftime = HowardBison[14]
HowardBisonHalftimeOU = HowardBison[16]

#Missouri Valley Teams

NorthernIowaPanthersList = MissouriValley.worksheet("Northern Iowa Panthers").get_all_values()
NorthernIowaPanthers = NorthernIowaPanthersList[1]
NorthernIowaPanthersCover = NorthernIowaPanthers[5]
NorthernIowaPanthersML = NorthernIowaPanthers[6]
NorthernIowaPanthersOU = NorthernIowaPanthers[8]
NorthernIowaPanthersSoloOU = NorthernIowaPanthers[10]
NorthernIowaPanthersHalftime = NorthernIowaPanthers[14]
NorthernIowaPanthersHalftimeOU = NorthernIowaPanthers[16]

LoyolaChicagoRamblersList = MissouriValley.worksheet("Loyola Chicago Ramblers").get_all_values()
LoyolaChicagoRamblers = LoyolaChicagoRamblersList[1]
LoyolaChicagoRamblersCover = LoyolaChicagoRamblers[5]
LoyolaChicagoRamblersML = LoyolaChicagoRamblers[6]
LoyolaChicagoRamblersOU = LoyolaChicagoRamblers[8]
LoyolaChicagoRamblersSoloOU = LoyolaChicagoRamblers[10]
LoyolaChicagoRamblersHalftime = LoyolaChicagoRamblers[14]
LoyolaChicagoRamblersHalftimeOU = LoyolaChicagoRamblers[16]

BradleyBravesList = MissouriValley.worksheet("Bradley Braves").get_all_values()
BradleyBraves = BradleyBravesList[1]
BradleyBravesCover = BradleyBraves[5]
BradleyBravesML = BradleyBraves[6]
BradleyBravesOU = BradleyBraves[8]
BradleyBravesSoloOU = BradleyBraves[10]
BradleyBravesHalftime = BradleyBraves[14]
BradleyBravesHalftimeOU = BradleyBraves[16]

IndianaStateSycamoresList = MissouriValley.worksheet("Indiana State Sycamores").get_all_values()
IndianaStateSycamores = IndianaStateSycamoresList[1]
IndianaStateSycamoresCover = IndianaStateSycamores[5]
IndianaStateSycamoresML = IndianaStateSycamores[6]
IndianaStateSycamoresOU = IndianaStateSycamores[8]
IndianaStateSycamoresSoloOU = IndianaStateSycamores[10]
IndianaStateSycamoresHalftime = IndianaStateSycamores[14]
IndianaStateSycamoresHalftimeOU = IndianaStateSycamores[16]

SouthernIllinoisSalukisList = MissouriValley.worksheet("Southern Illinois Salukis").get_all_values()
SouthernIllinoisSalukis = SouthernIllinoisSalukisList[1]
SouthernIllinoisSalukisCover = SouthernIllinoisSalukis[5]
SouthernIllinoisSalukisML = SouthernIllinoisSalukis[6]
SouthernIllinoisSalukisOU = SouthernIllinoisSalukis[8]
SouthernIllinoisSalukisSoloOU = SouthernIllinoisSalukis[10]
SouthernIllinoisSalukisHalftime = SouthernIllinoisSalukis[14]
SouthernIllinoisSalukisHalftimeOU = SouthernIllinoisSalukis[16]

ValparaisoCrusadersList = MissouriValley.worksheet("Valparaiso Crusaders").get_all_values()
ValparaisoCrusaders = ValparaisoCrusadersList[1]
ValparaisoCrusadersCover = ValparaisoCrusaders[5]
ValparaisoCrusadersML = ValparaisoCrusaders[6]
ValparaisoCrusadersOU = ValparaisoCrusaders[8]
ValparaisoCrusadersSoloOU = ValparaisoCrusaders[10]
ValparaisoCrusadersHalftime = ValparaisoCrusaders[14]
ValparaisoCrusadersHalftimeOU = ValparaisoCrusaders[16]

MissouriStateBearsList = MissouriValley.worksheet("Missouri State Bears").get_all_values()
MissouriStateBears = MissouriStateBearsList[1]
MissouriStateBearsCover = MissouriStateBears[5]
MissouriStateBearsML = MissouriStateBears[6]
MissouriStateBearsOU = MissouriStateBears[8]
MissouriStateBearsSoloOU = MissouriStateBears[10]
MissouriStateBearsHalftime = MissouriStateBears[14]
MissouriStateBearsHalftimeOU = MissouriStateBears[16]

DrakeBulldogsList = MissouriValley.worksheet("Drake Bulldogs").get_all_values()
DrakeBulldogs = DrakeBulldogsList[1]
DrakeBulldogsCover = DrakeBulldogs[5]
DrakeBulldogsML = DrakeBulldogs[6]
DrakeBulldogsOU = DrakeBulldogs[8]
DrakeBulldogsSoloOU = DrakeBulldogs[10]
DrakeBulldogsHalftime = DrakeBulldogs[14]
DrakeBulldogsHalftimeOU = DrakeBulldogs[16]

IllinoisStateRedbirdsList = MissouriValley.worksheet("Illinois State Redbirds").get_all_values()
IllinoisStateRedbirds = IllinoisStateRedbirdsList[1]
IllinoisStateRedbirdsCover = IllinoisStateRedbirds[5]
IllinoisStateRedbirdsML = IllinoisStateRedbirds[6]
IllinoisStateRedbirdsOU = IllinoisStateRedbirds[8]
IllinoisStateRedbirdsSoloOU = IllinoisStateRedbirds[10]
IllinoisStateRedbirdsHalftime = IllinoisStateRedbirds[14]
IllinoisStateRedbirdsHalftimeOU = IllinoisStateRedbirds[16]

EvansvillePurpleAcesList = MissouriValley.worksheet("Evansville Purple Aces").get_all_values()
EvansvillePurpleAces = EvansvillePurpleAcesList[1]
EvansvillePurpleAcesCover = EvansvillePurpleAces[5]
EvansvillePurpleAcesML = EvansvillePurpleAces[6]
EvansvillePurpleAcesOU = EvansvillePurpleAces[8]
EvansvillePurpleAcesSoloOU = EvansvillePurpleAces[10]
EvansvillePurpleAcesHalftime = EvansvillePurpleAces[14]
EvansvillePurpleAcesHalftimeOU = EvansvillePurpleAces[16]
#Mountain West Teams

SanDiegoStateAztecsList = MountainWest.worksheet("San Diego State Aztecs").get_all_values()
SanDiegoStateAztecs = SanDiegoStateAztecsList[1]
SanDiegoStateAztecsCover = SanDiegoStateAztecs[5]
SanDiegoStateAztecsML = SanDiegoStateAztecs[6]
SanDiegoStateAztecsOU = SanDiegoStateAztecs[8]
SanDiegoStateAztecsSoloOU = SanDiegoStateAztecs[10]
SanDiegoStateAztecsHalftime = SanDiegoStateAztecs[14]
SanDiegoStateAztecsHalftimeOU = SanDiegoStateAztecs[16]

UtahStateAggiesList = MountainWest.worksheet("Utah State Aggies").get_all_values()
UtahStateAggies = UtahStateAggiesList[1]
UtahStateAggiesCover = UtahStateAggies[5]
UtahStateAggiesML = UtahStateAggies[6]
UtahStateAggiesOU = UtahStateAggies[8]
UtahStateAggiesSoloOU = UtahStateAggies[10]
UtahStateAggiesHalftime = UtahStateAggies[14]
UtahStateAggiesHalftimeOU = UtahStateAggies[16]

NevadaWolfPackList = MountainWest.worksheet("Nevada Wolf Pack").get_all_values()
NevadaWolfPack = NevadaWolfPackList[1]
NevadaWolfPackCover = NevadaWolfPack[5]
NevadaWolfPackML = NevadaWolfPack[6]
NevadaWolfPackOU = NevadaWolfPack[8]
NevadaWolfPackSoloOU = NevadaWolfPack[10]
NevadaWolfPackHalftime = NevadaWolfPack[14]
NevadaWolfPackHalftimeOU = NevadaWolfPack[16]

UNLVRebelsList = MountainWest.worksheet("UNLV Rebels").get_all_values()
UNLVRebels = UNLVRebelsList[1]
UNLVRebelsCover = UNLVRebels[5]
UNLVRebelsML = UNLVRebels[6]
UNLVRebelsOU = UNLVRebels[8]
UNLVRebelsSoloOU = UNLVRebels[10]
UNLVRebelsHalftime = UNLVRebels[14]
UNLVRebelsHalftimeOU = UNLVRebels[16]

BoiseStateBroncosList = MountainWest.worksheet("Boise State Broncos").get_all_values()
BoiseStateBroncos = BoiseStateBroncosList[1]
BoiseStateBroncosCover = BoiseStateBroncos[5]
BoiseStateBroncosML = BoiseStateBroncos[6]
BoiseStateBroncosOU = BoiseStateBroncos[8]
BoiseStateBroncosSoloOU = BoiseStateBroncos[10]
BoiseStateBroncosHalftime = BoiseStateBroncos[14]
BoiseStateBroncosHalftimeOU = BoiseStateBroncos[16]

ColoradoStateRamsList = MountainWest.worksheet("Colorado State Rams").get_all_values()
ColoradoStateRams = ColoradoStateRamsList[1]
ColoradoStateRamsCover = ColoradoStateRams[5]
ColoradoStateRamsML = ColoradoStateRams[6]
ColoradoStateRamsOU = ColoradoStateRams[8]
ColoradoStateRamsSoloOU = ColoradoStateRams[10]
ColoradoStateRamsHalftime = ColoradoStateRams[14]
ColoradoStateRamsHalftimeOU = ColoradoStateRams[16]

NewMexicoLobosList = MountainWest.worksheet("New Mexico Lobos").get_all_values()
NewMexicoLobos = NewMexicoLobosList[1]
NewMexicoLobosCover = NewMexicoLobos[5]
NewMexicoLobosML = NewMexicoLobos[6]
NewMexicoLobosOU = NewMexicoLobos[8]
NewMexicoLobosSoloOU = NewMexicoLobos[10]
NewMexicoLobosHalftime = NewMexicoLobos[14]
NewMexicoLobosHalftimeOU = NewMexicoLobos[16]

FresnoStateBulldogsList = MountainWest.worksheet("Fresno State Bulldogs").get_all_values()
FresnoStateBulldogs = FresnoStateBulldogsList[1]
FresnoStateBulldogsCover = FresnoStateBulldogs[5]
FresnoStateBulldogsML = FresnoStateBulldogs[6]
FresnoStateBulldogsOU = FresnoStateBulldogs[8]
FresnoStateBulldogsSoloOU = FresnoStateBulldogs[10]
FresnoStateBulldogsHalftime = FresnoStateBulldogs[14]
FresnoStateBulldogsHalftimeOU = FresnoStateBulldogs[16]

AirForceFalconsList = MountainWest.worksheet("Air Force Falcons").get_all_values()
AirForceFalcons = AirForceFalconsList[1]
AirForceFalconsCover = AirForceFalcons[5]
AirForceFalconsML = AirForceFalcons[6]
AirForceFalconsOU = AirForceFalcons[8]
AirForceFalconsSoloOU = AirForceFalcons[10]
AirForceFalconsHalftime = AirForceFalcons[14]
AirForceFalconsHalftimeOU = AirForceFalcons[16]

SanJoseStateSpartansList = MountainWest.worksheet("San Jose State Spartans").get_all_values()
SanJoseStateSpartans = SanJoseStateSpartansList[1]
SanJoseStateSpartansCover = SanJoseStateSpartans[5]
SanJoseStateSpartansML = SanJoseStateSpartans[6]
SanJoseStateSpartansOU = SanJoseStateSpartans[8]
SanJoseStateSpartansSoloOU = SanJoseStateSpartans[10]
SanJoseStateSpartansHalftime = SanJoseStateSpartans[14]
SanJoseStateSpartansHalftimeOU = SanJoseStateSpartans[16]

WyomingCowboysList = MountainWest.worksheet("Wyoming Cowboys").get_all_values()
WyomingCowboys = WyomingCowboysList[1]
WyomingCowboysCover = WyomingCowboys[5]
WyomingCowboysML = WyomingCowboys[6]
WyomingCowboysOU = WyomingCowboys[8]
WyomingCowboysSoloOU = WyomingCowboys[10]
WyomingCowboysHalftime = WyomingCowboys[14]
WyomingCowboysHalftimeOU = WyomingCowboys[16]

#North East Teams

MerrimackWarriorsList = NorthEast.worksheet("Merrimack Warriors").get_all_values()
MerrimackWarriors = MerrimackWarriorsList[1]
MerrimackWarriorsCover = MerrimackWarriors[5]
MerrimackWarriorsML = MerrimackWarriors[6]
MerrimackWarriorsOU = MerrimackWarriors[8]
MerrimackWarriorsSoloOU = MerrimackWarriors[10]
MerrimackWarriorsHalftime = MerrimackWarriors[14]
MerrimackWarriorsHalftimeOU = MerrimackWarriors[16]

StFrancisPARedFlashList = NorthEast.worksheet("St. Francis (PA) Red Flash").get_all_values()
StFrancisPARedFlash = StFrancisPARedFlashList[1]
StFrancisPARedFlashCover = StFrancisPARedFlash[5]
StFrancisPARedFlashML = StFrancisPARedFlash[6]
StFrancisPARedFlashOU = StFrancisPARedFlash[8]
StFrancisPARedFlashSoloOU = StFrancisPARedFlash[10]
StFrancisPARedFlashHalftime = StFrancisPARedFlash[14]
StFrancisPARedFlashHalftimeOU = StFrancisPARedFlash[16]

RobertMorrisColonialsList = NorthEast.worksheet("Robert Morris Colonials").get_all_values()
RobertMorrisColonials = RobertMorrisColonialsList[1]
RobertMorrisColonialsCover = RobertMorrisColonials[5]
RobertMorrisColonialsML = RobertMorrisColonials[6]
RobertMorrisColonialsOU = RobertMorrisColonials[8]
RobertMorrisColonialsSoloOU = RobertMorrisColonials[10]
RobertMorrisColonialsHalftime = RobertMorrisColonials[14]
RobertMorrisColonialsHalftimeOU = RobertMorrisColonials[16]

SacredHeartPioneersList = NorthEast.worksheet("Sacred Heart Pioneers").get_all_values()
SacredHeartPioneers = SacredHeartPioneersList[1]
SacredHeartPioneersCover = SacredHeartPioneers[5]
SacredHeartPioneersML = SacredHeartPioneers[6]
SacredHeartPioneersOU = SacredHeartPioneers[8]
SacredHeartPioneersSoloOU = SacredHeartPioneers[10]
SacredHeartPioneersHalftime = SacredHeartPioneers[14]
SacredHeartPioneersHalftimeOU = SacredHeartPioneers[16]

LongIslandUniversitySharksList = NorthEast.worksheet("Long Island University Sharks").get_all_values()
LongIslandUniversitySharks = LongIslandUniversitySharksList[1]
LongIslandUniversitySharksCover = LongIslandUniversitySharks[5]
LongIslandUniversitySharksML = LongIslandUniversitySharks[6]
LongIslandUniversitySharksOU = LongIslandUniversitySharks[8]
LongIslandUniversitySharksSoloOU = LongIslandUniversitySharks[10]
LongIslandUniversitySharksHalftime = LongIslandUniversitySharks[14]
LongIslandUniversitySharksHalftimeOU = LongIslandUniversitySharks[16]

FairleighDickinsonKnightsList = NorthEast.worksheet("Fairleigh Dickinson Knights").get_all_values()
FairleighDickinsonKnights = FairleighDickinsonKnightsList[1]
FairleighDickinsonKnightsCover = FairleighDickinsonKnights[5]
FairleighDickinsonKnightsML = FairleighDickinsonKnights[6]
FairleighDickinsonKnightsOU = FairleighDickinsonKnights[8]
FairleighDickinsonKnightsSoloOU = FairleighDickinsonKnights[10]
FairleighDickinsonKnightsHalftime = FairleighDickinsonKnights[14]
FairleighDickinsonKnightsHalftimeOU = FairleighDickinsonKnights[16]

MtStMarysMountaineersList = NorthEast.worksheet("Mt. St. Mary's Mountaineers").get_all_values()
MtStMarysMountaineers = MtStMarysMountaineersList[1]
MtStMarysMountaineersCover = MtStMarysMountaineers[5]
MtStMarysMountaineersML = MtStMarysMountaineers[6]
MtStMarysMountaineersOU = MtStMarysMountaineers[8]
MtStMarysMountaineersSoloOU = MtStMarysMountaineers[10]
MtStMarysMountaineersHalftime = MtStMarysMountaineers[14]
MtStMarysMountaineersHalftimeOU = MtStMarysMountaineers[16]

BryantBulldogsList = NorthEast.worksheet("Bryant Bulldogs").get_all_values()
BryantBulldogs = BryantBulldogsList[1]
BryantBulldogsCover = BryantBulldogs[5]
BryantBulldogsML = BryantBulldogs[6]
BryantBulldogsOU = BryantBulldogs[8]
BryantBulldogsSoloOU = BryantBulldogs[10]
BryantBulldogsHalftime = BryantBulldogs[14]
BryantBulldogsHalftimeOU = BryantBulldogs[16]

StFrancisBKNTerriersList = NorthEast.worksheet("St. Francis (BKN) Terriers").get_all_values()
StFrancisBKNTerriers = StFrancisBKNTerriersList[1]
StFrancisBKNTerriersCover = StFrancisBKNTerriers[5]
StFrancisBKNTerriersML = StFrancisBKNTerriers[6]
StFrancisBKNTerriersOU = StFrancisBKNTerriers[8]
StFrancisBKNTerriersSoloOU = StFrancisBKNTerriers[10]
StFrancisBKNTerriersHalftime = StFrancisBKNTerriers[14]
StFrancisBKNTerriersHalftimeOU = StFrancisBKNTerriers[16]

WagnerSeahawksList = NorthEast.worksheet("Wagner Seahawks").get_all_values()
WagnerSeahawks = WagnerSeahawksList[1]
WagnerSeahawksCover = WagnerSeahawks[5]
WagnerSeahawksML = WagnerSeahawks[6]
WagnerSeahawksOU = WagnerSeahawks[8]
WagnerSeahawksSoloOU = WagnerSeahawks[10]
WagnerSeahawksHalftime = WagnerSeahawks[14]
WagnerSeahawksHalftimeOU = WagnerSeahawks[16]

CentralConnecticutBlueDevilsList = NorthEast.worksheet("Central Connecticut Blue Devils").get_all_values()
CentralConnecticutBlueDevils = CentralConnecticutBlueDevilsList[1]
CentralConnecticutBlueDevilsCover = CentralConnecticutBlueDevils[5]
CentralConnecticutBlueDevilsML = CentralConnecticutBlueDevils[6]
CentralConnecticutBlueDevilsOU = CentralConnecticutBlueDevils[8]
CentralConnecticutBlueDevilsSoloOU = CentralConnecticutBlueDevils[10]
CentralConnecticutBlueDevilsHalftime = CentralConnecticutBlueDevils[14]
CentralConnecticutBlueDevilsHalftimeOU = CentralConnecticutBlueDevils[16]

#Ohio Valley Teams

BelmontBruinsList = OhioValley.worksheet("Belmont Bruins").get_all_values()
BelmontBruins = BelmontBruinsList[1]
BelmontBruinsCover = BelmontBruins[5]
BelmontBruinsML = BelmontBruins[6]
BelmontBruinsOU = BelmontBruins[8]
BelmontBruinsSoloOU = BelmontBruins[10]
BelmontBruinsHalftime = BelmontBruins[14]
BelmontBruinsHalftimeOU = BelmontBruins[16]

MurrayStateRacersList = OhioValley.worksheet("Murray State Racers").get_all_values()
MurrayStateRacers = MurrayStateRacersList[1]
MurrayStateRacersCover = MurrayStateRacers[5]
MurrayStateRacersML = MurrayStateRacers[6]
MurrayStateRacersOU = MurrayStateRacers[8]
MurrayStateRacersSoloOU = MurrayStateRacers[10]
MurrayStateRacersHalftime = MurrayStateRacers[14]
MurrayStateRacersHalftimeOU = MurrayStateRacers[16]

AustinPeayGovernorsList = OhioValley.worksheet("Austin Peay Governors").get_all_values()
AustinPeayGovernors = AustinPeayGovernorsList[1]
AustinPeayGovernorsCover = AustinPeayGovernors[5]
AustinPeayGovernorsML = AustinPeayGovernors[6]
AustinPeayGovernorsOU = AustinPeayGovernors[8]
AustinPeayGovernorsSoloOU = AustinPeayGovernors[10]
AustinPeayGovernorsHalftime = AustinPeayGovernors[14]
AustinPeayGovernorsHalftimeOU = AustinPeayGovernors[16]

EasternKentuckyColonelsList = OhioValley.worksheet("Eastern Kentucky Colonels").get_all_values()
EasternKentuckyColonels = EasternKentuckyColonelsList[1]
EasternKentuckyColonelsCover = EasternKentuckyColonels[5]
EasternKentuckyColonelsML = EasternKentuckyColonels[6]
EasternKentuckyColonelsOU = EasternKentuckyColonels[8]
EasternKentuckyColonelsSoloOU = EasternKentuckyColonels[10]
EasternKentuckyColonelsHalftime = EasternKentuckyColonels[14]
EasternKentuckyColonelsHalftimeOU = EasternKentuckyColonels[16]

TennesseeStateTigersList = OhioValley.worksheet("Tennessee State Tigers").get_all_values()
TennesseeStateTigers = TennesseeStateTigersList[1]
TennesseeStateTigersCover = TennesseeStateTigers[5]
TennesseeStateTigersML = TennesseeStateTigers[6]
TennesseeStateTigersOU = TennesseeStateTigers[8]
TennesseeStateTigersSoloOU = TennesseeStateTigers[10]
TennesseeStateTigersHalftime = TennesseeStateTigers[14]
TennesseeStateTigersHalftimeOU = TennesseeStateTigers[16]

EasternIllinoisPanthersList = OhioValley.worksheet("Eastern Illinois Panthers").get_all_values()
EasternIllinoisPanthers = EasternIllinoisPanthersList[1]
EasternIllinoisPanthersCover = EasternIllinoisPanthers[5]
EasternIllinoisPanthersML = EasternIllinoisPanthers[6]
EasternIllinoisPanthersOU = EasternIllinoisPanthers[8]
EasternIllinoisPanthersSoloOU = EasternIllinoisPanthers[10]
EasternIllinoisPanthersHalftime = EasternIllinoisPanthers[14]
EasternIllinoisPanthersHalftimeOU = EasternIllinoisPanthers[16]

JacksonvilleStateGamecocksList = OhioValley.worksheet("Jacksonville State Gamecocks").get_all_values()
JacksonvilleStateGamecocks = JacksonvilleStateGamecocksList[1]
JacksonvilleStateGamecocksCover = JacksonvilleStateGamecocks[5]
JacksonvilleStateGamecocksML = JacksonvilleStateGamecocks[6]
JacksonvilleStateGamecocksOU = JacksonvilleStateGamecocks[8]
JacksonvilleStateGamecocksSoloOU = JacksonvilleStateGamecocks[10]
JacksonvilleStateGamecocksHalftime = JacksonvilleStateGamecocks[14]
JacksonvilleStateGamecocksHalftimeOU = JacksonvilleStateGamecocks[16]

MoreheadStateEaglesList = OhioValley.worksheet("Morehead State Eagles").get_all_values()
MoreheadStateEagles = MoreheadStateEaglesList[1]
MoreheadStateEaglesCover = MoreheadStateEagles[5]
MoreheadStateEaglesML = MoreheadStateEagles[6]
MoreheadStateEaglesOU = MoreheadStateEagles[8]
MoreheadStateEaglesSoloOU = MoreheadStateEagles[10]
MoreheadStateEaglesHalftime = MoreheadStateEagles[14]
MoreheadStateEaglesHalftimeOU = MoreheadStateEagles[16]

TennesseeTechGoldenEaglesList = OhioValley.worksheet("Tennessee Tech Golden Eagles").get_all_values()
TennesseeTechGoldenEagles = TennesseeTechGoldenEaglesList[1]
TennesseeTechGoldenEaglesCover = TennesseeTechGoldenEagles[5]
TennesseeTechGoldenEaglesML = TennesseeTechGoldenEagles[6]
TennesseeTechGoldenEaglesOU = TennesseeTechGoldenEagles[8]
TennesseeTechGoldenEaglesSoloOU = TennesseeTechGoldenEagles[10]
TennesseeTechGoldenEaglesHalftime = TennesseeTechGoldenEagles[14]
TennesseeTechGoldenEaglesHalftimeOU = TennesseeTechGoldenEagles[16]

UTMartinSkyhawksList = OhioValley.worksheet("UT Martin Skyhawks").get_all_values()
UTMartinSkyhawks = UTMartinSkyhawksList[1]
UTMartinSkyhawksCover = UTMartinSkyhawks[5]
UTMartinSkyhawksML = UTMartinSkyhawks[6]
UTMartinSkyhawksOU = UTMartinSkyhawks[8]
UTMartinSkyhawksSoloOU = UTMartinSkyhawks[10]
UTMartinSkyhawksHalftime = UTMartinSkyhawks[14]
UTMartinSkyhawksHalftimeOU = UTMartinSkyhawks[16]

SIUEdwardsvilleCougarsList = OhioValley.worksheet("SIU-Edwardsville Cougars").get_all_values()
SIUEdwardsvilleCougars = SIUEdwardsvilleCougarsList[1]
SIUEdwardsvilleCougarsCover = SIUEdwardsvilleCougars[5]
SIUEdwardsvilleCougarsML = SIUEdwardsvilleCougars[6]
SIUEdwardsvilleCougarsOU = SIUEdwardsvilleCougars[8]
SIUEdwardsvilleCougarsSoloOU = SIUEdwardsvilleCougars[10]
SIUEdwardsvilleCougarsHalftime = SIUEdwardsvilleCougars[14]
SIUEdwardsvilleCougarsHalftimeOU = SIUEdwardsvilleCougars[16]

SEMissouriStRedhawksList = OhioValley.worksheet("SE Missouri St Redhawks").get_all_values()
SEMissouriStRedhawks = SEMissouriStRedhawksList[1]
SEMissouriStRedhawksCover = SEMissouriStRedhawks[5]
SEMissouriStRedhawksML = SEMissouriStRedhawks[6]
SEMissouriStRedhawksOU = SEMissouriStRedhawks[8]
SEMissouriStRedhawksSoloOU = SEMissouriStRedhawks[10]
SEMissouriStRedhawksHalftime = SEMissouriStRedhawks[14]
SEMissouriStRedhawksHalftimeOU = SEMissouriStRedhawks[16]

#Pac-12 Teams

OregonDucksList = Pac12.worksheet("Oregon Ducks").get_all_values()
OregonDucks = OregonDucksList[1]
OregonDucksCover = OregonDucks[5]
OregonDucksML = OregonDucks[6]
OregonDucksOU = OregonDucks[8]
OregonDucksSoloOU = OregonDucks[10]
OregonDucksHalftime = OregonDucks[14]
OregonDucksHalftimeOU = OregonDucks[16]

UCLABruinsList = Pac12.worksheet("UCLA Bruins").get_all_values()
UCLABruins = UCLABruinsList[1]
UCLABruinsCover = UCLABruins[5]
UCLABruinsML = UCLABruins[6]
UCLABruinsOU = UCLABruins[8]
UCLABruinsSoloOU = UCLABruins[10]
UCLABruinsHalftime = UCLABruins[14]
UCLABruinsHalftimeOU = UCLABruins[16]

USCTrojansList = Pac12.worksheet("USC Trojans").get_all_values()
USCTrojans = USCTrojansList[1]
USCTrojansCover = USCTrojans[5]
USCTrojansML = USCTrojans[6]
USCTrojansOU = USCTrojans[8]
USCTrojansSoloOU = USCTrojans[10]
USCTrojansHalftime = USCTrojans[14]
USCTrojansHalftimeOU = USCTrojans[16]

ArizonaStateSunDevilsList = Pac12.worksheet("Arizona State Sun Devils").get_all_values()
ArizonaStateSunDevils = ArizonaStateSunDevilsList[1]
ArizonaStateSunDevilsCover = ArizonaStateSunDevils[5]
ArizonaStateSunDevilsML = ArizonaStateSunDevils[6]
ArizonaStateSunDevilsOU = ArizonaStateSunDevils[8]
ArizonaStateSunDevilsSoloOU = ArizonaStateSunDevils[10]
ArizonaStateSunDevilsHalftime = ArizonaStateSunDevils[14]
ArizonaStateSunDevilsHalftimeOU = ArizonaStateSunDevils[16]

ArizonaWildcatsList = Pac12.worksheet("Arizona Wildcats").get_all_values()
ArizonaWildcats = ArizonaWildcatsList[1]
ArizonaWildcatsCover = ArizonaWildcats[5]
ArizonaWildcatsML = ArizonaWildcats[6]
ArizonaWildcatsOU = ArizonaWildcats[8]
ArizonaWildcatsSoloOU = ArizonaWildcats[10]
ArizonaWildcatsHalftime = ArizonaWildcats[14]
ArizonaWildcatsHalftimeOU = ArizonaWildcats[16]

ColoradoBuffaloesList = Pac12.worksheet("Colorado Buffaloes").get_all_values()
ColoradoBuffaloes = ColoradoBuffaloesList[1]
ColoradoBuffaloesCover = ColoradoBuffaloes[5]
ColoradoBuffaloesML = ColoradoBuffaloes[6]
ColoradoBuffaloesOU = ColoradoBuffaloes[8]
ColoradoBuffaloesSoloOU = ColoradoBuffaloes[10]
ColoradoBuffaloesHalftime = ColoradoBuffaloes[14]
ColoradoBuffaloesHalftimeOU = ColoradoBuffaloes[16]

StanfordCardinalsList = Pac12.worksheet("Stanford Cardinals").get_all_values()
StanfordCardinals = StanfordCardinalsList[1]
StanfordCardinalsCover = StanfordCardinals[5]
StanfordCardinalsML = StanfordCardinals[6]
StanfordCardinalsOU = StanfordCardinals[8]
StanfordCardinalsSoloOU = StanfordCardinals[10]
StanfordCardinalsHalftime = StanfordCardinals[14]
StanfordCardinalsHalftimeOU = StanfordCardinals[16]

OregonStateBeaversList = Pac12.worksheet("Oregon State Beavers").get_all_values()
OregonStateBeavers = OregonStateBeaversList[1]
OregonStateBeaversCover = OregonStateBeavers[5]
OregonStateBeaversML = OregonStateBeavers[6]
OregonStateBeaversOU = OregonStateBeavers[8]
OregonStateBeaversSoloOU = OregonStateBeavers[10]
OregonStateBeaversHalftime = OregonStateBeavers[14]
OregonStateBeaversHalftimeOU = OregonStateBeavers[16]

UtahUtesList = Pac12.worksheet("Utah Utes").get_all_values()
UtahUtes = UtahUtesList[1]
UtahUtesCover = UtahUtes[5]
UtahUtesML = UtahUtes[6]
UtahUtesOU = UtahUtes[8]
UtahUtesSoloOU = UtahUtes[10]
UtahUtesHalftime = UtahUtes[14]
UtahUtesHalftimeOU = UtahUtes[16]

CaliforniaGoldenBearsList = Pac12.worksheet("California Golden Bears").get_all_values()
CaliforniaGoldenBears = CaliforniaGoldenBearsList[1]
CaliforniaGoldenBearsCover = CaliforniaGoldenBears[5]
CaliforniaGoldenBearsML = CaliforniaGoldenBears[6]
CaliforniaGoldenBearsOU = CaliforniaGoldenBears[8]
CaliforniaGoldenBearsSoloOU = CaliforniaGoldenBears[10]
CaliforniaGoldenBearsHalftime = CaliforniaGoldenBears[14]
CaliforniaGoldenBearsHalftimeOU = CaliforniaGoldenBears[16]

WashingtonStateCougarsList = Pac12.worksheet("Washington State Cougars").get_all_values()
WashingtonStateCougars = WashingtonStateCougarsList[1]
WashingtonStateCougarsCover = WashingtonStateCougars[5]
WashingtonStateCougarsML = WashingtonStateCougars[6]
WashingtonStateCougarsOU = WashingtonStateCougars[8]
WashingtonStateCougarsSoloOU = WashingtonStateCougars[10]
WashingtonStateCougarsHalftime = WashingtonStateCougars[14]
WashingtonStateCougarsHalftimeOU = WashingtonStateCougars[16]

WashingtonHuskiesList = Pac12.worksheet("Washington Huskies").get_all_values()
WashingtonHuskies = WashingtonHuskiesList[1]
WashingtonHuskiesCover = WashingtonHuskies[5]
WashingtonHuskiesML = WashingtonHuskies[6]
WashingtonHuskiesOU = WashingtonHuskies[8]
WashingtonHuskiesSoloOU = WashingtonHuskies[10]
WashingtonHuskiesHalftime = WashingtonHuskies[14]
WashingtonHuskiesHalftimeOU = WashingtonHuskies[16]

#Patriot Teams

ColgateRaidersList = Patriot.worksheet("Colgate Raiders").get_all_values()
ColgateRaiders = ColgateRaidersList[1]
ColgateRaidersCover = ColgateRaiders[5]
ColgateRaidersML = ColgateRaiders[6]
ColgateRaidersOU = ColgateRaiders[8]
ColgateRaidersSoloOU = ColgateRaiders[10]
ColgateRaidersHalftime = ColgateRaiders[14]
ColgateRaidersHalftimeOU = ColgateRaiders[16]

BostonUnivTerriersList = Patriot.worksheet("Boston Univ. Terriers").get_all_values()
BostonUnivTerriers = BostonUnivTerriersList[1]
BostonUnivTerriersCover = BostonUnivTerriers[5]
BostonUnivTerriersML = BostonUnivTerriers[6]
BostonUnivTerriersOU = BostonUnivTerriers[8]
BostonUnivTerriersSoloOU = BostonUnivTerriers[10]
BostonUnivTerriersHalftime = BostonUnivTerriers[14]
BostonUnivTerriersHalftimeOU = BostonUnivTerriers[16]

AmericanEaglesList = Patriot.worksheet("American Eagles").get_all_values()
AmericanEagles = AmericanEaglesList[1]
AmericanEaglesCover = AmericanEagles[5]
AmericanEaglesML = AmericanEagles[6]
AmericanEaglesOU = AmericanEagles[8]
AmericanEaglesSoloOU = AmericanEagles[10]
AmericanEaglesHalftime = AmericanEagles[14]
AmericanEaglesHalftimeOU = AmericanEagles[16]

LafayetteLeopardsList = Patriot.worksheet("Lafayette Leopards").get_all_values()
LafayetteLeopards = LafayetteLeopardsList[1]
LafayetteLeopardsCover = LafayetteLeopards[5]
LafayetteLeopardsML = LafayetteLeopards[6]
LafayetteLeopardsOU = LafayetteLeopards[8]
LafayetteLeopardsSoloOU = LafayetteLeopards[10]
LafayetteLeopardsHalftime = LafayetteLeopards[14]
LafayetteLeopardsHalftimeOU = LafayetteLeopards[16]

ArmyBlackKnightsList = Patriot.worksheet("Army Black Knights").get_all_values()
ArmyBlackKnights = ArmyBlackKnightsList[1]
ArmyBlackKnightsCover = ArmyBlackKnights[5]
ArmyBlackKnightsML = ArmyBlackKnights[6]
ArmyBlackKnightsOU = ArmyBlackKnights[8]
ArmyBlackKnightsSoloOU = ArmyBlackKnights[10]
ArmyBlackKnightsHalftime = ArmyBlackKnights[14]
ArmyBlackKnightsHalftimeOU = ArmyBlackKnights[16]

NavyMidshipmenList = Patriot.worksheet("Navy Midshipmen").get_all_values()
NavyMidshipmen = NavyMidshipmenList[1]
NavyMidshipmenCover = NavyMidshipmen[5]
NavyMidshipmenML = NavyMidshipmen[6]
NavyMidshipmenOU = NavyMidshipmen[8]
NavyMidshipmenSoloOU = NavyMidshipmen[10]
NavyMidshipmenHalftime = NavyMidshipmen[14]
NavyMidshipmenHalftimeOU = NavyMidshipmen[16]

BucknellBisonList = Patriot.worksheet("Bucknell Bison").get_all_values()
BucknellBison = BucknellBisonList[1]
BucknellBisonCover = BucknellBison[5]
BucknellBisonML = BucknellBison[6]
BucknellBisonOU = BucknellBison[8]
BucknellBisonSoloOU = BucknellBison[10]
BucknellBisonHalftime = BucknellBison[14]
BucknellBisonHalftimeOU = BucknellBison[16]

LehighMountainHawksList = Patriot.worksheet("Lehigh Mountain Hawks").get_all_values()
LehighMountainHawks = LehighMountainHawksList[1]
LehighMountainHawksCover = LehighMountainHawks[5]
LehighMountainHawksML = LehighMountainHawks[6]
LehighMountainHawksOU = LehighMountainHawks[8]
LehighMountainHawksSoloOU = LehighMountainHawks[10]
LehighMountainHawksHalftime = LehighMountainHawks[14]
LehighMountainHawksHalftimeOU = LehighMountainHawks[16]

LoyolaMDGreyhoundsList = Patriot.worksheet("Loyola (MD) Greyhounds").get_all_values()
LoyolaMDGreyhounds = LoyolaMDGreyhoundsList[1]
LoyolaMDGreyhoundsCover = LoyolaMDGreyhounds[5]
LoyolaMDGreyhoundsML = LoyolaMDGreyhounds[6]
LoyolaMDGreyhoundsOU = LoyolaMDGreyhounds[8]
LoyolaMDGreyhoundsSoloOU = LoyolaMDGreyhounds[10]
LoyolaMDGreyhoundsHalftime = LoyolaMDGreyhounds[14]
LoyolaMDGreyhoundsHalftimeOU = LoyolaMDGreyhounds[16]

HolyCrossCrusadersList = Patriot.worksheet("Holy Cross Crusaders").get_all_values()
HolyCrossCrusaders = HolyCrossCrusadersList[1]
HolyCrossCrusadersCover = HolyCrossCrusaders[5]
HolyCrossCrusadersML = HolyCrossCrusaders[6]
HolyCrossCrusadersOU = HolyCrossCrusaders[8]
HolyCrossCrusadersSoloOU = HolyCrossCrusaders[10]
HolyCrossCrusadersHalftime = HolyCrossCrusaders[14]
HolyCrossCrusadersHalftimeOU = HolyCrossCrusaders[16]

#Southeastern Teams

KentuckyWildcatsList = SouthEastern.worksheet("Kentucky Wildcats").get_all_values()
KentuckyWildcats = KentuckyWildcatsList[1]
KentuckyWildcatsCover = KentuckyWildcats[5]
KentuckyWildcatsML = KentuckyWildcats[6]
KentuckyWildcatsOU = KentuckyWildcats[8]
KentuckyWildcatsSoloOU = KentuckyWildcats[10]
KentuckyWildcatsHalftime = KentuckyWildcats[14]
KentuckyWildcatsHalftimeOU = KentuckyWildcats[16]

AuburnTigersList = SouthEastern.worksheet("Auburn Tigers").get_all_values()
AuburnTigers = AuburnTigersList[1]
AuburnTigersCover = AuburnTigers[5]
AuburnTigersML = AuburnTigers[6]
AuburnTigersOU = AuburnTigers[8]
AuburnTigersSoloOU = AuburnTigers[10]
AuburnTigersHalftime = AuburnTigers[14]
AuburnTigersHalftimeOU = AuburnTigers[16]

LSUTigersList = SouthEastern.worksheet("LSU Tigers").get_all_values()
LSUTigers = LSUTigersList[1]
LSUTigersCover = LSUTigers[5]
LSUTigersML = LSUTigers[6]
LSUTigersOU = LSUTigers[8]
LSUTigersSoloOU = LSUTigers[10]
LSUTigersHalftime = LSUTigers[14]
LSUTigersHalftimeOU = LSUTigers[16]

MississippiStateBulldogsList = SouthEastern.worksheet("Mississippi State Bulldogs").get_all_values()
MississippiStateBulldogs = MississippiStateBulldogsList[1]
MississippiStateBulldogsCover = MississippiStateBulldogs[5]
MississippiStateBulldogsML = MississippiStateBulldogs[6]
MississippiStateBulldogsOU = MississippiStateBulldogs[8]
MississippiStateBulldogsSoloOU = MississippiStateBulldogs[10]
MississippiStateBulldogsHalftime = MississippiStateBulldogs[14]
MississippiStateBulldogsHalftimeOU = MississippiStateBulldogs[16]

FloridaGatorsList = SouthEastern.worksheet("Florida Gators").get_all_values()
FloridaGators = FloridaGatorsList[1]
FloridaGatorsCover = FloridaGators[5]
FloridaGatorsML = FloridaGators[6]
FloridaGatorsOU = FloridaGators[8]
FloridaGatorsSoloOU = FloridaGators[10]
FloridaGatorsHalftime = FloridaGators[14]
FloridaGatorsHalftimeOU = FloridaGators[16]

SouthCarolinaGamecocksList = SouthEastern.worksheet("South Carolina Gamecocks").get_all_values()
SouthCarolinaGamecocks = SouthCarolinaGamecocksList[1]
SouthCarolinaGamecocksCover = SouthCarolinaGamecocks[5]
SouthCarolinaGamecocksML = SouthCarolinaGamecocks[6]
SouthCarolinaGamecocksOU = SouthCarolinaGamecocks[8]
SouthCarolinaGamecocksSoloOU = SouthCarolinaGamecocks[10]
SouthCarolinaGamecocksHalftime = SouthCarolinaGamecocks[14]
SouthCarolinaGamecocksHalftimeOU = SouthCarolinaGamecocks[16]

TexasAandMAggiesList = SouthEastern.worksheet("Texas A&M Aggies").get_all_values()
TexasAandMAggies = TexasAandMAggiesList[1]
TexasAandMAggiesCover = TexasAandMAggies[5]
TexasAandMAggiesML = TexasAandMAggies[6]
TexasAandMAggiesOU = TexasAandMAggies[8]
TexasAandMAggiesSoloOU = TexasAandMAggies[10]
TexasAandMAggiesHalftime = TexasAandMAggies[14]
TexasAandMAggiesHalftimeOU = TexasAandMAggies[16]

TennesseeVolunteersList = SouthEastern.worksheet("Tennessee Volunteers").get_all_values()
TennesseeVolunteers = TennesseeVolunteersList[1]
TennesseeVolunteersCover = TennesseeVolunteers[5]
TennesseeVolunteersML = TennesseeVolunteers[6]
TennesseeVolunteersOU = TennesseeVolunteers[8]
TennesseeVolunteersSoloOU = TennesseeVolunteers[10]
TennesseeVolunteersHalftime = TennesseeVolunteers[14]
TennesseeVolunteersHalftimeOU = TennesseeVolunteers[16]

AlabamaCrimsonTideList = SouthEastern.worksheet("Alabama Crimson Tide").get_all_values()
AlabamaCrimsonTide = AlabamaCrimsonTideList[1]
AlabamaCrimsonTideCover = AlabamaCrimsonTide[5]
AlabamaCrimsonTideML = AlabamaCrimsonTide[6]
AlabamaCrimsonTideOU = AlabamaCrimsonTide[8]
AlabamaCrimsonTideSoloOU = AlabamaCrimsonTide[10]
AlabamaCrimsonTideHalftime = AlabamaCrimsonTide[14]
AlabamaCrimsonTideHalftimeOU = AlabamaCrimsonTide[16]

ArkansasRazorbacksList = SouthEastern.worksheet("Arkansas Razorbacks").get_all_values()
ArkansasRazorbacks = ArkansasRazorbacksList[1]
ArkansasRazorbacksCover = ArkansasRazorbacks[5]
ArkansasRazorbacksML = ArkansasRazorbacks[6]
ArkansasRazorbacksOU = ArkansasRazorbacks[8]
ArkansasRazorbacksSoloOU = ArkansasRazorbacks[10]
ArkansasRazorbacksHalftime = ArkansasRazorbacks[14]
ArkansasRazorbacksHalftimeOU = ArkansasRazorbacks[16]

MissouriTigersList = SouthEastern.worksheet("Missouri Tigers").get_all_values()
MissouriTigers = MissouriTigersList[1]
MissouriTigersCover = MissouriTigers[5]
MissouriTigersML = MissouriTigers[6]
MissouriTigersOU = MissouriTigers[8]
MissouriTigersSoloOU = MissouriTigers[10]
MissouriTigersHalftime = MissouriTigers[14]
MissouriTigersHalftimeOU = MissouriTigers[16]

OleMissRebelsList = SouthEastern.worksheet("Ole Miss Rebels").get_all_values()
OleMissRebels = OleMissRebelsList[1]
OleMissRebelsCover = OleMissRebels[5]
OleMissRebelsML = OleMissRebels[6]
OleMissRebelsOU = OleMissRebels[8]
OleMissRebelsSoloOU = OleMissRebels[10]
OleMissRebelsHalftime = OleMissRebels[14]
OleMissRebelsHalftimeOU = OleMissRebels[16]

GeorgiaBulldogsList = SouthEastern.worksheet("Georgia Bulldogs").get_all_values()
GeorgiaBulldogs = GeorgiaBulldogsList[1]
GeorgiaBulldogsCover = GeorgiaBulldogs[5]
GeorgiaBulldogsML = GeorgiaBulldogs[6]
GeorgiaBulldogsOU = GeorgiaBulldogs[8]
GeorgiaBulldogsSoloOU = GeorgiaBulldogs[10]
GeorgiaBulldogsHalftime = GeorgiaBulldogs[14]
GeorgiaBulldogsHalftimeOU = GeorgiaBulldogs[16]

VanderbiltCommodoresList = SouthEastern.worksheet("Vanderbilt Commodores").get_all_values()
VanderbiltCommodores = VanderbiltCommodoresList[1]
VanderbiltCommodoresCover = VanderbiltCommodores[5]
VanderbiltCommodoresML = VanderbiltCommodores[6]
VanderbiltCommodoresOU = VanderbiltCommodores[8]
VanderbiltCommodoresSoloOU = VanderbiltCommodores[10]
VanderbiltCommodoresHalftime = VanderbiltCommodores[14]
VanderbiltCommodoresHalftimeOU = VanderbiltCommodores[16]

#Southern Teams

EastTennesseeStateBuccaneersList = Southern.worksheet("East Tennessee State Buccaneers").get_all_values()
EastTennesseeStateBuccaneers = EastTennesseeStateBuccaneersList[1]
EastTennesseeStateBuccaneersCover = EastTennesseeStateBuccaneers[5]
EastTennesseeStateBuccaneersML = EastTennesseeStateBuccaneers[6]
EastTennesseeStateBuccaneersOU = EastTennesseeStateBuccaneers[8]
EastTennesseeStateBuccaneersSoloOU = EastTennesseeStateBuccaneers[10]
EastTennesseeStateBuccaneersHalftime = EastTennesseeStateBuccaneers[14]
EastTennesseeStateBuccaneersHalftimeOU = EastTennesseeStateBuccaneers[16]

FurmanPaladinsList = Southern.worksheet("Furman Paladins").get_all_values()
FurmanPaladins = FurmanPaladinsList[1]
FurmanPaladinsCover = FurmanPaladins[5]
FurmanPaladinsML = FurmanPaladins[6]
FurmanPaladinsOU = FurmanPaladins[8]
FurmanPaladinsSoloOU = FurmanPaladins[10]
FurmanPaladinsHalftime = FurmanPaladins[14]
FurmanPaladinsHalftimeOU = FurmanPaladins[16]

UNCGreensboroSpartansList = Southern.worksheet("UNC Greensboro Spartans").get_all_values()
UNCGreensboroSpartans = UNCGreensboroSpartansList[1]
UNCGreensboroSpartansCover = UNCGreensboroSpartans[5]
UNCGreensboroSpartansML = UNCGreensboroSpartans[6]
UNCGreensboroSpartansOU = UNCGreensboroSpartans[8]
UNCGreensboroSpartansSoloOU = UNCGreensboroSpartans[10]
UNCGreensboroSpartansHalftime = UNCGreensboroSpartans[14]
UNCGreensboroSpartansHalftimeOU = UNCGreensboroSpartans[16]

MercerBearsList = Southern.worksheet("Mercer Bears").get_all_values()
MercerBears = MercerBearsList[1]
MercerBearsCover = MercerBears[5]
MercerBearsML = MercerBears[6]
MercerBearsOU = MercerBears[8]
MercerBearsSoloOU = MercerBears[10]
MercerBearsHalftime = MercerBears[14]
MercerBearsHalftimeOU = MercerBears[16]

WesternCarolinaCatamountsList = Southern.worksheet("Western Carolina Catamounts").get_all_values()
WesternCarolinaCatamounts = WesternCarolinaCatamountsList[1]
WesternCarolinaCatamountsCover = WesternCarolinaCatamounts[5]
WesternCarolinaCatamountsML = WesternCarolinaCatamounts[6]
WesternCarolinaCatamountsOU = WesternCarolinaCatamounts[8]
WesternCarolinaCatamountsSoloOU = WesternCarolinaCatamounts[10]
WesternCarolinaCatamountsHalftime = WesternCarolinaCatamounts[14]
WesternCarolinaCatamountsHalftimeOU = WesternCarolinaCatamounts[16]

ChattanoogaMocsList = Southern.worksheet("Chattanooga Mocs").get_all_values()
ChattanoogaMocs = ChattanoogaMocsList[1]
ChattanoogaMocsCover = ChattanoogaMocs[5]
ChattanoogaMocsML = ChattanoogaMocs[6]
ChattanoogaMocsOU = ChattanoogaMocs[8]
ChattanoogaMocsSoloOU = ChattanoogaMocs[10]
ChattanoogaMocsHalftime = ChattanoogaMocs[14]
ChattanoogaMocsHalftimeOU = ChattanoogaMocs[16]

WoffordTerriersList = Southern.worksheet("Wofford Terriers").get_all_values()
WoffordTerriers = WoffordTerriersList[1]
WoffordTerriersCover = WoffordTerriers[5]
WoffordTerriersML = WoffordTerriers[6]
WoffordTerriersOU = WoffordTerriers[8]
WoffordTerriersSoloOU = WoffordTerriers[10]
WoffordTerriersHalftime = WoffordTerriers[14]
WoffordTerriersHalftimeOU = WoffordTerriers[16]

SamfordBulldogsList = Southern.worksheet("Samford Bulldogs").get_all_values()
SamfordBulldogs = SamfordBulldogsList[1]
SamfordBulldogsCover = SamfordBulldogs[5]
SamfordBulldogsML = SamfordBulldogs[6]
SamfordBulldogsOU = SamfordBulldogs[8]
SamfordBulldogsSoloOU = SamfordBulldogs[10]
SamfordBulldogsHalftime = SamfordBulldogs[14]
SamfordBulldogsHalftimeOU = SamfordBulldogs[16]

VMIKeydetsList = Southern.worksheet("VMI Keydets").get_all_values()
VMIKeydets = VMIKeydetsList[1]
VMIKeydetsCover = VMIKeydets[5]
VMIKeydetsML = VMIKeydets[6]
VMIKeydetsOU = VMIKeydets[8]
VMIKeydetsSoloOU = VMIKeydets[10]
VMIKeydetsHalftime = VMIKeydets[14]
VMIKeydetsHalftimeOU = VMIKeydets[16]

TheCitadelBulldogsList = Southern.worksheet("The Citadel Bulldogs").get_all_values()
TheCitadelBulldogs = TheCitadelBulldogsList[1]
TheCitadelBulldogsCover = TheCitadelBulldogs[5]
TheCitadelBulldogsML = TheCitadelBulldogs[6]
TheCitadelBulldogsOU = TheCitadelBulldogs[8]
TheCitadelBulldogsSoloOU = TheCitadelBulldogs[10]
TheCitadelBulldogsHalftime = TheCitadelBulldogs[14]
TheCitadelBulldogsHalftimeOU = TheCitadelBulldogs[16]

#Southland Teams

StephenFAustinLumberjacksList = SouthLand.worksheet("Stephen F. Austin Lumberjacks").get_all_values()
StephenFAustinLumberjacks = StephenFAustinLumberjacksList[1]
StephenFAustinLumberjacksCover = StephenFAustinLumberjacks[5]
StephenFAustinLumberjacksML = StephenFAustinLumberjacks[6]
StephenFAustinLumberjacksOU = StephenFAustinLumberjacks[8]
StephenFAustinLumberjacksSoloOU = StephenFAustinLumberjacks[10]
StephenFAustinLumberjacksHalftime = StephenFAustinLumberjacks[14]
StephenFAustinLumberjacksHalftimeOU = StephenFAustinLumberjacks[16]

NichollsColonelsList = SouthLand.worksheet("Nicholls Colonels").get_all_values()
NichollsColonels = NichollsColonelsList[1]
NichollsColonelsCover = NichollsColonels[5]
NichollsColonelsML = NichollsColonels[6]
NichollsColonelsOU = NichollsColonels[8]
NichollsColonelsSoloOU = NichollsColonels[10]
NichollsColonelsHalftime = NichollsColonels[14]
NichollsColonelsHalftimeOU = NichollsColonels[16]

AbileneChristianWildcatsList = SouthLand.worksheet("Abilene Christian Wildcats").get_all_values()
AbileneChristianWildcats = AbileneChristianWildcatsList[1]
AbileneChristianWildcatsCover = AbileneChristianWildcats[5]
AbileneChristianWildcatsML = AbileneChristianWildcats[6]
AbileneChristianWildcatsOU = AbileneChristianWildcats[8]
AbileneChristianWildcatsSoloOU = AbileneChristianWildcats[10]
AbileneChristianWildcatsHalftime = AbileneChristianWildcats[14]
AbileneChristianWildcatsHalftimeOU = AbileneChristianWildcats[16]

SamHoustonStateBearkatsList = SouthLand.worksheet("Sam Houston State Bearkats").get_all_values()
SamHoustonStateBearkats = SamHoustonStateBearkatsList[1]
SamHoustonStateBearkatsCover = SamHoustonStateBearkats[5]
SamHoustonStateBearkatsML = SamHoustonStateBearkats[6]
SamHoustonStateBearkatsOU = SamHoustonStateBearkats[8]
SamHoustonStateBearkatsSoloOU = SamHoustonStateBearkats[10]
SamHoustonStateBearkatsHalftime = SamHoustonStateBearkats[14]
SamHoustonStateBearkatsHalftimeOU = SamHoustonStateBearkats[16]

NorthwesternStateDemonsList = SouthLand.worksheet("Northwestern State Demons").get_all_values()
NorthwesternStateDemons = NorthwesternStateDemonsList[1]
NorthwesternStateDemonsCover = NorthwesternStateDemons[5]
NorthwesternStateDemonsML = NorthwesternStateDemons[6]
NorthwesternStateDemonsOU = NorthwesternStateDemons[8]
NorthwesternStateDemonsSoloOU = NorthwesternStateDemons[10]
NorthwesternStateDemonsHalftime = NorthwesternStateDemons[14]
NorthwesternStateDemonsHalftimeOU = NorthwesternStateDemons[16]

TexasAandMCCIslandersList = SouthLand.worksheet("Texas A&M-CC Islanders").get_all_values()
TexasAandMCCIslanders = TexasAandMCCIslandersList[1]
TexasAandMCCIslandersCover = TexasAandMCCIslanders[5]
TexasAandMCCIslandersML = TexasAandMCCIslanders[6]
TexasAandMCCIslandersOU = TexasAandMCCIslanders[8]
TexasAandMCCIslandersSoloOU = TexasAandMCCIslanders[10]
TexasAandMCCIslandersHalftime = TexasAandMCCIslanders[14]
TexasAandMCCIslandersHalftimeOU = TexasAandMCCIslanders[16]

LamarCardinalsList = SouthLand.worksheet("Lamar Cardinals").get_all_values()
LamarCardinals = LamarCardinalsList[1]
LamarCardinalsCover = LamarCardinals[5]
LamarCardinalsML = LamarCardinals[6]
LamarCardinalsOU = LamarCardinals[8]
LamarCardinalsSoloOU = LamarCardinals[10]
LamarCardinalsHalftime = LamarCardinals[14]
LamarCardinalsHalftimeOU = LamarCardinals[16]

McNeeseStateCowboysList = SouthLand.worksheet("McNeese State Cowboys").get_all_values()
McNeeseStateCowboys = McNeeseStateCowboysList[1]
McNeeseStateCowboysCover = McNeeseStateCowboys[5]
McNeeseStateCowboysML = McNeeseStateCowboys[6]
McNeeseStateCowboysOU = McNeeseStateCowboys[8]
McNeeseStateCowboysSoloOU = McNeeseStateCowboys[10]
McNeeseStateCowboysHalftime = McNeeseStateCowboys[14]
McNeeseStateCowboysHalftimeOU = McNeeseStateCowboys[16]

CentralArkansasBearsList = SouthLand.worksheet("Central Arkansas Bears").get_all_values()
CentralArkansasBears = CentralArkansasBearsList[1]
CentralArkansasBearsCover = CentralArkansasBears[5]
CentralArkansasBearsML = CentralArkansasBears[6]
CentralArkansasBearsOU = CentralArkansasBears[8]
CentralArkansasBearsSoloOU = CentralArkansasBears[10]
CentralArkansasBearsHalftime = CentralArkansasBears[14]
CentralArkansasBearsHalftimeOU = CentralArkansasBears[16]

IncarnateWordCardinalsList = SouthLand.worksheet("Incarnate Word Cardinals").get_all_values()
IncarnateWordCardinals = IncarnateWordCardinalsList[1]
IncarnateWordCardinalsCover = IncarnateWordCardinals[5]
IncarnateWordCardinalsML = IncarnateWordCardinals[6]
IncarnateWordCardinalsOU = IncarnateWordCardinals[8]
IncarnateWordCardinalsSoloOU = IncarnateWordCardinals[10]
IncarnateWordCardinalsHalftime = IncarnateWordCardinals[14]
IncarnateWordCardinalsHalftimeOU = IncarnateWordCardinals[16]

NewOrleansPrivateersList = SouthLand.worksheet("New Orleans Privateers").get_all_values()
NewOrleansPrivateers = NewOrleansPrivateersList[1]
NewOrleansPrivateersCover = NewOrleansPrivateers[5]
NewOrleansPrivateersML = NewOrleansPrivateers[6]
NewOrleansPrivateersOU = NewOrleansPrivateers[8]
NewOrleansPrivateersSoloOU = NewOrleansPrivateers[10]
NewOrleansPrivateersHalftime = NewOrleansPrivateers[14]
NewOrleansPrivateersHalftimeOU = NewOrleansPrivateers[16]

SELouisianaLionsList = SouthLand.worksheet("SE Louisiana Lions").get_all_values()
SELouisianaLions = SELouisianaLionsList[1]
SELouisianaLionsCover = SELouisianaLions[5]
SELouisianaLionsML = SELouisianaLions[6]
SELouisianaLionsOU = SELouisianaLions[8]
SELouisianaLionsSoloOU = SELouisianaLions[10]
SELouisianaLionsHalftime = SELouisianaLions[14]
SELouisianaLionsHalftimeOU = SELouisianaLions[16]

HoustonBaptistHuskiesList = SouthLand.worksheet("Houston Baptist Huskies").get_all_values()
HoustonBaptistHuskies = HoustonBaptistHuskiesList[1]
HoustonBaptistHuskiesCover = HoustonBaptistHuskies[5]
HoustonBaptistHuskiesML = HoustonBaptistHuskies[6]
HoustonBaptistHuskiesOU = HoustonBaptistHuskies[8]
HoustonBaptistHuskiesSoloOU = HoustonBaptistHuskies[10]
HoustonBaptistHuskiesHalftime = HoustonBaptistHuskies[14]
HoustonBaptistHuskiesHalftimeOU = HoustonBaptistHuskies[16]

#SWAC Teams

PrairieViewAandMPanthersList = SWAC.worksheet("Prairie View A&M Panthers").get_all_values()
PrairieViewAandMPanthers = PrairieViewAandMPanthersList[1]
PrairieViewAandMPanthersCover = PrairieViewAandMPanthers[5]
PrairieViewAandMPanthersML = PrairieViewAandMPanthers[6]
PrairieViewAandMPanthersOU = PrairieViewAandMPanthers[8]
PrairieViewAandMPanthersSoloOU = PrairieViewAandMPanthers[10]
PrairieViewAandMPanthersHalftime = PrairieViewAandMPanthers[14]
PrairieViewAandMPanthersHalftimeOU = PrairieViewAandMPanthers[16]

SouthernJaguarsList = SWAC.worksheet("Southern Jaguars").get_all_values()
SouthernJaguars = SouthernJaguarsList[1]
SouthernJaguarsCover = SouthernJaguars[5]
SouthernJaguarsML = SouthernJaguars[6]
SouthernJaguarsOU = SouthernJaguars[8]
SouthernJaguarsSoloOU = SouthernJaguars[10]
SouthernJaguarsHalftime = SouthernJaguars[14]
SouthernJaguarsHalftimeOU = SouthernJaguars[16]

TexasSouthernTigersList = SWAC.worksheet("Texas Southern Tigers").get_all_values()
TexasSouthernTigers = TexasSouthernTigersList[1]
TexasSouthernTigersCover = TexasSouthernTigers[5]
TexasSouthernTigersML = TexasSouthernTigers[6]
TexasSouthernTigersOU = TexasSouthernTigers[8]
TexasSouthernTigersSoloOU = TexasSouthernTigers[10]
TexasSouthernTigersHalftime = TexasSouthernTigers[14]
TexasSouthernTigersHalftimeOU = TexasSouthernTigers[16]

JacksonStateTigersList = SWAC.worksheet("Jackson State Tigers").get_all_values()
JacksonStateTigers = JacksonStateTigersList[1]
JacksonStateTigersCover = JacksonStateTigers[5]
JacksonStateTigersML = JacksonStateTigers[6]
JacksonStateTigersOU = JacksonStateTigers[8]
JacksonStateTigersSoloOU = JacksonStateTigers[10]
JacksonStateTigersHalftime = JacksonStateTigers[14]
JacksonStateTigersHalftimeOU = JacksonStateTigers[16]

GramblingTigersList = SWAC.worksheet("Grambling Tigers").get_all_values()
GramblingTigers = GramblingTigersList[1]
GramblingTigersCover = GramblingTigers[5]
GramblingTigersML = GramblingTigers[6]
GramblingTigersOU = GramblingTigers[8]
GramblingTigersSoloOU = GramblingTigers[10]
GramblingTigersHalftime = GramblingTigers[14]
GramblingTigersHalftimeOU = GramblingTigers[16]

AlcornStateBravesList = SWAC.worksheet("Alcorn State Braves").get_all_values()
AlcornStateBraves = AlcornStateBravesList[1]
AlcornStateBravesCover = AlcornStateBraves[5]
AlcornStateBravesML = AlcornStateBraves[6]
AlcornStateBravesOU = AlcornStateBraves[8]
AlcornStateBravesSoloOU = AlcornStateBraves[10]
AlcornStateBravesHalftime = AlcornStateBraves[14]
AlcornStateBravesHalftimeOU = AlcornStateBraves[16]

AlabamaStateHornetsList = SWAC.worksheet("Alabama State Hornets").get_all_values()
AlabamaStateHornets = AlabamaStateHornetsList[1]
AlabamaStateHornetsCover = AlabamaStateHornets[5]
AlabamaStateHornetsML = AlabamaStateHornets[6]
AlabamaStateHornetsOU = AlabamaStateHornets[8]
AlabamaStateHornetsSoloOU = AlabamaStateHornets[10]
AlabamaStateHornetsHalftime = AlabamaStateHornets[14]
AlabamaStateHornetsHalftimeOU = AlabamaStateHornets[16]

AlabamaAandMBulldogsList = SWAC.worksheet("Alabama A&M Bulldogs").get_all_values()
AlabamaAandMBulldogs = AlabamaAandMBulldogsList[1]
AlabamaAandMBulldogsCover = AlabamaAandMBulldogs[5]
AlabamaAandMBulldogsML = AlabamaAandMBulldogs[6]
AlabamaAandMBulldogsOU = AlabamaAandMBulldogs[8]
AlabamaAandMBulldogsSoloOU = AlabamaAandMBulldogs[10]
AlabamaAandMBulldogsHalftime = AlabamaAandMBulldogs[14]
AlabamaAandMBulldogsHalftimeOU = AlabamaAandMBulldogs[16]

ArkansasPineBluffGoldenLionsList = SWAC.worksheet("Arkansas-Pine Bluff Golden Lions").get_all_values()
ArkansasPineBluffGoldenLions = ArkansasPineBluffGoldenLionsList[1]
ArkansasPineBluffGoldenLionsCover = ArkansasPineBluffGoldenLions[5]
ArkansasPineBluffGoldenLionsML = ArkansasPineBluffGoldenLions[6]
ArkansasPineBluffGoldenLionsOU = ArkansasPineBluffGoldenLions[8]
ArkansasPineBluffGoldenLionsSoloOU = ArkansasPineBluffGoldenLions[10]
ArkansasPineBluffGoldenLionsHalftime = ArkansasPineBluffGoldenLions[14]
ArkansasPineBluffGoldenLionsHalftimeOU = ArkansasPineBluffGoldenLions[16]

MississippiValleyStateDeltaDevilsList = SWAC.worksheet("Mississippi Valley State Delta Devils").get_all_values()
MississippiValleyStateDeltaDevils = MississippiValleyStateDeltaDevilsList[1]
MississippiValleyStateDeltaDevilsCover = MississippiValleyStateDeltaDevils[5]
MississippiValleyStateDeltaDevilsML = MississippiValleyStateDeltaDevils[6]
MississippiValleyStateDeltaDevilsOU = MississippiValleyStateDeltaDevils[8]
MississippiValleyStateDeltaDevilsSoloOU = MississippiValleyStateDeltaDevils[10]
MississippiValleyStateDeltaDevilsHalftime = MississippiValleyStateDeltaDevils[14]
MississippiValleyStateDeltaDevilsHalftimeOU = MississippiValleyStateDeltaDevils[16]

#Summit Teams

NorthDakotaStateBisonList = Summit.worksheet("North Dakota State Bison").get_all_values()
NorthDakotaStateBison = NorthDakotaStateBisonList[1]
NorthDakotaStateBisonCover = NorthDakotaStateBison[5]
NorthDakotaStateBisonML = NorthDakotaStateBison[6]
NorthDakotaStateBisonOU = NorthDakotaStateBison[8]
NorthDakotaStateBisonSoloOU = NorthDakotaStateBison[10]
NorthDakotaStateBisonHalftime = NorthDakotaStateBison[14]
NorthDakotaStateBisonHalftimeOU = NorthDakotaStateBison[16]

SouthDakotaStateJackrabbitsList = Summit.worksheet("South Dakota State Jackrabbits").get_all_values()
SouthDakotaStateJackrabbits = SouthDakotaStateJackrabbitsList[1]
SouthDakotaStateJackrabbitsCover = SouthDakotaStateJackrabbits[5]
SouthDakotaStateJackrabbitsML = SouthDakotaStateJackrabbits[6]
SouthDakotaStateJackrabbitsOU = SouthDakotaStateJackrabbits[8]
SouthDakotaStateJackrabbitsSoloOU = SouthDakotaStateJackrabbits[10]
SouthDakotaStateJackrabbitsHalftime = SouthDakotaStateJackrabbits[14]
SouthDakotaStateJackrabbitsHalftimeOU = SouthDakotaStateJackrabbits[16]

SouthDakotaCoyotesList = Summit.worksheet("South Dakota Coyotes").get_all_values()
SouthDakotaCoyotes = SouthDakotaCoyotesList[1]
SouthDakotaCoyotesCover = SouthDakotaCoyotes[5]
SouthDakotaCoyotesML = SouthDakotaCoyotes[6]
SouthDakotaCoyotesOU = SouthDakotaCoyotes[8]
SouthDakotaCoyotesSoloOU = SouthDakotaCoyotes[10]
SouthDakotaCoyotesHalftime = SouthDakotaCoyotes[14]
SouthDakotaCoyotesHalftimeOU = SouthDakotaCoyotes[16]

OralRobertsGoldenEaglesList = Summit.worksheet("Oral Roberts Golden Eagles").get_all_values()
OralRobertsGoldenEagles = OralRobertsGoldenEaglesList[1]
OralRobertsGoldenEaglesCover = OralRobertsGoldenEagles[5]
OralRobertsGoldenEaglesML = OralRobertsGoldenEagles[6]
OralRobertsGoldenEaglesOU = OralRobertsGoldenEagles[8]
OralRobertsGoldenEaglesSoloOU = OralRobertsGoldenEagles[10]
OralRobertsGoldenEaglesHalftime = OralRobertsGoldenEagles[14]
OralRobertsGoldenEaglesHalftimeOU = OralRobertsGoldenEagles[16]

OmahaMavericksList = Summit.worksheet("Omaha Mavericks").get_all_values()
OmahaMavericks = OmahaMavericksList[1]
OmahaMavericksCover = OmahaMavericks[5]
OmahaMavericksML = OmahaMavericks[6]
OmahaMavericksOU = OmahaMavericks[8]
OmahaMavericksSoloOU = OmahaMavericks[10]
OmahaMavericksHalftime = OmahaMavericks[14]
OmahaMavericksHalftimeOU = OmahaMavericks[16]

NorthDakotaFightingHawksList = Summit.worksheet("North Dakota Fighting Hawks").get_all_values()
NorthDakotaFightingHawks = NorthDakotaFightingHawksList[1]
NorthDakotaFightingHawksCover = NorthDakotaFightingHawks[5]
NorthDakotaFightingHawksML = NorthDakotaFightingHawks[6]
NorthDakotaFightingHawksOU = NorthDakotaFightingHawks[8]
NorthDakotaFightingHawksSoloOU = NorthDakotaFightingHawks[10]
NorthDakotaFightingHawksHalftime = NorthDakotaFightingHawks[14]
NorthDakotaFightingHawksHalftimeOU = NorthDakotaFightingHawks[16]

PurdueFortWayneMastodonsList = Summit.worksheet("Purdue Fort Wayne Mastodons").get_all_values()
PurdueFortWayneMastodons = PurdueFortWayneMastodonsList[1]
PurdueFortWayneMastodonsCover = PurdueFortWayneMastodons[5]
PurdueFortWayneMastodonsML = PurdueFortWayneMastodons[6]
PurdueFortWayneMastodonsOU = PurdueFortWayneMastodons[8]
PurdueFortWayneMastodonsSoloOU = PurdueFortWayneMastodons[10]
PurdueFortWayneMastodonsHalftime = PurdueFortWayneMastodons[14]
PurdueFortWayneMastodonsHalftimeOU = PurdueFortWayneMastodons[16]

DenverPioneersList = Summit.worksheet("Denver Pioneers").get_all_values()
DenverPioneers = DenverPioneersList[1]
DenverPioneersCover = DenverPioneers[5]
DenverPioneersML = DenverPioneers[6]
DenverPioneersOU = DenverPioneers[8]
DenverPioneersSoloOU = DenverPioneers[10]
DenverPioneersHalftime = DenverPioneers[14]
DenverPioneersHalftimeOU = DenverPioneers[16]

WesternIllinoisLeathernecksList = Summit.worksheet("Western Illinois Leathernecks").get_all_values()
WesternIllinoisLeathernecks = WesternIllinoisLeathernecksList[1]
WesternIllinoisLeathernecksCover = WesternIllinoisLeathernecks[5]
WesternIllinoisLeathernecksML = WesternIllinoisLeathernecks[6]
WesternIllinoisLeathernecksOU = WesternIllinoisLeathernecks[8]
WesternIllinoisLeathernecksSoloOU = WesternIllinoisLeathernecks[10]
WesternIllinoisLeathernecksHalftime = WesternIllinoisLeathernecks[14]
WesternIllinoisLeathernecksHalftimeOU = WesternIllinoisLeathernecks[16]

#Sun Belt Teams

LittleRockTrojansList = SunBelt.worksheet("Little Rock Trojans").get_all_values()
LittleRockTrojans = LittleRockTrojansList[1]
LittleRockTrojansCover = LittleRockTrojans[5]
LittleRockTrojansML = LittleRockTrojans[6]
LittleRockTrojansOU = LittleRockTrojans[8]
LittleRockTrojansSoloOU = LittleRockTrojans[10]
LittleRockTrojansHalftime = LittleRockTrojans[14]
LittleRockTrojansHalftimeOU = LittleRockTrojans[16]

SouthAlabamaJaguarsList = SunBelt.worksheet("South Alabama Jaguars").get_all_values()
SouthAlabamaJaguars = SouthAlabamaJaguarsList[1]
SouthAlabamaJaguarsCover = SouthAlabamaJaguars[5]
SouthAlabamaJaguarsML = SouthAlabamaJaguars[6]
SouthAlabamaJaguarsOU = SouthAlabamaJaguars[8]
SouthAlabamaJaguarsSoloOU = SouthAlabamaJaguars[10]
SouthAlabamaJaguarsHalftime = SouthAlabamaJaguars[14]
SouthAlabamaJaguarsHalftimeOU = SouthAlabamaJaguars[16]

TexasStateBobcatsList = SunBelt.worksheet("Texas State Bobcats").get_all_values()
TexasStateBobcats = TexasStateBobcatsList[1]
TexasStateBobcatsCover = TexasStateBobcats[5]
TexasStateBobcatsML = TexasStateBobcats[6]
TexasStateBobcatsOU = TexasStateBobcats[8]
TexasStateBobcatsSoloOU = TexasStateBobcats[10]
TexasStateBobcatsHalftime = TexasStateBobcats[14]
TexasStateBobcatsHalftimeOU = TexasStateBobcats[16]

GeorgiaSouthernEaglesList = SunBelt.worksheet("Georgia Southern Eagles").get_all_values()
GeorgiaSouthernEagles = GeorgiaSouthernEaglesList[1]
GeorgiaSouthernEaglesCover = GeorgiaSouthernEagles[5]
GeorgiaSouthernEaglesML = GeorgiaSouthernEagles[6]
GeorgiaSouthernEaglesOU = GeorgiaSouthernEagles[8]
GeorgiaSouthernEaglesSoloOU = GeorgiaSouthernEagles[10]
GeorgiaSouthernEaglesHalftime = GeorgiaSouthernEagles[14]
GeorgiaSouthernEaglesHalftimeOU = GeorgiaSouthernEagles[16]

GeorgiaStatePanthersList = SunBelt.worksheet("Georgia State Panthers").get_all_values()
GeorgiaStatePanthers = GeorgiaStatePanthersList[1]
GeorgiaStatePanthersCover = GeorgiaStatePanthers[5]
GeorgiaStatePanthersML = GeorgiaStatePanthers[6]
GeorgiaStatePanthersOU = GeorgiaStatePanthers[8]
GeorgiaStatePanthersSoloOU = GeorgiaStatePanthers[10]
GeorgiaStatePanthersHalftime = GeorgiaStatePanthers[14]
GeorgiaStatePanthersHalftimeOU = GeorgiaStatePanthers[16]

AppalachianStateMountaineersList = SunBelt.worksheet("Appalachian State Mountaineers").get_all_values()
AppalachianStateMountaineers = AppalachianStateMountaineersList[1]
AppalachianStateMountaineersCover = AppalachianStateMountaineers[5]
AppalachianStateMountaineersML = AppalachianStateMountaineers[6]
AppalachianStateMountaineersOU = AppalachianStateMountaineers[8]
AppalachianStateMountaineersSoloOU = AppalachianStateMountaineers[10]
AppalachianStateMountaineersHalftime = AppalachianStateMountaineers[14]
AppalachianStateMountaineersHalftimeOU = AppalachianStateMountaineers[16]

UTArlingtonMavericksList = SunBelt.worksheet("UT Arlington Mavericks").get_all_values()
UTArlingtonMavericks = UTArlingtonMavericksList[1]
UTArlingtonMavericksCover = UTArlingtonMavericks[5]
UTArlingtonMavericksML = UTArlingtonMavericks[6]
UTArlingtonMavericksOU = UTArlingtonMavericks[8]
UTArlingtonMavericksSoloOU = UTArlingtonMavericks[10]
UTArlingtonMavericksHalftime = UTArlingtonMavericks[14]
UTArlingtonMavericksHalftimeOU = UTArlingtonMavericks[16]

LouisianaRaginCajunsList = SunBelt.worksheet("Louisiana Ragin' Cajuns").get_all_values()
LouisianaRaginCajuns = LouisianaRaginCajunsList[1]
LouisianaRaginCajunsCover = LouisianaRaginCajuns[5]
LouisianaRaginCajunsML = LouisianaRaginCajuns[6]
LouisianaRaginCajunsOU = LouisianaRaginCajuns[8]
LouisianaRaginCajunsSoloOU = LouisianaRaginCajuns[10]
LouisianaRaginCajunsHalftime = LouisianaRaginCajuns[14]
LouisianaRaginCajunsHalftimeOU = LouisianaRaginCajuns[16]

ArkansasStRedWolvesList = SunBelt.worksheet("Arkansas St Red Wolves").get_all_values()
ArkansasStRedWolves = ArkansasStRedWolvesList[1]
ArkansasStRedWolvesCover = ArkansasStRedWolves[5]
ArkansasStRedWolvesML = ArkansasStRedWolves[6]
ArkansasStRedWolvesOU = ArkansasStRedWolves[8]
ArkansasStRedWolvesSoloOU = ArkansasStRedWolves[10]
ArkansasStRedWolvesHalftime = ArkansasStRedWolves[14]
ArkansasStRedWolvesHalftimeOU = ArkansasStRedWolves[16]

CoastalCarolinaChanticleersList = SunBelt.worksheet("Coastal Carolina Chanticleers").get_all_values()
CoastalCarolinaChanticleers = CoastalCarolinaChanticleersList[1]
CoastalCarolinaChanticleersCover = CoastalCarolinaChanticleers[5]
CoastalCarolinaChanticleersML = CoastalCarolinaChanticleers[6]
CoastalCarolinaChanticleersOU = CoastalCarolinaChanticleers[8]
CoastalCarolinaChanticleersSoloOU = CoastalCarolinaChanticleers[10]
CoastalCarolinaChanticleersHalftime = CoastalCarolinaChanticleers[14]
CoastalCarolinaChanticleersHalftimeOU = CoastalCarolinaChanticleers[16]

ULMonroeWarhawksList = SunBelt.worksheet("UL Monroe Warhawks").get_all_values()
ULMonroeWarhawks = ULMonroeWarhawksList[1]
ULMonroeWarhawksCover = ULMonroeWarhawks[5]
ULMonroeWarhawksML = ULMonroeWarhawks[6]
ULMonroeWarhawksOU = ULMonroeWarhawks[8]
ULMonroeWarhawksSoloOU = ULMonroeWarhawks[10]
ULMonroeWarhawksHalftime = ULMonroeWarhawks[14]
ULMonroeWarhawksHalftimeOU = ULMonroeWarhawks[16]

TroyTrojansList = SunBelt.worksheet("Troy Trojans").get_all_values()
TroyTrojans = TroyTrojansList[1]
TroyTrojansCover = TroyTrojans[5]
TroyTrojansML = TroyTrojans[6]
TroyTrojansOU = TroyTrojans[8]
TroyTrojansSoloOU = TroyTrojans[10]
TroyTrojansHalftime = TroyTrojans[14]
TroyTrojansHalftimeOU = TroyTrojans[16]

#West Coast

GonzagaBulldogsList = WestCoast.worksheet("Gonzaga Bulldogs").get_all_values()
GonzagaBulldogs = GonzagaBulldogsList[1]
GonzagaBulldogsCover = GonzagaBulldogs[5]
GonzagaBulldogsML = GonzagaBulldogs[6]
GonzagaBulldogsOU = GonzagaBulldogs[8]
GonzagaBulldogsSoloOU = GonzagaBulldogs[10]
GonzagaBulldogsHalftime = GonzagaBulldogs[14]
GonzagaBulldogsHalftimeOU = GonzagaBulldogs[16]

BYUCougarsList = WestCoast.worksheet("BYU Cougars").get_all_values()
BYUCougars = BYUCougarsList[1]
BYUCougarsCover = BYUCougars[5]
BYUCougarsML = BYUCougars[6]
BYUCougarsOU = BYUCougars[8]
BYUCougarsSoloOU = BYUCougars[10]
BYUCougarsHalftime = BYUCougars[14]
BYUCougarsHalftimeOU = BYUCougars[16]

SaintMarysGaelsList = WestCoast.worksheet("Saint Mary's Gaels").get_all_values()
SaintMarysGaels = SaintMarysGaelsList[1]
SaintMarysGaelsCover = SaintMarysGaels[5]
SaintMarysGaelsML = SaintMarysGaels[6]
SaintMarysGaelsOU = SaintMarysGaels[8]
SaintMarysGaelsSoloOU = SaintMarysGaels[10]
SaintMarysGaelsHalftime = SaintMarysGaels[14]
SaintMarysGaelsHalftimeOU = SaintMarysGaels[16]

PacificTigersList = WestCoast.worksheet("Pacific Tigers").get_all_values()
PacificTigers = PacificTigersList[1]
PacificTigersCover = PacificTigers[5]
PacificTigersML = PacificTigers[6]
PacificTigersOU = PacificTigers[8]
PacificTigersSoloOU = PacificTigers[10]
PacificTigersHalftime = PacificTigers[14]
PacificTigersHalftimeOU = PacificTigers[16]

SanFranciscoDonsList = WestCoast.worksheet("San Francisco Dons").get_all_values()
SanFranciscoDons = SanFranciscoDonsList[1]
SanFranciscoDonsCover = SanFranciscoDons[5]
SanFranciscoDonsML = SanFranciscoDons[6]
SanFranciscoDonsOU = SanFranciscoDons[8]
SanFranciscoDonsSoloOU = SanFranciscoDons[10]
SanFranciscoDonsHalftime = SanFranciscoDons[14]
SanFranciscoDonsHalftimeOU = SanFranciscoDons[16]

PepperdineWavesList = WestCoast.worksheet("Pepperdine Waves").get_all_values()
PepperdineWaves = PepperdineWavesList[1]
PepperdineWavesCover = PepperdineWaves[5]
PepperdineWavesML = PepperdineWaves[6]
PepperdineWavesOU = PepperdineWaves[8]
PepperdineWavesSoloOU = PepperdineWaves[10]
PepperdineWavesHalftime = PepperdineWaves[14]
PepperdineWavesHalftimeOU = PepperdineWaves[16]

SantaClaraBroncosList = WestCoast.worksheet("Santa Clara Broncos").get_all_values()
SantaClaraBroncos = SantaClaraBroncosList[1]
SantaClaraBroncosCover = SantaClaraBroncos[5]
SantaClaraBroncosML = SantaClaraBroncos[6]
SantaClaraBroncosOU = SantaClaraBroncos[8]
SantaClaraBroncosSoloOU = SantaClaraBroncos[10]
SantaClaraBroncosHalftime = SantaClaraBroncos[14]
SantaClaraBroncosHalftimeOU = SantaClaraBroncos[16]

LoyolaMarymountLionsList = WestCoast.worksheet("Loyola Marymount Lions").get_all_values()
LoyolaMarymountLions = LoyolaMarymountLionsList[1]
LoyolaMarymountLionsCover = LoyolaMarymountLions[5]
LoyolaMarymountLionsML = LoyolaMarymountLions[6]
LoyolaMarymountLionsOU = LoyolaMarymountLions[8]
LoyolaMarymountLionsSoloOU = LoyolaMarymountLions[10]
LoyolaMarymountLionsHalftime = LoyolaMarymountLions[14]
LoyolaMarymountLionsHalftimeOU = LoyolaMarymountLions[16]

SanDiegoTorerosList = WestCoast.worksheet("San Diego Toreros").get_all_values()
SanDiegoToreros = SanDiegoTorerosList[1]
SanDiegoTorerosCover = SanDiegoToreros[5]
SanDiegoTorerosML = SanDiegoToreros[6]
SanDiegoTorerosOU = SanDiegoToreros[8]
SanDiegoTorerosSoloOU = SanDiegoToreros[10]
SanDiegoTorerosHalftime = SanDiegoToreros[14]
SanDiegoTorerosHalftimeOU = SanDiegoToreros[16]

PortlandPilotsList = WestCoast.worksheet("Portland Pilots").get_all_values()
PortlandPilots = PortlandPilotsList[1]
PortlandPilotsCover = PortlandPilots[5]
PortlandPilotsML = PortlandPilots[6]
PortlandPilotsOU = PortlandPilots[8]
PortlandPilotsSoloOU = PortlandPilots[10]
PortlandPilotsHalftime = PortlandPilots[14]
PortlandPilotsHalftimeOU = PortlandPilots[16]

#WAC Teams

NewMexicoStateAggiesList = WAC.worksheet("New Mexico State Aggies").get_all_values()
NewMexicoStateAggies = NewMexicoStateAggiesList[1]
NewMexicoStateAggiesCover = NewMexicoStateAggies[5]
NewMexicoStateAggiesML = NewMexicoStateAggies[6]
NewMexicoStateAggiesOU = NewMexicoStateAggies[8]
NewMexicoStateAggiesSoloOU = NewMexicoStateAggies[10]
NewMexicoStateAggiesHalftime = NewMexicoStateAggies[14]
NewMexicoStateAggiesHalftimeOU = NewMexicoStateAggies[16]

CaliforniaBaptistLancersList = WAC.worksheet("California Baptist Lancers").get_all_values()
CaliforniaBaptistLancers = CaliforniaBaptistLancersList[1]
CaliforniaBaptistLancersCover = CaliforniaBaptistLancers[5]
CaliforniaBaptistLancersML = CaliforniaBaptistLancers[6]
CaliforniaBaptistLancersOU = CaliforniaBaptistLancers[8]
CaliforniaBaptistLancersSoloOU = CaliforniaBaptistLancers[10]
CaliforniaBaptistLancersHalftime = CaliforniaBaptistLancers[14]
CaliforniaBaptistLancersHalftimeOU = CaliforniaBaptistLancers[16]

UTRioGrandeValleyVaquerosList = WAC.worksheet("UT Rio Grande Valley Vaqueros").get_all_values()
UTRioGrandeValleyVaqueros = UTRioGrandeValleyVaquerosList[1]
UTRioGrandeValleyVaquerosCover = UTRioGrandeValleyVaqueros[5]
UTRioGrandeValleyVaquerosML = UTRioGrandeValleyVaqueros[6]
UTRioGrandeValleyVaquerosOU = UTRioGrandeValleyVaqueros[8]
UTRioGrandeValleyVaquerosSoloOU = UTRioGrandeValleyVaqueros[10]
UTRioGrandeValleyVaquerosHalftime = UTRioGrandeValleyVaqueros[14]
UTRioGrandeValleyVaquerosHalftimeOU = UTRioGrandeValleyVaqueros[16]

UMKCKangaroosList = WAC.worksheet("UMKC Kangaroos").get_all_values()
UMKCKangaroos = UMKCKangaroosList[1]
UMKCKangaroosCover = UMKCKangaroos[5]
UMKCKangaroosML = UMKCKangaroos[6]
UMKCKangaroosOU = UMKCKangaroos[8]
UMKCKangaroosSoloOU = UMKCKangaroos[10]
UMKCKangaroosHalftime = UMKCKangaroos[14]
UMKCKangaroosHalftimeOU = UMKCKangaroos[16]

GrandCanyonAntelopesList = WAC.worksheet("Grand Canyon Antelopes").get_all_values()
GrandCanyonAntelopes = GrandCanyonAntelopesList[1]
GrandCanyonAntelopesCover = GrandCanyonAntelopes[5]
GrandCanyonAntelopesML = GrandCanyonAntelopes[6]
GrandCanyonAntelopesOU = GrandCanyonAntelopes[8]
GrandCanyonAntelopesSoloOU = GrandCanyonAntelopes[10]
GrandCanyonAntelopesHalftime = GrandCanyonAntelopes[14]
GrandCanyonAntelopesHalftimeOU = GrandCanyonAntelopes[16]

SeattleRedhawksList = WAC.worksheet("Seattle Redhawks").get_all_values()
SeattleRedhawks = SeattleRedhawksList[1]
SeattleRedhawksCover = SeattleRedhawks[5]
SeattleRedhawksML = SeattleRedhawks[6]
SeattleRedhawksOU = SeattleRedhawks[8]
SeattleRedhawksSoloOU = SeattleRedhawks[10]
SeattleRedhawksHalftime = SeattleRedhawks[14]
SeattleRedhawksHalftimeOU = SeattleRedhawks[16]

CSUBakersfieldRoadrunnersList = WAC.worksheet("CSU Bakersfield Roadrunners").get_all_values()
CSUBakersfieldRoadrunners = CSUBakersfieldRoadrunnersList[1]
CSUBakersfieldRoadrunnersCover = CSUBakersfieldRoadrunners[5]
CSUBakersfieldRoadrunnersML = CSUBakersfieldRoadrunners[6]
CSUBakersfieldRoadrunnersOU = CSUBakersfieldRoadrunners[8]
CSUBakersfieldRoadrunnersSoloOU = CSUBakersfieldRoadrunners[10]
CSUBakersfieldRoadrunnersHalftime = CSUBakersfieldRoadrunners[14]
CSUBakersfieldRoadrunnersHalftimeOU = CSUBakersfieldRoadrunners[16]

UtahValleyWolverinesList = WAC.worksheet("Utah Valley Wolverines").get_all_values()
UtahValleyWolverines = UtahValleyWolverinesList[1]
UtahValleyWolverinesCover = UtahValleyWolverines[5]
UtahValleyWolverinesML = UtahValleyWolverines[6]
UtahValleyWolverinesOU = UtahValleyWolverines[8]
UtahValleyWolverinesSoloOU = UtahValleyWolverines[10]
UtahValleyWolverinesHalftime = UtahValleyWolverines[14]
UtahValleyWolverinesHalftimeOU = UtahValleyWolverines[16]

ChicagoStateCougarsList = WAC.worksheet("Chicago State Cougars").get_all_values()
ChicagoStateCougars = ChicagoStateCougarsList[1]
ChicagoStateCougarsCover = ChicagoStateCougars[5]
ChicagoStateCougarsML = ChicagoStateCougars[6]
ChicagoStateCougarsOU = ChicagoStateCougars[8]
ChicagoStateCougarsSoloOU = ChicagoStateCougars[10]
ChicagoStateCougarsHalftime = ChicagoStateCougars[14]
ChicagoStateCougarsHalftimeOU = ChicagoStateCougars[16]

import MLB
import operator


# AL Central Teams Dictionaries

MLBCWSDict = {
    'MLBCWSSuperRL' : MLB.CWSSuperRL,
    'MLBCWSRL' : MLB.CWSRL,
    'MLBCWSML' : MLB.CWSML,
    'MLBCWSOU' : MLB.CWSOU,
    'MLBCWSSoloOU' : MLB.CWSSoloOU,
    'MLBCWSFirstInning' : MLB.CWSFirstInning,
    'MLBCWSHalftime' : MLB.CWSHalftime,
    'MLBCWSHalftimeOU' : MLB.CWSHalftimeOU
}

MLBCLEDict = {
    'MLBCLESuperRL' : MLB.CLESuperRL,
    'MLBCLERL' : MLB.CLERL,
    'MLBCLEML' : MLB.CLEML,
    'MLBCLEOU' : MLB.CLEOU,
    'MLBCLESoloOU' : MLB.CLESoloOU,
    'MLBCLEFirstInning' : MLB.CLEFirstInning,
    'MLBCLEHalftime' : MLB.CLEHalftime,
    'MLBCLEHalftimeOU' : MLB.CLEHalftimeOU
}


MLBDETDict = {
    'MLBDETSuperRL' : MLB.DETSuperRL,
    'MLBDETRL' : MLB.DETRL,
    'MLBDETML' : MLB.DETML,
    'MLBDETOU' : MLB.DETOU,
    'MLBDETSoloOU' : MLB.DETSoloOU,
    'MLBDETFirstInning' : MLB.DETFirstInning,
    'MLBDETHalftime' : MLB.DETHalftime,
    'MLBDETHalftimeOU' : MLB.DETHalftimeOU
}

MLBKANDict = {
    'MLBKANSuperRL' : MLB.KANSuperRL,
    'MLBKANRL' : MLB.KANRL,
    'MLBKANML' : MLB.KANML,
    'MLBKANOU' : MLB.KANOU,
    'MLBKANSoloOU' : MLB.KANSoloOU,
    'MLBKANFirstInning' : MLB.KANFirstInning,
    'MLBKANHalftime' : MLB.KANHalftime,
    'MLBKANHalftimeOU' : MLB.KANHalftimeOU
}

MLBMINDict = {
    'MLBMINSuperRL' : MLB.MINSuperRL,
    'MLBMINRL' : MLB.MINRL,
    'MLBMINML' : MLB.MINML,
    'MLBMINOU' : MLB.MINOU,
    'MLBMINSoloOU' : MLB.MINSoloOU,
    'MLBMINFirstInning' : MLB.MINFirstInning,
    'MLBMINHalftime' : MLB.MINHalftime,
    'MLBMINHalftimeOU' : MLB.MINHalftimeOU
}

# AL East Teams Dictionaries

MLBBALDict = {
    'MLBBALSuperRL' : MLB.BALSuperRL,
    'MLBBALRL' : MLB.BALRL,
    'MLBBALML' : MLB.BALML,
    'MLBBALOU' : MLB.BALOU,
    'MLBBALSoloOU' : MLB.BALSoloOU,
    'MLBBALFirstInning' : MLB.BALFirstInning,
    'MLBBALHalftime' : MLB.BALHalftime,
    'MLBBALHalftimeOU' : MLB.BALHalftimeOU
}

MLBBOSDict = {
    'MLBBOSSuperRL' : MLB.MLBBOSSuperRL,
    'MLBBOSRL' : MLB.MLBBOSRL,
    'MLBBOSML' : MLB.MLBBOSML,
    'MLBBOSOU' : MLB.MLBBOSOU,
    'MLBBOSSoloOU' : MLB.MLBBOSSoloOU,
    'MLBBOSFirstInning' : MLB.MLBBOSFirstInning,
    'MLBBOSHalftime' : MLB.MLBBOSHalftime,
    'MLBBOSHalftimeOU' : MLB.MLBBOSHalftimeOU
}

MLBNYYDict = {
    'MLBNYYSuperRL' : MLB.NYYSuperRL,
    'MLBNYYRL' : MLB.NYYRL,
    'MLBNYYML' : MLB.NYYML,
    'MLBNYYOU' : MLB.NYYOU,
    'MLBNYYSoloOU' : MLB.NYYSoloOU,
    'MLBNYYFirstInning' : MLB.NYYFirstInning,
    'MLBNYYHalftime' : MLB.NYYHalftime,
    'MLBNYYHalftimeOU' : MLB.NYYHalftimeOU
}

MLBTORDict = {
    'MLBTORSuperRL' : MLB.MLBTORSuperRL,
    'MLBTORRL' : MLB.MLBTORRL,
    'MLBTORML' : MLB.MLBTORML,
    'MLBTOROU' : MLB.MLBTOROU,
    'MLBTORSoloOU' : MLB.MLBTORSoloOU,
    'MLBTORFirstInning' : MLB.MLBTORFirstInning,
    'MLBTORHalftime' : MLB.MLBTORHalftime,
    'MLBTORHalftimeOU' : MLB.MLBTORHalftimeOU
}

MLBTBDict = {
    'MLBTBSuperRL' : MLB.TBSuperRL,
    'MLBTBRL' : MLB.TBRL,
    'MLBTBML' : MLB.TBML,
    'MLBTBOU' : MLB.TBOU,
    'MLBTBSoloOU' : MLB.TBSoloOU,
    'MLBTBFirstInning' : MLB.TBFirstInning,
    'MLBTBHalftime' : MLB.TBHalftime,
    'MLBTBHalftimeOU' : MLB.TBHalftimeOU
}

#AL West Teams Dictionaries

MLBLAADict = {
    'MLBLAASuperRL' : MLB.LAASuperRL,
    'MLBLAARL' : MLB.LAARL,
    'MLBLAAML' : MLB.LAAML,
    'MLBLAAOU' : MLB.LAAOU,
    'MLBLAASoloOU' : MLB.LAASoloOU,
    'MLBLAAFirstInning' : MLB.LAAFirstInning,
    'MLBLAAHalftime' : MLB.LAAHalftime,
    'MLBLAAHalftimeOU' : MLB.LAAHalftimeOU
}

MLBOAKDict = {
    'MLBOAKSuperRL' : MLB.OAKSuperRL,
    'MLBOAKRL' : MLB.OAKRL,
    'MLBOAKML' : MLB.OAKML,
    'MLBOAKOU' : MLB.OAKOU,
    'MLBOAKSoloOU' : MLB.OAKSoloOU,
    'MLBOAKFirstInning' : MLB.OAKFirstInning,
    'MLBOAKHalftime' : MLB.OAKHalftime,
    'MLBOAKHalftimeOU' : MLB.OAKHalftimeOU
}

MLBSEADict = {
    'MLBSEASuperRL' : MLB.SEASuperRL,
    'MLBSEARL' : MLB.SEARL,
    'MLBSEAML' : MLB.SEAML,
    'MLBSEAOU' : MLB.SEAOU,
    'MLBSEASoloOU' : MLB.SEASoloOU,
    'MLBSEAFirstInning' : MLB.SEAFirstInning,
    'MLBSEAHalftime' : MLB.SEAHalftime,
    'MLBSEAHalftimeOU' : MLB.SEAHalftimeOU
}

MLBTEXDict = {
    'MLBTEXSuperRL' : MLB.TEXSuperRL,
    'MLBTEXRL' : MLB.TEXRL,
    'MLBTEXML' : MLB.TEXML,
    'MLBTEXOU' : MLB.TEXOU,
    'MLBTEXSoloOU' : MLB.TEXSoloOU,
    'MLBTEXFirstInning' : MLB.TEXFirstInning,
    'MLBTEXHalftime' : MLB.TEXHalftime,
    'MLBTEXHalftimeOU' : MLB.TEXHalftimeOU
}

MLBHOUDict = {
    'MLBHOUSuperRL' : MLB.MLBHOUSuperRL,
    'MLBHOURL' : MLB.MLBHOURL,
    'MLBHOUML' : MLB.MLBHOUML,
    'MLBHOUOU' : MLB.MLBHOUOU,
    'MLBHOUSoloOU' : MLB.MLBHOUSoloOU,
    'MLBHOUFirstInning' : MLB.MLBHOUFirstInning,
    'MLBHOUHalftime' : MLB.MLBHOUHalftime,
    'MLBHOUHalftimeOU' : MLB.MLBHOUHalftimeOU
}

# NL Central Teams Dictionaries

MLBMILDict = {
    'MLBMILSuperRL' : MLB.MILSuperRL,
    'MLBMILRL' : MLB.MILRL,
    'MLBMILML' : MLB.MILML,
    'MLBMILOU' : MLB.MILOU,
    'MLBMILSoloOU' : MLB.MILSoloOU,
    'MLBMILFirstInning' : MLB.MILFirstInning,
    'MLBMILHalftime' : MLB.MILHalftime,
    'MLBMILHalftimeOU' : MLB.MILHalftimeOU
}

MLBCHCDict = {
    'MLBCHCSuperRL' : MLB.CHCSuperRL,
    'MLBCHCRL' : MLB.CHCRL,
    'MLBCHCML' : MLB.CHCML,
    'MLBCHCOU' : MLB.CHCOU,
    'MLBCHCSoloOU' : MLB.CHCSoloOU,
    'MLBCHCFirstInning' : MLB.CHCFirstInning,
    'MLBCHCHalftime' : MLB.CHCHalftime,
    'MLBCHCHalftimeOU' : MLB.CHCHalftimeOU
}

MLBCINDict = {
    'MLBCINSuperRL' : MLB.CINSuperRL,
    'MLBCINRL' : MLB.CINRL,
    'MLBCINML' : MLB.CINML,
    'MLBCINOU' : MLB.CINOU,
    'MLBCINSoloOU' : MLB.CINSoloOU,
    'MLBCINFirstInning' : MLB.CINFirstInning,
    'MLBCINHalftime' : MLB.CINHalftime,
    'MLBCINHalftimeOU' : MLB.CINHalftimeOU
}

MLBPITDict = {
    'MLBPITSuperRL' : MLB.PITSuperRL,
    'MLBPITRL' : MLB.PITRL,
    'MLBPITML' : MLB.PITML,
    'MLBPITOU' : MLB.PITOU,
    'MLBPITSoloOU' : MLB.PITSoloOU,
    'MLBPITFirstInning' : MLB.PITFirstInning,
    'MLBPITHalftime' : MLB.PITHalftime,
    'MLBPITHalftimeOU' : MLB.PITHalftimeOU
}

MLBSTLDict = {
    'MLBSTLSuperRL' : MLB.STLSuperRL,
    'MLBSTLRL' : MLB.STLRL,
    'MLBSTLML' : MLB.STLML,
    'MLBSTLOU' : MLB.STLOU,
    'MLBSTLSoloOU' : MLB.STLSoloOU,
    'MLBSTLFirstInning' : MLB.STLFirstInning,
    'MLBSTLHalftime' : MLB.STLHalftime,
    'MLBSTLHalftimeOU' : MLB.STLHalftimeOU
}
#NL East Teams Dictionaries

MLBATLDict = {
    'MLBATLSuperRL' : MLB.ATLSuperRL,
    'MLBATLRL' : MLB.ATLRL,
    'MLBATLML' : MLB.ATLML,
    'MLBATLOU' : MLB.ATLOU,
    'MLBATLSoloOU' : MLB.ATLSoloOU,
    'MLBATLFirstInning' : MLB.ATLFirstInning,
    'MLBATLHalftime' : MLB.ATLHalftime,
    'MLBATLHalftimeOU' : MLB.ATLHalftimeOU
}

MLBWASDict = {
    'MLBWASSuperRL' : MLB.WASSuperRL,
    'MLBWASRL' : MLB.WASRL,
    'MLBWASML' : MLB.WASML,
    'MLBWASOU' : MLB.WASOU,
    'MLBWASSoloOU' : MLB.WASSoloOU,
    'MLBWASFirstInning' : MLB.WASFirstInning,
    'MLBWASHalftime' : MLB.WASHalftime,
    'MLBWASHalftimeOU' : MLB.WASHalftimeOU
}

MLBNYMDict = {
    'MLBNYMSuperRL' : MLB.NYMSuperRL,
    'MLBNYMRL' : MLB.NYMRL,
    'MLBNYMML' : MLB.NYMML,
    'MLBNYMOU' : MLB.NYMOU,
    'MLBNYMSoloOU' : MLB.NYMSoloOU,
    'MLBNYMFirstInning' : MLB.NYMFirstInning,
    'MLBNYMHalftime' : MLB.NYMHalftime,
    'MLBNYMHalftimeOU' : MLB.NYMHalftimeOU
}

MLBPHIDict = {
    'MLBPHISuperRL' : MLB.MLBPHISuperRL,
    'MLBPHIRL' : MLB.MLBPHIRL,
    'MLBPHIML' : MLB.MLBPHIML,
    'MLBPHIOU' : MLB.MLBPHIOU,
    'MLBPHISoloOU' : MLB.MLBPHISoloOU,
    'MLBPHIFirstInning' : MLB.MLBPHIFirstInning,
    'MLBPHIHalftime' : MLB.MLBPHIHalftime,
    'MLBPHIHalftimeOU' : MLB.MLBPHIHalftimeOU
}

MLBMIADict = {
    'MLBMIASuperRL' : MLB.MIASuperRL,
    'MLBMIARL' : MLB.MIARL,
    'MLBMIAML' : MLB.MIAML,
    'MLBMIAOU' : MLB.MIAOU,
    'MLBMIASoloOU' : MLB.MIASoloOU,
    'MLBMIAFirstInning' : MLB.MIAFirstInning,
    'MLBMIAHalftime' : MLB.MIAHalftime,
    'MLBMIAHalftimeOU' : MLB.MIAHalftimeOU
}

MLBLADDict = {
    'MLBLADSuperRL' : MLB.LADSuperRL,
    'MLBLADRL' : MLB.LADRL,
    'MLBLADML' : MLB.LADML,
    'MLBLADOU' : MLB.LADOU,
    'MLBLADSoloOU' : MLB.LADSoloOU,
    'MLBLADFirstInning' : MLB.LADFirstInning,
    'MLBLADHalftime' : MLB.LADHalftime,
    'MLBLADHalftimeOU' : MLB.LADHalftimeOU
}

MLBSDDict = {
    'MLBSDSuperRL' : MLB.SDSuperRL,
    'MLBSDRL' : MLB.SDRL,
    'MLBSDML' : MLB.SDML,
    'MLBSDOU' : MLB.SDOU,
    'MLBSDSoloOU' : MLB.SDSoloOU,
    'MLBSDFirstInning' : MLB.SDFirstInning,
    'MLBSDHalftime' : MLB.SDHalftime,
    'MLBSDHalftimeOU' : MLB.SDHalftimeOU
}

MLBSFDict = {
    'MLBSFSuperRL' : MLB.SFSuperRL,
    'MLBSFRL' : MLB.SFRL,
    'MLBSFML' : MLB.SFML,
    'MLBSFOU' : MLB.SFOU,
    'MLBSFSoloOU' : MLB.SFSoloOU,
    'MLBSFFirstInning' : MLB.SFFirstInning,
    'MLBSFHalftime' : MLB.SFHalftime,
    'MLBSFHalftimeOU' : MLB.SFHalftimeOU
}

MLBCOLDict = {
    'MLBCOLSuperRL' : MLB.COLSuperRL,
    'MLBCOLRL' : MLB.COLRL,
    'MLBCOLML' : MLB.COLML,
    'MLBCOLOU' : MLB.COLOU,
    'MLBCOLSoloOU' : MLB.COLSoloOU,
    'MLBCOLFirstInning' : MLB.COLFirstInning,
    'MLBCOLHalftime' : MLB.COLHalftime,
    'MLBCOLHalftimeOU' : MLB.COLHalftimeOU
}

MLBARIDict = {
    'MLBARISuperRL' : MLB.ARISuperRL,
    'MLBARIRL' : MLB.ARIRL,
    'MLBARIML' : MLB.ARIML,
    'MLBARIOU' : MLB.ARIOU,
    'MLBARISoloOU' : MLB.ARISoloOU,
    'MLBARIFirstInning' : MLB.ARIFirstInning,
    'MLBARIHalftime' : MLB.ARIHalftime,
    'MLBARIHalftimeOU' : MLB.ARIHalftimeOU
}

ALCentralDict = {**MLBCWSDict, **MLBCLEDict, **MLBKANDict, **MLBMINDict, **MLBDETDict}
ALEastDict = {**MLBBALDict, **MLBBOSDict, **MLBNYYDict, **MLBTORDict, **MLBTBDict}
ALWestDict = {**MLBLAADict, **MLBOAKDict, **MLBSEADict, **MLBTEXDict, **MLBHOUDict}
NLCentralDict = {**MLBMILDict, **MLBCHCDict, **MLBCINDict, **MLBPITDict, **MLBSTLDict}
NLEastDict = {**MLBATLDict, **MLBWASDict, **MLBNYMDict, **MLBPHIDict, **MLBMIADict}
NLWestDict = {**MLBLADDict, **MLBSDDict, **MLBSFDict, **MLBCOLDict, **MLBARIDict}
MLBDict = {**ALEastDict, **ALCentralDict, **ALWestDict, **NLCentralDict, **NLEastDict, **NLWestDict}

OrderedMLBDict = sorted(MLBDict.items(), key=operator.itemgetter(1), reverse = True) [:5]
# This is what I have to do in order to get the top 5 values. Reverse puts them in descending order -- put it after the parenthesis[:5]

#Remember to reverse the order in order to see if the Under % is top 5

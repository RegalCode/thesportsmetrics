//<![CDATA[
// array of possible teams in the same order as they appear in the team selection list
var teamLists = new Array(30)
teamLists["empty"] = ["Select a Stat"];
teamLists["Arizona Diamondbacks"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1st Inning %", "Halftime Cover", "Halftime Over", "Halftime Under"];
teamLists["Atlanta Braves"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1st Inning %", "Halftime Cover", "Halftime Over", "Halftime Under"];
teamLists["Baltimore Orioles"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1st Inning %", "Halftime Cover", "Halftime Over", "Halftime Under"];
teamLists["Boston Red Sox"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1st Inning %", "Halftime Cover", "Halftime Over", "Halftime Under"];
teamLists["Chicago White Sox"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1st Inning %", "Halftime Cover", "Halftime Over", "Halftime Under"];
teamLists["Chicago Cubs"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1st Inning %", "Halftime Cover", "Halftime Over", "Halftime Under"];
teamLists["Cincinnati Reds"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1st Inning %", "Halftime Cover", "Halftime Over", "Halftime Under"];
teamLists["Cleveland Indians"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1st Inning %", "Halftime Cover", "Halftime Over", "Halftime Under"];
teamLists["Colorado Rockies"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1st Inning %", "Halftime Cover", "Halftime Over", "Halftime Under"];
teamLists["Detroit Tigers"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1st Inning %", "Halftime Cover", "Halftime Over", "Halftime Under"];
teamLists["Houston Astros"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1st Inning %", "Halftime Cover", "Halftime Over", "Halftime Under"];
teamLists["Kansas City Royals"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1st Inning %", "Halftime Cover", "Halftime Over", "Halftime Under"];
teamLists["Los Angeles Angels"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1st Inning %", "Halftime Cover", "Halftime Over", "Halftime Under"];
teamLists["Los Angeles Dodgers"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1st Inning %", "Halftime Cover", "Halftime Over", "Halftime Under"];
teamLists["Miami Marlins"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1st Inning %", "Halftime Cover", "Halftime Over", "Halftime Under"];
teamLists["Milwaukee Brewers"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1st Inning %", "Halftime Cover", "Halftime Over", "Halftime Under"];
teamLists["Minnesota Twins"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1st Inning %", "Halftime Cover", "Halftime Over", "Halftime Under"];
teamLists["New York Yankees"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1st Inning %", "Halftime Cover", "Halftime Over", "Halftime Under"];
teamLists["New York Mets"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1st Inning %", "Halftime Cover", "Halftime Over", "Halftime Under"];
teamLists["Oakland Athletics"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1st Inning %", "Halftime Cover", "Halftime Over", "Halftime Under"];
teamLists["Philadelphia Phillies"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1st Inning %", "Halftime Cover", "Halftime Over", "Halftime Under"];
teamLists["Pittsburgh Pirates"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1st Inning %", "Halftime Cover", "Halftime Over", "Halftime Under"];
teamLists["San Diego Padres"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1st Inning %", "Halftime Cover", "Halftime Over", "Halftime Under"];
teamLists["San Francisco Giants"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1st Inning %", "Halftime Cover", "Halftime Over", "Halftime Under"];
teamLists["Seattle Mariners"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1st Inning %", "Halftime Cover", "Halftime Over", "Halftime Under"];
teamLists["St. Louis Cardinals"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1st Inning %", "Halftime Cover", "Halftime Over", "Halftime Under"];
teamLists["Tampa Bay Rays"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1st Inning %", "Halftime Cover", "Halftime Over", "Halftime Under"];
teamLists["Texas Rangers"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1st Inning %", "Halftime Cover", "Halftime Over", "Halftime Under"];
teamLists["Toronto Blue Jays"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1st Inning %", "Halftime Cover", "Halftime Over", "Halftime Under"];
teamLists["Washington Nationals"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1st Inning %", "Halftime Cover", "Halftime Over", "Halftime Under"];
/* teamChange() is called from the onchange event of a select element.
* param selectObj - the select object which fired the on change event.
*/

function teamChange(selectObj) {
// get the index of the selected option
 index = selectObj.selectedIndex;
// get the value of the selected option
var which = selectObj.options[index].value;
// use the selected option value to retrieve the list of items from the countryLists array
tList = teamLists[which];
// get the country select element via its known id
var tSelect = document.getElementById("stat-change");
// remove the current options from the country select
var len = tSelect.options.length;

while (tSelect.options.length > 0) {
tSelect.remove(0);
}
var newOption;
// create new options
for (var i=0; i<tList.length; i++) {
newOption = document.createElement("option");
newOption.value = tList[i];  // assumes option string and value are the same
newOption.text=tList[i];
// add the new option
try {
tSelect.add(newOption);  // this will fail in DOM browsers but is needed for IE
}
catch (e) {
tSelect.appendChild(newOption);
}
}
}

function statChange(selectObj) {

  var ariSuperRL = document.getElementById("ARISuperRL").innerHTML;
  var ariRL = document.getElementById("ARIRL").innerHTML;
  var ariML = document.getElementById("ARIML").innerHTML;
  var ariO = document.getElementById("ARIO").innerHTML;
  var ariO = ariO.replace(/[',()]/g, "");
  var ariSoloO = document.getElementById("ARISoloO").innerHTML;
  var ariSoloO = ariSoloO.replace(/[',()]/g, "");
  var ariFirstInning = document.getElementById("ARIFirstInning").innerHTML;
  var ariHalftime = document.getElementById("ARIHalftime").innerHTML;
  var ariHalftimeO = document.getElementById("ARIHalftimeO").innerHTML;
  var ariHalftimeO = ariHalftimeO.replace(/[',()]/g, "");

  var atlSuperRL = document.getElementById("ATLSuperRL").innerHTML;
  var atlRL = document.getElementById("ATLRL").innerHTML;
  var atlML = document.getElementById("ATLML").innerHTML;
  var atlO = document.getElementById("ATLO").innerHTML;
  var atlO = atlO.replace(/[',()]/g, "");
  var atlSoloO = document.getElementById("ATLSoloO").innerHTML;
  var atlSoloO = atlSoloO.replace(/[',()]/g, "");
  var atlFirstInning = document.getElementById("ATLFirstInning").innerHTML;
  var atlHalftime = document.getElementById("ATLHalftime").innerHTML;
  var atlHalftimeO = document.getElementById("ATLHalftimeO").innerHTML;
  var atlHalftimeO = atlHalftimeO.replace(/[',()]/g, "");

  var balSuperRL = document.getElementById("BALSuperRL").innerHTML;
  var balRL = document.getElementById("BALRL").innerHTML;
  var balML = document.getElementById("BALML").innerHTML;
  var balO = document.getElementById("BALO").innerHTML;
  var balO = balO.replace(/[',()]/g, "");
  var balSoloO = document.getElementById("BALSoloO").innerHTML;
  var balSoloO = balSoloO.replace(/[',()]/g, "");
  var balFirstInning = document.getElementById("BALFirstInning").innerHTML;
  var balHalftime = document.getElementById("BALHalftime").innerHTML;
  var balHalftimeO = document.getElementById("BALHalftimeO").innerHTML;
  var balHalftimeO = balHalftimeO.replace(/[',()]/g, "");

  var bosSuperRL = document.getElementById("BOSSuperRL").innerHTML;
  var bosRL = document.getElementById("BOSRL").innerHTML;
  var bosML = document.getElementById("BOSML").innerHTML;
  var bosO = document.getElementById("BOSO").innerHTML;
  var bosO = bosO.replace(/[',()]/g, "");
  var bosSoloO = document.getElementById("BOSSoloO").innerHTML;
  var bosSoloO = bosSoloO.replace(/[',()]/g, "");
  var bosFirstInning = document.getElementById("BOSFirstInning").innerHTML;
  var bosHalftime = document.getElementById("BOSHalftime").innerHTML;
  var bosHalftimeO = document.getElementById("BOSHalftimeO").innerHTML;
  var bosHalftimeO = bosHalftimeO.replace(/[',()]/g, "");

  var chcSuperRL = document.getElementById("CHCSuperRL").innerHTML;
  var chcRL = document.getElementById("CHCRL").innerHTML;
  var chcML = document.getElementById("CHCML").innerHTML;
  var chcO = document.getElementById("CHCO").innerHTML;
  var chcO = chcO.replace(/[',()]/g, "");
  var chcSoloO = document.getElementById("CHCSoloO").innerHTML;
  var chcSoloO = chcSoloO.replace(/[',()]/g, "");
  var chcFirstInning = document.getElementById("CHCFirstInning").innerHTML;
  var chcHalftime = document.getElementById("CHCHalftime").innerHTML;
  var chcHalftimeO = document.getElementById("CHCHalftimeO").innerHTML;
  var chcHalftimeO = chcHalftimeO.replace(/[',()]/g, "");

  var cwsSuperRL = document.getElementById("CWSSuperRL").innerHTML;
  var cwsRL = document.getElementById("CWSRL").innerHTML;
  var cwsML = document.getElementById("CWSML").innerHTML;
  var cwsO = document.getElementById("CWSO").innerHTML;
  var cwsO = cwsO.replace(/[',()]/g, "");
  var cwsSoloO = document.getElementById("CWSSoloO").innerHTML;
  var cwsSoloO = cwsSoloO.replace(/[',()]/g, "");
  var cwsFirstInning = document.getElementById("CWSFirstInning").innerHTML;
  var cwsHalftime = document.getElementById("CWSHalftime").innerHTML;
  var cwsHalftimeO = document.getElementById("CWSHalftimeO").innerHTML;
  var cwsHalftimeO = cwsHalftimeO.replace(/[',()]/g, "");

  var cinSuperRL = document.getElementById("CINSuperRL").innerHTML;
  var cinRL = document.getElementById("CINRL").innerHTML;
  var cinML = document.getElementById("CINML").innerHTML;
  var cinO = document.getElementById("CINO").innerHTML;
  var cinO = cinO.replace(/[',()]/g, "");
  var cinSoloO = document.getElementById("CINSoloO").innerHTML;
  var cinSoloO = cinSoloO.replace(/[',()]/g, "");
  var cinFirstInning = document.getElementById("CINFirstInning").innerHTML;
  var cinHalftime = document.getElementById("CINHalftime").innerHTML;
  var cinHalftimeO = document.getElementById("CINHalftimeO").innerHTML;
  var cinHalftimeO = cinHalftimeO.replace(/[',()]/g, "");

  var cleSuperRL = document.getElementById("CLESuperRL").innerHTML;
  var cleRL = document.getElementById("CLERL").innerHTML;
  var cleML = document.getElementById("CLEML").innerHTML;
  var cleO = document.getElementById("CLEO").innerHTML;
  var cleO = cleO.replace(/[',()]/g, "");
  var cleSoloO = document.getElementById("CLESoloO").innerHTML;
  var cleSoloO = cleSoloO.replace(/[',()]/g, "");
  var cleFirstInning = document.getElementById("CLEFirstInning").innerHTML;
  var cleHalftime = document.getElementById("CLEHalftime").innerHTML;
  var cleHalftimeO = document.getElementById("CLEHalftimeO").innerHTML;
  var cleHalftimeO = cleHalftimeO.replace(/[',()]/g, "");

  var colSuperRL = document.getElementById("COLSuperRL").innerHTML;
  var colRL = document.getElementById("COLRL").innerHTML;
  var colML = document.getElementById("COLML").innerHTML;
  var colO = document.getElementById("COLO").innerHTML;
  var colO = colO.replace(/[',()]/g, "");
  var colSoloO = document.getElementById("COLSoloO").innerHTML;
  var colSoloO = colSoloO.replace(/[',()]/g, "");
  var colFirstInning = document.getElementById("COLFirstInning").innerHTML;
  var colHalftime = document.getElementById("COLHalftime").innerHTML;
  var colHalftimeO = document.getElementById("COLHalftimeO").innerHTML;
  var colHalftimeO = colHalftimeO.replace(/[',()]/g, "");

  var detSuperRL = document.getElementById("DETSuperRL").innerHTML;
  var detRL = document.getElementById("DETRL").innerHTML;
  var detML = document.getElementById("DETML").innerHTML;
  var detO = document.getElementById("DETO").innerHTML;
  var detO = detO.replace(/[',()]/g, "");
  var detSoloO = document.getElementById("DETSoloO").innerHTML;
  var detSoloO = detSoloO.replace(/[',()]/g, "");
  var detFirstInning = document.getElementById("DETFirstInning").innerHTML;
  var detHalftime = document.getElementById("DETHalftime").innerHTML;
  var detHalftimeO = document.getElementById("DETHalftimeO").innerHTML;
  var detHalftimeO = detHalftimeO.replace(/[',()]/g, "");

  var miaSuperRL = document.getElementById("MIASuperRL").innerHTML;
  var miaRL = document.getElementById("MIARL").innerHTML;
  var miaML = document.getElementById("MIAML").innerHTML;
  var miaO = document.getElementById("MIAO").innerHTML;
  var miaO = miaO.replace(/[',()]/g, "");
  var miaSoloO = document.getElementById("MIASoloO").innerHTML;
  var miaSoloO = miaSoloO.replace(/[',()]/g, "");
  var miaFirstInning = document.getElementById("MIAFirstInning").innerHTML;
  var miaHalftime = document.getElementById("MIAHalftime").innerHTML;
  var miaHalftimeO = document.getElementById("MIAHalftimeO").innerHTML;
  var miaHalftimeO = miaHalftimeO.replace(/[',()]/g, "");

  var houSuperRL = document.getElementById("HOUSuperRL").innerHTML;
  var houRL = document.getElementById("HOURL").innerHTML;
  var houML = document.getElementById("HOUML").innerHTML;
  var houO = document.getElementById("HOUO").innerHTML;
  var houO = houO.replace(/[',()]/g, "");
  var houSoloO = document.getElementById("HOUSoloO").innerHTML;
  var houSoloO = houSoloO.replace(/[',()]/g, "");
  var houFirstInning = document.getElementById("HOUFirstInning").innerHTML;
  var houHalftime = document.getElementById("HOUHalftime").innerHTML;
  var houHalftimeO = document.getElementById("HOUHalftimeO").innerHTML;
  var houHalftimeO = houHalftimeO.replace(/[',()]/g, "");

  var kanSuperRL = document.getElementById("KANSuperRL").innerHTML;
  var kanRL = document.getElementById("KANRL").innerHTML;
  var kanML = document.getElementById("KANML").innerHTML;
  var kanO = document.getElementById("KANO").innerHTML;
  var kanO = kanO.replace(/[',()]/g, "");
  var kanSoloO = document.getElementById("KANSoloO").innerHTML;
  var kanSoloO = kanSoloO.replace(/[',()]/g, "");
  var kanFirstInning = document.getElementById("KANFirstInning").innerHTML;
  var kanHalftime = document.getElementById("KANHalftime").innerHTML;
  var kanHalftimeO = document.getElementById("KANHalftimeO").innerHTML;
  var kanHalftimeO = kanHalftimeO.replace(/[',()]/g, "");

  var laaSuperRL = document.getElementById("LAASuperRL").innerHTML;
  var laaRL = document.getElementById("LAARL").innerHTML;
  var laaML = document.getElementById("LAAML").innerHTML;
  var laaO = document.getElementById("LAAO").innerHTML;
  var laaO = laaO.replace(/[',()]/g, "");
  var laaSoloO = document.getElementById("LAASoloO").innerHTML;
  var laaSoloO = laaSoloO.replace(/[',()]/g, "");
  var laaFirstInning = document.getElementById("LAAFirstInning").innerHTML;
  var laaHalftime = document.getElementById("LAAHalftime").innerHTML;
  var laaHalftimeO = document.getElementById("LAAHalftimeO").innerHTML;
  var laaHalftimeO = laaHalftimeO.replace(/[',()]/g, "");

  var ladSuperRL = document.getElementById("LADSuperRL").innerHTML;
  var ladRL = document.getElementById("LADRL").innerHTML;
  var ladML = document.getElementById("LADML").innerHTML;
  var ladO = document.getElementById("LADO").innerHTML;
  var ladO = ladO.replace(/[',()]/g, "");
  var ladSoloO = document.getElementById("LADSoloO").innerHTML;
  var ladSoloO = ladSoloO.replace(/[',()]/g, "");
  var ladFirstInning = document.getElementById("LADFirstInning").innerHTML;
  var ladHalftime = document.getElementById("LADHalftime").innerHTML;
  var ladHalftimeO = document.getElementById("LADHalftimeO").innerHTML;
  var ladHalftimeO = ladHalftimeO.replace(/[',()]/g, "");

  var milSuperRL = document.getElementById("MILSuperRL").innerHTML;
  var milRL = document.getElementById("MILRL").innerHTML;
  var milML = document.getElementById("MILML").innerHTML;
  var milO = document.getElementById("MILO").innerHTML;
  var milO = milO.replace(/[',()]/g, "");
  var milSoloO = document.getElementById("MILSoloO").innerHTML;
  var milSoloO = milSoloO.replace(/[',()]/g, "");
  var milFirstInning = document.getElementById("MILFirstInning").innerHTML;
  var milHalftime = document.getElementById("MILHalftime").innerHTML;
  var milHalftimeO = document.getElementById("MILHalftimeO").innerHTML;
  var milHalftimeO = milHalftimeO.replace(/[',()]/g, "");

  var minSuperRL = document.getElementById("MINSuperRL").innerHTML;
  var minRL = document.getElementById("MINRL").innerHTML;
  var minML = document.getElementById("MINML").innerHTML;
  var minO = document.getElementById("MINO").innerHTML;
  var minO = minO.replace(/[',()]/g, "");
  var minSoloO = document.getElementById("MINSoloO").innerHTML;
  var minSoloO = minSoloO.replace(/[',()]/g, "");
  var minFirstInning = document.getElementById("MINFirstInning").innerHTML;
  var minHalftime = document.getElementById("MINHalftime").innerHTML;
  var minHalftimeO = document.getElementById("MINHalftimeO").innerHTML;
  var minHalftimeO = minHalftimeO.replace(/[',()]/g, "");

  var nymSuperRL = document.getElementById("NYMSuperRL").innerHTML;
  var nymRL = document.getElementById("NYMRL").innerHTML;
  var nymML = document.getElementById("NYMML").innerHTML;
  var nymO = document.getElementById("NYMO").innerHTML;
  var nymO = nymO.replace(/[',()]/g, "");
  var nymSoloO = document.getElementById("NYMSoloO").innerHTML;
  var nymSoloO = nymSoloO.replace(/[',()]/g, "");
  var nymFirstInning = document.getElementById("NYMFirstInning").innerHTML;
  var nymHalftime = document.getElementById("NYMHalftime").innerHTML;
  var nymHalftimeO = document.getElementById("NYMHalftimeO").innerHTML;
  var nymHalftimeO = nymHalftimeO.replace(/[',()]/g, "");

  var nyySuperRL = document.getElementById("NYYSuperRL").innerHTML;
  var nyyRL = document.getElementById("NYYRL").innerHTML;
  var nyyML = document.getElementById("NYYML").innerHTML;
  var nyyO = document.getElementById("NYYO").innerHTML;
  var nyyO = nyyO.replace(/[',()]/g, "");
  var nyySoloO = document.getElementById("NYYSoloO").innerHTML;
  var nyySoloO = nyySoloO.replace(/[',()]/g, "");
  var nyyFirstInning = document.getElementById("NYYFirstInning").innerHTML;
  var nyyHalftime = document.getElementById("NYYHalftime").innerHTML;
  var nyyHalftimeO = document.getElementById("NYYHalftimeO").innerHTML;
  var nyyHalftimeO = nyyHalftimeO.replace(/[',()]/g, "");

  var oakSuperRL = document.getElementById("OAKSuperRL").innerHTML;
  var oakRL = document.getElementById("OAKRL").innerHTML;
  var oakML = document.getElementById("OAKML").innerHTML;
  var oakO = document.getElementById("OAKO").innerHTML;
  var oakO = oakO.replace(/[',()]/g, "");
  var oakSoloO = document.getElementById("OAKSoloO").innerHTML;
  var oakSoloO = oakSoloO.replace(/[',()]/g, "");
  var oakFirstInning = document.getElementById("OAKFirstInning").innerHTML;
  var oakHalftime = document.getElementById("OAKHalftime").innerHTML;
  var oakHalftimeO = document.getElementById("OAKHalftimeO").innerHTML;
  var oakHalftimeO = oakHalftimeO.replace(/[',()]/g, "");

  var phiSuperRL = document.getElementById("PHISuperRL").innerHTML;
  var phiRL = document.getElementById("PHIRL").innerHTML;
  var phiML = document.getElementById("PHIML").innerHTML;
  var phiO = document.getElementById("PHIO").innerHTML;
  var phiO = phiO.replace(/[',()]/g, "");
  var phiSoloO = document.getElementById("PHISoloO").innerHTML;
  var phiSoloO = phiSoloO.replace(/[',()]/g, "");
  var phiFirstInning = document.getElementById("PHIFirstInning").innerHTML;
  var phiHalftime = document.getElementById("PHIHalftime").innerHTML;
  var phiHalftimeO = document.getElementById("PHIHalftimeO").innerHTML;
  var phiHalftimeO = phiHalftimeO.replace(/[',()]/g, "");

  var pitSuperRL = document.getElementById("PITSuperRL").innerHTML;
  var pitRL = document.getElementById("PITRL").innerHTML;
  var pitML = document.getElementById("PITML").innerHTML;
  var pitO = document.getElementById("PITO").innerHTML;
  var pitO = pitO.replace(/[',()]/g, "");
  var pitSoloO = document.getElementById("PITSoloO").innerHTML;
  var pitSoloO = pitSoloO.replace(/[',()]/g, "");
  var pitFirstInning = document.getElementById("PITFirstInning").innerHTML;
  var pitHalftime = document.getElementById("PITHalftime").innerHTML;
  var pitHalftimeO = document.getElementById("PITHalftimeO").innerHTML;
  var pitHalftimeO = pitHalftimeO.replace(/[',()]/g, "");

  var sdSuperRL = document.getElementById("SDSuperRL").innerHTML;
  var sdRL = document.getElementById("SDRL").innerHTML;
  var sdML = document.getElementById("SDML").innerHTML;
  var sdO = document.getElementById("SDO").innerHTML;
  var sdO = sdO.replace(/[',()]/g, "");
  var sdSoloO = document.getElementById("SDSoloO").innerHTML;
  var sdSoloO = sdSoloO.replace(/[',()]/g, "");
  var sdFirstInning = document.getElementById("SDFirstInning").innerHTML;
  var sdHalftime = document.getElementById("SDHalftime").innerHTML;
  var sdHalftimeO = document.getElementById("SDHalftimeO").innerHTML;
  var sdHalftimeO = sdHalftimeO.replace(/[',()]/g, "");

  var sfSuperRL = document.getElementById("SFSuperRL").innerHTML;
  var sfRL = document.getElementById("SFRL").innerHTML;
  var sfML = document.getElementById("SFML").innerHTML;
  var sfO = document.getElementById("SFO").innerHTML;
  var sfO = sfO.replace(/[',()]/g, "");
  var sfSoloO = document.getElementById("SFSoloO").innerHTML;
  var sfSoloO = sfSoloO.replace(/[',()]/g, "");
  var sfFirstInning = document.getElementById("SFFirstInning").innerHTML;
  var sfHalftime = document.getElementById("SFHalftime").innerHTML;
  var sfHalftimeO = document.getElementById("SFHalftimeO").innerHTML;
  var sfHalftimeO = sfHalftimeO.replace(/[',()]/g, "");

  var seaSuperRL = document.getElementById("SEASuperRL").innerHTML;
  var seaRL = document.getElementById("SEARL").innerHTML;
  var seaML = document.getElementById("SEAML").innerHTML;
  var seaO = document.getElementById("SEAO").innerHTML;
  var seaO = seaO.replace(/[',()]/g, "");
  var seaSoloO = document.getElementById("SEASoloO").innerHTML;
  var seaSoloO = seaSoloO.replace(/[',()]/g, "");
  var seaFirstInning = document.getElementById("SEAFirstInning").innerHTML;
  var seaHalftime = document.getElementById("SEAHalftime").innerHTML;
  var seaHalftimeO = document.getElementById("SEAHalftimeO").innerHTML;
  var seaHalftimeO = seaHalftimeO.replace(/[',()]/g, "");

  var stlSuperRL = document.getElementById("STLSuperRL").innerHTML;
  var stlRL = document.getElementById("STLRL").innerHTML;
  var stlML = document.getElementById("STLML").innerHTML;
  var stlO = document.getElementById("STLO").innerHTML;
  var stlO = stlO.replace(/[',()]/g, "");
  var stlSoloO = document.getElementById("STLSoloO").innerHTML;
  var stlSoloO = stlSoloO.replace(/[',()]/g, "");
  var stlFirstInning = document.getElementById("STLFirstInning").innerHTML;
  var stlHalftime = document.getElementById("STLHalftime").innerHTML;
  var stlHalftimeO = document.getElementById("STLHalftimeO").innerHTML;
  var stlHalftimeO = stlHalftimeO.replace(/[',()]/g, "");

  var tbSuperRL = document.getElementById("TBSuperRL").innerHTML;
  var tbRL = document.getElementById("TBRL").innerHTML;
  var tbML = document.getElementById("TBML").innerHTML;
  var tbO = document.getElementById("TBO").innerHTML;
  var tbO = tbO.replace(/[',()]/g, "");
  var tbSoloO = document.getElementById("TBSoloO").innerHTML;
  var tbSoloO = tbSoloO.replace(/[',()]/g, "");
  var tbFirstInning = document.getElementById("TBFirstInning").innerHTML;
  var tbHalftime = document.getElementById("TBHalftime").innerHTML;
  var tbHalftimeO = document.getElementById("TBHalftimeO").innerHTML;
  var tbHalftimeO = tbHalftimeO.replace(/[',()]/g, "");

  var texSuperRL = document.getElementById("TEXSuperRL").innerHTML;
  var texRL = document.getElementById("TEXRL").innerHTML;
  var texML = document.getElementById("TEXML").innerHTML;
  var texO = document.getElementById("TEXO").innerHTML;
  var texO = texO.replace(/[',()]/g, "");
  var texSoloO = document.getElementById("TEXSoloO").innerHTML;
  var texSoloO = texSoloO.replace(/[',()]/g, "");
  var texFirstInning = document.getElementById("TEXFirstInning").innerHTML;
  var texHalftime = document.getElementById("TEXHalftime").innerHTML;
  var texHalftimeO = document.getElementById("TEXHalftimeO").innerHTML;
  var texHalftimeO = texHalftimeO.replace(/[',()]/g, "");

  var torSuperRL = document.getElementById("TORSuperRL").innerHTML;
  var torRL = document.getElementById("TORRL").innerHTML;
  var torML = document.getElementById("TORML").innerHTML;
  var torO = document.getElementById("TORO").innerHTML;
  var torO = torO.replace(/[',()]/g, "");
  var torSoloO = document.getElementById("TORSoloO").innerHTML;
  var torSoloO = torSoloO.replace(/[',()]/g, "");
  var torFirstInning = document.getElementById("TORFirstInning").innerHTML;
  var torHalftime = document.getElementById("TORHalftime").innerHTML;
  var torHalftimeO = document.getElementById("TORHalftimeO").innerHTML;
  var torHalftimeO = torHalftimeO.replace(/[',()]/g, "");

  var wasSuperRL = document.getElementById("WASSuperRL").innerHTML;
  var wasRL = document.getElementById("WASRL").innerHTML;
  var wasML = document.getElementById("WASML").innerHTML;
  var wasO = document.getElementById("WASO").innerHTML;
  var wasO = wasO.replace(/[',()]/g, "");
  var wasSoloO = document.getElementById("WASSoloO").innerHTML;
  var wasSoloO = wasSoloO.replace(/[',()]/g, "");
  var wasFirstInning = document.getElementById("WASFirstInning").innerHTML;
  var wasHalftime = document.getElementById("WASHalftime").innerHTML;
  var wasHalftimeO = document.getElementById("WASHalftimeO").innerHTML;
  var wasHalftimeO = wasHalftimeO.replace(/[',()]/g, "");



  // How to get the under of a team

  // turn the variable into an integer
  var ariUnder = parseFloat(ariO, 10);
  var arisolounder = parseFloat(ariSoloO, 10);
  var arihalftimeunder = parseFloat(ariHalftimeO, 10);

  var atlUnder = parseFloat(atlO, 10);
  var atlsolounder = parseFloat(atlSoloO, 10);
  var atlhalftimeunder = parseFloat(atlHalftimeO, 10);

  var balUnder = parseFloat(balO, 10);
  var balsolounder = parseFloat(balSoloO, 10);
  var balhalftimeunder = parseFloat(balHalftimeO, 10);

  var bosUnder = parseFloat(bosO, 10);
  var bossolounder = parseFloat(bosSoloO, 10);
  var boshalftimeunder = parseFloat(bosHalftimeO, 10);

  var chcUnder = parseFloat(chcO, 10);
  var chcsolounder = parseFloat(chcSoloO, 10);
  var chchalftimeunder = parseFloat(chcHalftimeO, 10);

  var cwsUnder = parseFloat(cwsO, 10);
  var cwssolounder = parseFloat(cwsSoloO, 10);
  var cwshalftimeunder = parseFloat(cwsHalftimeO, 10);

  var cinUnder = parseFloat(cinO, 10);
  var cinsolounder = parseFloat(cinSoloO, 10);
  var cinhalftimeunder = parseFloat(cinHalftimeO, 10);

  var cleUnder = parseFloat(cleO, 10);
  var clesolounder = parseFloat(cleSoloO, 10);
  var clehalftimeunder = parseFloat(cleHalftimeO, 10);

  var colUnder = parseFloat(colO, 10);
  var colsolounder = parseFloat(colSoloO, 10);
  var colhalftimeunder = parseFloat(colHalftimeO, 10);

  var detUnder = parseFloat(detO, 10);
  var detsolounder = parseFloat(detSoloO, 10);
  var dethalftimeunder = parseFloat(detHalftimeO, 10);

  var miaUnder = parseFloat(miaO, 10);
  var miasolounder = parseFloat(miaSoloO, 10);
  var miahalftimeunder = parseFloat(miaHalftimeO, 10);

  var houUnder = parseFloat(houO, 10);
  var housolounder = parseFloat(houSoloO, 10);
  var houhalftimeunder = parseFloat(houHalftimeO, 10);

  var kanUnder = parseFloat(kanO, 10);
  var kansolounder = parseFloat(kanSoloO, 10);
  var kanhalftimeunder = parseFloat(kanHalftimeO, 10);

  var laaUnder = parseFloat(laaO, 10);
  var laasolounder = parseFloat(laaSoloO, 10);
  var laahalftimeunder = parseFloat(laaHalftimeO, 10);

  var ladUnder = parseFloat(ladO, 10);
  var ladsolounder = parseFloat(ladSoloO, 10);
  var ladhalftimeunder = parseFloat(ladHalftimeO, 10);

  var milUnder = parseFloat(milO, 10);
  var milsolounder = parseFloat(milSoloO, 10);
  var milhalftimeunder = parseFloat(milHalftimeO, 10);

  var minUnder = parseFloat(minO, 10);
  var minsolounder = parseFloat(minSoloO, 10);
  var minhalftimeunder = parseFloat(minHalftimeO, 10);

  var nymUnder = parseFloat(nymO, 10);
  var nymsolounder = parseFloat(nymSoloO, 10);
  var nymhalftimeunder = parseFloat(nymHalftimeO, 10);

  var nyyUnder = parseFloat(nyyO, 10);
  var nyysolounder = parseFloat(nyySoloO, 10);
  var nyyhalftimeunder = parseFloat(nyyHalftimeO, 10);

  var oakUnder = parseFloat(oakO, 10);
  var oaksolounder = parseFloat(oakSoloO, 10);
  var oakhalftimeunder = parseFloat(oakHalftimeO, 10);

  var phiUnder = parseFloat(phiO, 10);
  var phisolounder = parseFloat(phiSoloO, 10);
  var phihalftimeunder = parseFloat(phiHalftimeO, 10);

  var pitUnder = parseFloat(pitO, 10);
  var pitsolounder = parseFloat(pitSoloO, 10);
  var pithalftimeunder = parseFloat(pitHalftimeO, 10);

  var sdUnder = parseFloat(sdO, 10);
  var sdsolounder = parseFloat(sdSoloO, 10);
  var sdhalftimeunder = parseFloat(sdHalftimeO, 10);

  var sfUnder = parseFloat(sfO, 10);
  var sfsolounder = parseFloat(sfSoloO, 10);
  var sfhalftimeunder = parseFloat(sfHalftimeO, 10);

  var seaUnder = parseFloat(seaO, 10);
  var seasolounder = parseFloat(seaSoloO, 10);
  var seahalftimeunder = parseFloat(seaHalftimeO, 10);

  var stlUnder = parseFloat(stlO, 10);
  var stlsolounder = parseFloat(stlSoloO, 10);
  var stlhalftimeunder = parseFloat(stlHalftimeO, 10);

  var tbUnder = parseFloat(tbO, 10);
  var tbsolounder = parseFloat(tbSoloO, 10);
  var tbhalftimeunder = parseFloat(tbHalftimeO, 10);

  var texUnder = parseFloat(texO, 10);
  var texsolounder = parseFloat(texSoloO, 10);
  var texhalftimeunder = parseFloat(texHalftimeO, 10);

  var torUnder = parseFloat(torO, 10);
  var torsolounder = parseFloat(torSoloO, 10);
  var torhalftimeunder = parseFloat(torHalftimeO, 10);

  var wasUnder = parseFloat(wasO, 10);
  var wassolounder = parseFloat(wasSoloO, 10);
  var washalftimeunder = parseFloat(wasHalftimeO, 10);

  // Turn the over into under by subtracting by 100

  var ariU = 100 - ariUnder;
  var ariSoloU = 100 - arisolounder;
  var ariHalftimeU = 100 - arihalftimeunder;

  var atlU = 100 - atlUnder;
  var atlSoloU = 100 - atlsolounder;
  var atlHalftimeU = 100 - atlhalftimeunder;

  var balU = 100 - balUnder;
  var balSoloU = 100 - balsolounder;
  var balHalftimeU = 100 - balhalftimeunder;

  var bosU = 100 - bosUnder;
  var bosSoloU = 100 - bossolounder;
  var bosHalftimeU = 100 - boshalftimeunder;

  var chcU = 100 - chcUnder;
  var chcSoloU = 100 - chcsolounder;
  var chcHalftimeU = 100 - chchalftimeunder;

  var cwsU = 100 - cwsUnder;
  var cwsSoloU = 100 - cwssolounder;
  var cwsHalftimeU = 100 - cwshalftimeunder;

  var cinU = 100 - cinUnder;
  var cinSoloU = 100 - cinsolounder;
  var cinHalftimeU = 100 - cinhalftimeunder;

  var cleU = 100 - cleUnder;
  var cleSoloU = 100 - clesolounder;
  var cleHalftimeU = 100 - clehalftimeunder;

  var colU = 100 - colUnder;
  var colSoloU = 100 - colsolounder;
  var colHalftimeU = 100 - colhalftimeunder;

  var detU = 100 - detUnder;
  var detSoloU = 100 - detsolounder;
  var detHalftimeU = 100 - dethalftimeunder;

  var miaU = 100 - miaUnder;
  var miaSoloU = 100 - miasolounder;
  var miaHalftimeU = 100 - miahalftimeunder;

  var houU = 100 - houUnder;
  var houSoloU = 100 - housolounder;
  var houHalftimeU = 100 - houhalftimeunder;

  var kanU = 100 - kanUnder;
  var kanSoloU = 100 - kansolounder;
  var kanHalftimeU = 100 - kanhalftimeunder;

  var laaU = 100 - laaUnder;
  var laaSoloU = 100 - laasolounder;
  var laaHalftimeU = 100 - laahalftimeunder;

  var ladU = 100 - ladUnder;
  var ladSoloU = 100 - ladsolounder;
  var ladHalftimeU = 100 - ladhalftimeunder;

  var milU = 100 - milUnder;
  var milSoloU = 100 - milsolounder;
  var milHalftimeU = 100 - milhalftimeunder;

  var minU = 100 - minUnder;
  var minSoloU = 100 - minsolounder;
  var minHalftimeU = 100 - minhalftimeunder;

  var nymU = 100 - nymUnder;
  var nymSoloU = 100 - nymsolounder;
  var nymHalftimeU = 100 - nymhalftimeunder;

  var nyyU = 100 - nyyUnder;
  var nyySoloU = 100 - nyysolounder;
  var nyyHalftimeU = 100 - nyyhalftimeunder;

  var oakU = 100 - oakUnder;
  var oakSoloU = 100 - oaksolounder;
  var oakHalftimeU = 100 - oakhalftimeunder;

  var phiU = 100 - phiUnder;
  var phiSoloU = 100 - phisolounder;
  var phiHalftimeU = 100 - phihalftimeunder;

  var pitU = 100 - pitUnder;
  var pitSoloU = 100 - pitsolounder;
  var pitHalftimeU = 100 - pithalftimeunder;

  var sdU = 100 - sdUnder;
  var sdSoloU = 100 - sdsolounder;
  var sdHalftimeU = 100 - sdhalftimeunder;

  var sfU = 100 - sfUnder;
  var sfSoloU = 100 - sfsolounder;
  var sfHalftimeU = 100 - sfhalftimeunder;

  var seaU = 100 - seaUnder;
  var seaSoloU = 100 - seasolounder;
  var seaHalftimeU = 100 - seahalftimeunder;

  var stlU = 100 - stlUnder;
  var stlSoloU = 100 - stlsolounder;
  var stlHalftimeU = 100 - stlhalftimeunder;

  var tbU = 100 - tbUnder;
  var tbSoloU = 100 - tbsolounder;
  var tbHalftimeU = 100 - tbhalftimeunder;

  var texU = 100 - texUnder;
  var texSoloU = 100 - texsolounder;
  var texHalftimeU = 100 - texhalftimeunder;

  var torU = 100 - torUnder;
  var torSoloU = 100 - torsolounder;
  var torHalftimeU = 100 - torhalftimeunder;

  var wasU = 100 - wasUnder;
  var wasSoloU = 100 - wassolounder;
  var wasHalftimeU = 100 - washalftimeunder;

  // Add the % sign as a string to new variable

  var finalariU = ariU + "%";
  var finalariSoloU = ariSoloU + "%";
  var finalariHalftimeU = ariHalftimeU + "%";

  var finalatlU = atlU + "%";
  var finalatlSoloU = atlSoloU + "%";
  var finalatlHalftimeU = atlHalftimeU + "%";

  var finalbalU = balU + "%";
  var finalbalSoloU = balSoloU + "%";
  var finalbalHalftimeU = balHalftimeU + "%";

  var finalbosU = bosU + "%";
  var finalbosSoloU = bosSoloU + "%";
  var finalbosHalftimeU = bosHalftimeU + "%";

  var finalchcU = chcU + "%";
  var finalchcSoloU = chcSoloU + "%";
  var finalchcHalftimeU = chcHalftimeU + "%";

  var finalcwsU = cwsU + "%";
  var finalcwsSoloU = cwsSoloU + "%";
  var finalcwsHalftimeU = cwsHalftimeU + "%";

  var finalcinU = cinU + "%";
  var finalcinSoloU = cinSoloU + "%";
  var finalcinHalftimeU = cinHalftimeU + "%";

  var finalcleU = cleU + "%";
  var finalcleSoloU = cleSoloU + "%";
  var finalcleHalftimeU = cleHalftimeU + "%";

  var finalcolU = colU + "%";
  var finalcolSoloU = colSoloU + "%";
  var finalcolHalftimeU = colHalftimeU + "%";

  var finaldetU = detU + "%";
  var finaldetSoloU = detSoloU + "%";
  var finaldetHalftimeU = detHalftimeU + "%";

  var finalmiaU = miaU + "%";
  var finalmiaSoloU = miaSoloU + "%";
  var finalmiaHalftimeU = miaHalftimeU + "%";

  var finalhouU = houU + "%";
  var finalhouSoloU = houSoloU + "%";
  var finalhouHalftimeU = houHalftimeU + "%";

  var finalkanU = kanU + "%";
  var finalkanSoloU = kanSoloU + "%";
  var finalkanHalftimeU = kanHalftimeU + "%";

  var finallaaU = laaU + "%";
  var finallaaSoloU = laaSoloU + "%";
  var finallaaHalftimeU = laaHalftimeU + "%";

  var finalladU = ladU + "%";
  var finalladSoloU = ladSoloU + "%";
  var finalladHalftimeU = ladHalftimeU + "%";

  var finalmilU = milU + "%";
  var finalmilSoloU = milSoloU + "%";
  var finalmilHalftimeU = milHalftimeU + "%";

  var finalminU = minU + "%";
  var finalminSoloU = minSoloU + "%";
  var finalminHalftimeU = minHalftimeU + "%";

  var finalnymU = nymU + "%";
  var finalnymSoloU = nymSoloU + "%";
  var finalnymHalftimeU = nymHalftimeU + "%";

  var finalnyyU = nyyU + "%";
  var finalnyySoloU = nyySoloU + "%";
  var finalnyyHalftimeU = nyyHalftimeU + "%";

  var finaloakU = oakU + "%";
  var finaloakSoloU = oakSoloU + "%";
  var finaloakHalftimeU = oakHalftimeU + "%";

  var finalphiU = phiU + "%";
  var finalphiSoloU = phiSoloU + "%";
  var finalphiHalftimeU = phiHalftimeU + "%";

  var finalpitU = pitU + "%";
  var finalpitSoloU = pitSoloU + "%";
  var finalpitHalftimeU = pitHalftimeU + "%";

  var finalsdU = sdU + "%";
  var finalsdSoloU = sdSoloU + "%";
  var finalsdHalftimeU = sdHalftimeU + "%";

  var finalsfU = sfU + "%";
  var finalsfSoloU = sfSoloU + "%";
  var finalsfHalftimeU = sfHalftimeU + "%";

  var finalseaU = seaU + "%";
  var finalseaSoloU = seaSoloU + "%";
  var finalseaHalftimeU = seaHalftimeU + "%";

  var finalstlU = stlU + "%";
  var finalstlSoloU = stlSoloU + "%";
  var finalstlHalftimeU = stlHalftimeU + "%";

  var finaltbU = tbU + "%";
  var finaltbSoloU = tbSoloU + "%";
  var finaltbHalftimeU = tbHalftimeU + "%";

  var finaltexU = texU + "%";
  var finaltexSoloU = texSoloU + "%";
  var finaltexHalftimeU = texHalftimeU + "%";

  var finaltorU = torU + "%";
  var finaltorSoloU = torSoloU + "%";
  var finaltorHalftimeU = torHalftimeU + "%";

  var finalwasU = wasU + "%";
  var finalwasSoloU = wasSoloU + "%";
  var finalwasHalftimeU = wasHalftimeU + "%";

  // Team stats in order by team index & stat index
  var statLists = new Array(10)
  statLists["SuperRL"] = [ariSuperRL, atlSuperRL, balSuperRL, bosSuperRL,chcSuperRL, cwsSuperRL, cinSuperRL, cleSuperRL, colSuperRL, detSuperRL, miaSuperRL, houSuperRL, kanSuperRL, laaSuperRL, ladSuperRL, milSuperRL, minSuperRL, nymSuperRL, nyySuperRL, oakSuperRL, phiSuperRL, pitSuperRL, sdSuperRL, sfSuperRL, seaSuperRL, stlSuperRL, tbSuperRL, texSuperRL, torSuperRL, wasSuperRL]
  statLists["RL"] = [ariRL, atlRL, balRL, bosRL,chcRL, cwsRL, cinRL, cleRL, colRL, detRL, miaRL, houRL, kanRL, laaRL, ladRL, milRL, minRL, nymRL, nyyRL, oakRL, phiRL, pitRL, sdRL, sfRL, seaRL, stlRL, tbRL, texRL, torRL, wasRL]
  statLists["ML"] = [ariML, atlML, balML, bosML,chcML, cwsML, cinML, cleML, colML, detML, miaML, houML, kanML, laaML, ladML, milML, minML, nymML, nyyML, oakML, phiML, pitML, sdML, sfML, seaML, stlML, tbML, texML, torML, wasML]
  statLists["Over"] = [ariO, atlO, balO, bosO,chcO, cwsO, cinO, cleO, colO, detO, miaO, houO, kanO, laaO, ladO, milO, minO, nymO, nyyO, oakO, phiO, pitO, sdO, sfO, seaO, stlO, tbO, texO, torO, wasO]
  statLists["Under"] = [finalariU,finalatlU,finalbalU,finalbosU,finalchcU,finalcwsU,finalcinU,finalcleU,finalcolU,finaldetU,finalmiaU,finalhouU,finalkanU,finallaaU,finalladU,finalmilU,finalminU,finalnymU,finalnyyU,finaloakU,finalphiU,finalpitU,finalsdU,finalsfU,finalseaU,finalstlU,finaltbU,finaltexU,finaltorU,finalwasU]
  statLists["Solo Over"] = [ariSoloO, atlSoloO, balSoloO, bosSoloO,chcSoloO, cwsSoloO, cinSoloO, cleSoloO, colSoloO, detSoloO, miaSoloO, houSoloO, kanSoloO, laaSoloO, ladSoloO, milSoloO, minSoloO, nymSoloO, nyySoloO, oakSoloO, phiSoloO, pitSoloO, sdSoloO, sfSoloO, seaSoloO, stlSoloO, tbSoloO, texSoloO, torSoloO, wasSoloO]
  statLists["Solo Under"] = [finalariSoloU, finalatlSoloU, finalbalSoloU, finalbosSoloU, finalchcSoloU,finalcwsSoloU,finalcinSoloU,finalcleSoloU,finalcolSoloU,finaldetSoloU,finalmiaSoloU,finalhouSoloU,finalkanSoloU,finallaaSoloU,finalladSoloU,finalmilSoloU,finalminSoloU,finalnymSoloU,finalnyySoloU,finaloakSoloU,finalphiSoloU,finalpitSoloU,finalsdSoloU,finalsfSoloU,finalseaSoloU,finalstlSoloU,finaltbSoloU,finaltexSoloU,finaltorSoloU,finalwasSoloU]
  statLists["1st Inning %"] = [ariFirstInning, atlFirstInning, balFirstInning, bosFirstInning,chcFirstInning, cwsFirstInning, cinFirstInning, cleFirstInning, colFirstInning, detFirstInning, miaFirstInning, houFirstInning, kanFirstInning, laaFirstInning, ladFirstInning, milFirstInning, minFirstInning, nymFirstInning, nyyFirstInning, oakFirstInning, phiFirstInning, pitFirstInning, sdFirstInning, sfFirstInning, seaFirstInning, stlFirstInning, tbFirstInning, texFirstInning, torFirstInning, wasFirstInning]
  statLists["Halftime Cover"] = [ariHalftime, atlHalftime, balHalftime, bosHalftime,chcHalftime, cwsHalftime, cinHalftime, cleHalftime, colHalftime, detHalftime, miaHalftime, houHalftime, kanHalftime, laaHalftime, ladHalftime, milHalftime, minHalftime, nymHalftime, nyyHalftime, oakHalftime, phiHalftime, pitHalftime, sdHalftime, sfHalftime, seaHalftime, stlHalftime, tbHalftime, texHalftime, torHalftime, wasHalftime]
  statLists["Halftime Over"] = [ariHalftimeO, atlHalftimeO, balHalftimeO, bosHalftimeO,chcHalftimeO, cwsHalftimeO, cinHalftimeO, cleHalftimeO, colHalftimeO, detHalftimeO, miaHalftimeO, houHalftimeO, kanHalftimeO, laaHalftimeO, ladHalftimeO, milHalftimeO, minHalftimeO, nymHalftimeO, nyyHalftimeO, oakHalftimeO, phiHalftimeO, pitHalftimeO, sdHalftimeO, sfHalftimeO, seaHalftimeO, stlHalftimeO, tbHalftimeO, texHalftimeO, torHalftimeO, wasHalftimeO]
  statLists["Halftime Under"] = [finalariHalftimeU, finalatlHalftimeU, finalbalHalftimeU, finalbosHalftimeU, finalchcHalftimeU, finalcwsHalftimeU, finalcinHalftimeU, finalcleHalftimeU, finalcolHalftimeU, finaldetHalftimeU, finalmiaHalftimeU, finalhouHalftimeU, finalkanHalftimeU, finallaaHalftimeU, finalladHalftimeU, finalmilHalftimeU, finalminHalftimeU, finalnymHalftimeU, finalnyyHalftimeU, finaloakHalftimeU, finalphiHalftimeU, finalpitHalftimeU, finalsdHalftimeU, finalsfHalftimeU, finalseaHalftimeU, finalstlHalftimeU, finaltbHalftimeU, finaltexHalftimeU, finaltorHalftimeU, finalwasHalftimeU]

  // Stat index clicked by user is logged
  var statIndex = selectObj.selectedIndex;

  // Value of stat index is logged
  var statValue = selectObj.options[statIndex].value;

  // Actual number is retrieved from statList
  stat = statLists[statValue]

  // Remove extra characters extracted from back-end
  finalstat = stat[index - 1]

  finalstat = finalstat.replace(/[',()]/g, "");


  // HTML Element that has stat % passed through to front-end user

if (finalstat.includes("%")) {

  document.getElementById("stat").innerHTML = "This happens " + finalstat + " of the time";
  document.getElementById("stat").style.opacity = "1";

} else {

  document.getElementById("stat").innerHTML = "This happens " + finalstat + "% of the time";
  document.getElementById("stat").style.opacity = "1";
}
}
$(document).ready(function() {
    $('.Dropdown').select2({
      width: 'resolve',
});
});

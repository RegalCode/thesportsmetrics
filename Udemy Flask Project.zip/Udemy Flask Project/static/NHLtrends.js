//<![CDATA[
// array of possible teams in the same order as they appear in the team selection list
var teamLists = new Array(31)
teamLists["empty"] = ["Select a Stat"];
teamLists["Anaheim Ducks"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1Q Cover", "1Q Over", "1Q Under", "2Q Cover", "2Q Over", "2Q Under", "3Q Cover", "3Q Over", "3Q Under"];
teamLists["Arizona Coyotes"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1Q Cover", "1Q Over", "1Q Under", "2Q Cover", "2Q Over", "2Q Under", "3Q Cover", "3Q Over", "3Q Under"];
teamLists["Boston Bruins"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1Q Cover", "1Q Over", "1Q Under", "2Q Cover", "2Q Over", "2Q Under", "3Q Cover", "3Q Over", "3Q Under"];
teamLists["Buffalo Sabres"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1Q Cover", "1Q Over", "1Q Under", "2Q Cover", "2Q Over", "2Q Under", "3Q Cover", "3Q Over", "3Q Under"];
teamLists["Calgary Flames"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1Q Cover", "1Q Over", "1Q Under", "2Q Cover", "2Q Over", "2Q Under", "3Q Cover", "3Q Over", "3Q Under"];
teamLists["Carolina Hurricanes"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1Q Cover", "1Q Over", "1Q Under", "2Q Cover", "2Q Over", "2Q Under", "3Q Cover", "3Q Over", "3Q Under"];
teamLists["Chicago Blackhawks"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1Q Cover", "1Q Over", "1Q Under", "2Q Cover", "2Q Over", "2Q Under", "3Q Cover", "3Q Over", "3Q Under"];
teamLists["Colorado Avalanche"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1Q Cover", "1Q Over", "1Q Under", "2Q Cover", "2Q Over", "2Q Under", "3Q Cover", "3Q Over", "3Q Under"];
teamLists["Columbus Blue Jackets"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1Q Cover", "1Q Over", "1Q Under", "2Q Cover", "2Q Over", "2Q Under", "3Q Cover", "3Q Over", "3Q Under"];
teamLists["Dallas Stars"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1Q Cover", "1Q Over", "1Q Under", "2Q Cover", "2Q Over", "2Q Under", "3Q Cover", "3Q Over", "3Q Under"];
teamLists["Detroit Red Wings"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1Q Cover", "1Q Over", "1Q Under", "2Q Cover", "2Q Over", "2Q Under", "3Q Cover", "3Q Over", "3Q Under"];
teamLists["Edmonton Oilers"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1Q Cover", "1Q Over", "1Q Under", "2Q Cover", "2Q Over", "2Q Under", "3Q Cover", "3Q Over", "3Q Under"];
teamLists["Florida Panthers"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1Q Cover", "1Q Over", "1Q Under", "2Q Cover", "2Q Over", "2Q Under", "3Q Cover", "3Q Over", "3Q Under"];
teamLists["Los Angeles Kings"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1Q Cover", "1Q Over", "1Q Under", "2Q Cover", "2Q Over", "2Q Under", "3Q Cover", "3Q Over", "3Q Under"];
teamLists["Minnesota Wild"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1Q Cover", "1Q Over", "1Q Under", "2Q Cover", "2Q Over", "2Q Under", "3Q Cover", "3Q Over", "3Q Under"];
teamLists["Montreal Canadiens"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1Q Cover", "1Q Over", "1Q Under", "2Q Cover", "2Q Over", "2Q Under", "3Q Cover", "3Q Over", "3Q Under"];
teamLists["Nashville Predators"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1Q Cover", "1Q Over", "1Q Under", "2Q Cover", "2Q Over", "2Q Under", "3Q Cover", "3Q Over", "3Q Under"];
teamLists["New Jersey Devils"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1Q Cover", "1Q Over", "1Q Under", "2Q Cover", "2Q Over", "2Q Under", "3Q Cover", "3Q Over", "3Q Under"];
teamLists["New York Islanders"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1Q Cover", "1Q Over", "1Q Under", "2Q Cover", "2Q Over", "2Q Under", "3Q Cover", "3Q Over", "3Q Under"];
teamLists["New York Rangers"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1Q Cover", "1Q Over", "1Q Under", "2Q Cover", "2Q Over", "2Q Under", "3Q Cover", "3Q Over", "3Q Under"];
teamLists["Ottawa Senators"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1Q Cover", "1Q Over", "1Q Under", "2Q Cover", "2Q Over", "2Q Under", "3Q Cover", "3Q Over", "3Q Under"];
teamLists["Philadelphia Flyers"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1Q Cover", "1Q Over", "1Q Under", "2Q Cover", "2Q Over", "2Q Under", "3Q Cover", "3Q Over", "3Q Under"];
teamLists["Pittsburgh Penguins"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1Q Cover", "1Q Over", "1Q Under", "2Q Cover", "2Q Over", "2Q Under", "3Q Cover", "3Q Over", "3Q Under"];
teamLists["San Jose Sharks"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1Q Cover", "1Q Over", "1Q Under", "2Q Cover", "2Q Over", "2Q Under", "3Q Cover", "3Q Over", "3Q Under"];
teamLists["St. Louis Blues"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1Q Cover", "1Q Over", "1Q Under", "2Q Cover", "2Q Over", "2Q Under", "3Q Cover", "3Q Over", "3Q Under"];
teamLists["Tampa Bay Lightning"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1Q Cover", "1Q Over", "1Q Under", "2Q Cover", "2Q Over", "2Q Under", "3Q Cover", "3Q Over", "3Q Under"];
teamLists["Toronto Maple Leafs"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1Q Cover", "1Q Over", "1Q Under", "2Q Cover", "2Q Over", "2Q Under", "3Q Cover", "3Q Over", "3Q Under"];
teamLists["Vancouver Canucks"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1Q Cover", "1Q Over", "1Q Under", "2Q Cover", "2Q Over", "2Q Under", "3Q Cover", "3Q Over", "3Q Under"];
teamLists["Vegas Golden Knights"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1Q Cover", "1Q Over", "1Q Under", "2Q Cover", "2Q Over", "2Q Under", "3Q Cover", "3Q Over", "3Q Under"];
teamLists["Washington Capitals"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1Q Cover", "1Q Over", "1Q Under", "2Q Cover", "2Q Over", "2Q Under", "3Q Cover", "3Q Over", "3Q Under"];
teamLists["Winnipeg Jets"] = ["Select a Stat", "SuperRL", "RL", "ML", "Over", "Under", "Solo Over", "Solo Under", "1Q Cover", "1Q Over", "1Q Under", "2Q Cover", "2Q Over", "2Q Under", "3Q Cover", "3Q Over", "3Q Under"];
/* teamChange() is called from the onchange event of a select element.
* param selectObj - the select object which fired the on change event.
*/

function teamChange(selectObj) {
// get the index of the selected option
  index = selectObj.selectedIndex;
// get the value of the selected option
var which = selectObj.options[index].value;
// use the selected option value to retrieve the list of items from the countryLists array
tList = teamLists[which];
// get the country select element via its known id
var tSelect = document.getElementById("stat-change");
// remove the current options from the country select
var len = tSelect.options.length;

while (tSelect.options.length > 0) {
tSelect.remove(0);
}
var newOption;
// create new options
for (var i=0; i<tList.length; i++) {
newOption = document.createElement("option");
newOption.value = tList[i];  // assumes option string and value are the same
newOption.text=tList[i];
// add the new option
try {
tSelect.add(newOption);  // this will fail in DOM browsers but is needed for IE
}
catch (e) {
tSelect.appendChild(newOption);
}
}
}

function statChange(selectObj) {

  var anaSuperRL = document.getElementById('ANASuperRL').innerHTML;
  var anaRL = document.getElementById('ANARL').innerHTML;
  var anaML = document.getElementById("ANAML").innerHTML;
  var anaO = document.getElementById("ANAO").innerHTML;
  var anaO = anaO.replace(/[',()]/g, "");
  var anaSoloO = document.getElementById("ANASoloO").innerHTML;
  var anaSoloO = anaSoloO.replace(/[',()]/g, "");
  var ana1Q = document.getElementById("ANA1Q").innerHTML;
  var ana1QO = document.getElementById("ANA1QO").innerHTML;
  var ana1QO = ana1QO.replace(/[',()]/g, "");
  var ana2Q = document.getElementById("ANA2Q").innerHTML;
  var ana2QO = document.getElementById("ANA2QO").innerHTML;
  var ana2QO = ana2Q.replace(/[',()]/g, "");
  var ana3Q = document.getElementById("ANA3Q").innerHTML;
  var ana3QO = document.getElementById("ANA3QO").innerHTML;
  var ana3QO = ana3QO.replace(/[',()]/g, "");

  var ariSuperRL = document.getElementById('ARISuperRL').innerHTML;
  var ariRL = document.getElementById('ARIRL').innerHTML;
  var ariML = document.getElementById("ARIML").innerHTML;
  var ariO = document.getElementById("ARIO").innerHTML;
  var ariO = ariO.replace(/[',()]/g, "");
  var ariSoloO = document.getElementById("ARISoloO").innerHTML;
  var ariSoloO = ariSoloO.replace(/[',()]/g, "");
  var ari1Q = document.getElementById("ARI1Q").innerHTML;
  var ari1QO = document.getElementById("ARI1QO").innerHTML;
  var ari1QO = ari1QO.replace(/[',()]/g, "");
  var ari2Q = document.getElementById("ARI2Q").innerHTML;
  var ari2QO = document.getElementById("ARI2QO").innerHTML;
  var ari2QO = ari2Q.replace(/[',()]/g, "");
  var ari3Q = document.getElementById("ARI3Q").innerHTML;
  var ari3QO = document.getElementById("ARI3QO").innerHTML;
  var ari3QO = ari3QO.replace(/[',()]/g, "");

  var bosSuperRL = document.getElementById('BOSSuperRL').innerHTML;
  var bosRL = document.getElementById('BOSRL').innerHTML;
  var bosML = document.getElementById("BOSML").innerHTML;
  var bosO = document.getElementById("BOSO").innerHTML;
  var bosO = bosO.replace(/[',()]/g, "");
  var bosSoloO = document.getElementById("BOSSoloO").innerHTML;
  var bosSoloO = bosSoloO.replace(/[',()]/g, "");
  var bos1Q = document.getElementById("BOS1Q").innerHTML;
  var bos1QO = document.getElementById("BOS1QO").innerHTML;
  var bos1QO = bos1QO.replace(/[',()]/g, "");
  var bos2Q = document.getElementById("BOS2Q").innerHTML;
  var bos2QO = document.getElementById("BOS2QO").innerHTML;
  var bos2QO = bos2Q.replace(/[',()]/g, "");
  var bos3Q = document.getElementById("BOS3Q").innerHTML;
  var bos3QO = document.getElementById("BOS3QO").innerHTML;
  var bos3QO = bos3QO.replace(/[',()]/g, "");

  var bufSuperRL = document.getElementById('BUFSuperRL').innerHTML;
  var bufRL = document.getElementById('BUFRL').innerHTML;
  var bufML = document.getElementById("BUFML").innerHTML;
  var bufO = document.getElementById("BUFO").innerHTML;
  var bufO = bufO.replace(/[',()]/g, "");
  var bufSoloO = document.getElementById("BUFSoloO").innerHTML;
  var bufSoloO = bufSoloO.replace(/[',()]/g, "");
  var buf1Q = document.getElementById("BUF1Q").innerHTML;
  var buf1QO = document.getElementById("BUF1QO").innerHTML;
  var buf1QO = buf1QO.replace(/[',()]/g, "");
  var buf2Q = document.getElementById("BUF2Q").innerHTML;
  var buf2QO = document.getElementById("BUF2QO").innerHTML;
  var buf2QO = buf2Q.replace(/[',()]/g, "");
  var buf3Q = document.getElementById("BUF3Q").innerHTML;
  var buf3QO = document.getElementById("BUF3QO").innerHTML;
  var buf3QO = buf3QO.replace(/[',()]/g, "");

  var cgySuperRL = document.getElementById('CGYSuperRL').innerHTML;
  var cgyRL = document.getElementById('CGYRL').innerHTML;
  var cgyML = document.getElementById("CGYML").innerHTML;
  var cgyO = document.getElementById("CGYO").innerHTML;
  var cgyO = cgyO.replace(/[',()]/g, "");
  var cgySoloO = document.getElementById("CGYSoloO").innerHTML;
  var cgySoloO = cgySoloO.replace(/[',()]/g, "");
  var cgy1Q = document.getElementById("CGY1Q").innerHTML;
  var cgy1QO = document.getElementById("CGY1QO").innerHTML;
  var cgy1QO = cgy1QO.replace(/[',()]/g, "");
  var cgy2Q = document.getElementById("CGY2Q").innerHTML;
  var cgy2QO = document.getElementById("CGY2QO").innerHTML;
  var cgy2QO = cgy2Q.replace(/[',()]/g, "");
  var cgy3Q = document.getElementById("CGY3Q").innerHTML;
  var cgy3QO = document.getElementById("CGY3QO").innerHTML;
  var cgy3QO = cgy3QO.replace(/[',()]/g, "");

  var carSuperRL = document.getElementById('CARSuperRL').innerHTML;
  var carRL = document.getElementById('CARRL').innerHTML;
  var carML = document.getElementById("CARML").innerHTML;
  var carO = document.getElementById("CARO").innerHTML;
  var carO = carO.replace(/[',()]/g, "");
  var carSoloO = document.getElementById("CARSoloO").innerHTML;
  var carSoloO = carSoloO.replace(/[',()]/g, "");
  var car1Q = document.getElementById("CAR1Q").innerHTML;
  var car1QO = document.getElementById("CAR1QO").innerHTML;
  var car1QO = car1QO.replace(/[',()]/g, "");
  var car2Q = document.getElementById("CAR2Q").innerHTML;
  var car2QO = document.getElementById("CAR2QO").innerHTML;
  var car2QO = car2Q.replace(/[',()]/g, "");
  var car3Q = document.getElementById("CAR3Q").innerHTML;
  var car3QO = document.getElementById("CAR3QO").innerHTML;
  var car3QO = car3QO.replace(/[',()]/g, "");

  var chiSuperRL = document.getElementById('CHISuperRL').innerHTML;
  var chiRL = document.getElementById('CHIRL').innerHTML;
  var chiML = document.getElementById("CHIML").innerHTML;
  var chiO = document.getElementById("CHIO").innerHTML;
  var chiO = chiO.replace(/[',()]/g, "");
  var chiSoloO = document.getElementById("CHISoloO").innerHTML;
  var chiSoloO = chiSoloO.replace(/[',()]/g, "");
  var chi1Q = document.getElementById("CHI1Q").innerHTML;
  var chi1QO = document.getElementById("CHI1QO").innerHTML;
  var chi1QO = chi1QO.replace(/[',()]/g, "");
  var chi2Q = document.getElementById("CHI2Q").innerHTML;
  var chi2QO = document.getElementById("CHI2QO").innerHTML;
  var chi2QO = chi2Q.replace(/[',()]/g, "");
  var chi3Q = document.getElementById("CHI3Q").innerHTML;
  var chi3QO = document.getElementById("CHI3QO").innerHTML;
  var chi3QO = chi3QO.replace(/[',()]/g, "");

  var colSuperRL = document.getElementById('COLSuperRL').innerHTML;
  var colRL = document.getElementById('COLRL').innerHTML;
  var colML = document.getElementById("COLML").innerHTML;
  var colO = document.getElementById("COLO").innerHTML;
  var colO = colO.replace(/[',()]/g, "");
  var colSoloO = document.getElementById("COLSoloO").innerHTML;
  var colSoloO = colSoloO.replace(/[',()]/g, "");
  var col1Q = document.getElementById("COL1Q").innerHTML;
  var col1QO = document.getElementById("COL1QO").innerHTML;
  var col1QO = col1QO.replace(/[',()]/g, "");
  var col2Q = document.getElementById("COL2Q").innerHTML;
  var col2QO = document.getElementById("COL2QO").innerHTML;
  var col2QO = col2Q.replace(/[',()]/g, "");
  var col3Q = document.getElementById("COL3Q").innerHTML;
  var col3QO = document.getElementById("COL3QO").innerHTML;
  var col3QO = col3QO.replace(/[',()]/g, "");

  var cbjSuperRL = document.getElementById('CBJSuperRL').innerHTML;
  var cbjRL = document.getElementById('CBJRL').innerHTML;
  var cbjML = document.getElementById("CBJML").innerHTML;
  var cbjO = document.getElementById("CBJO").innerHTML;
  var cbjO = cbjO.replace(/[',()]/g, "");
  var cbjSoloO = document.getElementById("CBJSoloO").innerHTML;
  var cbjSoloO = cbjSoloO.replace(/[',()]/g, "");
  var cbj1Q = document.getElementById("CBJ1Q").innerHTML;
  var cbj1QO = document.getElementById("CBJ1QO").innerHTML;
  var cbj1QO = cbj1QO.replace(/[',()]/g, "");
  var cbj2Q = document.getElementById("CBJ2Q").innerHTML;
  var cbj2QO = document.getElementById("CBJ2QO").innerHTML;
  var cbj2QO = cbj2Q.replace(/[',()]/g, "");
  var cbj3Q = document.getElementById("CBJ3Q").innerHTML;
  var cbj3QO = document.getElementById("CBJ3QO").innerHTML;
  var cbj3QO = cbj3QO.replace(/[',()]/g, "");

  var dalSuperRL = document.getElementById('DALSuperRL').innerHTML;
  var dalRL = document.getElementById('DALRL').innerHTML;
  var dalML = document.getElementById("DALML").innerHTML;
  var dalO = document.getElementById("DALO").innerHTML;
  var dalO = dalO.replace(/[',()]/g, "");
  var dalSoloO = document.getElementById("DALSoloO").innerHTML;
  var dalSoloO = dalSoloO.replace(/[',()]/g, "");
  var dal1Q = document.getElementById("DAL1Q").innerHTML;
  var dal1QO = document.getElementById("DAL1QO").innerHTML;
  var dal1QO = dal1QO.replace(/[',()]/g, "");
  var dal2Q = document.getElementById("DAL2Q").innerHTML;
  var dal2QO = document.getElementById("DAL2QO").innerHTML;
  var dal2QO = dal2Q.replace(/[',()]/g, "");
  var dal3Q = document.getElementById("DAL3Q").innerHTML;
  var dal3QO = document.getElementById("DAL3QO").innerHTML;
  var dal3QO = dal3QO.replace(/[',()]/g, "");

  var detSuperRL = document.getElementById('DETSuperRL').innerHTML;
  var detRL = document.getElementById('DETRL').innerHTML;
  var detML = document.getElementById("DETML").innerHTML;
  var detO = document.getElementById("DETO").innerHTML;
  var detO = detO.replace(/[',()]/g, "");
  var detSoloO = document.getElementById("DETSoloO").innerHTML;
  var detSoloO = detSoloO.replace(/[',()]/g, "");
  var det1Q = document.getElementById("DET1Q").innerHTML;
  var det1QO = document.getElementById("DET1QO").innerHTML;
  var det1QO = det1QO.replace(/[',()]/g, "");
  var det2Q = document.getElementById("DET2Q").innerHTML;
  var det2QO = document.getElementById("DET2QO").innerHTML;
  var det2QO = det2Q.replace(/[',()]/g, "");
  var det3Q = document.getElementById("DET3Q").innerHTML;
  var det3QO = document.getElementById("DET3QO").innerHTML;
  var det3QO = det3QO.replace(/[',()]/g, "");

  var edmSuperRL = document.getElementById('EDMSuperRL').innerHTML;
  var edmRL = document.getElementById('EDMRL').innerHTML;
  var edmML = document.getElementById("EDMML").innerHTML;
  var edmO = document.getElementById("EDMO").innerHTML;
  var edmO = edmO.replace(/[',()]/g, "");
  var edmSoloO = document.getElementById("EDMSoloO").innerHTML;
  var edmSoloO = edmSoloO.replace(/[',()]/g, "");
  var edm1Q = document.getElementById("EDM1Q").innerHTML;
  var edm1QO = document.getElementById("EDM1QO").innerHTML;
  var edm1QO = edm1QO.replace(/[',()]/g, "");
  var edm2Q = document.getElementById("EDM2Q").innerHTML;
  var edm2QO = document.getElementById("EDM2QO").innerHTML;
  var edm2QO = edm2Q.replace(/[',()]/g, "");
  var edm3Q = document.getElementById("EDM3Q").innerHTML;
  var edm3QO = document.getElementById("EDM3QO").innerHTML;
  var edm3QO = edm3QO.replace(/[',()]/g, "");

  var flaSuperRL = document.getElementById('FLASuperRL').innerHTML;
  var flaRL = document.getElementById('FLARL').innerHTML;
  var flaML = document.getElementById("FLAML").innerHTML;
  var flaO = document.getElementById("FLAO").innerHTML;
  var flaO = flaO.replace(/[',()]/g, "");
  var flaSoloO = document.getElementById("FLASoloO").innerHTML;
  var flaSoloO = flaSoloO.replace(/[',()]/g, "");
  var fla1Q = document.getElementById("FLA1Q").innerHTML;
  var fla1QO = document.getElementById("FLA1QO").innerHTML;
  var fla1QO = fla1QO.replace(/[',()]/g, "");
  var fla2Q = document.getElementById("FLA2Q").innerHTML;
  var fla2QO = document.getElementById("FLA2QO").innerHTML;
  var fla2QO = fla2Q.replace(/[',()]/g, "");
  var fla3Q = document.getElementById("FLA3Q").innerHTML;
  var fla3QO = document.getElementById("FLA3QO").innerHTML;
  var fla3QO = fla3QO.replace(/[',()]/g, "");

  var lakSuperRL = document.getElementById('LAKSuperRL').innerHTML;
  var lakRL = document.getElementById('LAKRL').innerHTML;
  var lakML = document.getElementById("LAKML").innerHTML;
  var lakO = document.getElementById("LAKO").innerHTML;
  var lakO = lakO.replace(/[',()]/g, "");
  var lakSoloO = document.getElementById("LAKSoloO").innerHTML;
  var lakSoloO = lakSoloO.replace(/[',()]/g, "");
  var lak1Q = document.getElementById("LAK1Q").innerHTML;
  var lak1QO = document.getElementById("LAK1QO").innerHTML;
  var lak1QO = lak1QO.replace(/[',()]/g, "");
  var lak2Q = document.getElementById("LAK2Q").innerHTML;
  var lak2QO = document.getElementById("LAK2QO").innerHTML;
  var lak2QO = lak2Q.replace(/[',()]/g, "");
  var lak3Q = document.getElementById("LAK3Q").innerHTML;
  var lak3QO = document.getElementById("LAK3QO").innerHTML;
  var lak3QO = lak3QO.replace(/[',()]/g, "");

  var minSuperRL = document.getElementById('MINSuperRL').innerHTML;
  var minRL = document.getElementById('MINRL').innerHTML;
  var minML = document.getElementById("MINML").innerHTML;
  var minO = document.getElementById("MINO").innerHTML;
  var minO = minO.replace(/[',()]/g, "");
  var minSoloO = document.getElementById("MINSoloO").innerHTML;
  var minSoloO = minSoloO.replace(/[',()]/g, "");
  var min1Q = document.getElementById("MIN1Q").innerHTML;
  var min1QO = document.getElementById("MIN1QO").innerHTML;
  var min1QO = min1QO.replace(/[',()]/g, "");
  var min2Q = document.getElementById("MIN2Q").innerHTML;
  var min2QO = document.getElementById("MIN2QO").innerHTML;
  var min2QO = min2Q.replace(/[',()]/g, "");
  var min3Q = document.getElementById("MIN3Q").innerHTML;
  var min3QO = document.getElementById("MIN3QO").innerHTML;
  var min3QO = min3QO.replace(/[',()]/g, "");

  var mtlSuperRL = document.getElementById('MTLSuperRL').innerHTML;
  var mtlRL = document.getElementById('MTLRL').innerHTML;
  var mtlML = document.getElementById("MTLML").innerHTML;
  var mtlO = document.getElementById("MTLO").innerHTML;
  var mtlO = mtlO.replace(/[',()]/g, "");
  var mtlSoloO = document.getElementById("MTLSoloO").innerHTML;
  var mtlSoloO = mtlSoloO.replace(/[',()]/g, "");
  var mtl1Q = document.getElementById("MTL1Q").innerHTML;
  var mtl1QO = document.getElementById("MTL1QO").innerHTML;
  var mtl1QO = mtl1QO.replace(/[',()]/g, "");
  var mtl2Q = document.getElementById("MTL2Q").innerHTML;
  var mtl2QO = document.getElementById("MTL2QO").innerHTML;
  var mtl2QO = mtl2Q.replace(/[',()]/g, "");
  var mtl3Q = document.getElementById("MTL3Q").innerHTML;
  var mtl3QO = document.getElementById("MTL3QO").innerHTML;
  var mtl3QO = mtl3QO.replace(/[',()]/g, "");

  var nshSuperRL = document.getElementById('NSHSuperRL').innerHTML;
  var nshRL = document.getElementById('NSHRL').innerHTML;
  var nshML = document.getElementById("NSHML").innerHTML;
  var nshO = document.getElementById("NSHO").innerHTML;
  var nshO = nshO.replace(/[',()]/g, "");
  var nshSoloO = document.getElementById("NSHSoloO").innerHTML;
  var nshSoloO = nshSoloO.replace(/[',()]/g, "");
  var nsh1Q = document.getElementById("NSH1Q").innerHTML;
  var nsh1QO = document.getElementById("NSH1QO").innerHTML;
  var nsh1QO = nsh1QO.replace(/[',()]/g, "");
  var nsh2Q = document.getElementById("NSH2Q").innerHTML;
  var nsh2QO = document.getElementById("NSH2QO").innerHTML;
  var nsh2QO = nsh2Q.replace(/[',()]/g, "");
  var nsh3Q = document.getElementById("NSH3Q").innerHTML;
  var nsh3QO = document.getElementById("NSH3QO").innerHTML;
  var nsh3QO = nsh3QO.replace(/[',()]/g, "");

  var njdSuperRL = document.getElementById('NJDSuperRL').innerHTML;
  var njdRL = document.getElementById('NJDRL').innerHTML;
  var njdML = document.getElementById("NJDML").innerHTML;
  var njdO = document.getElementById("NJDO").innerHTML;
  var njdO = njdO.replace(/[',()]/g, "");
  var njdSoloO = document.getElementById("NJDSoloO").innerHTML;
  var njdSoloO = njdSoloO.replace(/[',()]/g, "");
  var njd1Q = document.getElementById("NJD1Q").innerHTML;
  var njd1QO = document.getElementById("NJD1QO").innerHTML;
  var njd1QO = njd1QO.replace(/[',()]/g, "");
  var njd2Q = document.getElementById("NJD2Q").innerHTML;
  var njd2QO = document.getElementById("NJD2QO").innerHTML;
  var njd2QO = njd2Q.replace(/[',()]/g, "");
  var njd3Q = document.getElementById("NJD3Q").innerHTML;
  var njd3QO = document.getElementById("NJD3QO").innerHTML;
  var njd3QO = njd3QO.replace(/[',()]/g, "");

  var nyiSuperRL = document.getElementById('NYISuperRL').innerHTML;
  var nyiRL = document.getElementById('NYIRL').innerHTML;
  var nyiML = document.getElementById("NYIML").innerHTML;
  var nyiO = document.getElementById("NYIO").innerHTML;
  var nyiO = nyiO.replace(/[',()]/g, "");
  var nyiSoloO = document.getElementById("NYISoloO").innerHTML;
  var nyiSoloO = nyiSoloO.replace(/[',()]/g, "");
  var nyi1Q = document.getElementById("NYI1Q").innerHTML;
  var nyi1QO = document.getElementById("NYI1QO").innerHTML;
  var nyi1QO = nyi1QO.replace(/[',()]/g, "");
  var nyi2Q = document.getElementById("NYI2Q").innerHTML;
  var nyi2QO = document.getElementById("NYI2QO").innerHTML;
  var nyi2QO = nyi2Q.replace(/[',()]/g, "");
  var nyi3Q = document.getElementById("NYI3Q").innerHTML;
  var nyi3QO = document.getElementById("NYI3QO").innerHTML;
  var nyi3QO = nyi3QO.replace(/[',()]/g, "");

  var nyrSuperRL = document.getElementById('NYRSuperRL').innerHTML;
  var nyrRL = document.getElementById('NYRRL').innerHTML;
  var nyrML = document.getElementById("NYRML").innerHTML;
  var nyrO = document.getElementById("NYRO").innerHTML;
  var nyrO = nyrO.replace(/[',()]/g, "");
  var nyrSoloO = document.getElementById("NYRSoloO").innerHTML;
  var nyrSoloO = nyrSoloO.replace(/[',()]/g, "");
  var nyr1Q = document.getElementById("NYR1Q").innerHTML;
  var nyr1QO = document.getElementById("NYR1QO").innerHTML;
  var nyr1QO = nyr1QO.replace(/[',()]/g, "");
  var nyr2Q = document.getElementById("NYR2Q").innerHTML;
  var nyr2QO = document.getElementById("NYR2QO").innerHTML;
  var nyr2QO = nyr2Q.replace(/[',()]/g, "");
  var nyr3Q = document.getElementById("NYR3Q").innerHTML;
  var nyr3QO = document.getElementById("NYR3QO").innerHTML;
  var nyr3QO = nyr3QO.replace(/[',()]/g, "");

  var ottSuperRL = document.getElementById('OTTSuperRL').innerHTML;
  var ottRL = document.getElementById('OTTRL').innerHTML;
  var ottML = document.getElementById("OTTML").innerHTML;
  var ottO = document.getElementById("OTTO").innerHTML;
  var ottO = ottO.replace(/[',()]/g, "");
  var ottSoloO = document.getElementById("OTTSoloO").innerHTML;
  var ottSoloO = ottSoloO.replace(/[',()]/g, "");
  var ott1Q = document.getElementById("OTT1Q").innerHTML;
  var ott1QO = document.getElementById("OTT1QO").innerHTML;
  var ott1QO = ott1QO.replace(/[',()]/g, "");
  var ott2Q = document.getElementById("OTT2Q").innerHTML;
  var ott2QO = document.getElementById("OTT2QO").innerHTML;
  var ott2QO = ott2Q.replace(/[',()]/g, "");
  var ott3Q = document.getElementById("OTT3Q").innerHTML;
  var ott3QO = document.getElementById("OTT3QO").innerHTML;
  var ott3QO = ott3QO.replace(/[',()]/g, "");

  var phiSuperRL = document.getElementById('PHISuperRL').innerHTML;
  var phiRL = document.getElementById('PHIRL').innerHTML;
  var phiML = document.getElementById("PHIML").innerHTML;
  var phiO = document.getElementById("PHIO").innerHTML;
  var phiO = phiO.replace(/[',()]/g, "");
  var phiSoloO = document.getElementById("PHISoloO").innerHTML;
  var phiSoloO = phiSoloO.replace(/[',()]/g, "");
  var phi1Q = document.getElementById("PHI1Q").innerHTML;
  var phi1QO = document.getElementById("PHI1QO").innerHTML;
  var phi1QO = phi1QO.replace(/[',()]/g, "");
  var phi2Q = document.getElementById("PHI2Q").innerHTML;
  var phi2QO = document.getElementById("PHI2QO").innerHTML;
  var phi2QO = phi2Q.replace(/[',()]/g, "");
  var phi3Q = document.getElementById("PHI3Q").innerHTML;
  var phi3QO = document.getElementById("PHI3QO").innerHTML;
  var phi3QO = phi3QO.replace(/[',()]/g, "");

  var pitSuperRL = document.getElementById('PITSuperRL').innerHTML;
  var pitRL = document.getElementById('PITRL').innerHTML;
  var pitML = document.getElementById("PITML").innerHTML;
  var pitO = document.getElementById("PITO").innerHTML;
  var pitO = pitO.replace(/[',()]/g, "");
  var pitSoloO = document.getElementById("PITSoloO").innerHTML;
  var pitSoloO = pitSoloO.replace(/[',()]/g, "");
  var pit1Q = document.getElementById("PIT1Q").innerHTML;
  var pit1QO = document.getElementById("PIT1QO").innerHTML;
  var pit1QO = pit1QO.replace(/[',()]/g, "");
  var pit2Q = document.getElementById("PIT2Q").innerHTML;
  var pit2QO = document.getElementById("PIT2QO").innerHTML;
  var pit2QO = pit2Q.replace(/[',()]/g, "");
  var pit3Q = document.getElementById("PIT3Q").innerHTML;
  var pit3QO = document.getElementById("PIT3QO").innerHTML;
  var pit3QO = pit3QO.replace(/[',()]/g, "");

  var sjsSuperRL = document.getElementById('SJSSuperRL').innerHTML;
  var sjsRL = document.getElementById('SJSRL').innerHTML;
  var sjsML = document.getElementById("SJSML").innerHTML;
  var sjsO = document.getElementById("SJSO").innerHTML;
  var sjsO = sjsO.replace(/[',()]/g, "");
  var sjsSoloO = document.getElementById("SJSSoloO").innerHTML;
  var sjsSoloO = sjsSoloO.replace(/[',()]/g, "");
  var sjs1Q = document.getElementById("SJS1Q").innerHTML;
  var sjs1QO = document.getElementById("SJS1QO").innerHTML;
  var sjs1QO = sjs1QO.replace(/[',()]/g, "");
  var sjs2Q = document.getElementById("SJS2Q").innerHTML;
  var sjs2QO = document.getElementById("SJS2QO").innerHTML;
  var sjs2QO = sjs2Q.replace(/[',()]/g, "");
  var sjs3Q = document.getElementById("SJS3Q").innerHTML;
  var sjs3QO = document.getElementById("SJS3QO").innerHTML;
  var sjs3QO = sjs3QO.replace(/[',()]/g, "");

  var stlSuperRL = document.getElementById('STLSuperRL').innerHTML;
  var stlRL = document.getElementById('STLRL').innerHTML;
  var stlML = document.getElementById("STLML").innerHTML;
  var stlO = document.getElementById("STLO").innerHTML;
  var stlO = stlO.replace(/[',()]/g, "");
  var stlSoloO = document.getElementById("STLSoloO").innerHTML;
  var stlSoloO = stlSoloO.replace(/[',()]/g, "");
  var stl1Q = document.getElementById("STL1Q").innerHTML;
  var stl1QO = document.getElementById("STL1QO").innerHTML;
  var stl1QO = stl1QO.replace(/[',()]/g, "");
  var stl2Q = document.getElementById("STL2Q").innerHTML;
  var stl2QO = document.getElementById("STL2QO").innerHTML;
  var stl2QO = stl2Q.replace(/[',()]/g, "");
  var stl3Q = document.getElementById("STL3Q").innerHTML;
  var stl3QO = document.getElementById("STL3QO").innerHTML;
  var stl3QO = stl3QO.replace(/[',()]/g, "");

  var tblSuperRL = document.getElementById('TBLSuperRL').innerHTML;
  var tblRL = document.getElementById('TBLRL').innerHTML;
  var tblML = document.getElementById("TBLML").innerHTML;
  var tblO = document.getElementById("TBLO").innerHTML;
  var tblO = tblO.replace(/[',()]/g, "");
  var tblSoloO = document.getElementById("TBLSoloO").innerHTML;
  var tblSoloO = tblSoloO.replace(/[',()]/g, "");
  var tbl1Q = document.getElementById("TBL1Q").innerHTML;
  var tbl1QO = document.getElementById("TBL1QO").innerHTML;
  var tbl1QO = tbl1QO.replace(/[',()]/g, "");
  var tbl2Q = document.getElementById("TBL2Q").innerHTML;
  var tbl2QO = document.getElementById("TBL2QO").innerHTML;
  var tbl2QO = tbl2Q.replace(/[',()]/g, "");
  var tbl3Q = document.getElementById("TBL3Q").innerHTML;
  var tbl3QO = document.getElementById("TBL3QO").innerHTML;
  var tbl3QO = tbl3QO.replace(/[',()]/g, "");

  var torSuperRL = document.getElementById('TORSuperRL').innerHTML;
  var torRL = document.getElementById('TORRL').innerHTML;
  var torML = document.getElementById("TORML").innerHTML;
  var torO = document.getElementById("TORO").innerHTML;
  var torO = torO.replace(/[',()]/g, "");
  var torSoloO = document.getElementById("TORSoloO").innerHTML;
  var torSoloO = torSoloO.replace(/[',()]/g, "");
  var tor1Q = document.getElementById("TOR1Q").innerHTML;
  var tor1QO = document.getElementById("TOR1QO").innerHTML;
  var tor1QO = tor1QO.replace(/[',()]/g, "");
  var tor2Q = document.getElementById("TOR2Q").innerHTML;
  var tor2QO = document.getElementById("TOR2QO").innerHTML;
  var tor2QO = tor2Q.replace(/[',()]/g, "");
  var tor3Q = document.getElementById("TOR3Q").innerHTML;
  var tor3QO = document.getElementById("TOR3QO").innerHTML;
  var tor3QO = tor3QO.replace(/[',()]/g, "");

  var vanSuperRL = document.getElementById('VANSuperRL').innerHTML;
  var vanRL = document.getElementById('VANRL').innerHTML;
  var vanML = document.getElementById("VANML").innerHTML;
  var vanO = document.getElementById("VANO").innerHTML;
  var vanO = vanO.replace(/[',()]/g, "");
  var vanSoloO = document.getElementById("VANSoloO").innerHTML;
  var vanSoloO = vanSoloO.replace(/[',()]/g, "");
  var van1Q = document.getElementById("VAN1Q").innerHTML;
  var van1QO = document.getElementById("VAN1QO").innerHTML;
  var van1QO = van1QO.replace(/[',()]/g, "");
  var van2Q = document.getElementById("VAN2Q").innerHTML;
  var van2QO = document.getElementById("VAN2QO").innerHTML;
  var van2QO = van2Q.replace(/[',()]/g, "");
  var van3Q = document.getElementById("VAN3Q").innerHTML;
  var van3QO = document.getElementById("VAN3QO").innerHTML;
  var van3QO = van3QO.replace(/[',()]/g, "");

  var vgkSuperRL = document.getElementById('VGKSuperRL').innerHTML;
  var vgkRL = document.getElementById('VGKRL').innerHTML;
  var vgkML = document.getElementById("VGKML").innerHTML;
  var vgkO = document.getElementById("VGKO").innerHTML;
  var vgkO = vgkO.replace(/[',()]/g, "");
  var vgkSoloO = document.getElementById("VGKSoloO").innerHTML;
  var vgkSoloO = vgkSoloO.replace(/[',()]/g, "");
  var vgk1Q = document.getElementById("VGK1Q").innerHTML;
  var vgk1QO = document.getElementById("VGK1QO").innerHTML;
  var vgk1QO = vgk1QO.replace(/[',()]/g, "");
  var vgk2Q = document.getElementById("VGK2Q").innerHTML;
  var vgk2QO = document.getElementById("VGK2QO").innerHTML;
  var vgk2QO = vgk2Q.replace(/[',()]/g, "");
  var vgk3Q = document.getElementById("VGK3Q").innerHTML;
  var vgk3QO = document.getElementById("VGK3QO").innerHTML;
  var vgk3QO = vgk3QO.replace(/[',()]/g, "");

  var wasSuperRL = document.getElementById('WASSuperRL').innerHTML;
  var wasRL = document.getElementById('WASRL').innerHTML;
  var wasML = document.getElementById("WASML").innerHTML;
  var wasO = document.getElementById("WASO").innerHTML;
  var wasO = wasO.replace(/[',()]/g, "");
  var wasSoloO = document.getElementById("WASSoloO").innerHTML;
  var wasSoloO = wasSoloO.replace(/[',()]/g, "");
  var was1Q = document.getElementById("WAS1Q").innerHTML;
  var was1QO = document.getElementById("WAS1QO").innerHTML;
  var was1QO = was1QO.replace(/[',()]/g, "");
  var was2Q = document.getElementById("WAS2Q").innerHTML;
  var was2QO = document.getElementById("WAS2QO").innerHTML;
  var was2QO = was2Q.replace(/[',()]/g, "");
  var was3Q = document.getElementById("WAS3Q").innerHTML;
  var was3QO = document.getElementById("WAS3QO").innerHTML;
  var was3QO = was3QO.replace(/[',()]/g, "");

  // How to get the under of a team

  // turn the variable into an integer

  var anaUnder = parseFloat(anaO, 10);
  var anaSoloUnder = parseFloat(anaO,10);
  var ana1QU = parseFloat(ana1QO,10);
  var ana2QU = parseFloat(ana2QO,10);
  var ana3QU = parseFloat(ana3QO,10);

  var ariUnder = parseFloat(ariO, 10);
  var ariSoloUnder = parseFloat(ariO,10);
  var ari1QU = parseFloat(ari1QO,10);
  var ari2QU = parseFloat(ari2QO,10);
  var ari3QU = parseFloat(ari3QO,10);

  var bosUnder = parseFloat(bosO, 10);
  var bosSoloUnder = parseFloat(bosO,10);
  var bos1QU = parseFloat(bos1QO,10);
  var bos2QU = parseFloat(bos2QO,10);
  var bos3QU = parseFloat(bos3QO,10);

  var bufUnder = parseFloat(bufO, 10);
  var bufSoloUnder = parseFloat(bufO,10);
  var buf1QU = parseFloat(buf1QO,10);
  var buf2QU = parseFloat(buf2QO,10);
  var buf3QU = parseFloat(buf3QO,10);

  var cgyUnder = parseFloat(cgyO, 10);
  var cgySoloUnder = parseFloat(cgyO,10);
  var cgy1QU = parseFloat(cgy1QO,10);
  var cgy2QU = parseFloat(cgy2QO,10);
  var cgy3QU = parseFloat(cgy3QO,10);

  var carUnder = parseFloat(carO, 10);
  var carSoloUnder = parseFloat(carO,10);
  var car1QU = parseFloat(car1QO,10);
  var car2QU = parseFloat(car2QO,10);
  var car3QU = parseFloat(car3QO,10);

  var chiUnder = parseFloat(chiO, 10);
  var chiSoloUnder = parseFloat(chiO,10);
  var chi1QU = parseFloat(chi1QO,10);
  var chi2QU = parseFloat(chi2QO,10);
  var chi3QU = parseFloat(chi3QO,10);

  var colUnder = parseFloat(colO, 10);
  var colSoloUnder = parseFloat(colO,10);
  var col1QU = parseFloat(col1QO,10);
  var col2QU = parseFloat(col2QO,10);
  var col3QU = parseFloat(col3QO,10);

  var cbjUnder = parseFloat(cbjO, 10);
  var cbjSoloUnder = parseFloat(cbjO,10);
  var cbj1QU = parseFloat(cbj1QO,10);
  var cbj2QU = parseFloat(cbj2QO,10);
  var cbj3QU = parseFloat(cbj3QO,10);

  var dalUnder = parseFloat(dalO, 10);
  var dalSoloUnder = parseFloat(dalO,10);
  var dal1QU = parseFloat(dal1QO,10);
  var dal2QU = parseFloat(dal2QO,10);
  var dal3QU = parseFloat(dal3QO,10);

  var detUnder = parseFloat(detO, 10);
  var detSoloUnder = parseFloat(detO,10);
  var det1QU = parseFloat(det1QO,10);
  var det2QU = parseFloat(det2QO,10);
  var det3QU = parseFloat(det3QO,10);

  var edmUnder = parseFloat(edmO, 10);
  var edmSoloUnder = parseFloat(edmO,10);
  var edm1QU = parseFloat(edm1QO,10);
  var edm2QU = parseFloat(edm2QO,10);
  var edm3QU = parseFloat(edm3QO,10);

  var flaUnder = parseFloat(flaO, 10);
  var flaSoloUnder = parseFloat(flaO,10);
  var fla1QU = parseFloat(fla1QO,10);
  var fla2QU = parseFloat(fla2QO,10);
  var fla3QU = parseFloat(fla3QO,10);

  var lakUnder = parseFloat(lakO, 10);
  var lakSoloUnder = parseFloat(lakO,10);
  var lak1QU = parseFloat(lak1QO,10);
  var lak2QU = parseFloat(lak2QO,10);
  var lak3QU = parseFloat(lak3QO,10);

  var minUnder = parseFloat(minO, 10);
  var minSoloUnder = parseFloat(minO,10);
  var min1QU = parseFloat(min1QO,10);
  var min2QU = parseFloat(min2QO,10);
  var min3QU = parseFloat(min3QO,10);

  var mtlUnder = parseFloat(mtlO, 10);
  var mtlSoloUnder = parseFloat(mtlO,10);
  var mtl1QU = parseFloat(mtl1QO,10);
  var mtl2QU = parseFloat(mtl2QO,10);
  var mtl3QU = parseFloat(mtl3QO,10);

  var nshUnder = parseFloat(nshO, 10);
  var nshSoloUnder = parseFloat(nshO,10);
  var nsh1QU = parseFloat(nsh1QO,10);
  var nsh2QU = parseFloat(nsh2QO,10);
  var nsh3QU = parseFloat(nsh3QO,10);

  var njdUnder = parseFloat(njdO, 10);
  var njdSoloUnder = parseFloat(njdO,10);
  var njd1QU = parseFloat(njd1QO,10);
  var njd2QU = parseFloat(njd2QO,10);
  var njd3QU = parseFloat(njd3QO,10);

  var nyiUnder = parseFloat(nyiO, 10);
  var nyiSoloUnder = parseFloat(nyiO,10);
  var nyi1QU = parseFloat(nyi1QO,10);
  var nyi2QU = parseFloat(nyi2QO,10);
  var nyi3QU = parseFloat(nyi3QO,10);

  var nyrUnder = parseFloat(nyrO, 10);
  var nyrSoloUnder = parseFloat(nyrO,10);
  var nyr1QU = parseFloat(nyr1QO,10);
  var nyr2QU = parseFloat(nyr2QO,10);
  var nyr3QU = parseFloat(nyr3QO,10);

  var ottUnder = parseFloat(ottO, 10);
  var ottSoloUnder = parseFloat(ottO,10);
  var ott1QU = parseFloat(ott1QO,10);
  var ott2QU = parseFloat(ott2QO,10);
  var ott3QU = parseFloat(ott3QO,10);

  var phiUnder = parseFloat(phiO, 10);
  var phiSoloUnder = parseFloat(phiO,10);
  var phi1QU = parseFloat(phi1QO,10);
  var phi2QU = parseFloat(phi2QO,10);
  var phi3QU = parseFloat(phi3QO,10);

  var pitUnder = parseFloat(pitO, 10);
  var pitSoloUnder = parseFloat(pitO,10);
  var pit1QU = parseFloat(pit1QO,10);
  var pit2QU = parseFloat(pit2QO,10);
  var pit3QU = parseFloat(pit3QO,10);

  var sjsUnder = parseFloat(sjsO, 10);
  var sjsSoloUnder = parseFloat(sjsO,10);
  var sjs1QU = parseFloat(sjs1QO,10);
  var sjs2QU = parseFloat(sjs2QO,10);
  var sjs3QU = parseFloat(sjs3QO,10);

  var stlUnder = parseFloat(stlO, 10);
  var stlSoloUnder = parseFloat(stlO,10);
  var stl1QU = parseFloat(stl1QO,10);
  var stl2QU = parseFloat(stl2QO,10);
  var stl3QU = parseFloat(stl3QO,10);

  var tblUnder = parseFloat(tblO, 10);
  var tblSoloUnder = parseFloat(tblO,10);
  var tbl1QU = parseFloat(tbl1QO,10);
  var tbl2QU = parseFloat(tbl2QO,10);
  var tbl3QU = parseFloat(tbl3QO,10);

  var torUnder = parseFloat(torO, 10);
  var torSoloUnder = parseFloat(torO,10);
  var tor1QU = parseFloat(tor1QO,10);
  var tor2QU = parseFloat(tor2QO,10);
  var tor3QU = parseFloat(tor3QO,10);

  var vanUnder = parseFloat(vanO, 10);
  var vanSoloUnder = parseFloat(vanO,10);
  var van1QU = parseFloat(van1QO,10);
  var van2QU = parseFloat(van2QO,10);
  var van3QU = parseFloat(van3QO,10);

  var vgkUnder = parseFloat(vgkO, 10);
  var vgkSoloUnder = parseFloat(vgkO,10);
  var vgk1QU = parseFloat(vgk1QO,10);
  var vgk2QU = parseFloat(vgk2QO,10);
  var vgk3QU = parseFloat(vgk3QO,10);

  var wasUnder = parseFloat(wasO, 10);
  var wasSoloUnder = parseFloat(wasO,10);
  var was1QU = parseFloat(was1QO,10);
  var was2QU = parseFloat(was2QO,10);
  var was3QU = parseFloat(was3QO,10);

  // Turn the over into under by subtracting by 100

  var anaU = 100 - anaUnder;
  var anaSoloU = 100 - anaSoloUnder;
  var ana1QUnder = 100 - ana1QU;
  var ana2QUnder = 100 - ana2QU;
  var ana3QUnder = 100 - ana3QU;

  var ariU = 100 - ariUnder;
  var ariSoloU = 100 - ariSoloUnder;
  var ari1QUnder = 100 - ari1QU;
  var ari2QUnder = 100 - ari2QU;
  var ari3QUnder = 100 - ari3QU;

  var bosU = 100 - bosUnder;
  var bosSoloU = 100 - bosSoloUnder;
  var bos1QUnder = 100 - bos1QU;
  var bos2QUnder = 100 - bos2QU;
  var bos3QUnder = 100 - bos3QU;

  var bufU = 100 - bufUnder;
  var bufSoloU = 100 - bufSoloUnder;
  var buf1QUnder = 100 - buf1QU;
  var buf2QUnder = 100 - buf2QU;
  var buf3QUnder = 100 - buf3QU;

  var cgyU = 100 - cgyUnder;
  var cgySoloU = 100 - cgySoloUnder;
  var cgy1QUnder = 100 - cgy1QU;
  var cgy2QUnder = 100 - cgy2QU;
  var cgy3QUnder = 100 - cgy3QU;

  var carU = 100 - carUnder;
  var carSoloU = 100 - carSoloUnder;
  var car1QUnder = 100 - car1QU;
  var car2QUnder = 100 - car2QU;
  var car3QUnder = 100 - car3QU;

  var chiU = 100 - chiUnder;
  var chiSoloU = 100 - chiSoloUnder;
  var chi1QUnder = 100 - chi1QU;
  var chi2QUnder = 100 - chi2QU;
  var chi3QUnder = 100 - chi3QU;

  var colU = 100 - colUnder;
  var colSoloU = 100 - colSoloUnder;
  var col1QUnder = 100 - col1QU;
  var col2QUnder = 100 - col2QU;
  var col3QUnder = 100 - col3QU;

  var cbjU = 100 - cbjUnder;
  var cbjSoloU = 100 - cbjSoloUnder;
  var cbj1QUnder = 100 - cbj1QU;
  var cbj2QUnder = 100 - cbj2QU;
  var cbj3QUnder = 100 - cbj3QU;

  var dalU = 100 - dalUnder;
  var dalSoloU = 100 - dalSoloUnder;
  var dal1QUnder = 100 - dal1QU;
  var dal2QUnder = 100 - dal2QU;
  var dal3QUnder = 100 - dal3QU;

  var detU = 100 - detUnder;
  var detSoloU = 100 - detSoloUnder;
  var det1QUnder = 100 - det1QU;
  var det2QUnder = 100 - det2QU;
  var det3QUnder = 100 - det3QU;

  var edmU = 100 - edmUnder;
  var edmSoloU = 100 - edmSoloUnder;
  var edm1QUnder = 100 - edm1QU;
  var edm2QUnder = 100 - edm2QU;
  var edm3QUnder = 100 - edm3QU;

  var flaU = 100 - flaUnder;
  var flaSoloU = 100 - flaSoloUnder;
  var fla1QUnder = 100 - fla1QU;
  var fla2QUnder = 100 - fla2QU;
  var fla3QUnder = 100 - fla3QU;

  var lakU = 100 - lakUnder;
  var lakSoloU = 100 - lakSoloUnder;
  var lak1QUnder = 100 - lak1QU;
  var lak2QUnder = 100 - lak2QU;
  var lak3QUnder = 100 - lak3QU;

  var minU = 100 - minUnder;
  var minSoloU = 100 - minSoloUnder;
  var min1QUnder = 100 - min1QU;
  var min2QUnder = 100 - min2QU;
  var min3QUnder = 100 - min3QU;

  var mtlU = 100 - mtlUnder;
  var mtlSoloU = 100 - mtlSoloUnder;
  var mtl1QUnder = 100 - mtl1QU;
  var mtl2QUnder = 100 - mtl2QU;
  var mtl3QUnder = 100 - mtl3QU;

  var nshU = 100 - nshUnder;
  var nshSoloU = 100 - nshSoloUnder;
  var nsh1QUnder = 100 - nsh1QU;
  var nsh2QUnder = 100 - nsh2QU;
  var nsh3QUnder = 100 - nsh3QU;

  var njdU = 100 - njdUnder;
  var njdSoloU = 100 - njdSoloUnder;
  var njd1QUnder = 100 - njd1QU;
  var njd2QUnder = 100 - njd2QU;
  var njd3QUnder = 100 - njd3QU;

  var nyiU = 100 - nyiUnder;
  var nyiSoloU = 100 - nyiSoloUnder;
  var nyi1QUnder = 100 - nyi1QU;
  var nyi2QUnder = 100 - nyi2QU;
  var nyi3QUnder = 100 - nyi3QU;

  var nyrU = 100 - nyrUnder;
  var nyrSoloU = 100 - nyrSoloUnder;
  var nyr1QUnder = 100 - nyr1QU;
  var nyr2QUnder = 100 - nyr2QU;
  var nyr3QUnder = 100 - nyr3QU;

  var ottU = 100 - ottUnder;
  var ottSoloU = 100 - ottSoloUnder;
  var ott1QUnder = 100 - ott1QU;
  var ott2QUnder = 100 - ott2QU;
  var ott3QUnder = 100 - ott3QU;

  var phiU = 100 - phiUnder;
  var phiSoloU = 100 - phiSoloUnder;
  var phi1QUnder = 100 - phi1QU;
  var phi2QUnder = 100 - phi2QU;
  var phi3QUnder = 100 - phi3QU;

  var pitU = 100 - pitUnder;
  var pitSoloU = 100 - pitSoloUnder;
  var pit1QUnder = 100 - pit1QU;
  var pit2QUnder = 100 - pit2QU;
  var pit3QUnder = 100 - pit3QU;

  var sjsU = 100 - sjsUnder;
  var sjsSoloU = 100 - sjsSoloUnder;
  var sjs1QUnder = 100 - sjs1QU;
  var sjs2QUnder = 100 - sjs2QU;
  var sjs3QUnder = 100 - sjs3QU;

  var stlU = 100 - stlUnder;
  var stlSoloU = 100 - stlSoloUnder;
  var stl1QUnder = 100 - stl1QU;
  var stl2QUnder = 100 - stl2QU;
  var stl3QUnder = 100 - stl3QU;

  var tblU = 100 - tblUnder;
  var tblSoloU = 100 - tblSoloUnder;
  var tbl1QUnder = 100 - tbl1QU;
  var tbl2QUnder = 100 - tbl2QU;
  var tbl3QUnder = 100 - tbl3QU;

  var torU = 100 - torUnder;
  var torSoloU = 100 - torSoloUnder;
  var tor1QUnder = 100 - tor1QU;
  var tor2QUnder = 100 - tor2QU;
  var tor3QUnder = 100 - tor3QU;

  var vanU = 100 - vanUnder;
  var vanSoloU = 100 - vanSoloUnder;
  var van1QUnder = 100 - van1QU;
  var van2QUnder = 100 - van2QU;
  var van3QUnder = 100 - van3QU;

  var vgkU = 100 - vgkUnder;
  var vgkSoloU = 100 - vgkSoloUnder;
  var vgk1QUnder = 100 - vgk1QU;
  var vgk2QUnder = 100 - vgk2QU;
  var vgk3QUnder = 100 - vgk3QU;

  var wasU = 100 - wasUnder;
  var wasSoloU = 100 - wasSoloUnder;
  var was1QUnder = 100 - was1QU;
  var was2QUnder = 100 - was2QU;
  var was3QUnder = 100 - was3QU;

  // Team stats in order by team index & stat index
  var statLists = new Array(21)
statLists["SuperRL"] = [anaSuperRL, ariSuperRL, bosSuperRL, bufSuperRL, cgySuperRL, carSuperRL, chiSuperRL, colSuperRL, cbjSuperRL, dalSuperRL, detSuperRL, edmSuperRL, flaSuperRL, lakSuperRL, minSuperRL, mtlSuperRL, nshSuperRL, njdSuperRL, nyiSuperRL, nyrSuperRL, ottSuperRL, phiSuperRL, pitSuperRL, sjsSuperRL, stlSuperRL, tblSuperRL, torSuperRL, vanSuperRL, vgkSuperRL, wasSuperRL]
statLists["RL"] = [anaRL, ariRL, bosRL, bufRL, cgyRL, carRL, chiRL, colRL, cbjRL, dalRL, detRL, edmRL, flaRL, lakRL, minRL, mtlRL, nshRL, njdRL, nyiRL, nyrRL, ottRL, phiRL, pitRL, sjsRL, stlRL, tblRL, torRL, vanRL, vgkRL, wasRL]
statLists["ML"] = [anaML, ariML, bosML, bufML, cgyML, carML, chiML, colML, cbjML, dalML, detML, edmML, flaML, lakML, minML, mtlML, nshML, njdML, nyiML, nyrML, ottML, phiML, pitML, sjsML, stlML, tblML, torML, vanML, vgkML, wasML]
statLists["Over"] = [anaO, ariO, bosO, bufO, cgyO, carO, chiO, colO, cbjO, dalO, detO, edmO, flaO, lakO, minO, mtlO, nshO, njdO, nyiO, nyrO, ottO, phiO, pitO, sjsO, stlO, tblO, torO, vanO, vgkO, wasO]
statLists["Under"] = [anaU, ariU, bosU, bufU, cgyU, carU, chiU, colU, cbjU, dalU, detU, edmU, flaU, lakU, minU, mtlU, nshU, njdU, nyiU, nyrU, ottU, phiU, pitU, sjsU, stlU, tblU, torU, vanU, vgkU, wasU]
statLists["Solo Over"] = [anaSoloO, ariSoloO, bosSoloO, bufSoloO, cgySoloO, carSoloO, chiSoloO, colSoloO, cbjSoloO, dalSoloO, detSoloO, edmSoloO, flaSoloO, lakSoloO, minSoloO, mtlSoloO, nshSoloO, njdSoloO, nyiSoloO, nyrSoloO, ottSoloO, phiSoloO, pitSoloO, sjsSoloO, stlSoloO, tblSoloO, torSoloO, vanSoloO, vgkSoloO, wasSoloO]
statLists["Solo Under"] = [anaSoloU, ariSoloU, bosSoloU, bufSoloU, cgySoloU, carSoloU, chiSoloU, colSoloU, cbjSoloU, dalSoloU, detSoloU, edmSoloU, flaSoloU, lakSoloU, minSoloU, mtlSoloU, nshSoloU, njdSoloU, nyiSoloU, nyrSoloU, ottSoloU, phiSoloU, pitSoloU, sjsSoloU, stlSoloU, tblSoloU, torSoloU, vanSoloU, vgkSoloU, wasSoloU]
statLists["1Q Cover"] = [ana1Q, ari1Q, bos1Q, buf1Q, cgy1Q, car1Q, chi1Q, col1Q, cbj1Q, dal1Q, det1Q, edm1Q, fla1Q, lak1Q, min1Q, mtl1Q, nsh1Q, njd1Q, nyi1Q, nyr1Q, ott1Q, phi1Q, pit1Q, sjs1Q, stl1Q, tbl1Q, tor1Q, van1Q, vgk1Q, was1Q]
statLists["1Q Over"] = [ana1QO, ari1QO, bos1QO, buf1QO, cgy1QO, car1QO, chi1QO, col1QO, cbj1QO, dal1QO, det1QO, edm1QO, fla1QO, lak1QO, min1QO, mtl1QO, nsh1QO, njd1QO, nyi1QO, nyr1QO, ott1QO, phi1QO, pit1QO, sjs1QO, stl1QO, tbl1QO, tor1QO, van1QO, vgk1QO, was1QO]
statLists["1Q Under"] = [ana1QUnder, ari1QUnder, bos1QUnder, buf1QUnder, cgy1QUnder, car1QUnder, chi1QUnder, col1QUnder, cbj1QUnder, dal1QUnder, det1QUnder, edm1QUnder, fla1QUnder, lak1QUnder, min1QUnder, mtl1QUnder, nsh1QUnder, njd1QUnder, nyi1QUnder, nyr1QUnder, ott1QUnder, phi1QUnder, pit1QUnder, sjs1QUnder, stl1QUnder, tbl1QUnder, tor1QUnder, van1QUnder, vgk1QUnder, was1QUnder]
statLists["2Q Cover"] = [ana2Q, ari2Q, bos2Q, buf2Q, cgy2Q, car2Q, chi2Q, col2Q, cbj2Q, dal2Q, det2Q, edm2Q, fla2Q, lak2Q, min2Q, mtl2Q, nsh2Q, njd2Q, nyi2Q, nyr2Q, ott2Q, phi2Q, pit2Q, sjs2Q, stl2Q, tbl2Q, tor2Q, van2Q, vgk2Q, was2Q]
statLists["2Q Over"] = [ana2QO, ari2QO, bos2QO, buf2QO, cgy2QO, car2QO, chi2QO, col2QO, cbj2QO, dal2QO, det2QO, edm2QO, fla2QO, lak2QO, min2QO, mtl2QO, nsh2QO, njd2QO, nyi2QO, nyr2QO, ott2QO, phi2QO, pit2QO, sjs2QO, stl2QO, tbl2QO, tor2QO, van2QO, vgk2QO, was2QO]
statLists["2Q Under"] = [ana2QUnder, ari2QUnder, bos2QUnder, buf2QUnder, cgy2QUnder, car2QUnder, chi2QUnder, col2QUnder, cbj2QUnder, dal2QUnder, det2QUnder, edm2QUnder, fla2QUnder, lak2QUnder, min2QUnder, mtl2QUnder, nsh2QUnder, njd2QUnder, nyi2QUnder, nyr2QUnder, ott2QUnder, phi2QUnder, pit2QUnder, sjs2QUnder, stl2QUnder, tbl2QUnder, tor2QUnder, van2QUnder, vgk2QUnder, was2QUnder]
statLists["3Q Cover"] = [ana3Q, ari3Q, bos3Q, buf3Q, cgy3Q, car3Q, chi3Q, col3Q, cbj3Q, dal3Q, det3Q, edm3Q, fla3Q, lak3Q, min3Q, mtl3Q, nsh3Q, njd3Q, nyi3Q, nyr3Q, ott3Q, phi3Q, pit3Q, sjs3Q, stl3Q, tbl3Q, tor3Q, van3Q, vgk3Q, was3Q]
statLists["3Q Over"] = [ana3QO, ari3QO, bos3QO, buf3QO, cgy3QO, car3QO, chi3QO, col3QO, cbj3QO, dal3QO, det3QO, edm3QO, fla3QO, lak3QO, min3QO, mtl3QO, nsh3QO, njd3QO, nyi3QO, nyr3QO, ott3QO, phi3QO, pit3QO, sjs3QO, stl3QO, tbl3QO, tor3QO, van3QO, vgk3QO, was3QO]
statLists["3Q Under"] = [ana3QUnder, ari3QUnder, bos3QUnder, buf3QUnder, cgy3QUnder, car3QUnder, chi3QUnder, col3QUnder, cbj3QUnder, dal3QUnder, det3QUnder, edm3QUnder, fla3QUnder, lak3QUnder, min3QUnder, mtl3QUnder, nsh3QUnder, njd3QUnder, nyi3QUnder, nyr3QUnder, ott3QUnder, phi3QUnder, pit3QUnder, sjs3QUnder, stl3QUnder, tbl3QUnder, tor3QUnder, van3QUnder, vgk3QUnder, was3QUnder]

  // Stat index clicked by user is logged
  var statIndex = selectObj.selectedIndex;

  // Value of stat index is logged
  var statValue = selectObj.options[statIndex].value;

  // Actual number is retrieved from statList
  stat = statLists[statValue]

  // Remove extra characters extracted from back-end
  finalstat = stat[index - 1]

  finalstat = String(finalstat).replace(/[',()]/g, "");

if (finalstat.includes("%")) {

  document.getElementById("stat").innerHTML = "This happens " + finalstat + " of the time";
  document.getElementById("stat").style.opacity = "1";

} else {

  document.getElementById("stat").innerHTML = "This happens " + finalstat + "% of the time";
  document.getElementById("stat").style.opacity = "1";
}
}
$(document).ready(function() {
    $('.Dropdown').select2({
      width: 'resolve',
});
});

//<![CDATA[
// array of possible teams in the same order as they appear in the team selection list

var teamLists = new Array(30)
teamLists["empty"] = ["Select a Stat"];
teamLists["Abilene Christian Wildcats"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Akron Zips"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Alabama Crimson Tide"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Alabama A&M Bulldogs"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["UAB Blazers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Alabama State Hornets"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Albany Great Danes"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Alcorn State Braves"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["American Eagles"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Appalachian State Mountaineers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Arizona Wildcats"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Arizona State Sun Devils"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Arkansas Razorbacks"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Little Rock Trojans"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Arkansas-Pine Bluff Golden Lions"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Arkansas State Red Wolves"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Auburn Tigers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Austin Peay Governors"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Ball State Cardinals"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Baylor Bears"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Belmont Bruins"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Bethune-Cookman Wildcats"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Binghamton Bearcats"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Boise State Broncos"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Boston College Eagles"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Boston University Terriers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Bowling Green Falcons"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Bradley Braves"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["BYU Cougars"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Brown Bears"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Bryant Bulldogs"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Bucknell Bison"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Buffalo Bulls"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Butler Bulldogs"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["California Golden Bears"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["UC Davis Aggies"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["UC Irvine Anteaters"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["UCLA Bruins"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Cal Poly Mustangs"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["UC Riverside Highlanders"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["UC Santa Barbara Gauchos"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["CSU Bakersfield Roadrunners"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Fresno State Bulldogs"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["CSU Fullerton Titans"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Long Beach State 49ers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["CSU Northridge Matadors"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Sacramento State Hornets"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Campbell Fighting Camels"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Canisius Golden Griffins"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Central Arkansas Bears"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Central Connecticut Blue Devils"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["UCF Knights"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Central Michigan Chippewas"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Charleston Cougars"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Charleston Southern Buccaneers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Chicago State Cougars"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Cincinnati Bearcats"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["The Citadel Bulldogs"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Clemson Tigers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Cleveland State Vikings"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Coastal Carolina Chanticleers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Colgate Raiders"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Colorado Buffaloes"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Colorado State Rams"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Columbia Lions"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["UConn Huskies"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Coppin State Eagles"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Cornell Big Red"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Creighton Bluejays"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Dartmouth Big Green"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Davidson Wildcats"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Dayton Flyers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Delaware Blue Hens"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Delaware State Hornets"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Denver Pioneers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["DePaul Blue Demons"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Detroit Mercy Titans"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Drake Bulldogs"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Drexel Dragons"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Duke Blue Devils"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Duquesne Dukes"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["East Tennessee State Buccaneers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Eastern Illinois Panthers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Eastern Kentucky Colonels"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Eastern Michigan Eagles"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Elon Phoenix"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Evansville Purple Aces"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Fairfield Stags"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Fairleigh Dickinson Knights"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Florida Gators"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Florida A&M Rattlers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Florida Atlantic Owls"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Florida Gulf Coast Eagles"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Florida International Panthers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Florida State Seminoles"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Fordham Rams"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Furman Paladins"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Gardner-Webb Bulldogs"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["George Mason Patriots"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["George Washington Colonials"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Georgetown Hoyas"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Georgia Bulldogs"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Georgia Tech Yellow Jackets"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Georgia Southern Eagles"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Georgia State Panthers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Gonzaga Bulldogs"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Grambling Tigers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Grand Canyon Antelopes"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Hampton Pirates"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Hartford Hawks"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Harvard Crimson"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Hawaii Rainbow Warriors"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["High Point Panthers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Hofstra Pride"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Holy Cross Crusaders"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Houston Cougars"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Houston Baptist Huskies"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Howard Bison"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Idaho Vandals"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Idaho State Bengals"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["UIC Flames"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Illinois State Red Birds"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Illinois Fighting Illini"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Incarnate Word Cardinals"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Indiana Hoosiers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Indiana State Sycamores"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["IUPUI Jaguars"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Iona Gaels"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Iowa Hawkeyes"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Iowa State Cyclones"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Jackson State Tigers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Jacksonville Dolphins"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Jacksonville State Gamecocks"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["James Madison Dukes"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Kansas Jayhawks"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Kansas State Wildcats"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Kennesaw State Owls"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Kent State Golden Flashes"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Kentucky Wildcats"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["La Salle Explorers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Lafayette Leopards"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Lamar Cardinals"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Lehigh Mountain Hawks"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Liberty Flames"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Lipscomb Bisons"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Long Island University Sharks"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Longwood Lancers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Louisiana Ragin' Cajuns"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["UL Monroe Warhawks"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["LSU Tigers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Louisiana Tech Bulldogs"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Louisville Cardinals"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Loyola-Chicago Ramblers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Loyola (MD) Greyhounds"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Loyola Marymount Lions"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Maine Black Bears"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Manhattan Jaspers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Marist Red Foxes"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Marquette Golden Eagles"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Marshall Thundering Herd"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["UMBC Retrievers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Maryland Terrapins"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["UMass Minutemen"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["UMass Lowell River Hawks"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["McNeese State Cowboys"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Memphis Tigers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Mercer Bears"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Miami Hurricanes"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Miami (OH) Redhawks"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Michigan Wolverines"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Michigan State Spartans"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Middle Tennessee Blue Raiders"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Minnesota Golden Gophers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Ole Miss Rebels"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Mississippi State Bulldogs"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Mississippi Valley State Delta Devils"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Missouri Tigers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["UMKC Kangaroos"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Missouri State Bears"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Monmouth Hawks"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Montana Grizzlies"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Montana State Bobcats"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Morehead State Eagles"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Morgan State Bears"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Mount St. Mary's Mountaineers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Murray State Racers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Nebraska Cornhuskers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Omaha Mavericks"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["UNLV Rebels"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Nevada Wolf Pack"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["New Hampshire Wildcats"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["NJIT Highlanders"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["New Mexico Lobos"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["New Mexico State Aggies"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["New Orleans Privateers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Niagara Purple Eagles"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Nicholls Colonels"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Norfolk State Spartans"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["North Carolina A&T Aggies"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["UNC Asheville Bulldogs"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["North Carolina Central Eagles"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["North Carolina Tar Heels"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["CHarlotte 49ers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["UNC Greensboro Spartans"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["NC State Wolfpack"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["UNC Wilmington Seahawks"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["North Dakota Fighting Hawks"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["North Dakota State Bison"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["North Florida Ospreys"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["North Texas Mean Green"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Northeastern Huskies"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Northern Arizona Lumberjacks"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Northern Colorado Bears"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Northern Illinois Huskies"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Northern Iowa Panthers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Northern Kentucky Norse"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Northwestern Wildcats"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Northwestern State Demons"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Notre Dame Fighting Irish"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Oakland Golden Grizzlies"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Ohio Bobcats"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Ohio State Buckeyes"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Oklahoma Sooners"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Oklahoma State Cowboys"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Old Dominion Monarchs"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Oral Roberts Golden Eagles"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Oregon Ducks"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Oregon State Beavers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Pacific Tigers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Pennsylvania Quakers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Penn State Nittany Lions"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Pepperdine Waves"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Pittsburgh Panthers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Portland Pilots"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Portland State Vikings"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Prairie View A&M Panthers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Presbyterian Blue Hose"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Princeton Tigers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Providence Friars"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Purdue Boilermakers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Purdue Fort Wayne Mastodons"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Quinnipiac Bobcats"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Radford Highlanders"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Rhode Island Rams"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Rice Owls"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Richmond Spiders"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Rider Broncs"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Robert Morries Colonials"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Rutgers Scarlet Knights"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Sacred Heart Pioneers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["St. Bonaventure Bonnies"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["St. Francis (BKN) Terriers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["St. Francis (PA) Red Flash"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["St. John's Red Storm"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Saint Joseph's Hawks"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Saint Louis Billikens"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Saint Mary's Gaels"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Saint Peter's Peacocks"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Sam Houston State Bearkats"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Samford Bulldogs"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["San Diego Toreros"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["San Diego Aztecs"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["San Francisco Dons"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["San Jose State Spartans"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Santa Clara Broncos"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Seattle Redhawks"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Seton Hall Pirates"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Siena Saints"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["South Alabama Jaguars"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["South Carolina Gamecocks"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["South Carolina State Bulldogs"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["USC Upstate Spartans"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["South Dakota Coyotes"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["South Dakota State Jackrabbits"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["South Florida Bulls"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["SE Missouri State Redhawks"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["SE Louisiana Lions"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Southern Jaguars"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["USC Trojans"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Southern Illinois Salukis"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["SIU Edwardsville Cougars"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["SMU Mustangs"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Southern Miss Golden Eagles"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Southern Utah Thunderbirds"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Stanford Cardinals"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Stephen F. Austin Lumberjacks"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Stetson Hatters"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Stony Brook Seawolves"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Syracuse Orange"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Temple Owls"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Tennessee Volunteers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Chattanooga Mocs"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["UT Martin Skyhawks"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Tennessee State Tigers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Tennessee Tech Golden Eagles"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Texas A&M Aggies"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Texas A&M-CC Islanders"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["UT Arlington Mavericks"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Texas Longhorns"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["TCU Horned Frogs"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["UTEP Miners"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["UT Rio Grande Valley Vaqueros"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["UTSA Roadrunners"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Texas Southern Tigers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Texas State Bobcats"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Texas Tech Red Raiders"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Toledo Rockets"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Towson Tigers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Troy Trojans"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Tulane Green Wave"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Tulsa Golden Hurricane"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Air Force Falcons"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Army Black Knights"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Navy Midshipmen"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Utah Utes"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Utah State Aggies"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Utah Valley Wolverines"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Valparaiso Crusaders"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Vanderbilt Commodores"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Vermont Catamounts"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Villanova Wildcats"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Virginia Cavaliers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["VCU Rams"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["VMI Keydets"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Virginia Tech Hokies"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Wagner Seahawks"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Wake Forest Demon Deacons"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Washington Huskies"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Washington State Cougars"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Weber State Wildcats"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["West Virginia Mountaineers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Western Carolina Catamounts"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Western Illinois Leathernecks"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Western Michigan Broncos"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Wichita State Shockers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["William & Mary Tribe"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Winthrop Eagles"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Green Bay Phoenix"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Wisconsin Badgers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Milwaukee Panthers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Wofford Terriers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Wright State Raiders"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Wyoming Cowboys"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Xavier Musketeers"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Yale Bulldogs"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];
teamLists["Youngstown State Penguins"] = ["Select a Stat", "ATS", "ML", "Over", "Under", "Solo Over", "Solo Under", "Halftime ATS", "Halftime Over", "Halftime Under"];

/* teamChange() is called from the onchange event of a select element.
* param selectObj - the select object which fired the on change event.
*/

function teamChange(selectObj) {
// get the index of the selected option
  index = selectObj.selectedIndex;

// get the value of the selected option
var which = selectObj.options[index].value;
// use the selected option value to retrieve the list of items from the countryLists array
tList = teamLists[which];
// get the country select element via its known id
var tSelect = document.getElementById("stat-change");
// remove the current options from the country select
var len = tSelect.options.length;

while (tSelect.options.length > 0) {
tSelect.remove(0);
}
var newOption;
// create new options
for (var i=0; i<tList.length; i++) {
newOption = document.createElement("option");
newOption.value = tList[i];  // assumes option string and value are the same
newOption.text=tList[i];
// add the new option
try {
tSelect.add(newOption);  // this will fail in DOM browsers but is needed for IE
}
catch (e) {
tSelect.appendChild(newOption);
}
}
}

function statChange(selectObj) {

  var abilenechristianwildcatscover = document.getElementById("AbileneChristianWildcatsCover").innerHTML;
  var abilenechristianwildcatsML = document.getElementById("AbileneChristianWildcatsML").innerHTML;
  var abilenechristianwildcatsO = document.getElementById("AbileneChristianWildcatsOU").innerHTML;
  var abilenechristianwildcatsO = abilenechristianwildcatsO.replace(/[',()]/g, "");
  var abilenechristianwildcatsSoloO = document.getElementById("AbileneChristianWildcatsSoloOU").innerHTML;
  var abilenechristianwildcatsSoloO = abilenechristianwildcatsSoloO.replace(/[',()]/g, "");
  var abilenechristianwildcatsHalftime = document.getElementById("AbileneChristianWildcatsHalftime").innerHTML;
  var abilenechristianwildcatsHalftimeO = document.getElementById("AbileneChristianWildcatsHalftimeOU").innerHTML;
  var abilenechristianwildcatsHalftimeO = abilenechristianwildcatsHalftimeO.replace(/[',()]/g, "");

  var akronzipscover = document.getElementById("AkronZipsCover").innerHTML;
  var akronzipsML = document.getElementById("AkronZipsML").innerHTML;
  var akronzipsO = document.getElementById("AkronZipsOU").innerHTML;
  var akronzipsO = akronzipsO.replace(/[',()]/g, "");
  var akronzipsSoloO = document.getElementById("AkronZipsSoloOU").innerHTML;
  var akronzipsSoloO = akronzipsSoloO.replace(/[',()]/g, "");
  var akronzipsHalftime = document.getElementById("AkronZipsHalftime").innerHTML;
  var akronzipsHalftimeO = document.getElementById("AkronZipsHalftimeOU").innerHTML;
  var akronzipsHalftimeO = akronzipsHalftimeO.replace(/[',()]/g, "");

  var alabamacrimsontidecover = document.getElementById("AlabamaCrimsonTideCover").innerHTML;
  var alabamacrimsontideML = document.getElementById("AlabamaCrimsonTideML").innerHTML;
  var alabamacrimsontideO = document.getElementById("AlabamaCrimsonTideOU").innerHTML;
  var alabamacrimsontideO = alabamacrimsontideO.replace(/[',()]/g, "");
  var alabamacrimsontideSoloO = document.getElementById("AlabamaCrimsonTideSoloOU").innerHTML;
  var alabamacrimsontideSoloO = alabamacrimsontideSoloO.replace(/[',()]/g, "");
  var alabamacrimsontideHalftime = document.getElementById("AlabamaCrimsonTideHalftime").innerHTML;
  var alabamacrimsontideHalftimeO = document.getElementById("AlabamaCrimsonTideHalftimeOU").innerHTML;
  var alabamacrimsontideHalftimeO = alabamacrimsontideHalftimeO.replace(/[',()]/g, "");

  var alabamaaandmbulldogscover = document.getElementById("AlabamaAandMBulldogsCover").innerHTML;
  var alabamaaandmbulldogsML = document.getElementById("AlabamaAandMBulldogsML").innerHTML;
  var alabamaaandmbulldogsO = document.getElementById("AlabamaAandMBulldogsOU").innerHTML;
  var alabamaaandmbulldogsO = alabamaaandmbulldogsO.replace(/[',()]/g, "");
  var alabamaaandmbulldogsSoloO = document.getElementById("AlabamaAandMBulldogsSoloOU").innerHTML;
  var alabamaaandmbulldogsSoloO = alabamaaandmbulldogsSoloO.replace(/[',()]/g, "");
  var alabamaaandmbulldogsHalftime = document.getElementById("AlabamaAandMBulldogsHalftime").innerHTML;
  var alabamaaandmbulldogsHalftimeO = document.getElementById("AlabamaAandMBulldogsHalftimeOU").innerHTML;
  var alabamaaandmbulldogsHalftimeO = alabamaaandmbulldogsHalftimeO.replace(/[',()]/g, "");

  var uabblazerscover = document.getElementById("UABBlazersCover").innerHTML;
  var uabblazersML = document.getElementById("UABBlazersML").innerHTML;
  var uabblazersO = document.getElementById("UABBlazersOU").innerHTML;
  var uabblazersO = uabblazersO.replace(/[',()]/g, "");
  var uabblazersSoloO = document.getElementById("UABBlazersSoloOU").innerHTML;
  var uabblazersSoloO = uabblazersSoloO.replace(/[',()]/g, "");
  var uabblazersHalftime = document.getElementById("UABBlazersHalftime").innerHTML;
  var uabblazersHalftimeO = document.getElementById("UABBlazersHalftimeOU").innerHTML;
  var uabblazersHalftimeO = uabblazersHalftimeO.replace(/[',()]/g, "");

  var alabamastatehornetscover = document.getElementById("AlabamaStateHornetsCover").innerHTML;
  var alabamastatehornetsML = document.getElementById("AlabamaStateHornetsML").innerHTML;
  var alabamastatehornetsO = document.getElementById("AlabamaStateHornetsOU").innerHTML;
  var alabamastatehornetsO = alabamastatehornetsO.replace(/[',()]/g, "");
  var alabamastatehornetsSoloO = document.getElementById("AlabamaStateHornetsSoloOU").innerHTML;
  var alabamastatehornetsSoloO = alabamastatehornetsSoloO.replace(/[',()]/g, "");
  var alabamastatehornetsHalftime = document.getElementById("AlabamaStateHornetsHalftime").innerHTML;
  var alabamastatehornetsHalftimeO = document.getElementById("AlabamaStateHornetsHalftimeOU").innerHTML;
  var alabamastatehornetsHalftimeO = alabamastatehornetsHalftimeO.replace(/[',()]/g, "");

  var albanygreatdanescover = document.getElementById("AlbanyGreatDanesCover").innerHTML;
  var albanygreatdanesML = document.getElementById("AlbanyGreatDanesML").innerHTML;
  var albanygreatdanesO = document.getElementById("AlbanyGreatDanesOU").innerHTML;
  var albanygreatdanesO = albanygreatdanesO.replace(/[',()]/g, "");
  var albanygreatdanesSoloO = document.getElementById("AlbanyGreatDanesSoloOU").innerHTML;
  var albanygreatdanesSoloO = albanygreatdanesSoloO.replace(/[',()]/g, "");
  var albanygreatdanesHalftime = document.getElementById("AlbanyGreatDanesHalftime").innerHTML;
  var albanygreatdanesHalftimeO = document.getElementById("AlbanyGreatDanesHalftimeOU").innerHTML;
  var albanygreatdanesHalftimeO = albanygreatdanesHalftimeO.replace(/[',()]/g, "");

  var alcornstatebravescover = document.getElementById("AlcornStateBravesCover").innerHTML;
  var alcornstatebravesML = document.getElementById("AlcornStateBravesML").innerHTML;
  var alcornstatebravesO = document.getElementById("AlcornStateBravesOU").innerHTML;
  var alcornstatebravesO = alcornstatebravesO.replace(/[',()]/g, "");
  var alcornstatebravesSoloO = document.getElementById("AlcornStateBravesSoloOU").innerHTML;
  var alcornstatebravesSoloO = alcornstatebravesSoloO.replace(/[',()]/g, "");
  var alcornstatebravesHalftime = document.getElementById("AlcornStateBravesHalftime").innerHTML;
  var alcornstatebravesHalftimeO = document.getElementById("AlcornStateBravesHalftimeOU").innerHTML;
  var alcornstatebravesHalftimeO = alcornstatebravesHalftimeO.replace(/[',()]/g, "");

  var americaneaglescover = document.getElementById("AmericanEaglesCover").innerHTML;
  var americaneaglesML = document.getElementById("AmericanEaglesML").innerHTML;
  var americaneaglesO = document.getElementById("AmericanEaglesOU").innerHTML;
  var americaneaglesO = americaneaglesO.replace(/[',()]/g, "");
  var americaneaglesSoloO = document.getElementById("AmericanEaglesSoloOU").innerHTML;
  var americaneaglesSoloO = americaneaglesSoloO.replace(/[',()]/g, "");
  var americaneaglesHalftime = document.getElementById("AmericanEaglesHalftime").innerHTML;
  var americaneaglesHalftimeO = document.getElementById("AmericanEaglesHalftimeOU").innerHTML;
  var americaneaglesHalftimeO = americaneaglesHalftimeO.replace(/[',()]/g, "");

  var appalachianstatemountaineerscover = document.getElementById("AppalachianStateMountaineersCover").innerHTML;
  var appalachianstatemountaineersML = document.getElementById("AppalachianStateMountaineersML").innerHTML;
  var appalachianstatemountaineersO = document.getElementById("AppalachianStateMountaineersOU").innerHTML;
  var appalachianstatemountaineersO = appalachianstatemountaineersO.replace(/[',()]/g, "");
  var appalachianstatemountaineersSoloO = document.getElementById("AppalachianStateMountaineersSoloOU").innerHTML;
  var appalachianstatemountaineersSoloO = appalachianstatemountaineersSoloO.replace(/[',()]/g, "");
  var appalachianstatemountaineersHalftime = document.getElementById("AppalachianStateMountaineersHalftime").innerHTML;
  var appalachianstatemountaineersHalftimeO = document.getElementById("AppalachianStateMountaineersHalftimeOU").innerHTML;
  var appalachianstatemountaineersHalftimeO = appalachianstatemountaineersHalftimeO.replace(/[',()]/g, "");

  var arizonawildcatscover = document.getElementById("ArizonaWildcatsCover").innerHTML;
  var arizonawildcatsML = document.getElementById("ArizonaWildcatsML").innerHTML;
  var arizonawildcatsO = document.getElementById("ArizonaWildcatsOU").innerHTML;
  var arizonawildcatsO = arizonawildcatsO.replace(/[',()]/g, "");
  var arizonawildcatsSoloO = document.getElementById("ArizonaWildcatsSoloOU").innerHTML;
  var arizonawildcatsSoloO = arizonawildcatsSoloO.replace(/[',()]/g, "");
  var arizonawildcatsHalftime = document.getElementById("ArizonaWildcatsHalftime").innerHTML;
  var arizonawildcatsHalftimeO = document.getElementById("ArizonaWildcatsHalftimeOU").innerHTML;
  var arizonawildcatsHalftimeO = arizonawildcatsHalftimeO.replace(/[',()]/g, "");

  var arizonastatesundevilscover = document.getElementById("ArizonaStateSunDevilsCover").innerHTML;
  var arizonastatesundevilsML = document.getElementById("ArizonaStateSunDevilsML").innerHTML;
  var arizonastatesundevilsO = document.getElementById("ArizonaStateSunDevilsOU").innerHTML;
  var arizonastatesundevilsO = arizonastatesundevilsO.replace(/[',()]/g, "");
  var arizonastatesundevilsSoloO = document.getElementById("ArizonaStateSunDevilsSoloOU").innerHTML;
  var arizonastatesundevilsSoloO = arizonastatesundevilsSoloO.replace(/[',()]/g, "");
  var arizonastatesundevilsHalftime = document.getElementById("ArizonaStateSunDevilsHalftime").innerHTML;
  var arizonastatesundevilsHalftimeO = document.getElementById("ArizonaStateSunDevilsHalftimeOU").innerHTML;
  var arizonastatesundevilsHalftimeO = arizonastatesundevilsHalftimeO.replace(/[',()]/g, "");

  var arkansasrazorbackscover = document.getElementById("ArkansasRazorbacksCover").innerHTML;
  var arkansasrazorbacksML = document.getElementById("ArkansasRazorbacksML").innerHTML;
  var arkansasrazorbacksO = document.getElementById("ArkansasRazorbacksOU").innerHTML;
  var arkansasrazorbacksO = arkansasrazorbacksO.replace(/[',()]/g, "");
  var arkansasrazorbacksSoloO = document.getElementById("ArkansasRazorbacksSoloOU").innerHTML;
  var arkansasrazorbacksSoloO = arkansasrazorbacksSoloO.replace(/[',()]/g, "");
  var arkansasrazorbacksHalftime = document.getElementById("ArkansasRazorbacksHalftime").innerHTML;
  var arkansasrazorbacksHalftimeO = document.getElementById("ArkansasRazorbacksHalftimeOU").innerHTML;
  var arkansasrazorbacksHalftimeO = arkansasrazorbacksHalftimeO.replace(/[',()]/g, "");

  var littlerocktrojanscover = document.getElementById("LittleRockTrojansCover").innerHTML;
  var littlerocktrojansML = document.getElementById("LittleRockTrojansML").innerHTML;
  var littlerocktrojansO = document.getElementById("LittleRockTrojansOU").innerHTML;
  var littlerocktrojansO = littlerocktrojansO.replace(/[',()]/g, "");
  var littlerocktrojansSoloO = document.getElementById("LittleRockTrojansSoloOU").innerHTML;
  var littlerocktrojansSoloO = littlerocktrojansSoloO.replace(/[',()]/g, "");
  var littlerocktrojansHalftime = document.getElementById("LittleRockTrojansHalftime").innerHTML;
  var littlerocktrojansHalftimeO = document.getElementById("LittleRockTrojansHalftimeOU").innerHTML;
  var littlerocktrojansHalftimeO = littlerocktrojansHalftimeO.replace(/[',()]/g, "");

  var arkansaspinebluffgoldenlionscover = document.getElementById("ArkansasPineBluffGoldenLionsCover").innerHTML;
  var arkansaspinebluffgoldenlionsML = document.getElementById("ArkansasPineBluffGoldenLionsML").innerHTML;
  var arkansaspinebluffgoldenlionsO = document.getElementById("ArkansasPineBluffGoldenLionsOU").innerHTML;
  var arkansaspinebluffgoldenlionsO = arkansaspinebluffgoldenlionsO.replace(/[',()]/g, "");
  var arkansaspinebluffgoldenlionsSoloO = document.getElementById("ArkansasPineBluffGoldenLionsSoloOU").innerHTML;
  var arkansaspinebluffgoldenlionsSoloO = arkansaspinebluffgoldenlionsSoloO.replace(/[',()]/g, "");
  var arkansaspinebluffgoldenlionsHalftime = document.getElementById("ArkansasPineBluffGoldenLionsHalftime").innerHTML;
  var arkansaspinebluffgoldenlionsHalftimeO = document.getElementById("ArkansasPineBluffGoldenLionsHalftimeOU").innerHTML;
  var arkansaspinebluffgoldenlionsHalftimeO = arkansaspinebluffgoldenlionsHalftimeO.replace(/[',()]/g, "");

  var arkansasstredwolvescover = document.getElementById("ArkansasStRedWolvesCover").innerHTML;
  var arkansasstredwolvesML = document.getElementById("ArkansasStRedWolvesML").innerHTML;
  var arkansasstredwolvesO = document.getElementById("ArkansasStRedWolvesOU").innerHTML;
  var arkansasstredwolvesO = arkansasstredwolvesO.replace(/[',()]/g, "");
  var arkansasstredwolvesSoloO = document.getElementById("ArkansasStRedWolvesSoloOU").innerHTML;
  var arkansasstredwolvesSoloO = arkansasstredwolvesSoloO.replace(/[',()]/g, "");
  var arkansasstredwolvesHalftime = document.getElementById("ArkansasStRedWolvesHalftime").innerHTML;
  var arkansasstredwolvesHalftimeO = document.getElementById("ArkansasStRedWolvesHalftimeOU").innerHTML;
  var arkansasstredwolvesHalftimeO = arkansasstredwolvesHalftimeO.replace(/[',()]/g, "");

  var auburntigerscover = document.getElementById("AuburnTigersCover").innerHTML;
  var auburntigersML = document.getElementById("AuburnTigersML").innerHTML;
  var auburntigersO = document.getElementById("AuburnTigersOU").innerHTML;
  var auburntigersO = auburntigersO.replace(/[',()]/g, "");
  var auburntigersSoloO = document.getElementById("AuburnTigersSoloOU").innerHTML;
  var auburntigersSoloO = auburntigersSoloO.replace(/[',()]/g, "");
  var auburntigersHalftime = document.getElementById("AuburnTigersHalftime").innerHTML;
  var auburntigersHalftimeO = document.getElementById("AuburnTigersHalftimeOU").innerHTML;
  var auburntigersHalftimeO = auburntigersHalftimeO.replace(/[',()]/g, "");

  var austinpeaygovernorscover = document.getElementById("AustinPeayGovernorsCover").innerHTML;
  var austinpeaygovernorsML = document.getElementById("AustinPeayGovernorsML").innerHTML;
  var austinpeaygovernorsO = document.getElementById("AustinPeayGovernorsOU").innerHTML;
  var austinpeaygovernorsO = austinpeaygovernorsO.replace(/[',()]/g, "");
  var austinpeaygovernorsSoloO = document.getElementById("AustinPeayGovernorsSoloOU").innerHTML;
  var austinpeaygovernorsSoloO = austinpeaygovernorsSoloO.replace(/[',()]/g, "");
  var austinpeaygovernorsHalftime = document.getElementById("AustinPeayGovernorsHalftime").innerHTML;
  var austinpeaygovernorsHalftimeO = document.getElementById("AustinPeayGovernorsHalftimeOU").innerHTML;
  var austinpeaygovernorsHalftimeO = austinpeaygovernorsHalftimeO.replace(/[',()]/g, "");

  var ballstatecardinalscover = document.getElementById("BallStateCardinalsCover").innerHTML;
  var ballstatecardinalsML = document.getElementById("BallStateCardinalsML").innerHTML;
  var ballstatecardinalsO = document.getElementById("BallStateCardinalsOU").innerHTML;
  var ballstatecardinalsO = ballstatecardinalsO.replace(/[',()]/g, "");
  var ballstatecardinalsSoloO = document.getElementById("BallStateCardinalsSoloOU").innerHTML;
  var ballstatecardinalsSoloO = ballstatecardinalsSoloO.replace(/[',()]/g, "");
  var ballstatecardinalsHalftime = document.getElementById("BallStateCardinalsHalftime").innerHTML;
  var ballstatecardinalsHalftimeO = document.getElementById("BallStateCardinalsHalftimeOU").innerHTML;
  var ballstatecardinalsHalftimeO = ballstatecardinalsHalftimeO.replace(/[',()]/g, "");

  var baylorbearscover = document.getElementById("BaylorBearsCover").innerHTML;
  var baylorbearsML = document.getElementById("BaylorBearsML").innerHTML;
  var baylorbearsO = document.getElementById("BaylorBearsOU").innerHTML;
  var baylorbearsO = baylorbearsO.replace(/[',()]/g, "");
  var baylorbearsSoloO = document.getElementById("BaylorBearsSoloOU").innerHTML;
  var baylorbearsSoloO = baylorbearsSoloO.replace(/[',()]/g, "");
  var baylorbearsHalftime = document.getElementById("BaylorBearsHalftime").innerHTML;
  var baylorbearsHalftimeO = document.getElementById("BaylorBearsHalftimeOU").innerHTML;
  var baylorbearsHalftimeO = baylorbearsHalftimeO.replace(/[',()]/g, "");

  var belmontbruinscover = document.getElementById("BelmontBruinsCover").innerHTML;
  var belmontbruinsML = document.getElementById("BelmontBruinsML").innerHTML;
  var belmontbruinsO = document.getElementById("BelmontBruinsOU").innerHTML;
  var belmontbruinsO = belmontbruinsO.replace(/[',()]/g, "");
  var belmontbruinsSoloO = document.getElementById("BelmontBruinsSoloOU").innerHTML;
  var belmontbruinsSoloO = belmontbruinsSoloO.replace(/[',()]/g, "");
  var belmontbruinsHalftime = document.getElementById("BelmontBruinsHalftime").innerHTML;
  var belmontbruinsHalftimeO = document.getElementById("BelmontBruinsHalftimeOU").innerHTML;
  var belmontbruinsHalftimeO = belmontbruinsHalftimeO.replace(/[',()]/g, "");

  var bethunecookmanwildcatscover = document.getElementById("BethuneCookmanWildcatsCover").innerHTML;
  var bethunecookmanwildcatsML = document.getElementById("BethuneCookmanWildcatsML").innerHTML;
  var bethunecookmanwildcatsO = document.getElementById("BethuneCookmanWildcatsOU").innerHTML;
  var bethunecookmanwildcatsO = bethunecookmanwildcatsO.replace(/[',()]/g, "");
  var bethunecookmanwildcatsSoloO = document.getElementById("BethuneCookmanWildcatsSoloOU").innerHTML;
  var bethunecookmanwildcatsSoloO = bethunecookmanwildcatsSoloO.replace(/[',()]/g, "");
  var bethunecookmanwildcatsHalftime = document.getElementById("BethuneCookmanWildcatsHalftime").innerHTML;
  var bethunecookmanwildcatsHalftimeO = document.getElementById("BethuneCookmanWildcatsHalftimeOU").innerHTML;
  var bethunecookmanwildcatsHalftimeO = bethunecookmanwildcatsHalftimeO.replace(/[',()]/g, "");

  var binghamtonbearcatscover = document.getElementById("BinghamtonBearcatsCover").innerHTML;
  var binghamtonbearcatsML = document.getElementById("BinghamtonBearcatsML").innerHTML;
  var binghamtonbearcatsO = document.getElementById("BinghamtonBearcatsOU").innerHTML;
  var binghamtonbearcatsO = binghamtonbearcatsO.replace(/[',()]/g, "");
  var binghamtonbearcatsSoloO = document.getElementById("BinghamtonBearcatsSoloOU").innerHTML;
  var binghamtonbearcatsSoloO = binghamtonbearcatsSoloO.replace(/[',()]/g, "");
  var binghamtonbearcatsHalftime = document.getElementById("BinghamtonBearcatsHalftime").innerHTML;
  var binghamtonbearcatsHalftimeO = document.getElementById("BinghamtonBearcatsHalftimeOU").innerHTML;
  var binghamtonbearcatsHalftimeO = binghamtonbearcatsHalftimeO.replace(/[',()]/g, "");

  var boisestatebroncoscover = document.getElementById("BoiseStateBroncosCover").innerHTML;
  var boisestatebroncosML = document.getElementById("BoiseStateBroncosML").innerHTML;
  var boisestatebroncosO = document.getElementById("BoiseStateBroncosOU").innerHTML;
  var boisestatebroncosO = boisestatebroncosO.replace(/[',()]/g, "");
  var boisestatebroncosSoloO = document.getElementById("BoiseStateBroncosSoloOU").innerHTML;
  var boisestatebroncosSoloO = boisestatebroncosSoloO.replace(/[',()]/g, "");
  var boisestatebroncosHalftime = document.getElementById("BoiseStateBroncosHalftime").innerHTML;
  var boisestatebroncosHalftimeO = document.getElementById("BoiseStateBroncosHalftimeOU").innerHTML;
  var boisestatebroncosHalftimeO = boisestatebroncosHalftimeO.replace(/[',()]/g, "");

  var bostoncollegeeaglescover = document.getElementById("BostonCollegeEaglesCover").innerHTML;
  var bostoncollegeeaglesML = document.getElementById("BostonCollegeEaglesML").innerHTML;
  var bostoncollegeeaglesO = document.getElementById("BostonCollegeEaglesOU").innerHTML;
  var bostoncollegeeaglesO = bostoncollegeeaglesO.replace(/[',()]/g, "");
  var bostoncollegeeaglesSoloO = document.getElementById("BostonCollegeEaglesSoloOU").innerHTML;
  var bostoncollegeeaglesSoloO = bostoncollegeeaglesSoloO.replace(/[',()]/g, "");
  var bostoncollegeeaglesHalftime = document.getElementById("BostonCollegeEaglesHalftime").innerHTML;
  var bostoncollegeeaglesHalftimeO = document.getElementById("BostonCollegeEaglesHalftimeOU").innerHTML;
  var bostoncollegeeaglesHalftimeO = bostoncollegeeaglesHalftimeO.replace(/[',()]/g, "");

  var bostonunivterrierscover = document.getElementById("BostonUnivTerriersCover").innerHTML;
  var bostonunivterriersML = document.getElementById("BostonUnivTerriersML").innerHTML;
  var bostonunivterriersO = document.getElementById("BostonUnivTerriersOU").innerHTML;
  var bostonunivterriersO = bostonunivterriersO.replace(/[',()]/g, "");
  var bostonunivterriersSoloO = document.getElementById("BostonUnivTerriersSoloOU").innerHTML;
  var bostonunivterriersSoloO = bostonunivterriersSoloO.replace(/[',()]/g, "");
  var bostonunivterriersHalftime = document.getElementById("BostonUnivTerriersHalftime").innerHTML;
  var bostonunivterriersHalftimeO = document.getElementById("BostonUnivTerriersHalftimeOU").innerHTML;
  var bostonunivterriersHalftimeO = bostonunivterriersHalftimeO.replace(/[',()]/g, "");

  var bowlinggreenfalconscover = document.getElementById("BowlingGreenFalconsCover").innerHTML;
  var bowlinggreenfalconsML = document.getElementById("BowlingGreenFalconsML").innerHTML;
  var bowlinggreenfalconsO = document.getElementById("BowlingGreenFalconsOU").innerHTML;
  var bowlinggreenfalconsO = bowlinggreenfalconsO.replace(/[',()]/g, "");
  var bowlinggreenfalconsSoloO = document.getElementById("BowlingGreenFalconsSoloOU").innerHTML;
  var bowlinggreenfalconsSoloO = bowlinggreenfalconsSoloO.replace(/[',()]/g, "");
  var bowlinggreenfalconsHalftime = document.getElementById("BowlingGreenFalconsHalftime").innerHTML;
  var bowlinggreenfalconsHalftimeO = document.getElementById("BowlingGreenFalconsHalftimeOU").innerHTML;
  var bowlinggreenfalconsHalftimeO = bowlinggreenfalconsHalftimeO.replace(/[',()]/g, "");

  var bradleybravescover = document.getElementById("BradleyBravesCover").innerHTML;
  var bradleybravesML = document.getElementById("BradleyBravesML").innerHTML;
  var bradleybravesO = document.getElementById("BradleyBravesOU").innerHTML;
  var bradleybravesO = bradleybravesO.replace(/[',()]/g, "");
  var bradleybravesSoloO = document.getElementById("BradleyBravesSoloOU").innerHTML;
  var bradleybravesSoloO = bradleybravesSoloO.replace(/[',()]/g, "");
  var bradleybravesHalftime = document.getElementById("BradleyBravesHalftime").innerHTML;
  var bradleybravesHalftimeO = document.getElementById("BradleyBravesHalftimeOU").innerHTML;
  var bradleybravesHalftimeO = bradleybravesHalftimeO.replace(/[',()]/g, "");

  var byucougarscover = document.getElementById("BYUCougarsCover").innerHTML;
  var byucougarsML = document.getElementById("BYUCougarsML").innerHTML;
  var byucougarsO = document.getElementById("BYUCougarsOU").innerHTML;
  var byucougarsO = byucougarsO.replace(/[',()]/g, "");
  var byucougarsSoloO = document.getElementById("BYUCougarsSoloOU").innerHTML;
  var byucougarsSoloO = byucougarsSoloO.replace(/[',()]/g, "");
  var byucougarsHalftime = document.getElementById("BYUCougarsHalftime").innerHTML;
  var byucougarsHalftimeO = document.getElementById("BYUCougarsHalftimeOU").innerHTML;
  var byucougarsHalftimeO = byucougarsHalftimeO.replace(/[',()]/g, "");

  var brownbearscover = document.getElementById("BrownBearsCover").innerHTML;
  var brownbearsML = document.getElementById("BrownBearsML").innerHTML;
  var brownbearsO = document.getElementById("BrownBearsOU").innerHTML;
  var brownbearsO = brownbearsO.replace(/[',()]/g, "");
  var brownbearsSoloO = document.getElementById("BrownBearsSoloOU").innerHTML;
  var brownbearsSoloO = brownbearsSoloO.replace(/[',()]/g, "");
  var brownbearsHalftime = document.getElementById("BrownBearsHalftime").innerHTML;
  var brownbearsHalftimeO = document.getElementById("BrownBearsHalftimeOU").innerHTML;
  var brownbearsHalftimeO = brownbearsHalftimeO.replace(/[',()]/g, "");

  var bryantbulldogscover = document.getElementById("BryantBulldogsCover").innerHTML;
  var bryantbulldogsML = document.getElementById("BryantBulldogsML").innerHTML;
  var bryantbulldogsO = document.getElementById("BryantBulldogsOU").innerHTML;
  var bryantbulldogsO = bryantbulldogsO.replace(/[',()]/g, "");
  var bryantbulldogsSoloO = document.getElementById("BryantBulldogsSoloOU").innerHTML;
  var bryantbulldogsSoloO = bryantbulldogsSoloO.replace(/[',()]/g, "");
  var bryantbulldogsHalftime = document.getElementById("BryantBulldogsHalftime").innerHTML;
  var bryantbulldogsHalftimeO = document.getElementById("BryantBulldogsHalftimeOU").innerHTML;
  var bryantbulldogsHalftimeO = bryantbulldogsHalftimeO.replace(/[',()]/g, "");

  var bucknellbisoncover = document.getElementById("BucknellBisonCover").innerHTML;
  var bucknellbisonML = document.getElementById("BucknellBisonML").innerHTML;
  var bucknellbisonO = document.getElementById("BucknellBisonOU").innerHTML;
  var bucknellbisonO = bucknellbisonO.replace(/[',()]/g, "");
  var bucknellbisonSoloO = document.getElementById("BucknellBisonSoloOU").innerHTML;
  var bucknellbisonSoloO = bucknellbisonSoloO.replace(/[',()]/g, "");
  var bucknellbisonHalftime = document.getElementById("BucknellBisonHalftime").innerHTML;
  var bucknellbisonHalftimeO = document.getElementById("BucknellBisonHalftimeOU").innerHTML;
  var bucknellbisonHalftimeO = bucknellbisonHalftimeO.replace(/[',()]/g, "");

  var buffalobullscover = document.getElementById("BuffaloBullsCover").innerHTML;
  var buffalobullsML = document.getElementById("BuffaloBullsML").innerHTML;
  var buffalobullsO = document.getElementById("BuffaloBullsOU").innerHTML;
  var buffalobullsO = buffalobullsO.replace(/[',()]/g, "");
  var buffalobullsSoloO = document.getElementById("BuffaloBullsSoloOU").innerHTML;
  var buffalobullsSoloO = buffalobullsSoloO.replace(/[',()]/g, "");
  var buffalobullsHalftime = document.getElementById("BuffaloBullsHalftime").innerHTML;
  var buffalobullsHalftimeO = document.getElementById("BuffaloBullsHalftimeOU").innerHTML;
  var buffalobullsHalftimeO = buffalobullsHalftimeO.replace(/[',()]/g, "");

  var butlerbulldogscover = document.getElementById("ButlerBulldogsCover").innerHTML;
  var butlerbulldogsML = document.getElementById("ButlerBulldogsML").innerHTML;
  var butlerbulldogsO = document.getElementById("ButlerBulldogsOU").innerHTML;
  var butlerbulldogsO = butlerbulldogsO.replace(/[',()]/g, "");
  var butlerbulldogsSoloO = document.getElementById("ButlerBulldogsSoloOU").innerHTML;
  var butlerbulldogsSoloO = butlerbulldogsSoloO.replace(/[',()]/g, "");
  var butlerbulldogsHalftime = document.getElementById("ButlerBulldogsHalftime").innerHTML;
  var butlerbulldogsHalftimeO = document.getElementById("ButlerBulldogsHalftimeOU").innerHTML;
  var butlerbulldogsHalftimeO = butlerbulldogsHalftimeO.replace(/[',()]/g, "");

  var californiagoldenbearscover = document.getElementById("CaliforniaGoldenBearsCover").innerHTML;
  var californiagoldenbearsML = document.getElementById("CaliforniaGoldenBearsML").innerHTML;
  var californiagoldenbearsO = document.getElementById("CaliforniaGoldenBearsOU").innerHTML;
  var californiagoldenbearsO = californiagoldenbearsO.replace(/[',()]/g, "");
  var californiagoldenbearsSoloO = document.getElementById("CaliforniaGoldenBearsSoloOU").innerHTML;
  var californiagoldenbearsSoloO = californiagoldenbearsSoloO.replace(/[',()]/g, "");
  var californiagoldenbearsHalftime = document.getElementById("CaliforniaGoldenBearsHalftime").innerHTML;
  var californiagoldenbearsHalftimeO = document.getElementById("CaliforniaGoldenBearsHalftimeOU").innerHTML;
  var californiagoldenbearsHalftimeO = californiagoldenbearsHalftimeO.replace(/[',()]/g, "");

  var ucdavisaggiescover = document.getElementById("UCDavisAggiesCover").innerHTML;
  var ucdavisaggiesML = document.getElementById("UCDavisAggiesML").innerHTML;
  var ucdavisaggiesO = document.getElementById("UCDavisAggiesOU").innerHTML;
  var ucdavisaggiesO = ucdavisaggiesO.replace(/[',()]/g, "");
  var ucdavisaggiesSoloO = document.getElementById("UCDavisAggiesSoloOU").innerHTML;
  var ucdavisaggiesSoloO = ucdavisaggiesSoloO.replace(/[',()]/g, "");
  var ucdavisaggiesHalftime = document.getElementById("UCDavisAggiesHalftime").innerHTML;
  var ucdavisaggiesHalftimeO = document.getElementById("UCDavisAggiesHalftimeOU").innerHTML;
  var ucdavisaggiesHalftimeO = ucdavisaggiesHalftimeO.replace(/[',()]/g, "");

  var ucirvineanteaterscover = document.getElementById("UCIrvineAnteatersCover").innerHTML;
  var ucirvineanteatersML = document.getElementById("UCIrvineAnteatersML").innerHTML;
  var ucirvineanteatersO = document.getElementById("UCIrvineAnteatersOU").innerHTML;
  var ucirvineanteatersO = ucirvineanteatersO.replace(/[',()]/g, "");
  var ucirvineanteatersSoloO = document.getElementById("UCIrvineAnteatersSoloOU").innerHTML;
  var ucirvineanteatersSoloO = ucirvineanteatersSoloO.replace(/[',()]/g, "");
  var ucirvineanteatersHalftime = document.getElementById("UCIrvineAnteatersHalftime").innerHTML;
  var ucirvineanteatersHalftimeO = document.getElementById("UCIrvineAnteatersHalftimeOU").innerHTML;
  var ucirvineanteatersHalftimeO = ucirvineanteatersHalftimeO.replace(/[',()]/g, "");

  var uclabruinscover = document.getElementById("UCLABruinsCover").innerHTML;
  var uclabruinsML = document.getElementById("UCLABruinsML").innerHTML;
  var uclabruinsO = document.getElementById("UCLABruinsOU").innerHTML;
  var uclabruinsO = uclabruinsO.replace(/[',()]/g, "");
  var uclabruinsSoloO = document.getElementById("UCLABruinsSoloOU").innerHTML;
  var uclabruinsSoloO = uclabruinsSoloO.replace(/[',()]/g, "");
  var uclabruinsHalftime = document.getElementById("UCLABruinsHalftime").innerHTML;
  var uclabruinsHalftimeO = document.getElementById("UCLABruinsHalftimeOU").innerHTML;
  var uclabruinsHalftimeO = uclabruinsHalftimeO.replace(/[',()]/g, "");

  var calpolymustangscover = document.getElementById("CalPolyMustangsCover").innerHTML;
  var calpolymustangsML = document.getElementById("CalPolyMustangsML").innerHTML;
  var calpolymustangsO = document.getElementById("CalPolyMustangsOU").innerHTML;
  var calpolymustangsO = calpolymustangsO.replace(/[',()]/g, "");
  var calpolymustangsSoloO = document.getElementById("CalPolyMustangsSoloOU").innerHTML;
  var calpolymustangsSoloO = calpolymustangsSoloO.replace(/[',()]/g, "");
  var calpolymustangsHalftime = document.getElementById("CalPolyMustangsHalftime").innerHTML;
  var calpolymustangsHalftimeO = document.getElementById("CalPolyMustangsHalftimeOU").innerHTML;
  var calpolymustangsHalftimeO = calpolymustangsHalftimeO.replace(/[',()]/g, "");

  var ucriversidehighlanderscover = document.getElementById("UCRiversideHighlandersCover").innerHTML;
  var ucriversidehighlandersML = document.getElementById("UCRiversideHighlandersML").innerHTML;
  var ucriversidehighlandersO = document.getElementById("UCRiversideHighlandersOU").innerHTML;
  var ucriversidehighlandersO = ucriversidehighlandersO.replace(/[',()]/g, "");
  var ucriversidehighlandersSoloO = document.getElementById("UCRiversideHighlandersSoloOU").innerHTML;
  var ucriversidehighlandersSoloO = ucriversidehighlandersSoloO.replace(/[',()]/g, "");
  var ucriversidehighlandersHalftime = document.getElementById("UCRiversideHighlandersHalftime").innerHTML;
  var ucriversidehighlandersHalftimeO = document.getElementById("UCRiversideHighlandersHalftimeOU").innerHTML;
  var ucriversidehighlandersHalftimeO = ucriversidehighlandersHalftimeO.replace(/[',()]/g, "");

  var ucsantabarbaragauchoscover = document.getElementById("UCSantaBarbaraGauchosCover").innerHTML;
  var ucsantabarbaragauchosML = document.getElementById("UCSantaBarbaraGauchosML").innerHTML;
  var ucsantabarbaragauchosO = document.getElementById("UCSantaBarbaraGauchosOU").innerHTML;
  var ucsantabarbaragauchosO = ucsantabarbaragauchosO.replace(/[',()]/g, "");
  var ucsantabarbaragauchosSoloO = document.getElementById("UCSantaBarbaraGauchosSoloOU").innerHTML;
  var ucsantabarbaragauchosSoloO = ucsantabarbaragauchosSoloO.replace(/[',()]/g, "");
  var ucsantabarbaragauchosHalftime = document.getElementById("UCSantaBarbaraGauchosHalftime").innerHTML;
  var ucsantabarbaragauchosHalftimeO = document.getElementById("UCSantaBarbaraGauchosHalftimeOU").innerHTML;
  var ucsantabarbaragauchosHalftimeO = ucsantabarbaragauchosHalftimeO.replace(/[',()]/g, "");

  var csubakersfieldroadrunnerscover = document.getElementById("CSUBakersfieldRoadrunnersCover").innerHTML;
  var csubakersfieldroadrunnersML = document.getElementById("CSUBakersfieldRoadrunnersML").innerHTML;
  var csubakersfieldroadrunnersO = document.getElementById("CSUBakersfieldRoadrunnersOU").innerHTML;
  var csubakersfieldroadrunnersO = csubakersfieldroadrunnersO.replace(/[',()]/g, "");
  var csubakersfieldroadrunnersSoloO = document.getElementById("CSUBakersfieldRoadrunnersSoloOU").innerHTML;
  var csubakersfieldroadrunnersSoloO = csubakersfieldroadrunnersSoloO.replace(/[',()]/g, "");
  var csubakersfieldroadrunnersHalftime = document.getElementById("CSUBakersfieldRoadrunnersHalftime").innerHTML;
  var csubakersfieldroadrunnersHalftimeO = document.getElementById("CSUBakersfieldRoadrunnersHalftimeOU").innerHTML;
  var csubakersfieldroadrunnersHalftimeO = csubakersfieldroadrunnersHalftimeO.replace(/[',()]/g, "");

  var fresnostatebulldogscover = document.getElementById("FresnoStateBulldogsCover").innerHTML;
  var fresnostatebulldogsML = document.getElementById("FresnoStateBulldogsML").innerHTML;
  var fresnostatebulldogsO = document.getElementById("FresnoStateBulldogsOU").innerHTML;
  var fresnostatebulldogsO = fresnostatebulldogsO.replace(/[',()]/g, "");
  var fresnostatebulldogsSoloO = document.getElementById("FresnoStateBulldogsSoloOU").innerHTML;
  var fresnostatebulldogsSoloO = fresnostatebulldogsSoloO.replace(/[',()]/g, "");
  var fresnostatebulldogsHalftime = document.getElementById("FresnoStateBulldogsHalftime").innerHTML;
  var fresnostatebulldogsHalftimeO = document.getElementById("FresnoStateBulldogsHalftimeOU").innerHTML;
  var fresnostatebulldogsHalftimeO = fresnostatebulldogsHalftimeO.replace(/[',()]/g, "");

  var csufullertontitanscover = document.getElementById("CSUFullertonTitansCover").innerHTML;
  var csufullertontitansML = document.getElementById("CSUFullertonTitansML").innerHTML;
  var csufullertontitansO = document.getElementById("CSUFullertonTitansOU").innerHTML;
  var csufullertontitansO = csufullertontitansO.replace(/[',()]/g, "");
  var csufullertontitansSoloO = document.getElementById("CSUFullertonTitansSoloOU").innerHTML;
  var csufullertontitansSoloO = csufullertontitansSoloO.replace(/[',()]/g, "");
  var csufullertontitansHalftime = document.getElementById("CSUFullertonTitansHalftime").innerHTML;
  var csufullertontitansHalftimeO = document.getElementById("CSUFullertonTitansHalftimeOU").innerHTML;
  var csufullertontitansHalftimeO = csufullertontitansHalftimeO.replace(/[',()]/g, "");

  var longbeachstate49erscover = document.getElementById("LongBeachState49ersCover").innerHTML;
  var longbeachstate49ersML = document.getElementById("LongBeachState49ersML").innerHTML;
  var longbeachstate49ersO = document.getElementById("LongBeachState49ersOU").innerHTML;
  var longbeachstate49ersO = longbeachstate49ersO.replace(/[',()]/g, "");
  var longbeachstate49ersSoloO = document.getElementById("LongBeachState49ersSoloOU").innerHTML;
  var longbeachstate49ersSoloO = longbeachstate49ersSoloO.replace(/[',()]/g, "");
  var longbeachstate49ersHalftime = document.getElementById("LongBeachState49ersHalftime").innerHTML;
  var longbeachstate49ersHalftimeO = document.getElementById("LongBeachState49ersHalftimeOU").innerHTML;
  var longbeachstate49ersHalftimeO = longbeachstate49ersHalftimeO.replace(/[',()]/g, "");

  var csunorthridgematadorscover = document.getElementById("CSUNorthridgeMatadorsCover").innerHTML;
  var csunorthridgematadorsML = document.getElementById("CSUNorthridgeMatadorsML").innerHTML;
  var csunorthridgematadorsO = document.getElementById("CSUNorthridgeMatadorsOU").innerHTML;
  var csunorthridgematadorsO = csunorthridgematadorsO.replace(/[',()]/g, "");
  var csunorthridgematadorsSoloO = document.getElementById("CSUNorthridgeMatadorsSoloOU").innerHTML;
  var csunorthridgematadorsSoloO = csunorthridgematadorsSoloO.replace(/[',()]/g, "");
  var csunorthridgematadorsHalftime = document.getElementById("CSUNorthridgeMatadorsHalftime").innerHTML;
  var csunorthridgematadorsHalftimeO = document.getElementById("CSUNorthridgeMatadorsHalftimeOU").innerHTML;
  var csunorthridgematadorsHalftimeO = csunorthridgematadorsHalftimeO.replace(/[',()]/g, "");

  var sacramentostatehornetscover = document.getElementById("SacramentoStateHornetsCover").innerHTML;
  var sacramentostatehornetsML = document.getElementById("SacramentoStateHornetsML").innerHTML;
  var sacramentostatehornetsO = document.getElementById("SacramentoStateHornetsOU").innerHTML;
  var sacramentostatehornetsO = sacramentostatehornetsO.replace(/[',()]/g, "");
  var sacramentostatehornetsSoloO = document.getElementById("SacramentoStateHornetsSoloOU").innerHTML;
  var sacramentostatehornetsSoloO = sacramentostatehornetsSoloO.replace(/[',()]/g, "");
  var sacramentostatehornetsHalftime = document.getElementById("SacramentoStateHornetsHalftime").innerHTML;
  var sacramentostatehornetsHalftimeO = document.getElementById("SacramentoStateHornetsHalftimeOU").innerHTML;
  var sacramentostatehornetsHalftimeO = sacramentostatehornetsHalftimeO.replace(/[',()]/g, "");

  var campbellfightingcamelscover = document.getElementById("CampbellFightingCamelsCover").innerHTML;
  var campbellfightingcamelsML = document.getElementById("CampbellFightingCamelsML").innerHTML;
  var campbellfightingcamelsO = document.getElementById("CampbellFightingCamelsOU").innerHTML;
  var campbellfightingcamelsO = campbellfightingcamelsO.replace(/[',()]/g, "");
  var campbellfightingcamelsSoloO = document.getElementById("CampbellFightingCamelsSoloOU").innerHTML;
  var campbellfightingcamelsSoloO = campbellfightingcamelsSoloO.replace(/[',()]/g, "");
  var campbellfightingcamelsHalftime = document.getElementById("CampbellFightingCamelsHalftime").innerHTML;
  var campbellfightingcamelsHalftimeO = document.getElementById("CampbellFightingCamelsHalftimeOU").innerHTML;
  var campbellfightingcamelsHalftimeO = campbellfightingcamelsHalftimeO.replace(/[',()]/g, "");

  var canisiusgoldengriffinscover = document.getElementById("CanisiusGoldenGriffinsCover").innerHTML;
  var canisiusgoldengriffinsML = document.getElementById("CanisiusGoldenGriffinsML").innerHTML;
  var canisiusgoldengriffinsO = document.getElementById("CanisiusGoldenGriffinsOU").innerHTML;
  var canisiusgoldengriffinsO = canisiusgoldengriffinsO.replace(/[',()]/g, "");
  var canisiusgoldengriffinsSoloO = document.getElementById("CanisiusGoldenGriffinsSoloOU").innerHTML;
  var canisiusgoldengriffinsSoloO = canisiusgoldengriffinsSoloO.replace(/[',()]/g, "");
  var canisiusgoldengriffinsHalftime = document.getElementById("CanisiusGoldenGriffinsHalftime").innerHTML;
  var canisiusgoldengriffinsHalftimeO = document.getElementById("CanisiusGoldenGriffinsHalftimeOU").innerHTML;
  var canisiusgoldengriffinsHalftimeO = canisiusgoldengriffinsHalftimeO.replace(/[',()]/g, "");

  var centralarkansasbearscover = document.getElementById("CentralArkansasBearsCover").innerHTML;
  var centralarkansasbearsML = document.getElementById("CentralArkansasBearsML").innerHTML;
  var centralarkansasbearsO = document.getElementById("CentralArkansasBearsOU").innerHTML;
  var centralarkansasbearsO = centralarkansasbearsO.replace(/[',()]/g, "");
  var centralarkansasbearsSoloO = document.getElementById("CentralArkansasBearsSoloOU").innerHTML;
  var centralarkansasbearsSoloO = centralarkansasbearsSoloO.replace(/[',()]/g, "");
  var centralarkansasbearsHalftime = document.getElementById("CentralArkansasBearsHalftime").innerHTML;
  var centralarkansasbearsHalftimeO = document.getElementById("CentralArkansasBearsHalftimeOU").innerHTML;
  var centralarkansasbearsHalftimeO = centralarkansasbearsHalftimeO.replace(/[',()]/g, "");

  var centralconnecticutbluedevilscover = document.getElementById("CentralConnecticutBlueDevilsCover").innerHTML;
  var centralconnecticutbluedevilsML = document.getElementById("CentralConnecticutBlueDevilsML").innerHTML;
  var centralconnecticutbluedevilsO = document.getElementById("CentralConnecticutBlueDevilsOU").innerHTML;
  var centralconnecticutbluedevilsO = centralconnecticutbluedevilsO.replace(/[',()]/g, "");
  var centralconnecticutbluedevilsSoloO = document.getElementById("CentralConnecticutBlueDevilsSoloOU").innerHTML;
  var centralconnecticutbluedevilsSoloO = centralconnecticutbluedevilsSoloO.replace(/[',()]/g, "");
  var centralconnecticutbluedevilsHalftime = document.getElementById("CentralConnecticutBlueDevilsHalftime").innerHTML;
  var centralconnecticutbluedevilsHalftimeO = document.getElementById("CentralConnecticutBlueDevilsHalftimeOU").innerHTML;
  var centralconnecticutbluedevilsHalftimeO = centralconnecticutbluedevilsHalftimeO.replace(/[',()]/g, "");

  var ucfknightscover = document.getElementById("UCFKnightsCover").innerHTML;
  var ucfknightsML = document.getElementById("UCFKnightsML").innerHTML;
  var ucfknightsO = document.getElementById("UCFKnightsOU").innerHTML;
  var ucfknightsO = ucfknightsO.replace(/[',()]/g, "");
  var ucfknightsSoloO = document.getElementById("UCFKnightsSoloOU").innerHTML;
  var ucfknightsSoloO = ucfknightsSoloO.replace(/[',()]/g, "");
  var ucfknightsHalftime = document.getElementById("UCFKnightsHalftime").innerHTML;
  var ucfknightsHalftimeO = document.getElementById("UCFKnightsHalftimeOU").innerHTML;
  var ucfknightsHalftimeO = ucfknightsHalftimeO.replace(/[',()]/g, "");

  var centralmichiganchippewascover = document.getElementById("CentralMichiganChippewasCover").innerHTML;
  var centralmichiganchippewasML = document.getElementById("CentralMichiganChippewasML").innerHTML;
  var centralmichiganchippewasO = document.getElementById("CentralMichiganChippewasOU").innerHTML;
  var centralmichiganchippewasO = centralmichiganchippewasO.replace(/[',()]/g, "");
  var centralmichiganchippewasSoloO = document.getElementById("CentralMichiganChippewasSoloOU").innerHTML;
  var centralmichiganchippewasSoloO = centralmichiganchippewasSoloO.replace(/[',()]/g, "");
  var centralmichiganchippewasHalftime = document.getElementById("CentralMichiganChippewasHalftime").innerHTML;
  var centralmichiganchippewasHalftimeO = document.getElementById("CentralMichiganChippewasHalftimeOU").innerHTML;
  var centralmichiganchippewasHalftimeO = centralmichiganchippewasHalftimeO.replace(/[',()]/g, "");

  var charlestoncougarscover = document.getElementById("CharlestonCougarsCover").innerHTML;
  var charlestoncougarsML = document.getElementById("CharlestonCougarsML").innerHTML;
  var charlestoncougarsO = document.getElementById("CharlestonCougarsOU").innerHTML;
  var charlestoncougarsO = charlestoncougarsO.replace(/[',()]/g, "");
  var charlestoncougarsSoloO = document.getElementById("CharlestonCougarsSoloOU").innerHTML;
  var charlestoncougarsSoloO = charlestoncougarsSoloO.replace(/[',()]/g, "");
  var charlestoncougarsHalftime = document.getElementById("CharlestonCougarsHalftime").innerHTML;
  var charlestoncougarsHalftimeO = document.getElementById("CharlestonCougarsHalftimeOU").innerHTML;
  var charlestoncougarsHalftimeO = charlestoncougarsHalftimeO.replace(/[',()]/g, "");

  var charlestonsouthernbuccaneerscover = document.getElementById("CharlestonSouthernBuccaneersCover").innerHTML;
  var charlestonsouthernbuccaneersML = document.getElementById("CharlestonSouthernBuccaneersML").innerHTML;
  var charlestonsouthernbuccaneersO = document.getElementById("CharlestonSouthernBuccaneersOU").innerHTML;
  var charlestonsouthernbuccaneersO = charlestonsouthernbuccaneersO.replace(/[',()]/g, "");
  var charlestonsouthernbuccaneersSoloO = document.getElementById("CharlestonSouthernBuccaneersSoloOU").innerHTML;
  var charlestonsouthernbuccaneersSoloO = charlestonsouthernbuccaneersSoloO.replace(/[',()]/g, "");
  var charlestonsouthernbuccaneersHalftime = document.getElementById("CharlestonSouthernBuccaneersHalftime").innerHTML;
  var charlestonsouthernbuccaneersHalftimeO = document.getElementById("CharlestonSouthernBuccaneersHalftimeOU").innerHTML;
  var charlestonsouthernbuccaneersHalftimeO = charlestonsouthernbuccaneersHalftimeO.replace(/[',()]/g, "");

  var chicagostatecougarscover = document.getElementById("ChicagoStateCougarsCover").innerHTML;
  var chicagostatecougarsML = document.getElementById("ChicagoStateCougarsML").innerHTML;
  var chicagostatecougarsO = document.getElementById("ChicagoStateCougarsOU").innerHTML;
  var chicagostatecougarsO = chicagostatecougarsO.replace(/[',()]/g, "");
  var chicagostatecougarsSoloO = document.getElementById("ChicagoStateCougarsSoloOU").innerHTML;
  var chicagostatecougarsSoloO = chicagostatecougarsSoloO.replace(/[',()]/g, "");
  var chicagostatecougarsHalftime = document.getElementById("ChicagoStateCougarsHalftime").innerHTML;
  var chicagostatecougarsHalftimeO = document.getElementById("ChicagoStateCougarsHalftimeOU").innerHTML;
  var chicagostatecougarsHalftimeO = chicagostatecougarsHalftimeO.replace(/[',()]/g, "");

  var cincinnatibearcatscover = document.getElementById("CincinnatiBearcatsCover").innerHTML;
  var cincinnatibearcatsML = document.getElementById("CincinnatiBearcatsML").innerHTML;
  var cincinnatibearcatsO = document.getElementById("CincinnatiBearcatsOU").innerHTML;
  var cincinnatibearcatsO = cincinnatibearcatsO.replace(/[',()]/g, "");
  var cincinnatibearcatsSoloO = document.getElementById("CincinnatiBearcatsSoloOU").innerHTML;
  var cincinnatibearcatsSoloO = cincinnatibearcatsSoloO.replace(/[',()]/g, "");
  var cincinnatibearcatsHalftime = document.getElementById("CincinnatiBearcatsHalftime").innerHTML;
  var cincinnatibearcatsHalftimeO = document.getElementById("CincinnatiBearcatsHalftimeOU").innerHTML;
  var cincinnatibearcatsHalftimeO = cincinnatibearcatsHalftimeO.replace(/[',()]/g, "");

  var thecitadelbulldogscover = document.getElementById("TheCitadelBulldogsCover").innerHTML;
  var thecitadelbulldogsML = document.getElementById("TheCitadelBulldogsML").innerHTML;
  var thecitadelbulldogsO = document.getElementById("TheCitadelBulldogsOU").innerHTML;
  var thecitadelbulldogsO = thecitadelbulldogsO.replace(/[',()]/g, "");
  var thecitadelbulldogsSoloO = document.getElementById("TheCitadelBulldogsSoloOU").innerHTML;
  var thecitadelbulldogsSoloO = thecitadelbulldogsSoloO.replace(/[',()]/g, "");
  var thecitadelbulldogsHalftime = document.getElementById("TheCitadelBulldogsHalftime").innerHTML;
  var thecitadelbulldogsHalftimeO = document.getElementById("TheCitadelBulldogsHalftimeOU").innerHTML;
  var thecitadelbulldogsHalftimeO = thecitadelbulldogsHalftimeO.replace(/[',()]/g, "");

  var clemsontigerscover = document.getElementById("ClemsonTigersCover").innerHTML;
  var clemsontigersML = document.getElementById("ClemsonTigersML").innerHTML;
  var clemsontigersO = document.getElementById("ClemsonTigersOU").innerHTML;
  var clemsontigersO = clemsontigersO.replace(/[',()]/g, "");
  var clemsontigersSoloO = document.getElementById("ClemsonTigersSoloOU").innerHTML;
  var clemsontigersSoloO = clemsontigersSoloO.replace(/[',()]/g, "");
  var clemsontigersHalftime = document.getElementById("ClemsonTigersHalftime").innerHTML;
  var clemsontigersHalftimeO = document.getElementById("ClemsonTigersHalftimeOU").innerHTML;
  var clemsontigersHalftimeO = clemsontigersHalftimeO.replace(/[',()]/g, "");

  var clevelandstatevikingscover = document.getElementById("ClevelandStateVikingsCover").innerHTML;
  var clevelandstatevikingsML = document.getElementById("ClevelandStateVikingsML").innerHTML;
  var clevelandstatevikingsO = document.getElementById("ClevelandStateVikingsOU").innerHTML;
  var clevelandstatevikingsO = clevelandstatevikingsO.replace(/[',()]/g, "");
  var clevelandstatevikingsSoloO = document.getElementById("ClevelandStateVikingsSoloOU").innerHTML;
  var clevelandstatevikingsSoloO = clevelandstatevikingsSoloO.replace(/[',()]/g, "");
  var clevelandstatevikingsHalftime = document.getElementById("ClevelandStateVikingsHalftime").innerHTML;
  var clevelandstatevikingsHalftimeO = document.getElementById("ClevelandStateVikingsHalftimeOU").innerHTML;
  var clevelandstatevikingsHalftimeO = clevelandstatevikingsHalftimeO.replace(/[',()]/g, "");

  var coastalcarolinachanticleerscover = document.getElementById("CoastalCarolinaChanticleersCover").innerHTML;
  var coastalcarolinachanticleersML = document.getElementById("CoastalCarolinaChanticleersML").innerHTML;
  var coastalcarolinachanticleersO = document.getElementById("CoastalCarolinaChanticleersOU").innerHTML;
  var coastalcarolinachanticleersO = coastalcarolinachanticleersO.replace(/[',()]/g, "");
  var coastalcarolinachanticleersSoloO = document.getElementById("CoastalCarolinaChanticleersSoloOU").innerHTML;
  var coastalcarolinachanticleersSoloO = coastalcarolinachanticleersSoloO.replace(/[',()]/g, "");
  var coastalcarolinachanticleersHalftime = document.getElementById("CoastalCarolinaChanticleersHalftime").innerHTML;
  var coastalcarolinachanticleersHalftimeO = document.getElementById("CoastalCarolinaChanticleersHalftimeOU").innerHTML;
  var coastalcarolinachanticleersHalftimeO = coastalcarolinachanticleersHalftimeO.replace(/[',()]/g, "");

  var colgateraiderscover = document.getElementById("ColgateRaidersCover").innerHTML;
  var colgateraidersML = document.getElementById("ColgateRaidersML").innerHTML;
  var colgateraidersO = document.getElementById("ColgateRaidersOU").innerHTML;
  var colgateraidersO = colgateraidersO.replace(/[',()]/g, "");
  var colgateraidersSoloO = document.getElementById("ColgateRaidersSoloOU").innerHTML;
  var colgateraidersSoloO = colgateraidersSoloO.replace(/[',()]/g, "");
  var colgateraidersHalftime = document.getElementById("ColgateRaidersHalftime").innerHTML;
  var colgateraidersHalftimeO = document.getElementById("ColgateRaidersHalftimeOU").innerHTML;
  var colgateraidersHalftimeO = colgateraidersHalftimeO.replace(/[',()]/g, "");

  var coloradobuffaloescover = document.getElementById("ColoradoBuffaloesCover").innerHTML;
  var coloradobuffaloesML = document.getElementById("ColoradoBuffaloesML").innerHTML;
  var coloradobuffaloesO = document.getElementById("ColoradoBuffaloesOU").innerHTML;
  var coloradobuffaloesO = coloradobuffaloesO.replace(/[',()]/g, "");
  var coloradobuffaloesSoloO = document.getElementById("ColoradoBuffaloesSoloOU").innerHTML;
  var coloradobuffaloesSoloO = coloradobuffaloesSoloO.replace(/[',()]/g, "");
  var coloradobuffaloesHalftime = document.getElementById("ColoradoBuffaloesHalftime").innerHTML;
  var coloradobuffaloesHalftimeO = document.getElementById("ColoradoBuffaloesHalftimeOU").innerHTML;
  var coloradobuffaloesHalftimeO = coloradobuffaloesHalftimeO.replace(/[',()]/g, "");

  var coloradostateramscover = document.getElementById("ColoradoStateRamsCover").innerHTML;
  var coloradostateramsML = document.getElementById("ColoradoStateRamsML").innerHTML;
  var coloradostateramsO = document.getElementById("ColoradoStateRamsOU").innerHTML;
  var coloradostateramsO = coloradostateramsO.replace(/[',()]/g, "");
  var coloradostateramsSoloO = document.getElementById("ColoradoStateRamsSoloOU").innerHTML;
  var coloradostateramsSoloO = coloradostateramsSoloO.replace(/[',()]/g, "");
  var coloradostateramsHalftime = document.getElementById("ColoradoStateRamsHalftime").innerHTML;
  var coloradostateramsHalftimeO = document.getElementById("ColoradoStateRamsHalftimeOU").innerHTML;
  var coloradostateramsHalftimeO = coloradostateramsHalftimeO.replace(/[',()]/g, "");

  var columbialionscover = document.getElementById("ColumbiaLionsCover").innerHTML;
  var columbialionsML = document.getElementById("ColumbiaLionsML").innerHTML;
  var columbialionsO = document.getElementById("ColumbiaLionsOU").innerHTML;
  var columbialionsO = columbialionsO.replace(/[',()]/g, "");
  var columbialionsSoloO = document.getElementById("ColumbiaLionsSoloOU").innerHTML;
  var columbialionsSoloO = columbialionsSoloO.replace(/[',()]/g, "");
  var columbialionsHalftime = document.getElementById("ColumbiaLionsHalftime").innerHTML;
  var columbialionsHalftimeO = document.getElementById("ColumbiaLionsHalftimeOU").innerHTML;
  var columbialionsHalftimeO = columbialionsHalftimeO.replace(/[',()]/g, "");

  var uconnhuskiescover = document.getElementById("UConnHuskiesCover").innerHTML;
  var uconnhuskiesML = document.getElementById("UConnHuskiesML").innerHTML;
  var uconnhuskiesO = document.getElementById("UConnHuskiesOU").innerHTML;
  var uconnhuskiesO = uconnhuskiesO.replace(/[',()]/g, "");
  var uconnhuskiesSoloO = document.getElementById("UConnHuskiesSoloOU").innerHTML;
  var uconnhuskiesSoloO = uconnhuskiesSoloO.replace(/[',()]/g, "");
  var uconnhuskiesHalftime = document.getElementById("UConnHuskiesHalftime").innerHTML;
  var uconnhuskiesHalftimeO = document.getElementById("UConnHuskiesHalftimeOU").innerHTML;
  var uconnhuskiesHalftimeO = uconnhuskiesHalftimeO.replace(/[',()]/g, "");

  var coppinstateeaglescover = document.getElementById("CoppinStateEaglesCover").innerHTML;
  var coppinstateeaglesML = document.getElementById("CoppinStateEaglesML").innerHTML;
  var coppinstateeaglesO = document.getElementById("CoppinStateEaglesOU").innerHTML;
  var coppinstateeaglesO = coppinstateeaglesO.replace(/[',()]/g, "");
  var coppinstateeaglesSoloO = document.getElementById("CoppinStateEaglesSoloOU").innerHTML;
  var coppinstateeaglesSoloO = coppinstateeaglesSoloO.replace(/[',()]/g, "");
  var coppinstateeaglesHalftime = document.getElementById("CoppinStateEaglesHalftime").innerHTML;
  var coppinstateeaglesHalftimeO = document.getElementById("CoppinStateEaglesHalftimeOU").innerHTML;
  var coppinstateeaglesHalftimeO = coppinstateeaglesHalftimeO.replace(/[',()]/g, "");

  var cornellbigredcover = document.getElementById("CornellBigRedCover").innerHTML;
  var cornellbigredML = document.getElementById("CornellBigRedML").innerHTML;
  var cornellbigredO = document.getElementById("CornellBigRedOU").innerHTML;
  var cornellbigredO = cornellbigredO.replace(/[',()]/g, "");
  var cornellbigredSoloO = document.getElementById("CornellBigRedSoloOU").innerHTML;
  var cornellbigredSoloO = cornellbigredSoloO.replace(/[',()]/g, "");
  var cornellbigredHalftime = document.getElementById("CornellBigRedHalftime").innerHTML;
  var cornellbigredHalftimeO = document.getElementById("CornellBigRedHalftimeOU").innerHTML;
  var cornellbigredHalftimeO = cornellbigredHalftimeO.replace(/[',()]/g, "");

  var creightonbluejayscover = document.getElementById("CreightonBluejaysCover").innerHTML;
  var creightonbluejaysML = document.getElementById("CreightonBluejaysML").innerHTML;
  var creightonbluejaysO = document.getElementById("CreightonBluejaysOU").innerHTML;
  var creightonbluejaysO = creightonbluejaysO.replace(/[',()]/g, "");
  var creightonbluejaysSoloO = document.getElementById("CreightonBluejaysSoloOU").innerHTML;
  var creightonbluejaysSoloO = creightonbluejaysSoloO.replace(/[',()]/g, "");
  var creightonbluejaysHalftime = document.getElementById("CreightonBluejaysHalftime").innerHTML;
  var creightonbluejaysHalftimeO = document.getElementById("CreightonBluejaysHalftimeOU").innerHTML;
  var creightonbluejaysHalftimeO = creightonbluejaysHalftimeO.replace(/[',()]/g, "");

  var dartmouthbiggreencover = document.getElementById("DartmouthBigGreenCover").innerHTML;
  var dartmouthbiggreenML = document.getElementById("DartmouthBigGreenML").innerHTML;
  var dartmouthbiggreenO = document.getElementById("DartmouthBigGreenOU").innerHTML;
  var dartmouthbiggreenO = dartmouthbiggreenO.replace(/[',()]/g, "");
  var dartmouthbiggreenSoloO = document.getElementById("DartmouthBigGreenSoloOU").innerHTML;
  var dartmouthbiggreenSoloO = dartmouthbiggreenSoloO.replace(/[',()]/g, "");
  var dartmouthbiggreenHalftime = document.getElementById("DartmouthBigGreenHalftime").innerHTML;
  var dartmouthbiggreenHalftimeO = document.getElementById("DartmouthBigGreenHalftimeOU").innerHTML;
  var dartmouthbiggreenHalftimeO = dartmouthbiggreenHalftimeO.replace(/[',()]/g, "");

  var davidsonwildcatscover = document.getElementById("DavidsonWildcatsCover").innerHTML;
  var davidsonwildcatsML = document.getElementById("DavidsonWildcatsML").innerHTML;
  var davidsonwildcatsO = document.getElementById("DavidsonWildcatsOU").innerHTML;
  var davidsonwildcatsO = davidsonwildcatsO.replace(/[',()]/g, "");
  var davidsonwildcatsSoloO = document.getElementById("DavidsonWildcatsSoloOU").innerHTML;
  var davidsonwildcatsSoloO = davidsonwildcatsSoloO.replace(/[',()]/g, "");
  var davidsonwildcatsHalftime = document.getElementById("DavidsonWildcatsHalftime").innerHTML;
  var davidsonwildcatsHalftimeO = document.getElementById("DavidsonWildcatsHalftimeOU").innerHTML;
  var davidsonwildcatsHalftimeO = davidsonwildcatsHalftimeO.replace(/[',()]/g, "");

  var daytonflyerscover = document.getElementById("DaytonFlyersCover").innerHTML;
  var daytonflyersML = document.getElementById("DaytonFlyersML").innerHTML;
  var daytonflyersO = document.getElementById("DaytonFlyersOU").innerHTML;
  var daytonflyersO = daytonflyersO.replace(/[',()]/g, "");
  var daytonflyersSoloO = document.getElementById("DaytonFlyersSoloOU").innerHTML;
  var daytonflyersSoloO = daytonflyersSoloO.replace(/[',()]/g, "");
  var daytonflyersHalftime = document.getElementById("DaytonFlyersHalftime").innerHTML;
  var daytonflyersHalftimeO = document.getElementById("DaytonFlyersHalftimeOU").innerHTML;
  var daytonflyersHalftimeO = daytonflyersHalftimeO.replace(/[',()]/g, "");

  var delawarebluehenscover = document.getElementById("DelawareBlueHensCover").innerHTML;
  var delawarebluehensML = document.getElementById("DelawareBlueHensML").innerHTML;
  var delawarebluehensO = document.getElementById("DelawareBlueHensOU").innerHTML;
  var delawarebluehensO = delawarebluehensO.replace(/[',()]/g, "");
  var delawarebluehensSoloO = document.getElementById("DelawareBlueHensSoloOU").innerHTML;
  var delawarebluehensSoloO = delawarebluehensSoloO.replace(/[',()]/g, "");
  var delawarebluehensHalftime = document.getElementById("DelawareBlueHensHalftime").innerHTML;
  var delawarebluehensHalftimeO = document.getElementById("DelawareBlueHensHalftimeOU").innerHTML;
  var delawarebluehensHalftimeO = delawarebluehensHalftimeO.replace(/[',()]/g, "");

  var delawarestatehornetscover = document.getElementById("DelawareStateHornetsCover").innerHTML;
  var delawarestatehornetsML = document.getElementById("DelawareStateHornetsML").innerHTML;
  var delawarestatehornetsO = document.getElementById("DelawareStateHornetsOU").innerHTML;
  var delawarestatehornetsO = delawarestatehornetsO.replace(/[',()]/g, "");
  var delawarestatehornetsSoloO = document.getElementById("DelawareStateHornetsSoloOU").innerHTML;
  var delawarestatehornetsSoloO = delawarestatehornetsSoloO.replace(/[',()]/g, "");
  var delawarestatehornetsHalftime = document.getElementById("DelawareStateHornetsHalftime").innerHTML;
  var delawarestatehornetsHalftimeO = document.getElementById("DelawareStateHornetsHalftimeOU").innerHTML;
  var delawarestatehornetsHalftimeO = delawarestatehornetsHalftimeO.replace(/[',()]/g, "");

  var denverpioneerscover = document.getElementById("DenverPioneersCover").innerHTML;
  var denverpioneersML = document.getElementById("DenverPioneersML").innerHTML;
  var denverpioneersO = document.getElementById("DenverPioneersOU").innerHTML;
  var denverpioneersO = denverpioneersO.replace(/[',()]/g, "");
  var denverpioneersSoloO = document.getElementById("DenverPioneersSoloOU").innerHTML;
  var denverpioneersSoloO = denverpioneersSoloO.replace(/[',()]/g, "");
  var denverpioneersHalftime = document.getElementById("DenverPioneersHalftime").innerHTML;
  var denverpioneersHalftimeO = document.getElementById("DenverPioneersHalftimeOU").innerHTML;
  var denverpioneersHalftimeO = denverpioneersHalftimeO.replace(/[',()]/g, "");

  var depaulbluedemonscover = document.getElementById("DePaulBlueDemonsCover").innerHTML;
  var depaulbluedemonsML = document.getElementById("DePaulBlueDemonsML").innerHTML;
  var depaulbluedemonsO = document.getElementById("DePaulBlueDemonsOU").innerHTML;
  var depaulbluedemonsO = depaulbluedemonsO.replace(/[',()]/g, "");
  var depaulbluedemonsSoloO = document.getElementById("DePaulBlueDemonsSoloOU").innerHTML;
  var depaulbluedemonsSoloO = depaulbluedemonsSoloO.replace(/[',()]/g, "");
  var depaulbluedemonsHalftime = document.getElementById("DePaulBlueDemonsHalftime").innerHTML;
  var depaulbluedemonsHalftimeO = document.getElementById("DePaulBlueDemonsHalftimeOU").innerHTML;
  var depaulbluedemonsHalftimeO = depaulbluedemonsHalftimeO.replace(/[',()]/g, "");

  var detroitmercytitanscover = document.getElementById("DetroitMercyTitansCover").innerHTML;
  var detroitmercytitansML = document.getElementById("DetroitMercyTitansML").innerHTML;
  var detroitmercytitansO = document.getElementById("DetroitMercyTitansOU").innerHTML;
  var detroitmercytitansO = detroitmercytitansO.replace(/[',()]/g, "");
  var detroitmercytitansSoloO = document.getElementById("DetroitMercyTitansSoloOU").innerHTML;
  var detroitmercytitansSoloO = detroitmercytitansSoloO.replace(/[',()]/g, "");
  var detroitmercytitansHalftime = document.getElementById("DetroitMercyTitansHalftime").innerHTML;
  var detroitmercytitansHalftimeO = document.getElementById("DetroitMercyTitansHalftimeOU").innerHTML;
  var detroitmercytitansHalftimeO = detroitmercytitansHalftimeO.replace(/[',()]/g, "");

  var drakebulldogscover = document.getElementById("DrakeBulldogsCover").innerHTML;
  var drakebulldogsML = document.getElementById("DrakeBulldogsML").innerHTML;
  var drakebulldogsO = document.getElementById("DrakeBulldogsOU").innerHTML;
  var drakebulldogsO = drakebulldogsO.replace(/[',()]/g, "");
  var drakebulldogsSoloO = document.getElementById("DrakeBulldogsSoloOU").innerHTML;
  var drakebulldogsSoloO = drakebulldogsSoloO.replace(/[',()]/g, "");
  var drakebulldogsHalftime = document.getElementById("DrakeBulldogsHalftime").innerHTML;
  var drakebulldogsHalftimeO = document.getElementById("DrakeBulldogsHalftimeOU").innerHTML;
  var drakebulldogsHalftimeO = drakebulldogsHalftimeO.replace(/[',()]/g, "");

  var drexeldragonscover = document.getElementById("DrexelDragonsCover").innerHTML;
  var drexeldragonsML = document.getElementById("DrexelDragonsML").innerHTML;
  var drexeldragonsO = document.getElementById("DrexelDragonsOU").innerHTML;
  var drexeldragonsO = drexeldragonsO.replace(/[',()]/g, "");
  var drexeldragonsSoloO = document.getElementById("DrexelDragonsSoloOU").innerHTML;
  var drexeldragonsSoloO = drexeldragonsSoloO.replace(/[',()]/g, "");
  var drexeldragonsHalftime = document.getElementById("DrexelDragonsHalftime").innerHTML;
  var drexeldragonsHalftimeO = document.getElementById("DrexelDragonsHalftimeOU").innerHTML;
  var drexeldragonsHalftimeO = drexeldragonsHalftimeO.replace(/[',()]/g, "");

  var dukebluedevilscover = document.getElementById("DukeBlueDevilsCover").innerHTML;
  var dukebluedevilsML = document.getElementById("DukeBlueDevilsML").innerHTML;
  var dukebluedevilsO = document.getElementById("DukeBlueDevilsOU").innerHTML;
  var dukebluedevilsO = dukebluedevilsO.replace(/[',()]/g, "");
  var dukebluedevilsSoloO = document.getElementById("DukeBlueDevilsSoloOU").innerHTML;
  var dukebluedevilsSoloO = dukebluedevilsSoloO.replace(/[',()]/g, "");
  var dukebluedevilsHalftime = document.getElementById("DukeBlueDevilsHalftime").innerHTML;
  var dukebluedevilsHalftimeO = document.getElementById("DukeBlueDevilsHalftimeOU").innerHTML;
  var dukebluedevilsHalftimeO = dukebluedevilsHalftimeO.replace(/[',()]/g, "");

  var duquesnedukescover = document.getElementById("DuquesneDukesCover").innerHTML;
  var duquesnedukesML = document.getElementById("DuquesneDukesML").innerHTML;
  var duquesnedukesO = document.getElementById("DuquesneDukesOU").innerHTML;
  var duquesnedukesO = duquesnedukesO.replace(/[',()]/g, "");
  var duquesnedukesSoloO = document.getElementById("DuquesneDukesSoloOU").innerHTML;
  var duquesnedukesSoloO = duquesnedukesSoloO.replace(/[',()]/g, "");
  var duquesnedukesHalftime = document.getElementById("DuquesneDukesHalftime").innerHTML;
  var duquesnedukesHalftimeO = document.getElementById("DuquesneDukesHalftimeOU").innerHTML;
  var duquesnedukesHalftimeO = duquesnedukesHalftimeO.replace(/[',()]/g, "");

  var easttennesseestatebuccaneerscover = document.getElementById("EastTennesseeStateBuccaneersCover").innerHTML;
  var easttennesseestatebuccaneersML = document.getElementById("EastTennesseeStateBuccaneersML").innerHTML;
  var easttennesseestatebuccaneersO = document.getElementById("EastTennesseeStateBuccaneersOU").innerHTML;
  var easttennesseestatebuccaneersO = easttennesseestatebuccaneersO.replace(/[',()]/g, "");
  var easttennesseestatebuccaneersSoloO = document.getElementById("EastTennesseeStateBuccaneersSoloOU").innerHTML;
  var easttennesseestatebuccaneersSoloO = easttennesseestatebuccaneersSoloO.replace(/[',()]/g, "");
  var easttennesseestatebuccaneersHalftime = document.getElementById("EastTennesseeStateBuccaneersHalftime").innerHTML;
  var easttennesseestatebuccaneersHalftimeO = document.getElementById("EastTennesseeStateBuccaneersHalftimeOU").innerHTML;
  var easttennesseestatebuccaneersHalftimeO = easttennesseestatebuccaneersHalftimeO.replace(/[',()]/g, "");

  var easternillinoispantherscover = document.getElementById("EasternIllinoisPanthersCover").innerHTML;
  var easternillinoispanthersML = document.getElementById("EasternIllinoisPanthersML").innerHTML;
  var easternillinoispanthersO = document.getElementById("EasternIllinoisPanthersOU").innerHTML;
  var easternillinoispanthersO = easternillinoispanthersO.replace(/[',()]/g, "");
  var easternillinoispanthersSoloO = document.getElementById("EasternIllinoisPanthersSoloOU").innerHTML;
  var easternillinoispanthersSoloO = easternillinoispanthersSoloO.replace(/[',()]/g, "");
  var easternillinoispanthersHalftime = document.getElementById("EasternIllinoisPanthersHalftime").innerHTML;
  var easternillinoispanthersHalftimeO = document.getElementById("EasternIllinoisPanthersHalftimeOU").innerHTML;
  var easternillinoispanthersHalftimeO = easternillinoispanthersHalftimeO.replace(/[',()]/g, "");

  var easternkentuckycolonelscover = document.getElementById("EasternKentuckyColonelsCover").innerHTML;
  var easternkentuckycolonelsML = document.getElementById("EasternKentuckyColonelsML").innerHTML;
  var easternkentuckycolonelsO = document.getElementById("EasternKentuckyColonelsOU").innerHTML;
  var easternkentuckycolonelsO = easternkentuckycolonelsO.replace(/[',()]/g, "");
  var easternkentuckycolonelsSoloO = document.getElementById("EasternKentuckyColonelsSoloOU").innerHTML;
  var easternkentuckycolonelsSoloO = easternkentuckycolonelsSoloO.replace(/[',()]/g, "");
  var easternkentuckycolonelsHalftime = document.getElementById("EasternKentuckyColonelsHalftime").innerHTML;
  var easternkentuckycolonelsHalftimeO = document.getElementById("EasternKentuckyColonelsHalftimeOU").innerHTML;
  var easternkentuckycolonelsHalftimeO = easternkentuckycolonelsHalftimeO.replace(/[',()]/g, "");

  var easternmichiganeaglescover = document.getElementById("EasternMichiganEaglesCover").innerHTML;
  var easternmichiganeaglesML = document.getElementById("EasternMichiganEaglesML").innerHTML;
  var easternmichiganeaglesO = document.getElementById("EasternMichiganEaglesOU").innerHTML;
  var easternmichiganeaglesO = easternmichiganeaglesO.replace(/[',()]/g, "");
  var easternmichiganeaglesSoloO = document.getElementById("EasternMichiganEaglesSoloOU").innerHTML;
  var easternmichiganeaglesSoloO = easternmichiganeaglesSoloO.replace(/[',()]/g, "");
  var easternmichiganeaglesHalftime = document.getElementById("EasternMichiganEaglesHalftime").innerHTML;
  var easternmichiganeaglesHalftimeO = document.getElementById("EasternMichiganEaglesHalftimeOU").innerHTML;
  var easternmichiganeaglesHalftimeO = easternmichiganeaglesHalftimeO.replace(/[',()]/g, "");

  var elonphoenixcover = document.getElementById("ElonPhoenixCover").innerHTML;
  var elonphoenixML = document.getElementById("ElonPhoenixML").innerHTML;
  var elonphoenixO = document.getElementById("ElonPhoenixOU").innerHTML;
  var elonphoenixO = elonphoenixO.replace(/[',()]/g, "");
  var elonphoenixSoloO = document.getElementById("ElonPhoenixSoloOU").innerHTML;
  var elonphoenixSoloO = elonphoenixSoloO.replace(/[',()]/g, "");
  var elonphoenixHalftime = document.getElementById("ElonPhoenixHalftime").innerHTML;
  var elonphoenixHalftimeO = document.getElementById("ElonPhoenixHalftimeOU").innerHTML;
  var elonphoenixHalftimeO = elonphoenixHalftimeO.replace(/[',()]/g, "");

  var evansvillepurpleacescover = document.getElementById("EvansvillePurpleAcesCover").innerHTML;
  var evansvillepurpleacesML = document.getElementById("EvansvillePurpleAcesML").innerHTML;
  var evansvillepurpleacesO = document.getElementById("EvansvillePurpleAcesOU").innerHTML;
  var evansvillepurpleacesO = evansvillepurpleacesO.replace(/[',()]/g, "");
  var evansvillepurpleacesSoloO = document.getElementById("EvansvillePurpleAcesSoloOU").innerHTML;
  var evansvillepurpleacesSoloO = evansvillepurpleacesSoloO.replace(/[',()]/g, "");
  var evansvillepurpleacesHalftime = document.getElementById("EvansvillePurpleAcesHalftime").innerHTML;
  var evansvillepurpleacesHalftimeO = document.getElementById("EvansvillePurpleAcesHalftimeOU").innerHTML;
  var evansvillepurpleacesHalftimeO = evansvillepurpleacesHalftimeO.replace(/[',()]/g, "");

  var fairfieldstagscover = document.getElementById("FairfieldStagsCover").innerHTML;
  var fairfieldstagsML = document.getElementById("FairfieldStagsML").innerHTML;
  var fairfieldstagsO = document.getElementById("FairfieldStagsOU").innerHTML;
  var fairfieldstagsO = fairfieldstagsO.replace(/[',()]/g, "");
  var fairfieldstagsSoloO = document.getElementById("FairfieldStagsSoloOU").innerHTML;
  var fairfieldstagsSoloO = fairfieldstagsSoloO.replace(/[',()]/g, "");
  var fairfieldstagsHalftime = document.getElementById("FairfieldStagsHalftime").innerHTML;
  var fairfieldstagsHalftimeO = document.getElementById("FairfieldStagsHalftimeOU").innerHTML;
  var fairfieldstagsHalftimeO = fairfieldstagsHalftimeO.replace(/[',()]/g, "");

  var fairleighdickinsonknightscover = document.getElementById("FairleighDickinsonKnightsCover").innerHTML;
  var fairleighdickinsonknightsML = document.getElementById("FairleighDickinsonKnightsML").innerHTML;
  var fairleighdickinsonknightsO = document.getElementById("FairleighDickinsonKnightsOU").innerHTML;
  var fairleighdickinsonknightsO = fairleighdickinsonknightsO.replace(/[',()]/g, "");
  var fairleighdickinsonknightsSoloO = document.getElementById("FairleighDickinsonKnightsSoloOU").innerHTML;
  var fairleighdickinsonknightsSoloO = fairleighdickinsonknightsSoloO.replace(/[',()]/g, "");
  var fairleighdickinsonknightsHalftime = document.getElementById("FairleighDickinsonKnightsHalftime").innerHTML;
  var fairleighdickinsonknightsHalftimeO = document.getElementById("FairleighDickinsonKnightsHalftimeOU").innerHTML;
  var fairleighdickinsonknightsHalftimeO = fairleighdickinsonknightsHalftimeO.replace(/[',()]/g, "");

  var floridagatorscover = document.getElementById("FloridaGatorsCover").innerHTML;
  var floridagatorsML = document.getElementById("FloridaGatorsML").innerHTML;
  var floridagatorsO = document.getElementById("FloridaGatorsOU").innerHTML;
  var floridagatorsO = floridagatorsO.replace(/[',()]/g, "");
  var floridagatorsSoloO = document.getElementById("FloridaGatorsSoloOU").innerHTML;
  var floridagatorsSoloO = floridagatorsSoloO.replace(/[',()]/g, "");
  var floridagatorsHalftime = document.getElementById("FloridaGatorsHalftime").innerHTML;
  var floridagatorsHalftimeO = document.getElementById("FloridaGatorsHalftimeOU").innerHTML;
  var floridagatorsHalftimeO = floridagatorsHalftimeO.replace(/[',()]/g, "");

  var floridaaandmrattlerscover = document.getElementById("FloridaAandMRattlersCover").innerHTML;
  var floridaaandmrattlersML = document.getElementById("FloridaAandMRattlersML").innerHTML;
  var floridaaandmrattlersO = document.getElementById("FloridaAandMRattlersOU").innerHTML;
  var floridaaandmrattlersO = floridaaandmrattlersO.replace(/[',()]/g, "");
  var floridaaandmrattlersSoloO = document.getElementById("FloridaAandMRattlersSoloOU").innerHTML;
  var floridaaandmrattlersSoloO = floridaaandmrattlersSoloO.replace(/[',()]/g, "");
  var floridaaandmrattlersHalftime = document.getElementById("FloridaAandMRattlersHalftime").innerHTML;
  var floridaaandmrattlersHalftimeO = document.getElementById("FloridaAandMRattlersHalftimeOU").innerHTML;
  var floridaaandmrattlersHalftimeO = floridaaandmrattlersHalftimeO.replace(/[',()]/g, "");

  var floridaatlanticowlscover = document.getElementById("FloridaAtlanticOwlsCover").innerHTML;
  var floridaatlanticowlsML = document.getElementById("FloridaAtlanticOwlsML").innerHTML;
  var floridaatlanticowlsO = document.getElementById("FloridaAtlanticOwlsOU").innerHTML;
  var floridaatlanticowlsO = floridaatlanticowlsO.replace(/[',()]/g, "");
  var floridaatlanticowlsSoloO = document.getElementById("FloridaAtlanticOwlsSoloOU").innerHTML;
  var floridaatlanticowlsSoloO = floridaatlanticowlsSoloO.replace(/[',()]/g, "");
  var floridaatlanticowlsHalftime = document.getElementById("FloridaAtlanticOwlsHalftime").innerHTML;
  var floridaatlanticowlsHalftimeO = document.getElementById("FloridaAtlanticOwlsHalftimeOU").innerHTML;
  var floridaatlanticowlsHalftimeO = floridaatlanticowlsHalftimeO.replace(/[',()]/g, "");

  var floridagulfcoasteaglescover = document.getElementById("FloridaGulfCoastEaglesCover").innerHTML;
  var floridagulfcoasteaglesML = document.getElementById("FloridaGulfCoastEaglesML").innerHTML;
  var floridagulfcoasteaglesO = document.getElementById("FloridaGulfCoastEaglesOU").innerHTML;
  var floridagulfcoasteaglesO = floridagulfcoasteaglesO.replace(/[',()]/g, "");
  var floridagulfcoasteaglesSoloO = document.getElementById("FloridaGulfCoastEaglesSoloOU").innerHTML;
  var floridagulfcoasteaglesSoloO = floridagulfcoasteaglesSoloO.replace(/[',()]/g, "");
  var floridagulfcoasteaglesHalftime = document.getElementById("FloridaGulfCoastEaglesHalftime").innerHTML;
  var floridagulfcoasteaglesHalftimeO = document.getElementById("FloridaGulfCoastEaglesHalftimeOU").innerHTML;
  var floridagulfcoasteaglesHalftimeO = floridagulfcoasteaglesHalftimeO.replace(/[',()]/g, "");

  var floridainternationalpantherscover = document.getElementById("FloridaInternationalPanthersCover").innerHTML;
  var floridainternationalpanthersML = document.getElementById("FloridaInternationalPanthersML").innerHTML;
  var floridainternationalpanthersO = document.getElementById("FloridaInternationalPanthersOU").innerHTML;
  var floridainternationalpanthersO = floridainternationalpanthersO.replace(/[',()]/g, "");
  var floridainternationalpanthersSoloO = document.getElementById("FloridaInternationalPanthersSoloOU").innerHTML;
  var floridainternationalpanthersSoloO = floridainternationalpanthersSoloO.replace(/[',()]/g, "");
  var floridainternationalpanthersHalftime = document.getElementById("FloridaInternationalPanthersHalftime").innerHTML;
  var floridainternationalpanthersHalftimeO = document.getElementById("FloridaInternationalPanthersHalftimeOU").innerHTML;
  var floridainternationalpanthersHalftimeO = floridainternationalpanthersHalftimeO.replace(/[',()]/g, "");

  var floridastateseminolescover = document.getElementById("FloridaStateSeminolesCover").innerHTML;
  var floridastateseminolesML = document.getElementById("FloridaStateSeminolesML").innerHTML;
  var floridastateseminolesO = document.getElementById("FloridaStateSeminolesOU").innerHTML;
  var floridastateseminolesO = floridastateseminolesO.replace(/[',()]/g, "");
  var floridastateseminolesSoloO = document.getElementById("FloridaStateSeminolesSoloOU").innerHTML;
  var floridastateseminolesSoloO = floridastateseminolesSoloO.replace(/[',()]/g, "");
  var floridastateseminolesHalftime = document.getElementById("FloridaStateSeminolesHalftime").innerHTML;
  var floridastateseminolesHalftimeO = document.getElementById("FloridaStateSeminolesHalftimeOU").innerHTML;
  var floridastateseminolesHalftimeO = floridastateseminolesHalftimeO.replace(/[',()]/g, "");

  var fordhamramscover = document.getElementById("FordhamRamsCover").innerHTML;
  var fordhamramsML = document.getElementById("FordhamRamsML").innerHTML;
  var fordhamramsO = document.getElementById("FordhamRamsOU").innerHTML;
  var fordhamramsO = fordhamramsO.replace(/[',()]/g, "");
  var fordhamramsSoloO = document.getElementById("FordhamRamsSoloOU").innerHTML;
  var fordhamramsSoloO = fordhamramsSoloO.replace(/[',()]/g, "");
  var fordhamramsHalftime = document.getElementById("FordhamRamsHalftime").innerHTML;
  var fordhamramsHalftimeO = document.getElementById("FordhamRamsHalftimeOU").innerHTML;
  var fordhamramsHalftimeO = fordhamramsHalftimeO.replace(/[',()]/g, "");

  var furmanpaladinscover = document.getElementById("FurmanPaladinsCover").innerHTML;
  var furmanpaladinsML = document.getElementById("FurmanPaladinsML").innerHTML;
  var furmanpaladinsO = document.getElementById("FurmanPaladinsOU").innerHTML;
  var furmanpaladinsO = furmanpaladinsO.replace(/[',()]/g, "");
  var furmanpaladinsSoloO = document.getElementById("FurmanPaladinsSoloOU").innerHTML;
  var furmanpaladinsSoloO = furmanpaladinsSoloO.replace(/[',()]/g, "");
  var furmanpaladinsHalftime = document.getElementById("FurmanPaladinsHalftime").innerHTML;
  var furmanpaladinsHalftimeO = document.getElementById("FurmanPaladinsHalftimeOU").innerHTML;
  var furmanpaladinsHalftimeO = furmanpaladinsHalftimeO.replace(/[',()]/g, "");

  var gardnerwebbbulldogscover = document.getElementById("GardnerWebbBulldogsCover").innerHTML;
  var gardnerwebbbulldogsML = document.getElementById("GardnerWebbBulldogsML").innerHTML;
  var gardnerwebbbulldogsO = document.getElementById("GardnerWebbBulldogsOU").innerHTML;
  var gardnerwebbbulldogsO = gardnerwebbbulldogsO.replace(/[',()]/g, "");
  var gardnerwebbbulldogsSoloO = document.getElementById("GardnerWebbBulldogsSoloOU").innerHTML;
  var gardnerwebbbulldogsSoloO = gardnerwebbbulldogsSoloO.replace(/[',()]/g, "");
  var gardnerwebbbulldogsHalftime = document.getElementById("GardnerWebbBulldogsHalftime").innerHTML;
  var gardnerwebbbulldogsHalftimeO = document.getElementById("GardnerWebbBulldogsHalftimeOU").innerHTML;
  var gardnerwebbbulldogsHalftimeO = gardnerwebbbulldogsHalftimeO.replace(/[',()]/g, "");

  var georgemasonpatriotscover = document.getElementById("GeorgeMasonPatriotsCover").innerHTML;
  var georgemasonpatriotsML = document.getElementById("GeorgeMasonPatriotsML").innerHTML;
  var georgemasonpatriotsO = document.getElementById("GeorgeMasonPatriotsOU").innerHTML;
  var georgemasonpatriotsO = georgemasonpatriotsO.replace(/[',()]/g, "");
  var georgemasonpatriotsSoloO = document.getElementById("GeorgeMasonPatriotsSoloOU").innerHTML;
  var georgemasonpatriotsSoloO = georgemasonpatriotsSoloO.replace(/[',()]/g, "");
  var georgemasonpatriotsHalftime = document.getElementById("GeorgeMasonPatriotsHalftime").innerHTML;
  var georgemasonpatriotsHalftimeO = document.getElementById("GeorgeMasonPatriotsHalftimeOU").innerHTML;
  var georgemasonpatriotsHalftimeO = georgemasonpatriotsHalftimeO.replace(/[',()]/g, "");

  var georgewashingtoncolonialscover = document.getElementById("GeorgeWashingtonColonialsCover").innerHTML;
  var georgewashingtoncolonialsML = document.getElementById("GeorgeWashingtonColonialsML").innerHTML;
  var georgewashingtoncolonialsO = document.getElementById("GeorgeWashingtonColonialsOU").innerHTML;
  var georgewashingtoncolonialsO = georgewashingtoncolonialsO.replace(/[',()]/g, "");
  var georgewashingtoncolonialsSoloO = document.getElementById("GeorgeWashingtonColonialsSoloOU").innerHTML;
  var georgewashingtoncolonialsSoloO = georgewashingtoncolonialsSoloO.replace(/[',()]/g, "");
  var georgewashingtoncolonialsHalftime = document.getElementById("GeorgeWashingtonColonialsHalftime").innerHTML;
  var georgewashingtoncolonialsHalftimeO = document.getElementById("GeorgeWashingtonColonialsHalftimeOU").innerHTML;
  var georgewashingtoncolonialsHalftimeO = georgewashingtoncolonialsHalftimeO.replace(/[',()]/g, "");

  var georgetownhoyascover = document.getElementById("GeorgetownHoyasCover").innerHTML;
  var georgetownhoyasML = document.getElementById("GeorgetownHoyasML").innerHTML;
  var georgetownhoyasO = document.getElementById("GeorgetownHoyasOU").innerHTML;
  var georgetownhoyasO = georgetownhoyasO.replace(/[',()]/g, "");
  var georgetownhoyasSoloO = document.getElementById("GeorgetownHoyasSoloOU").innerHTML;
  var georgetownhoyasSoloO = georgetownhoyasSoloO.replace(/[',()]/g, "");
  var georgetownhoyasHalftime = document.getElementById("GeorgetownHoyasHalftime").innerHTML;
  var georgetownhoyasHalftimeO = document.getElementById("GeorgetownHoyasHalftimeOU").innerHTML;
  var georgetownhoyasHalftimeO = georgetownhoyasHalftimeO.replace(/[',()]/g, "");

  var georgiabulldogscover = document.getElementById("GeorgiaBulldogsCover").innerHTML;
  var georgiabulldogsML = document.getElementById("GeorgiaBulldogsML").innerHTML;
  var georgiabulldogsO = document.getElementById("GeorgiaBulldogsOU").innerHTML;
  var georgiabulldogsO = georgiabulldogsO.replace(/[',()]/g, "");
  var georgiabulldogsSoloO = document.getElementById("GeorgiaBulldogsSoloOU").innerHTML;
  var georgiabulldogsSoloO = georgiabulldogsSoloO.replace(/[',()]/g, "");
  var georgiabulldogsHalftime = document.getElementById("GeorgiaBulldogsHalftime").innerHTML;
  var georgiabulldogsHalftimeO = document.getElementById("GeorgiaBulldogsHalftimeOU").innerHTML;
  var georgiabulldogsHalftimeO = georgiabulldogsHalftimeO.replace(/[',()]/g, "");

  var georgiatechyellowjacketscover = document.getElementById("GeorgiaTechYellowJacketsCover").innerHTML;
  var georgiatechyellowjacketsML = document.getElementById("GeorgiaTechYellowJacketsML").innerHTML;
  var georgiatechyellowjacketsO = document.getElementById("GeorgiaTechYellowJacketsOU").innerHTML;
  var georgiatechyellowjacketsO = georgiatechyellowjacketsO.replace(/[',()]/g, "");
  var georgiatechyellowjacketsSoloO = document.getElementById("GeorgiaTechYellowJacketsSoloOU").innerHTML;
  var georgiatechyellowjacketsSoloO = georgiatechyellowjacketsSoloO.replace(/[',()]/g, "");
  var georgiatechyellowjacketsHalftime = document.getElementById("GeorgiaTechYellowJacketsHalftime").innerHTML;
  var georgiatechyellowjacketsHalftimeO = document.getElementById("GeorgiaTechYellowJacketsHalftimeOU").innerHTML;
  var georgiatechyellowjacketsHalftimeO = georgiatechyellowjacketsHalftimeO.replace(/[',()]/g, "");

  var georgiasoutherneaglescover = document.getElementById("GeorgiaSouthernEaglesCover").innerHTML;
  var georgiasoutherneaglesML = document.getElementById("GeorgiaSouthernEaglesML").innerHTML;
  var georgiasoutherneaglesO = document.getElementById("GeorgiaSouthernEaglesOU").innerHTML;
  var georgiasoutherneaglesO = georgiasoutherneaglesO.replace(/[',()]/g, "");
  var georgiasoutherneaglesSoloO = document.getElementById("GeorgiaSouthernEaglesSoloOU").innerHTML;
  var georgiasoutherneaglesSoloO = georgiasoutherneaglesSoloO.replace(/[',()]/g, "");
  var georgiasoutherneaglesHalftime = document.getElementById("GeorgiaSouthernEaglesHalftime").innerHTML;
  var georgiasoutherneaglesHalftimeO = document.getElementById("GeorgiaSouthernEaglesHalftimeOU").innerHTML;
  var georgiasoutherneaglesHalftimeO = georgiasoutherneaglesHalftimeO.replace(/[',()]/g, "");

  var georgiastatepantherscover = document.getElementById("GeorgiaStatePanthersCover").innerHTML;
  var georgiastatepanthersML = document.getElementById("GeorgiaStatePanthersML").innerHTML;
  var georgiastatepanthersO = document.getElementById("GeorgiaStatePanthersOU").innerHTML;
  var georgiastatepanthersO = georgiastatepanthersO.replace(/[',()]/g, "");
  var georgiastatepanthersSoloO = document.getElementById("GeorgiaStatePanthersSoloOU").innerHTML;
  var georgiastatepanthersSoloO = georgiastatepanthersSoloO.replace(/[',()]/g, "");
  var georgiastatepanthersHalftime = document.getElementById("GeorgiaStatePanthersHalftime").innerHTML;
  var georgiastatepanthersHalftimeO = document.getElementById("GeorgiaStatePanthersHalftimeOU").innerHTML;
  var georgiastatepanthersHalftimeO = georgiastatepanthersHalftimeO.replace(/[',()]/g, "");

  var gonzagabulldogscover = document.getElementById("GonzagaBulldogsCover").innerHTML;
  var gonzagabulldogsML = document.getElementById("GonzagaBulldogsML").innerHTML;
  var gonzagabulldogsO = document.getElementById("GonzagaBulldogsOU").innerHTML;
  var gonzagabulldogsO = gonzagabulldogsO.replace(/[',()]/g, "");
  var gonzagabulldogsSoloO = document.getElementById("GonzagaBulldogsSoloOU").innerHTML;
  var gonzagabulldogsSoloO = gonzagabulldogsSoloO.replace(/[',()]/g, "");
  var gonzagabulldogsHalftime = document.getElementById("GonzagaBulldogsHalftime").innerHTML;
  var gonzagabulldogsHalftimeO = document.getElementById("GonzagaBulldogsHalftimeOU").innerHTML;
  var gonzagabulldogsHalftimeO = gonzagabulldogsHalftimeO.replace(/[',()]/g, "");

  var gramblingtigerscover = document.getElementById("GramblingTigersCover").innerHTML;
  var gramblingtigersML = document.getElementById("GramblingTigersML").innerHTML;
  var gramblingtigersO = document.getElementById("GramblingTigersOU").innerHTML;
  var gramblingtigersO = gramblingtigersO.replace(/[',()]/g, "");
  var gramblingtigersSoloO = document.getElementById("GramblingTigersSoloOU").innerHTML;
  var gramblingtigersSoloO = gramblingtigersSoloO.replace(/[',()]/g, "");
  var gramblingtigersHalftime = document.getElementById("GramblingTigersHalftime").innerHTML;
  var gramblingtigersHalftimeO = document.getElementById("GramblingTigersHalftimeOU").innerHTML;
  var gramblingtigersHalftimeO = gramblingtigersHalftimeO.replace(/[',()]/g, "");

  var grandcanyonantelopescover = document.getElementById("GrandCanyonAntelopesCover").innerHTML;
  var grandcanyonantelopesML = document.getElementById("GrandCanyonAntelopesML").innerHTML;
  var grandcanyonantelopesO = document.getElementById("GrandCanyonAntelopesOU").innerHTML;
  var grandcanyonantelopesO = grandcanyonantelopesO.replace(/[',()]/g, "");
  var grandcanyonantelopesSoloO = document.getElementById("GrandCanyonAntelopesSoloOU").innerHTML;
  var grandcanyonantelopesSoloO = grandcanyonantelopesSoloO.replace(/[',()]/g, "");
  var grandcanyonantelopesHalftime = document.getElementById("GrandCanyonAntelopesHalftime").innerHTML;
  var grandcanyonantelopesHalftimeO = document.getElementById("GrandCanyonAntelopesHalftimeOU").innerHTML;
  var grandcanyonantelopesHalftimeO = grandcanyonantelopesHalftimeO.replace(/[',()]/g, "");

  var hamptonpiratescover = document.getElementById("HamptonPiratesCover").innerHTML;
  var hamptonpiratesML = document.getElementById("HamptonPiratesML").innerHTML;
  var hamptonpiratesO = document.getElementById("HamptonPiratesOU").innerHTML;
  var hamptonpiratesO = hamptonpiratesO.replace(/[',()]/g, "");
  var hamptonpiratesSoloO = document.getElementById("HamptonPiratesSoloOU").innerHTML;
  var hamptonpiratesSoloO = hamptonpiratesSoloO.replace(/[',()]/g, "");
  var hamptonpiratesHalftime = document.getElementById("HamptonPiratesHalftime").innerHTML;
  var hamptonpiratesHalftimeO = document.getElementById("HamptonPiratesHalftimeOU").innerHTML;
  var hamptonpiratesHalftimeO = hamptonpiratesHalftimeO.replace(/[',()]/g, "");

  var hartfordhawkscover = document.getElementById("HartfordHawksCover").innerHTML;
  var hartfordhawksML = document.getElementById("HartfordHawksML").innerHTML;
  var hartfordhawksO = document.getElementById("HartfordHawksOU").innerHTML;
  var hartfordhawksO = hartfordhawksO.replace(/[',()]/g, "");
  var hartfordhawksSoloO = document.getElementById("HartfordHawksSoloOU").innerHTML;
  var hartfordhawksSoloO = hartfordhawksSoloO.replace(/[',()]/g, "");
  var hartfordhawksHalftime = document.getElementById("HartfordHawksHalftime").innerHTML;
  var hartfordhawksHalftimeO = document.getElementById("HartfordHawksHalftimeOU").innerHTML;
  var hartfordhawksHalftimeO = hartfordhawksHalftimeO.replace(/[',()]/g, "");

  var harvardcrimsoncover = document.getElementById("HarvardCrimsonCover").innerHTML;
  var harvardcrimsonML = document.getElementById("HarvardCrimsonML").innerHTML;
  var harvardcrimsonO = document.getElementById("HarvardCrimsonOU").innerHTML;
  var harvardcrimsonO = harvardcrimsonO.replace(/[',()]/g, "");
  var harvardcrimsonSoloO = document.getElementById("HarvardCrimsonSoloOU").innerHTML;
  var harvardcrimsonSoloO = harvardcrimsonSoloO.replace(/[',()]/g, "");
  var harvardcrimsonHalftime = document.getElementById("HarvardCrimsonHalftime").innerHTML;
  var harvardcrimsonHalftimeO = document.getElementById("HarvardCrimsonHalftimeOU").innerHTML;
  var harvardcrimsonHalftimeO = harvardcrimsonHalftimeO.replace(/[',()]/g, "");

  var hawaiirainbowwarriorscover = document.getElementById("HawaiiRainbowWarriorsCover").innerHTML;
  var hawaiirainbowwarriorsML = document.getElementById("HawaiiRainbowWarriorsML").innerHTML;
  var hawaiirainbowwarriorsO = document.getElementById("HawaiiRainbowWarriorsOU").innerHTML;
  var hawaiirainbowwarriorsO = hawaiirainbowwarriorsO.replace(/[',()]/g, "");
  var hawaiirainbowwarriorsSoloO = document.getElementById("HawaiiRainbowWarriorsSoloOU").innerHTML;
  var hawaiirainbowwarriorsSoloO = hawaiirainbowwarriorsSoloO.replace(/[',()]/g, "");
  var hawaiirainbowwarriorsHalftime = document.getElementById("HawaiiRainbowWarriorsHalftime").innerHTML;
  var hawaiirainbowwarriorsHalftimeO = document.getElementById("HawaiiRainbowWarriorsHalftimeOU").innerHTML;
  var hawaiirainbowwarriorsHalftimeO = hawaiirainbowwarriorsHalftimeO.replace(/[',()]/g, "");

  var highpointpantherscover = document.getElementById("HighPointPanthersCover").innerHTML;
  var highpointpanthersML = document.getElementById("HighPointPanthersML").innerHTML;
  var highpointpanthersO = document.getElementById("HighPointPanthersOU").innerHTML;
  var highpointpanthersO = highpointpanthersO.replace(/[',()]/g, "");
  var highpointpanthersSoloO = document.getElementById("HighPointPanthersSoloOU").innerHTML;
  var highpointpanthersSoloO = highpointpanthersSoloO.replace(/[',()]/g, "");
  var highpointpanthersHalftime = document.getElementById("HighPointPanthersHalftime").innerHTML;
  var highpointpanthersHalftimeO = document.getElementById("HighPointPanthersHalftimeOU").innerHTML;
  var highpointpanthersHalftimeO = highpointpanthersHalftimeO.replace(/[',()]/g, "");

  var hofstrapridecover = document.getElementById("HofstraPrideCover").innerHTML;
  var hofstraprideML = document.getElementById("HofstraPrideML").innerHTML;
  var hofstraprideO = document.getElementById("HofstraPrideOU").innerHTML;
  var hofstraprideO = hofstraprideO.replace(/[',()]/g, "");
  var hofstraprideSoloO = document.getElementById("HofstraPrideSoloOU").innerHTML;
  var hofstraprideSoloO = hofstraprideSoloO.replace(/[',()]/g, "");
  var hofstraprideHalftime = document.getElementById("HofstraPrideHalftime").innerHTML;
  var hofstraprideHalftimeO = document.getElementById("HofstraPrideHalftimeOU").innerHTML;
  var hofstraprideHalftimeO = hofstraprideHalftimeO.replace(/[',()]/g, "");

  var holycrosscrusaderscover = document.getElementById("HolyCrossCrusadersCover").innerHTML;
  var holycrosscrusadersML = document.getElementById("HolyCrossCrusadersML").innerHTML;
  var holycrosscrusadersO = document.getElementById("HolyCrossCrusadersOU").innerHTML;
  var holycrosscrusadersO = holycrosscrusadersO.replace(/[',()]/g, "");
  var holycrosscrusadersSoloO = document.getElementById("HolyCrossCrusadersSoloOU").innerHTML;
  var holycrosscrusadersSoloO = holycrosscrusadersSoloO.replace(/[',()]/g, "");
  var holycrosscrusadersHalftime = document.getElementById("HolyCrossCrusadersHalftime").innerHTML;
  var holycrosscrusadersHalftimeO = document.getElementById("HolyCrossCrusadersHalftimeOU").innerHTML;
  var holycrosscrusadersHalftimeO = holycrosscrusadersHalftimeO.replace(/[',()]/g, "");

  var houstoncougarscover = document.getElementById("HoustonCougarsCover").innerHTML;
  var houstoncougarsML = document.getElementById("HoustonCougarsML").innerHTML;
  var houstoncougarsO = document.getElementById("HoustonCougarsOU").innerHTML;
  var houstoncougarsO = houstoncougarsO.replace(/[',()]/g, "");
  var houstoncougarsSoloO = document.getElementById("HoustonCougarsSoloOU").innerHTML;
  var houstoncougarsSoloO = houstoncougarsSoloO.replace(/[',()]/g, "");
  var houstoncougarsHalftime = document.getElementById("HoustonCougarsHalftime").innerHTML;
  var houstoncougarsHalftimeO = document.getElementById("HoustonCougarsHalftimeOU").innerHTML;
  var houstoncougarsHalftimeO = houstoncougarsHalftimeO.replace(/[',()]/g, "");

  var houstonbaptisthuskiescover = document.getElementById("HoustonBaptistHuskiesCover").innerHTML;
  var houstonbaptisthuskiesML = document.getElementById("HoustonBaptistHuskiesML").innerHTML;
  var houstonbaptisthuskiesO = document.getElementById("HoustonBaptistHuskiesOU").innerHTML;
  var houstonbaptisthuskiesO = houstonbaptisthuskiesO.replace(/[',()]/g, "");
  var houstonbaptisthuskiesSoloO = document.getElementById("HoustonBaptistHuskiesSoloOU").innerHTML;
  var houstonbaptisthuskiesSoloO = houstonbaptisthuskiesSoloO.replace(/[',()]/g, "");
  var houstonbaptisthuskiesHalftime = document.getElementById("HoustonBaptistHuskiesHalftime").innerHTML;
  var houstonbaptisthuskiesHalftimeO = document.getElementById("HoustonBaptistHuskiesHalftimeOU").innerHTML;
  var houstonbaptisthuskiesHalftimeO = houstonbaptisthuskiesHalftimeO.replace(/[',()]/g, "");

  var howardbisoncover = document.getElementById("HowardBisonCover").innerHTML;
  var howardbisonML = document.getElementById("HowardBisonML").innerHTML;
  var howardbisonO = document.getElementById("HowardBisonOU").innerHTML;
  var howardbisonO = howardbisonO.replace(/[',()]/g, "");
  var howardbisonSoloO = document.getElementById("HowardBisonSoloOU").innerHTML;
  var howardbisonSoloO = howardbisonSoloO.replace(/[',()]/g, "");
  var howardbisonHalftime = document.getElementById("HowardBisonHalftime").innerHTML;
  var howardbisonHalftimeO = document.getElementById("HowardBisonHalftimeOU").innerHTML;
  var howardbisonHalftimeO = howardbisonHalftimeO.replace(/[',()]/g, "");

  var idahovandalscover = document.getElementById("IdahoVandalsCover").innerHTML;
  var idahovandalsML = document.getElementById("IdahoVandalsML").innerHTML;
  var idahovandalsO = document.getElementById("IdahoVandalsOU").innerHTML;
  var idahovandalsO = idahovandalsO.replace(/[',()]/g, "");
  var idahovandalsSoloO = document.getElementById("IdahoVandalsSoloOU").innerHTML;
  var idahovandalsSoloO = idahovandalsSoloO.replace(/[',()]/g, "");
  var idahovandalsHalftime = document.getElementById("IdahoVandalsHalftime").innerHTML;
  var idahovandalsHalftimeO = document.getElementById("IdahoVandalsHalftimeOU").innerHTML;
  var idahovandalsHalftimeO = idahovandalsHalftimeO.replace(/[',()]/g, "");

  var idahostatebengalscover = document.getElementById("IdahoStateBengalsCover").innerHTML;
  var idahostatebengalsML = document.getElementById("IdahoStateBengalsML").innerHTML;
  var idahostatebengalsO = document.getElementById("IdahoStateBengalsOU").innerHTML;
  var idahostatebengalsO = idahostatebengalsO.replace(/[',()]/g, "");
  var idahostatebengalsSoloO = document.getElementById("IdahoStateBengalsSoloOU").innerHTML;
  var idahostatebengalsSoloO = idahostatebengalsSoloO.replace(/[',()]/g, "");
  var idahostatebengalsHalftime = document.getElementById("IdahoStateBengalsHalftime").innerHTML;
  var idahostatebengalsHalftimeO = document.getElementById("IdahoStateBengalsHalftimeOU").innerHTML;
  var idahostatebengalsHalftimeO = idahostatebengalsHalftimeO.replace(/[',()]/g, "");

  var uicflamescover = document.getElementById("UICFlamesCover").innerHTML;
  var uicflamesML = document.getElementById("UICFlamesML").innerHTML;
  var uicflamesO = document.getElementById("UICFlamesOU").innerHTML;
  var uicflamesO = uicflamesO.replace(/[',()]/g, "");
  var uicflamesSoloO = document.getElementById("UICFlamesSoloOU").innerHTML;
  var uicflamesSoloO = uicflamesSoloO.replace(/[',()]/g, "");
  var uicflamesHalftime = document.getElementById("UICFlamesHalftime").innerHTML;
  var uicflamesHalftimeO = document.getElementById("UICFlamesHalftimeOU").innerHTML;
  var uicflamesHalftimeO = uicflamesHalftimeO.replace(/[',()]/g, "");

  var illinoisstateredbirdscover = document.getElementById("IllinoisStateRedbirdsCover").innerHTML;
  var illinoisstateredbirdsML = document.getElementById("IllinoisStateRedbirdsML").innerHTML;
  var illinoisstateredbirdsO = document.getElementById("IllinoisStateRedbirdsOU").innerHTML;
  var illinoisstateredbirdsO = illinoisstateredbirdsO.replace(/[',()]/g, "");
  var illinoisstateredbirdsSoloO = document.getElementById("IllinoisStateRedbirdsSoloOU").innerHTML;
  var illinoisstateredbirdsSoloO = illinoisstateredbirdsSoloO.replace(/[',()]/g, "");
  var illinoisstateredbirdsHalftime = document.getElementById("IllinoisStateRedbirdsHalftime").innerHTML;
  var illinoisstateredbirdsHalftimeO = document.getElementById("IllinoisStateRedbirdsHalftimeOU").innerHTML;
  var illinoisstateredbirdsHalftimeO = illinoisstateredbirdsHalftimeO.replace(/[',()]/g, "");

  var illinoisfightingillinicover = document.getElementById("IllinoisFightingIlliniCover").innerHTML;
  var illinoisfightingilliniML = document.getElementById("IllinoisFightingIlliniML").innerHTML;
  var illinoisfightingilliniO = document.getElementById("IllinoisFightingIlliniOU").innerHTML;
  var illinoisfightingilliniO = illinoisfightingilliniO.replace(/[',()]/g, "");
  var illinoisfightingilliniSoloO = document.getElementById("IllinoisFightingIlliniSoloOU").innerHTML;
  var illinoisfightingilliniSoloO = illinoisfightingilliniSoloO.replace(/[',()]/g, "");
  var illinoisfightingilliniHalftime = document.getElementById("IllinoisFightingIlliniHalftime").innerHTML;
  var illinoisfightingilliniHalftimeO = document.getElementById("IllinoisFightingIlliniHalftimeOU").innerHTML;
  var illinoisfightingilliniHalftimeO = illinoisfightingilliniHalftimeO.replace(/[',()]/g, "");

  var incarnatewordcardinalscover = document.getElementById("IncarnateWordCardinalsCover").innerHTML;
  var incarnatewordcardinalsML = document.getElementById("IncarnateWordCardinalsML").innerHTML;
  var incarnatewordcardinalsO = document.getElementById("IncarnateWordCardinalsOU").innerHTML;
  var incarnatewordcardinalsO = incarnatewordcardinalsO.replace(/[',()]/g, "");
  var incarnatewordcardinalsSoloO = document.getElementById("IncarnateWordCardinalsSoloOU").innerHTML;
  var incarnatewordcardinalsSoloO = incarnatewordcardinalsSoloO.replace(/[',()]/g, "");
  var incarnatewordcardinalsHalftime = document.getElementById("IncarnateWordCardinalsHalftime").innerHTML;
  var incarnatewordcardinalsHalftimeO = document.getElementById("IncarnateWordCardinalsHalftimeOU").innerHTML;
  var incarnatewordcardinalsHalftimeO = incarnatewordcardinalsHalftimeO.replace(/[',()]/g, "");

  var indianahoosierscover = document.getElementById("IndianaHoosiersCover").innerHTML;
  var indianahoosiersML = document.getElementById("IndianaHoosiersML").innerHTML;
  var indianahoosiersO = document.getElementById("IndianaHoosiersOU").innerHTML;
  var indianahoosiersO = indianahoosiersO.replace(/[',()]/g, "");
  var indianahoosiersSoloO = document.getElementById("IndianaHoosiersSoloOU").innerHTML;
  var indianahoosiersSoloO = indianahoosiersSoloO.replace(/[',()]/g, "");
  var indianahoosiersHalftime = document.getElementById("IndianaHoosiersHalftime").innerHTML;
  var indianahoosiersHalftimeO = document.getElementById("IndianaHoosiersHalftimeOU").innerHTML;
  var indianahoosiersHalftimeO = indianahoosiersHalftimeO.replace(/[',()]/g, "");

  var indianastatesycamorescover = document.getElementById("IndianaStateSycamoresCover").innerHTML;
  var indianastatesycamoresML = document.getElementById("IndianaStateSycamoresML").innerHTML;
  var indianastatesycamoresO = document.getElementById("IndianaStateSycamoresOU").innerHTML;
  var indianastatesycamoresO = indianastatesycamoresO.replace(/[',()]/g, "");
  var indianastatesycamoresSoloO = document.getElementById("IndianaStateSycamoresSoloOU").innerHTML;
  var indianastatesycamoresSoloO = indianastatesycamoresSoloO.replace(/[',()]/g, "");
  var indianastatesycamoresHalftime = document.getElementById("IndianaStateSycamoresHalftime").innerHTML;
  var indianastatesycamoresHalftimeO = document.getElementById("IndianaStateSycamoresHalftimeOU").innerHTML;
  var indianastatesycamoresHalftimeO = indianastatesycamoresHalftimeO.replace(/[',()]/g, "");

  var iupuijaguarscover = document.getElementById("IUPUIJaguarsCover").innerHTML;
  var iupuijaguarsML = document.getElementById("IUPUIJaguarsML").innerHTML;
  var iupuijaguarsO = document.getElementById("IUPUIJaguarsOU").innerHTML;
  var iupuijaguarsO = iupuijaguarsO.replace(/[',()]/g, "");
  var iupuijaguarsSoloO = document.getElementById("IUPUIJaguarsSoloOU").innerHTML;
  var iupuijaguarsSoloO = iupuijaguarsSoloO.replace(/[',()]/g, "");
  var iupuijaguarsHalftime = document.getElementById("IUPUIJaguarsHalftime").innerHTML;
  var iupuijaguarsHalftimeO = document.getElementById("IUPUIJaguarsHalftimeOU").innerHTML;
  var iupuijaguarsHalftimeO = iupuijaguarsHalftimeO.replace(/[',()]/g, "");

  var ionagaelscover = document.getElementById("IonaGaelsCover").innerHTML;
  var ionagaelsML = document.getElementById("IonaGaelsML").innerHTML;
  var ionagaelsO = document.getElementById("IonaGaelsOU").innerHTML;
  var ionagaelsO = ionagaelsO.replace(/[',()]/g, "");
  var ionagaelsSoloO = document.getElementById("IonaGaelsSoloOU").innerHTML;
  var ionagaelsSoloO = ionagaelsSoloO.replace(/[',()]/g, "");
  var ionagaelsHalftime = document.getElementById("IonaGaelsHalftime").innerHTML;
  var ionagaelsHalftimeO = document.getElementById("IonaGaelsHalftimeOU").innerHTML;
  var ionagaelsHalftimeO = ionagaelsHalftimeO.replace(/[',()]/g, "");

  var iowahawkeyescover = document.getElementById("IowaHawkeyesCover").innerHTML;
  var iowahawkeyesML = document.getElementById("IowaHawkeyesML").innerHTML;
  var iowahawkeyesO = document.getElementById("IowaHawkeyesOU").innerHTML;
  var iowahawkeyesO = iowahawkeyesO.replace(/[',()]/g, "");
  var iowahawkeyesSoloO = document.getElementById("IowaHawkeyesSoloOU").innerHTML;
  var iowahawkeyesSoloO = iowahawkeyesSoloO.replace(/[',()]/g, "");
  var iowahawkeyesHalftime = document.getElementById("IowaHawkeyesHalftime").innerHTML;
  var iowahawkeyesHalftimeO = document.getElementById("IowaHawkeyesHalftimeOU").innerHTML;
  var iowahawkeyesHalftimeO = iowahawkeyesHalftimeO.replace(/[',()]/g, "");

  var iowastatecyclonescover = document.getElementById("IowaStateCyclonesCover").innerHTML;
  var iowastatecyclonesML = document.getElementById("IowaStateCyclonesML").innerHTML;
  var iowastatecyclonesO = document.getElementById("IowaStateCyclonesOU").innerHTML;
  var iowastatecyclonesO = iowastatecyclonesO.replace(/[',()]/g, "");
  var iowastatecyclonesSoloO = document.getElementById("IowaStateCyclonesSoloOU").innerHTML;
  var iowastatecyclonesSoloO = iowastatecyclonesSoloO.replace(/[',()]/g, "");
  var iowastatecyclonesHalftime = document.getElementById("IowaStateCyclonesHalftime").innerHTML;
  var iowastatecyclonesHalftimeO = document.getElementById("IowaStateCyclonesHalftimeOU").innerHTML;
  var iowastatecyclonesHalftimeO = iowastatecyclonesHalftimeO.replace(/[',()]/g, "");

  var jacksonstatetigerscover = document.getElementById("JacksonStateTigersCover").innerHTML;
  var jacksonstatetigersML = document.getElementById("JacksonStateTigersML").innerHTML;
  var jacksonstatetigersO = document.getElementById("JacksonStateTigersOU").innerHTML;
  var jacksonstatetigersO = jacksonstatetigersO.replace(/[',()]/g, "");
  var jacksonstatetigersSoloO = document.getElementById("JacksonStateTigersSoloOU").innerHTML;
  var jacksonstatetigersSoloO = jacksonstatetigersSoloO.replace(/[',()]/g, "");
  var jacksonstatetigersHalftime = document.getElementById("JacksonStateTigersHalftime").innerHTML;
  var jacksonstatetigersHalftimeO = document.getElementById("JacksonStateTigersHalftimeOU").innerHTML;
  var jacksonstatetigersHalftimeO = jacksonstatetigersHalftimeO.replace(/[',()]/g, "");

  var jacksonvilledolphinscover = document.getElementById("JacksonvilleDolphinsCover").innerHTML;
  var jacksonvilledolphinsML = document.getElementById("JacksonvilleDolphinsML").innerHTML;
  var jacksonvilledolphinsO = document.getElementById("JacksonvilleDolphinsOU").innerHTML;
  var jacksonvilledolphinsO = jacksonvilledolphinsO.replace(/[',()]/g, "");
  var jacksonvilledolphinsSoloO = document.getElementById("JacksonvilleDolphinsSoloOU").innerHTML;
  var jacksonvilledolphinsSoloO = jacksonvilledolphinsSoloO.replace(/[',()]/g, "");
  var jacksonvilledolphinsHalftime = document.getElementById("JacksonvilleDolphinsHalftime").innerHTML;
  var jacksonvilledolphinsHalftimeO = document.getElementById("JacksonvilleDolphinsHalftimeOU").innerHTML;
  var jacksonvilledolphinsHalftimeO = jacksonvilledolphinsHalftimeO.replace(/[',()]/g, "");

  var jacksonvillestategamecockscover = document.getElementById("JacksonvilleStateGamecocksCover").innerHTML;
  var jacksonvillestategamecocksML = document.getElementById("JacksonvilleStateGamecocksML").innerHTML;
  var jacksonvillestategamecocksO = document.getElementById("JacksonvilleStateGamecocksOU").innerHTML;
  var jacksonvillestategamecocksO = jacksonvillestategamecocksO.replace(/[',()]/g, "");
  var jacksonvillestategamecocksSoloO = document.getElementById("JacksonvilleStateGamecocksSoloOU").innerHTML;
  var jacksonvillestategamecocksSoloO = jacksonvillestategamecocksSoloO.replace(/[',()]/g, "");
  var jacksonvillestategamecocksHalftime = document.getElementById("JacksonvilleStateGamecocksHalftime").innerHTML;
  var jacksonvillestategamecocksHalftimeO = document.getElementById("JacksonvilleStateGamecocksHalftimeOU").innerHTML;
  var jacksonvillestategamecocksHalftimeO = jacksonvillestategamecocksHalftimeO.replace(/[',()]/g, "");

  var jamesmadisondukescover = document.getElementById("JamesMadisonDukesCover").innerHTML;
  var jamesmadisondukesML = document.getElementById("JamesMadisonDukesML").innerHTML;
  var jamesmadisondukesO = document.getElementById("JamesMadisonDukesOU").innerHTML;
  var jamesmadisondukesO = jamesmadisondukesO.replace(/[',()]/g, "");
  var jamesmadisondukesSoloO = document.getElementById("JamesMadisonDukesSoloOU").innerHTML;
  var jamesmadisondukesSoloO = jamesmadisondukesSoloO.replace(/[',()]/g, "");
  var jamesmadisondukesHalftime = document.getElementById("JamesMadisonDukesHalftime").innerHTML;
  var jamesmadisondukesHalftimeO = document.getElementById("JamesMadisonDukesHalftimeOU").innerHTML;
  var jamesmadisondukesHalftimeO = jamesmadisondukesHalftimeO.replace(/[',()]/g, "");

  var kansasjayhawkscover = document.getElementById("KansasJayhawksCover").innerHTML;
  var kansasjayhawksML = document.getElementById("KansasJayhawksML").innerHTML;
  var kansasjayhawksO = document.getElementById("KansasJayhawksOU").innerHTML;
  var kansasjayhawksO = kansasjayhawksO.replace(/[',()]/g, "");
  var kansasjayhawksSoloO = document.getElementById("KansasJayhawksSoloOU").innerHTML;
  var kansasjayhawksSoloO = kansasjayhawksSoloO.replace(/[',()]/g, "");
  var kansasjayhawksHalftime = document.getElementById("KansasJayhawksHalftime").innerHTML;
  var kansasjayhawksHalftimeO = document.getElementById("KansasJayhawksHalftimeOU").innerHTML;
  var kansasjayhawksHalftimeO = kansasjayhawksHalftimeO.replace(/[',()]/g, "");

  var kansasstatewildcatscover = document.getElementById("KansasStateWildcatsCover").innerHTML;
  var kansasstatewildcatsML = document.getElementById("KansasStateWildcatsML").innerHTML;
  var kansasstatewildcatsO = document.getElementById("KansasStateWildcatsOU").innerHTML;
  var kansasstatewildcatsO = kansasstatewildcatsO.replace(/[',()]/g, "");
  var kansasstatewildcatsSoloO = document.getElementById("KansasStateWildcatsSoloOU").innerHTML;
  var kansasstatewildcatsSoloO = kansasstatewildcatsSoloO.replace(/[',()]/g, "");
  var kansasstatewildcatsHalftime = document.getElementById("KansasStateWildcatsHalftime").innerHTML;
  var kansasstatewildcatsHalftimeO = document.getElementById("KansasStateWildcatsHalftimeOU").innerHTML;
  var kansasstatewildcatsHalftimeO = kansasstatewildcatsHalftimeO.replace(/[',()]/g, "");

  var kennesawstateowlscover = document.getElementById("KennesawStateOwlsCover").innerHTML;
  var kennesawstateowlsML = document.getElementById("KennesawStateOwlsML").innerHTML;
  var kennesawstateowlsO = document.getElementById("KennesawStateOwlsOU").innerHTML;
  var kennesawstateowlsO = kennesawstateowlsO.replace(/[',()]/g, "");
  var kennesawstateowlsSoloO = document.getElementById("KennesawStateOwlsSoloOU").innerHTML;
  var kennesawstateowlsSoloO = kennesawstateowlsSoloO.replace(/[',()]/g, "");
  var kennesawstateowlsHalftime = document.getElementById("KennesawStateOwlsHalftime").innerHTML;
  var kennesawstateowlsHalftimeO = document.getElementById("KennesawStateOwlsHalftimeOU").innerHTML;
  var kennesawstateowlsHalftimeO = kennesawstateowlsHalftimeO.replace(/[',()]/g, "");

  var kentstategoldenflashescover = document.getElementById("KentStateGoldenFlashesCover").innerHTML;
  var kentstategoldenflashesML = document.getElementById("KentStateGoldenFlashesML").innerHTML;
  var kentstategoldenflashesO = document.getElementById("KentStateGoldenFlashesOU").innerHTML;
  var kentstategoldenflashesO = kentstategoldenflashesO.replace(/[',()]/g, "");
  var kentstategoldenflashesSoloO = document.getElementById("KentStateGoldenFlashesSoloOU").innerHTML;
  var kentstategoldenflashesSoloO = kentstategoldenflashesSoloO.replace(/[',()]/g, "");
  var kentstategoldenflashesHalftime = document.getElementById("KentStateGoldenFlashesHalftime").innerHTML;
  var kentstategoldenflashesHalftimeO = document.getElementById("KentStateGoldenFlashesHalftimeOU").innerHTML;
  var kentstategoldenflashesHalftimeO = kentstategoldenflashesHalftimeO.replace(/[',()]/g, "");

  var kentuckywildcatscover = document.getElementById("KentuckyWildcatsCover").innerHTML;
  var kentuckywildcatsML = document.getElementById("KentuckyWildcatsML").innerHTML;
  var kentuckywildcatsO = document.getElementById("KentuckyWildcatsOU").innerHTML;
  var kentuckywildcatsO = kentuckywildcatsO.replace(/[',()]/g, "");
  var kentuckywildcatsSoloO = document.getElementById("KentuckyWildcatsSoloOU").innerHTML;
  var kentuckywildcatsSoloO = kentuckywildcatsSoloO.replace(/[',()]/g, "");
  var kentuckywildcatsHalftime = document.getElementById("KentuckyWildcatsHalftime").innerHTML;
  var kentuckywildcatsHalftimeO = document.getElementById("KentuckyWildcatsHalftimeOU").innerHTML;
  var kentuckywildcatsHalftimeO = kentuckywildcatsHalftimeO.replace(/[',()]/g, "");

  var lasalleexplorerscover = document.getElementById("LaSalleExplorersCover").innerHTML;
  var lasalleexplorersML = document.getElementById("LaSalleExplorersML").innerHTML;
  var lasalleexplorersO = document.getElementById("LaSalleExplorersOU").innerHTML;
  var lasalleexplorersO = lasalleexplorersO.replace(/[',()]/g, "");
  var lasalleexplorersSoloO = document.getElementById("LaSalleExplorersSoloOU").innerHTML;
  var lasalleexplorersSoloO = lasalleexplorersSoloO.replace(/[',()]/g, "");
  var lasalleexplorersHalftime = document.getElementById("LaSalleExplorersHalftime").innerHTML;
  var lasalleexplorersHalftimeO = document.getElementById("LaSalleExplorersHalftimeOU").innerHTML;
  var lasalleexplorersHalftimeO = lasalleexplorersHalftimeO.replace(/[',()]/g, "");

  var lafayetteleopardscover = document.getElementById("LafayetteLeopardsCover").innerHTML;
  var lafayetteleopardsML = document.getElementById("LafayetteLeopardsML").innerHTML;
  var lafayetteleopardsO = document.getElementById("LafayetteLeopardsOU").innerHTML;
  var lafayetteleopardsO = lafayetteleopardsO.replace(/[',()]/g, "");
  var lafayetteleopardsSoloO = document.getElementById("LafayetteLeopardsSoloOU").innerHTML;
  var lafayetteleopardsSoloO = lafayetteleopardsSoloO.replace(/[',()]/g, "");
  var lafayetteleopardsHalftime = document.getElementById("LafayetteLeopardsHalftime").innerHTML;
  var lafayetteleopardsHalftimeO = document.getElementById("LafayetteLeopardsHalftimeOU").innerHTML;
  var lafayetteleopardsHalftimeO = lafayetteleopardsHalftimeO.replace(/[',()]/g, "");

  var lamarcardinalscover = document.getElementById("LamarCardinalsCover").innerHTML;
  var lamarcardinalsML = document.getElementById("LamarCardinalsML").innerHTML;
  var lamarcardinalsO = document.getElementById("LamarCardinalsOU").innerHTML;
  var lamarcardinalsO = lamarcardinalsO.replace(/[',()]/g, "");
  var lamarcardinalsSoloO = document.getElementById("LamarCardinalsSoloOU").innerHTML;
  var lamarcardinalsSoloO = lamarcardinalsSoloO.replace(/[',()]/g, "");
  var lamarcardinalsHalftime = document.getElementById("LamarCardinalsHalftime").innerHTML;
  var lamarcardinalsHalftimeO = document.getElementById("LamarCardinalsHalftimeOU").innerHTML;
  var lamarcardinalsHalftimeO = lamarcardinalsHalftimeO.replace(/[',()]/g, "");

  var lehighmountainhawkscover = document.getElementById("LehighMountainHawksCover").innerHTML;
  var lehighmountainhawksML = document.getElementById("LehighMountainHawksML").innerHTML;
  var lehighmountainhawksO = document.getElementById("LehighMountainHawksOU").innerHTML;
  var lehighmountainhawksO = lehighmountainhawksO.replace(/[',()]/g, "");
  var lehighmountainhawksSoloO = document.getElementById("LehighMountainHawksSoloOU").innerHTML;
  var lehighmountainhawksSoloO = lehighmountainhawksSoloO.replace(/[',()]/g, "");
  var lehighmountainhawksHalftime = document.getElementById("LehighMountainHawksHalftime").innerHTML;
  var lehighmountainhawksHalftimeO = document.getElementById("LehighMountainHawksHalftimeOU").innerHTML;
  var lehighmountainhawksHalftimeO = lehighmountainhawksHalftimeO.replace(/[',()]/g, "");

  var libertyflamescover = document.getElementById("LibertyFlamesCover").innerHTML;
  var libertyflamesML = document.getElementById("LibertyFlamesML").innerHTML;
  var libertyflamesO = document.getElementById("LibertyFlamesOU").innerHTML;
  var libertyflamesO = libertyflamesO.replace(/[',()]/g, "");
  var libertyflamesSoloO = document.getElementById("LibertyFlamesSoloOU").innerHTML;
  var libertyflamesSoloO = libertyflamesSoloO.replace(/[',()]/g, "");
  var libertyflamesHalftime = document.getElementById("LibertyFlamesHalftime").innerHTML;
  var libertyflamesHalftimeO = document.getElementById("LibertyFlamesHalftimeOU").innerHTML;
  var libertyflamesHalftimeO = libertyflamesHalftimeO.replace(/[',()]/g, "");

  var lipscombbisonscover = document.getElementById("LipscombBisonsCover").innerHTML;
  var lipscombbisonsML = document.getElementById("LipscombBisonsML").innerHTML;
  var lipscombbisonsO = document.getElementById("LipscombBisonsOU").innerHTML;
  var lipscombbisonsO = lipscombbisonsO.replace(/[',()]/g, "");
  var lipscombbisonsSoloO = document.getElementById("LipscombBisonsSoloOU").innerHTML;
  var lipscombbisonsSoloO = lipscombbisonsSoloO.replace(/[',()]/g, "");
  var lipscombbisonsHalftime = document.getElementById("LipscombBisonsHalftime").innerHTML;
  var lipscombbisonsHalftimeO = document.getElementById("LipscombBisonsHalftimeOU").innerHTML;
  var lipscombbisonsHalftimeO = lipscombbisonsHalftimeO.replace(/[',()]/g, "");

  var longislanduniversitysharkscover = document.getElementById("LongIslandUniversitySharksCover").innerHTML;
  var longislanduniversitysharksML = document.getElementById("LongIslandUniversitySharksML").innerHTML;
  var longislanduniversitysharksO = document.getElementById("LongIslandUniversitySharksOU").innerHTML;
  var longislanduniversitysharksO = longislanduniversitysharksO.replace(/[',()]/g, "");
  var longislanduniversitysharksSoloO = document.getElementById("LongIslandUniversitySharksSoloOU").innerHTML;
  var longislanduniversitysharksSoloO = longislanduniversitysharksSoloO.replace(/[',()]/g, "");
  var longislanduniversitysharksHalftime = document.getElementById("LongIslandUniversitySharksHalftime").innerHTML;
  var longislanduniversitysharksHalftimeO = document.getElementById("LongIslandUniversitySharksHalftimeOU").innerHTML;
  var longislanduniversitysharksHalftimeO = longislanduniversitysharksHalftimeO.replace(/[',()]/g, "");

  var longwoodlancerscover = document.getElementById("LongwoodLancersCover").innerHTML;
  var longwoodlancersML = document.getElementById("LongwoodLancersML").innerHTML;
  var longwoodlancersO = document.getElementById("LongwoodLancersOU").innerHTML;
  var longwoodlancersO = longwoodlancersO.replace(/[',()]/g, "");
  var longwoodlancersSoloO = document.getElementById("LongwoodLancersSoloOU").innerHTML;
  var longwoodlancersSoloO = longwoodlancersSoloO.replace(/[',()]/g, "");
  var longwoodlancersHalftime = document.getElementById("LongwoodLancersHalftime").innerHTML;
  var longwoodlancersHalftimeO = document.getElementById("LongwoodLancersHalftimeOU").innerHTML;
  var longwoodlancersHalftimeO = longwoodlancersHalftimeO.replace(/[',()]/g, "");

  var louisianaragincajunscover = document.getElementById("LouisianaRaginCajunsCover").innerHTML;
  var louisianaragincajunsML = document.getElementById("LouisianaRaginCajunsML").innerHTML;
  var louisianaragincajunsO = document.getElementById("LouisianaRaginCajunsOU").innerHTML;
  var louisianaragincajunsO = louisianaragincajunsO.replace(/[',()]/g, "");
  var louisianaragincajunsSoloO = document.getElementById("LouisianaRaginCajunsSoloOU").innerHTML;
  var louisianaragincajunsSoloO = louisianaragincajunsSoloO.replace(/[',()]/g, "");
  var louisianaragincajunsHalftime = document.getElementById("LouisianaRaginCajunsHalftime").innerHTML;
  var louisianaragincajunsHalftimeO = document.getElementById("LouisianaRaginCajunsHalftimeOU").innerHTML;
  var louisianaragincajunsHalftimeO = louisianaragincajunsHalftimeO.replace(/[',()]/g, "");

  var ulmonroewarhawkscover = document.getElementById("ULMonroeWarhawksCover").innerHTML;
  var ulmonroewarhawksML = document.getElementById("ULMonroeWarhawksML").innerHTML;
  var ulmonroewarhawksO = document.getElementById("ULMonroeWarhawksOU").innerHTML;
  var ulmonroewarhawksO = ulmonroewarhawksO.replace(/[',()]/g, "");
  var ulmonroewarhawksSoloO = document.getElementById("ULMonroeWarhawksSoloOU").innerHTML;
  var ulmonroewarhawksSoloO = ulmonroewarhawksSoloO.replace(/[',()]/g, "");
  var ulmonroewarhawksHalftime = document.getElementById("ULMonroeWarhawksHalftime").innerHTML;
  var ulmonroewarhawksHalftimeO = document.getElementById("ULMonroeWarhawksHalftimeOU").innerHTML;
  var ulmonroewarhawksHalftimeO = ulmonroewarhawksHalftimeO.replace(/[',()]/g, "");

  var lsutigerscover = document.getElementById("LSUTigersCover").innerHTML;
  var lsutigersML = document.getElementById("LSUTigersML").innerHTML;
  var lsutigersO = document.getElementById("LSUTigersOU").innerHTML;
  var lsutigersO = lsutigersO.replace(/[',()]/g, "");
  var lsutigersSoloO = document.getElementById("LSUTigersSoloOU").innerHTML;
  var lsutigersSoloO = lsutigersSoloO.replace(/[',()]/g, "");
  var lsutigersHalftime = document.getElementById("LSUTigersHalftime").innerHTML;
  var lsutigersHalftimeO = document.getElementById("LSUTigersHalftimeOU").innerHTML;
  var lsutigersHalftimeO = lsutigersHalftimeO.replace(/[',()]/g, "");

  var louisianatechbulldogscover = document.getElementById("LouisianaTechBulldogsCover").innerHTML;
  var louisianatechbulldogsML = document.getElementById("LouisianaTechBulldogsML").innerHTML;
  var louisianatechbulldogsO = document.getElementById("LouisianaTechBulldogsOU").innerHTML;
  var louisianatechbulldogsO = louisianatechbulldogsO.replace(/[',()]/g, "");
  var louisianatechbulldogsSoloO = document.getElementById("LouisianaTechBulldogsSoloOU").innerHTML;
  var louisianatechbulldogsSoloO = louisianatechbulldogsSoloO.replace(/[',()]/g, "");
  var louisianatechbulldogsHalftime = document.getElementById("LouisianaTechBulldogsHalftime").innerHTML;
  var louisianatechbulldogsHalftimeO = document.getElementById("LouisianaTechBulldogsHalftimeOU").innerHTML;
  var louisianatechbulldogsHalftimeO = louisianatechbulldogsHalftimeO.replace(/[',()]/g, "");

  var louisvillecardinalscover = document.getElementById("LouisvilleCardinalsCover").innerHTML;
  var louisvillecardinalsML = document.getElementById("LouisvilleCardinalsML").innerHTML;
  var louisvillecardinalsO = document.getElementById("LouisvilleCardinalsOU").innerHTML;
  var louisvillecardinalsO = louisvillecardinalsO.replace(/[',()]/g, "");
  var louisvillecardinalsSoloO = document.getElementById("LouisvilleCardinalsSoloOU").innerHTML;
  var louisvillecardinalsSoloO = louisvillecardinalsSoloO.replace(/[',()]/g, "");
  var louisvillecardinalsHalftime = document.getElementById("LouisvilleCardinalsHalftime").innerHTML;
  var louisvillecardinalsHalftimeO = document.getElementById("LouisvilleCardinalsHalftimeOU").innerHTML;
  var louisvillecardinalsHalftimeO = louisvillecardinalsHalftimeO.replace(/[',()]/g, "");

  var loyolachicagoramblerscover = document.getElementById("LoyolaChicagoRamblersCover").innerHTML;
  var loyolachicagoramblersML = document.getElementById("LoyolaChicagoRamblersML").innerHTML;
  var loyolachicagoramblersO = document.getElementById("LoyolaChicagoRamblersOU").innerHTML;
  var loyolachicagoramblersO = loyolachicagoramblersO.replace(/[',()]/g, "");
  var loyolachicagoramblersSoloO = document.getElementById("LoyolaChicagoRamblersSoloOU").innerHTML;
  var loyolachicagoramblersSoloO = loyolachicagoramblersSoloO.replace(/[',()]/g, "");
  var loyolachicagoramblersHalftime = document.getElementById("LoyolaChicagoRamblersHalftime").innerHTML;
  var loyolachicagoramblersHalftimeO = document.getElementById("LoyolaChicagoRamblersHalftimeOU").innerHTML;
  var loyolachicagoramblersHalftimeO = loyolachicagoramblersHalftimeO.replace(/[',()]/g, "");

  var loyolamdgreyhoundscover = document.getElementById("LoyolaMDGreyhoundsCover").innerHTML;
  var loyolamdgreyhoundsML = document.getElementById("LoyolaMDGreyhoundsML").innerHTML;
  var loyolamdgreyhoundsO = document.getElementById("LoyolaMDGreyhoundsOU").innerHTML;
  var loyolamdgreyhoundsO = loyolamdgreyhoundsO.replace(/[',()]/g, "");
  var loyolamdgreyhoundsSoloO = document.getElementById("LoyolaMDGreyhoundsSoloOU").innerHTML;
  var loyolamdgreyhoundsSoloO = loyolamdgreyhoundsSoloO.replace(/[',()]/g, "");
  var loyolamdgreyhoundsHalftime = document.getElementById("LoyolaMDGreyhoundsHalftime").innerHTML;
  var loyolamdgreyhoundsHalftimeO = document.getElementById("LoyolaMDGreyhoundsHalftimeOU").innerHTML;
  var loyolamdgreyhoundsHalftimeO = loyolamdgreyhoundsHalftimeO.replace(/[',()]/g, "");

  var loyolamarymountlionscover = document.getElementById("LoyolaMarymountLionsCover").innerHTML;
  var loyolamarymountlionsML = document.getElementById("LoyolaMarymountLionsML").innerHTML;
  var loyolamarymountlionsO = document.getElementById("LoyolaMarymountLionsOU").innerHTML;
  var loyolamarymountlionsO = loyolamarymountlionsO.replace(/[',()]/g, "");
  var loyolamarymountlionsSoloO = document.getElementById("LoyolaMarymountLionsSoloOU").innerHTML;
  var loyolamarymountlionsSoloO = loyolamarymountlionsSoloO.replace(/[',()]/g, "");
  var loyolamarymountlionsHalftime = document.getElementById("LoyolaMarymountLionsHalftime").innerHTML;
  var loyolamarymountlionsHalftimeO = document.getElementById("LoyolaMarymountLionsHalftimeOU").innerHTML;
  var loyolamarymountlionsHalftimeO = loyolamarymountlionsHalftimeO.replace(/[',()]/g, "");

  var maineblackbearscover = document.getElementById("MaineBlackBearsCover").innerHTML;
  var maineblackbearsML = document.getElementById("MaineBlackBearsML").innerHTML;
  var maineblackbearsO = document.getElementById("MaineBlackBearsOU").innerHTML;
  var maineblackbearsO = maineblackbearsO.replace(/[',()]/g, "");
  var maineblackbearsSoloO = document.getElementById("MaineBlackBearsSoloOU").innerHTML;
  var maineblackbearsSoloO = maineblackbearsSoloO.replace(/[',()]/g, "");
  var maineblackbearsHalftime = document.getElementById("MaineBlackBearsHalftime").innerHTML;
  var maineblackbearsHalftimeO = document.getElementById("MaineBlackBearsHalftimeOU").innerHTML;
  var maineblackbearsHalftimeO = maineblackbearsHalftimeO.replace(/[',()]/g, "");

  var manhattanjasperscover = document.getElementById("ManhattanJaspersCover").innerHTML;
  var manhattanjaspersML = document.getElementById("ManhattanJaspersML").innerHTML;
  var manhattanjaspersO = document.getElementById("ManhattanJaspersOU").innerHTML;
  var manhattanjaspersO = manhattanjaspersO.replace(/[',()]/g, "");
  var manhattanjaspersSoloO = document.getElementById("ManhattanJaspersSoloOU").innerHTML;
  var manhattanjaspersSoloO = manhattanjaspersSoloO.replace(/[',()]/g, "");
  var manhattanjaspersHalftime = document.getElementById("ManhattanJaspersHalftime").innerHTML;
  var manhattanjaspersHalftimeO = document.getElementById("ManhattanJaspersHalftimeOU").innerHTML;
  var manhattanjaspersHalftimeO = manhattanjaspersHalftimeO.replace(/[',()]/g, "");

  var maristredfoxescover = document.getElementById("MaristRedFoxesCover").innerHTML;
  var maristredfoxesML = document.getElementById("MaristRedFoxesML").innerHTML;
  var maristredfoxesO = document.getElementById("MaristRedFoxesOU").innerHTML;
  var maristredfoxesO = maristredfoxesO.replace(/[',()]/g, "");
  var maristredfoxesSoloO = document.getElementById("MaristRedFoxesSoloOU").innerHTML;
  var maristredfoxesSoloO = maristredfoxesSoloO.replace(/[',()]/g, "");
  var maristredfoxesHalftime = document.getElementById("MaristRedFoxesHalftime").innerHTML;
  var maristredfoxesHalftimeO = document.getElementById("MaristRedFoxesHalftimeOU").innerHTML;
  var maristredfoxesHalftimeO = maristredfoxesHalftimeO.replace(/[',()]/g, "");

  var marquettegoldeneaglescover = document.getElementById("MarquetteGoldenEaglesCover").innerHTML;
  var marquettegoldeneaglesML = document.getElementById("MarquetteGoldenEaglesML").innerHTML;
  var marquettegoldeneaglesO = document.getElementById("MarquetteGoldenEaglesOU").innerHTML;
  var marquettegoldeneaglesO = marquettegoldeneaglesO.replace(/[',()]/g, "");
  var marquettegoldeneaglesSoloO = document.getElementById("MarquetteGoldenEaglesSoloOU").innerHTML;
  var marquettegoldeneaglesSoloO = marquettegoldeneaglesSoloO.replace(/[',()]/g, "");
  var marquettegoldeneaglesHalftime = document.getElementById("MarquetteGoldenEaglesHalftime").innerHTML;
  var marquettegoldeneaglesHalftimeO = document.getElementById("MarquetteGoldenEaglesHalftimeOU").innerHTML;
  var marquettegoldeneaglesHalftimeO = marquettegoldeneaglesHalftimeO.replace(/[',()]/g, "");

  var marshallthunderingherdcover = document.getElementById("MarshallThunderingHerdCover").innerHTML;
  var marshallthunderingherdML = document.getElementById("MarshallThunderingHerdML").innerHTML;
  var marshallthunderingherdO = document.getElementById("MarshallThunderingHerdOU").innerHTML;
  var marshallthunderingherdO = marshallthunderingherdO.replace(/[',()]/g, "");
  var marshallthunderingherdSoloO = document.getElementById("MarshallThunderingHerdSoloOU").innerHTML;
  var marshallthunderingherdSoloO = marshallthunderingherdSoloO.replace(/[',()]/g, "");
  var marshallthunderingherdHalftime = document.getElementById("MarshallThunderingHerdHalftime").innerHTML;
  var marshallthunderingherdHalftimeO = document.getElementById("MarshallThunderingHerdHalftimeOU").innerHTML;
  var marshallthunderingherdHalftimeO = marshallthunderingherdHalftimeO.replace(/[',()]/g, "");

  var umbcretrieverscover = document.getElementById("UMBCRetrieversCover").innerHTML;
  var umbcretrieversML = document.getElementById("UMBCRetrieversML").innerHTML;
  var umbcretrieversO = document.getElementById("UMBCRetrieversOU").innerHTML;
  var umbcretrieversO = umbcretrieversO.replace(/[',()]/g, "");
  var umbcretrieversSoloO = document.getElementById("UMBCRetrieversSoloOU").innerHTML;
  var umbcretrieversSoloO = umbcretrieversSoloO.replace(/[',()]/g, "");
  var umbcretrieversHalftime = document.getElementById("UMBCRetrieversHalftime").innerHTML;
  var umbcretrieversHalftimeO = document.getElementById("UMBCRetrieversHalftimeOU").innerHTML;
  var umbcretrieversHalftimeO = umbcretrieversHalftimeO.replace(/[',()]/g, "");

  var marylandterrapinscover = document.getElementById("MarylandTerrapinsCover").innerHTML;
  var marylandterrapinsML = document.getElementById("MarylandTerrapinsML").innerHTML;
  var marylandterrapinsO = document.getElementById("MarylandTerrapinsOU").innerHTML;
  var marylandterrapinsO = marylandterrapinsO.replace(/[',()]/g, "");
  var marylandterrapinsSoloO = document.getElementById("MarylandTerrapinsSoloOU").innerHTML;
  var marylandterrapinsSoloO = marylandterrapinsSoloO.replace(/[',()]/g, "");
  var marylandterrapinsHalftime = document.getElementById("MarylandTerrapinsHalftime").innerHTML;
  var marylandterrapinsHalftimeO = document.getElementById("MarylandTerrapinsHalftimeOU").innerHTML;
  var marylandterrapinsHalftimeO = marylandterrapinsHalftimeO.replace(/[',()]/g, "");

  var marylandeasternshorehawkscover = document.getElementById("MarylandEasternShoreHawksCover").innerHTML;
  var marylandeasternshorehawksML = document.getElementById("MarylandEasternShoreHawksML").innerHTML;
  var marylandeasternshorehawksO = document.getElementById("MarylandEasternShoreHawksOU").innerHTML;
  var marylandeasternshorehawksO = marylandeasternshorehawksO.replace(/[',()]/g, "");
  var marylandeasternshorehawksSoloO = document.getElementById("MarylandEasternShoreHawksSoloOU").innerHTML;
  var marylandeasternshorehawksSoloO = marylandeasternshorehawksSoloO.replace(/[',()]/g, "");
  var marylandeasternshorehawksHalftime = document.getElementById("MarylandEasternShoreHawksHalftime").innerHTML;
  var marylandeasternshorehawksHalftimeO = document.getElementById("MarylandEasternShoreHawksHalftimeOU").innerHTML;
  var marylandeasternshorehawksHalftimeO = marylandeasternshorehawksHalftimeO.replace(/[',()]/g, "");

  var umassminutemencover = document.getElementById("UMassMinutemenCover").innerHTML;
  var umassminutemenML = document.getElementById("UMassMinutemenML").innerHTML;
  var umassminutemenO = document.getElementById("UMassMinutemenOU").innerHTML;
  var umassminutemenO = umassminutemenO.replace(/[',()]/g, "");
  var umassminutemenSoloO = document.getElementById("UMassMinutemenSoloOU").innerHTML;
  var umassminutemenSoloO = umassminutemenSoloO.replace(/[',()]/g, "");
  var umassminutemenHalftime = document.getElementById("UMassMinutemenHalftime").innerHTML;
  var umassminutemenHalftimeO = document.getElementById("UMassMinutemenHalftimeOU").innerHTML;
  var umassminutemenHalftimeO = umassminutemenHalftimeO.replace(/[',()]/g, "");

  var umasslowellriverhawkscover = document.getElementById("UMassLowellRiverHawksCover").innerHTML;
  var umasslowellriverhawksML = document.getElementById("UMassLowellRiverHawksML").innerHTML;
  var umasslowellriverhawksO = document.getElementById("UMassLowellRiverHawksOU").innerHTML;
  var umasslowellriverhawksO = umasslowellriverhawksO.replace(/[',()]/g, "");
  var umasslowellriverhawksSoloO = document.getElementById("UMassLowellRiverHawksSoloOU").innerHTML;
  var umasslowellriverhawksSoloO = umasslowellriverhawksSoloO.replace(/[',()]/g, "");
  var umasslowellriverhawksHalftime = document.getElementById("UMassLowellRiverHawksHalftime").innerHTML;
  var umasslowellriverhawksHalftimeO = document.getElementById("UMassLowellRiverHawksHalftimeOU").innerHTML;
  var umasslowellriverhawksHalftimeO = umasslowellriverhawksHalftimeO.replace(/[',()]/g, "");

  var mcneesestatecowboyscover = document.getElementById("McNeeseStateCowboysCover").innerHTML;
  var mcneesestatecowboysML = document.getElementById("McNeeseStateCowboysML").innerHTML;
  var mcneesestatecowboysO = document.getElementById("McNeeseStateCowboysOU").innerHTML;
  var mcneesestatecowboysO = mcneesestatecowboysO.replace(/[',()]/g, "");
  var mcneesestatecowboysSoloO = document.getElementById("McNeeseStateCowboysSoloOU").innerHTML;
  var mcneesestatecowboysSoloO = mcneesestatecowboysSoloO.replace(/[',()]/g, "");
  var mcneesestatecowboysHalftime = document.getElementById("McNeeseStateCowboysHalftime").innerHTML;
  var mcneesestatecowboysHalftimeO = document.getElementById("McNeeseStateCowboysHalftimeOU").innerHTML;
  var mcneesestatecowboysHalftimeO = mcneesestatecowboysHalftimeO.replace(/[',()]/g, "");

  var memphistigerscover = document.getElementById("MemphisTigersCover").innerHTML;
  var memphistigersML = document.getElementById("MemphisTigersML").innerHTML;
  var memphistigersO = document.getElementById("MemphisTigersOU").innerHTML;
  var memphistigersO = memphistigersO.replace(/[',()]/g, "");
  var memphistigersSoloO = document.getElementById("MemphisTigersSoloOU").innerHTML;
  var memphistigersSoloO = memphistigersSoloO.replace(/[',()]/g, "");
  var memphistigersHalftime = document.getElementById("MemphisTigersHalftime").innerHTML;
  var memphistigersHalftimeO = document.getElementById("MemphisTigersHalftimeOU").innerHTML;
  var memphistigersHalftimeO = memphistigersHalftimeO.replace(/[',()]/g, "");

  var mercerbearscover = document.getElementById("MercerBearsCover").innerHTML;
  var mercerbearsML = document.getElementById("MercerBearsML").innerHTML;
  var mercerbearsO = document.getElementById("MercerBearsOU").innerHTML;
  var mercerbearsO = mercerbearsO.replace(/[',()]/g, "");
  var mercerbearsSoloO = document.getElementById("MercerBearsSoloOU").innerHTML;
  var mercerbearsSoloO = mercerbearsSoloO.replace(/[',()]/g, "");
  var mercerbearsHalftime = document.getElementById("MercerBearsHalftime").innerHTML;
  var mercerbearsHalftimeO = document.getElementById("MercerBearsHalftimeOU").innerHTML;
  var mercerbearsHalftimeO = mercerbearsHalftimeO.replace(/[',()]/g, "");

  var miamihurricanescover = document.getElementById("MiamiHurricanesCover").innerHTML;
  var miamihurricanesML = document.getElementById("MiamiHurricanesML").innerHTML;
  var miamihurricanesO = document.getElementById("MiamiHurricanesOU").innerHTML;
  var miamihurricanesO = miamihurricanesO.replace(/[',()]/g, "");
  var miamihurricanesSoloO = document.getElementById("MiamiHurricanesSoloOU").innerHTML;
  var miamihurricanesSoloO = miamihurricanesSoloO.replace(/[',()]/g, "");
  var miamihurricanesHalftime = document.getElementById("MiamiHurricanesHalftime").innerHTML;
  var miamihurricanesHalftimeO = document.getElementById("MiamiHurricanesHalftimeOU").innerHTML;
  var miamihurricanesHalftimeO = miamihurricanesHalftimeO.replace(/[',()]/g, "");

  var miamiohredhawkscover = document.getElementById("MiamiOHRedHawksCover").innerHTML;
  var miamiohredhawksML = document.getElementById("MiamiOHRedHawksML").innerHTML;
  var miamiohredhawksO = document.getElementById("MiamiOHRedHawksOU").innerHTML;
  var miamiohredhawksO = miamiohredhawksO.replace(/[',()]/g, "");
  var miamiohredhawksSoloO = document.getElementById("MiamiOHRedHawksSoloOU").innerHTML;
  var miamiohredhawksSoloO = miamiohredhawksSoloO.replace(/[',()]/g, "");
  var miamiohredhawksHalftime = document.getElementById("MiamiOHRedHawksHalftime").innerHTML;
  var miamiohredhawksHalftimeO = document.getElementById("MiamiOHRedHawksHalftimeOU").innerHTML;
  var miamiohredhawksHalftimeO = miamiohredhawksHalftimeO.replace(/[',()]/g, "");

  var michiganwolverinescover = document.getElementById("MichiganWolverinesCover").innerHTML;
  var michiganwolverinesML = document.getElementById("MichiganWolverinesML").innerHTML;
  var michiganwolverinesO = document.getElementById("MichiganWolverinesOU").innerHTML;
  var michiganwolverinesO = michiganwolverinesO.replace(/[',()]/g, "");
  var michiganwolverinesSoloO = document.getElementById("MichiganWolverinesSoloOU").innerHTML;
  var michiganwolverinesSoloO = michiganwolverinesSoloO.replace(/[',()]/g, "");
  var michiganwolverinesHalftime = document.getElementById("MichiganWolverinesHalftime").innerHTML;
  var michiganwolverinesHalftimeO = document.getElementById("MichiganWolverinesHalftimeOU").innerHTML;
  var michiganwolverinesHalftimeO = michiganwolverinesHalftimeO.replace(/[',()]/g, "");

  var michiganstatespartanscover = document.getElementById("MichiganStateSpartansCover").innerHTML;
  var michiganstatespartansML = document.getElementById("MichiganStateSpartansML").innerHTML;
  var michiganstatespartansO = document.getElementById("MichiganStateSpartansOU").innerHTML;
  var michiganstatespartansO = michiganstatespartansO.replace(/[',()]/g, "");
  var michiganstatespartansSoloO = document.getElementById("MichiganStateSpartansSoloOU").innerHTML;
  var michiganstatespartansSoloO = michiganstatespartansSoloO.replace(/[',()]/g, "");
  var michiganstatespartansHalftime = document.getElementById("MichiganStateSpartansHalftime").innerHTML;
  var michiganstatespartansHalftimeO = document.getElementById("MichiganStateSpartansHalftimeOU").innerHTML;
  var michiganstatespartansHalftimeO = michiganstatespartansHalftimeO.replace(/[',()]/g, "");

  var middletennesseeblueraiderscover = document.getElementById("MiddleTennesseeBlueRaidersCover").innerHTML;
  var middletennesseeblueraidersML = document.getElementById("MiddleTennesseeBlueRaidersML").innerHTML;
  var middletennesseeblueraidersO = document.getElementById("MiddleTennesseeBlueRaidersOU").innerHTML;
  var middletennesseeblueraidersO = middletennesseeblueraidersO.replace(/[',()]/g, "");
  var middletennesseeblueraidersSoloO = document.getElementById("MiddleTennesseeBlueRaidersSoloOU").innerHTML;
  var middletennesseeblueraidersSoloO = middletennesseeblueraidersSoloO.replace(/[',()]/g, "");
  var middletennesseeblueraidersHalftime = document.getElementById("MiddleTennesseeBlueRaidersHalftime").innerHTML;
  var middletennesseeblueraidersHalftimeO = document.getElementById("MiddleTennesseeBlueRaidersHalftimeOU").innerHTML;
  var middletennesseeblueraidersHalftimeO = middletennesseeblueraidersHalftimeO.replace(/[',()]/g, "");

  var minnesotagoldengopherscover = document.getElementById("MinnesotaGoldenGophersCover").innerHTML;
  var minnesotagoldengophersML = document.getElementById("MinnesotaGoldenGophersML").innerHTML;
  var minnesotagoldengophersO = document.getElementById("MinnesotaGoldenGophersOU").innerHTML;
  var minnesotagoldengophersO = minnesotagoldengophersO.replace(/[',()]/g, "");
  var minnesotagoldengophersSoloO = document.getElementById("MinnesotaGoldenGophersSoloOU").innerHTML;
  var minnesotagoldengophersSoloO = minnesotagoldengophersSoloO.replace(/[',()]/g, "");
  var minnesotagoldengophersHalftime = document.getElementById("MinnesotaGoldenGophersHalftime").innerHTML;
  var minnesotagoldengophersHalftimeO = document.getElementById("MinnesotaGoldenGophersHalftimeOU").innerHTML;
  var minnesotagoldengophersHalftimeO = minnesotagoldengophersHalftimeO.replace(/[',()]/g, "");

  var olemissrebelscover = document.getElementById("OleMissRebelsCover").innerHTML;
  var olemissrebelsML = document.getElementById("OleMissRebelsML").innerHTML;
  var olemissrebelsO = document.getElementById("OleMissRebelsOU").innerHTML;
  var olemissrebelsO = olemissrebelsO.replace(/[',()]/g, "");
  var olemissrebelsSoloO = document.getElementById("OleMissRebelsSoloOU").innerHTML;
  var olemissrebelsSoloO = olemissrebelsSoloO.replace(/[',()]/g, "");
  var olemissrebelsHalftime = document.getElementById("OleMissRebelsHalftime").innerHTML;
  var olemissrebelsHalftimeO = document.getElementById("OleMissRebelsHalftimeOU").innerHTML;
  var olemissrebelsHalftimeO = olemissrebelsHalftimeO.replace(/[',()]/g, "");

  var mississippistatebulldogscover = document.getElementById("MississippiStateBulldogsCover").innerHTML;
  var mississippistatebulldogsML = document.getElementById("MississippiStateBulldogsML").innerHTML;
  var mississippistatebulldogsO = document.getElementById("MississippiStateBulldogsOU").innerHTML;
  var mississippistatebulldogsO = mississippistatebulldogsO.replace(/[',()]/g, "");
  var mississippistatebulldogsSoloO = document.getElementById("MississippiStateBulldogsSoloOU").innerHTML;
  var mississippistatebulldogsSoloO = mississippistatebulldogsSoloO.replace(/[',()]/g, "");
  var mississippistatebulldogsHalftime = document.getElementById("MississippiStateBulldogsHalftime").innerHTML;
  var mississippistatebulldogsHalftimeO = document.getElementById("MississippiStateBulldogsHalftimeOU").innerHTML;
  var mississippistatebulldogsHalftimeO = mississippistatebulldogsHalftimeO.replace(/[',()]/g, "");

  var mississippivalleystatedeltadevilscover = document.getElementById("MississippiValleyStateDeltaDevilsCover").innerHTML;
  var mississippivalleystatedeltadevilsML = document.getElementById("MississippiValleyStateDeltaDevilsML").innerHTML;
  var mississippivalleystatedeltadevilsO = document.getElementById("MississippiValleyStateDeltaDevilsOU").innerHTML;
  var mississippivalleystatedeltadevilsO = mississippivalleystatedeltadevilsO.replace(/[',()]/g, "");
  var mississippivalleystatedeltadevilsSoloO = document.getElementById("MississippiValleyStateDeltaDevilsSoloOU").innerHTML;
  var mississippivalleystatedeltadevilsSoloO = mississippivalleystatedeltadevilsSoloO.replace(/[',()]/g, "");
  var mississippivalleystatedeltadevilsHalftime = document.getElementById("MississippiValleyStateDeltaDevilsHalftime").innerHTML;
  var mississippivalleystatedeltadevilsHalftimeO = document.getElementById("MississippiValleyStateDeltaDevilsHalftimeOU").innerHTML;
  var mississippivalleystatedeltadevilsHalftimeO = mississippivalleystatedeltadevilsHalftimeO.replace(/[',()]/g, "");

  var missouritigerscover = document.getElementById("MissouriTigersCover").innerHTML;
  var missouritigersML = document.getElementById("MissouriTigersML").innerHTML;
  var missouritigersO = document.getElementById("MissouriTigersOU").innerHTML;
  var missouritigersO = missouritigersO.replace(/[',()]/g, "");
  var missouritigersSoloO = document.getElementById("MissouriTigersSoloOU").innerHTML;
  var missouritigersSoloO = missouritigersSoloO.replace(/[',()]/g, "");
  var missouritigersHalftime = document.getElementById("MissouriTigersHalftime").innerHTML;
  var missouritigersHalftimeO = document.getElementById("MissouriTigersHalftimeOU").innerHTML;
  var missouritigersHalftimeO = missouritigersHalftimeO.replace(/[',()]/g, "");

  var umkckangarooscover = document.getElementById("UMKCKangaroosCover").innerHTML;
  var umkckangaroosML = document.getElementById("UMKCKangaroosML").innerHTML;
  var umkckangaroosO = document.getElementById("UMKCKangaroosOU").innerHTML;
  var umkckangaroosO = umkckangaroosO.replace(/[',()]/g, "");
  var umkckangaroosSoloO = document.getElementById("UMKCKangaroosSoloOU").innerHTML;
  var umkckangaroosSoloO = umkckangaroosSoloO.replace(/[',()]/g, "");
  var umkckangaroosHalftime = document.getElementById("UMKCKangaroosHalftime").innerHTML;
  var umkckangaroosHalftimeO = document.getElementById("UMKCKangaroosHalftimeOU").innerHTML;
  var umkckangaroosHalftimeO = umkckangaroosHalftimeO.replace(/[',()]/g, "");

  var missouristatebearscover = document.getElementById("MissouriStateBearsCover").innerHTML;
  var missouristatebearsML = document.getElementById("MissouriStateBearsML").innerHTML;
  var missouristatebearsO = document.getElementById("MissouriStateBearsOU").innerHTML;
  var missouristatebearsO = missouristatebearsO.replace(/[',()]/g, "");
  var missouristatebearsSoloO = document.getElementById("MissouriStateBearsSoloOU").innerHTML;
  var missouristatebearsSoloO = missouristatebearsSoloO.replace(/[',()]/g, "");
  var missouristatebearsHalftime = document.getElementById("MissouriStateBearsHalftime").innerHTML;
  var missouristatebearsHalftimeO = document.getElementById("MissouriStateBearsHalftimeOU").innerHTML;
  var missouristatebearsHalftimeO = missouristatebearsHalftimeO.replace(/[',()]/g, "");

  var monmouthhawkscover = document.getElementById("MonmouthHawksCover").innerHTML;
  var monmouthhawksML = document.getElementById("MonmouthHawksML").innerHTML;
  var monmouthhawksO = document.getElementById("MonmouthHawksOU").innerHTML;
  var monmouthhawksO = monmouthhawksO.replace(/[',()]/g, "");
  var monmouthhawksSoloO = document.getElementById("MonmouthHawksSoloOU").innerHTML;
  var monmouthhawksSoloO = monmouthhawksSoloO.replace(/[',()]/g, "");
  var monmouthhawksHalftime = document.getElementById("MonmouthHawksHalftime").innerHTML;
  var monmouthhawksHalftimeO = document.getElementById("MonmouthHawksHalftimeOU").innerHTML;
  var monmouthhawksHalftimeO = monmouthhawksHalftimeO.replace(/[',()]/g, "");

  var montanagrizzliescover = document.getElementById("MontanaGrizzliesCover").innerHTML;
  var montanagrizzliesML = document.getElementById("MontanaGrizzliesML").innerHTML;
  var montanagrizzliesO = document.getElementById("MontanaGrizzliesOU").innerHTML;
  var montanagrizzliesO = montanagrizzliesO.replace(/[',()]/g, "");
  var montanagrizzliesSoloO = document.getElementById("MontanaGrizzliesSoloOU").innerHTML;
  var montanagrizzliesSoloO = montanagrizzliesSoloO.replace(/[',()]/g, "");
  var montanagrizzliesHalftime = document.getElementById("MontanaGrizzliesHalftime").innerHTML;
  var montanagrizzliesHalftimeO = document.getElementById("MontanaGrizzliesHalftimeOU").innerHTML;
  var montanagrizzliesHalftimeO = montanagrizzliesHalftimeO.replace(/[',()]/g, "");

  var montanastatebobcatscover = document.getElementById("MontanaStateBobcatsCover").innerHTML;
  var montanastatebobcatsML = document.getElementById("MontanaStateBobcatsML").innerHTML;
  var montanastatebobcatsO = document.getElementById("MontanaStateBobcatsOU").innerHTML;
  var montanastatebobcatsO = montanastatebobcatsO.replace(/[',()]/g, "");
  var montanastatebobcatsSoloO = document.getElementById("MontanaStateBobcatsSoloOU").innerHTML;
  var montanastatebobcatsSoloO = montanastatebobcatsSoloO.replace(/[',()]/g, "");
  var montanastatebobcatsHalftime = document.getElementById("MontanaStateBobcatsHalftime").innerHTML;
  var montanastatebobcatsHalftimeO = document.getElementById("MontanaStateBobcatsHalftimeOU").innerHTML;
  var montanastatebobcatsHalftimeO = montanastatebobcatsHalftimeO.replace(/[',()]/g, "");

  var moreheadstateeaglescover = document.getElementById("MoreheadStateEaglesCover").innerHTML;
  var moreheadstateeaglesML = document.getElementById("MoreheadStateEaglesML").innerHTML;
  var moreheadstateeaglesO = document.getElementById("MoreheadStateEaglesOU").innerHTML;
  var moreheadstateeaglesO = moreheadstateeaglesO.replace(/[',()]/g, "");
  var moreheadstateeaglesSoloO = document.getElementById("MoreheadStateEaglesSoloOU").innerHTML;
  var moreheadstateeaglesSoloO = moreheadstateeaglesSoloO.replace(/[',()]/g, "");
  var moreheadstateeaglesHalftime = document.getElementById("MoreheadStateEaglesHalftime").innerHTML;
  var moreheadstateeaglesHalftimeO = document.getElementById("MoreheadStateEaglesHalftimeOU").innerHTML;
  var moreheadstateeaglesHalftimeO = moreheadstateeaglesHalftimeO.replace(/[',()]/g, "");

  var morganstatebearscover = document.getElementById("MorganStateBearsCover").innerHTML;
  var morganstatebearsML = document.getElementById("MorganStateBearsML").innerHTML;
  var morganstatebearsO = document.getElementById("MorganStateBearsOU").innerHTML;
  var morganstatebearsO = morganstatebearsO.replace(/[',()]/g, "");
  var morganstatebearsSoloO = document.getElementById("MorganStateBearsSoloOU").innerHTML;
  var morganstatebearsSoloO = morganstatebearsSoloO.replace(/[',()]/g, "");
  var morganstatebearsHalftime = document.getElementById("MorganStateBearsHalftime").innerHTML;
  var morganstatebearsHalftimeO = document.getElementById("MorganStateBearsHalftimeOU").innerHTML;
  var morganstatebearsHalftimeO = morganstatebearsHalftimeO.replace(/[',()]/g, "");

  var mtstmarysmountaineerscover = document.getElementById("MtStMarysMountaineersCover").innerHTML;
  var mtstmarysmountaineersML = document.getElementById("MtStMarysMountaineersML").innerHTML;
  var mtstmarysmountaineersO = document.getElementById("MtStMarysMountaineersOU").innerHTML;
  var mtstmarysmountaineersO = mtstmarysmountaineersO.replace(/[',()]/g, "");
  var mtstmarysmountaineersSoloO = document.getElementById("MtStMarysMountaineersSoloOU").innerHTML;
  var mtstmarysmountaineersSoloO = mtstmarysmountaineersSoloO.replace(/[',()]/g, "");
  var mtstmarysmountaineersHalftime = document.getElementById("MtStMarysMountaineersHalftime").innerHTML;
  var mtstmarysmountaineersHalftimeO = document.getElementById("MtStMarysMountaineersHalftimeOU").innerHTML;
  var mtstmarysmountaineersHalftimeO = mtstmarysmountaineersHalftimeO.replace(/[',()]/g, "");

  var murraystateracerscover = document.getElementById("MurrayStateRacersCover").innerHTML;
  var murraystateracersML = document.getElementById("MurrayStateRacersML").innerHTML;
  var murraystateracersO = document.getElementById("MurrayStateRacersOU").innerHTML;
  var murraystateracersO = murraystateracersO.replace(/[',()]/g, "");
  var murraystateracersSoloO = document.getElementById("MurrayStateRacersSoloOU").innerHTML;
  var murraystateracersSoloO = murraystateracersSoloO.replace(/[',()]/g, "");
  var murraystateracersHalftime = document.getElementById("MurrayStateRacersHalftime").innerHTML;
  var murraystateracersHalftimeO = document.getElementById("MurrayStateRacersHalftimeOU").innerHTML;
  var murraystateracersHalftimeO = murraystateracersHalftimeO.replace(/[',()]/g, "");

  var nebraskacornhuskerscover = document.getElementById("NebraskaCornhuskersCover").innerHTML;
  var nebraskacornhuskersML = document.getElementById("NebraskaCornhuskersML").innerHTML;
  var nebraskacornhuskersO = document.getElementById("NebraskaCornhuskersOU").innerHTML;
  var nebraskacornhuskersO = nebraskacornhuskersO.replace(/[',()]/g, "");
  var nebraskacornhuskersSoloO = document.getElementById("NebraskaCornhuskersSoloOU").innerHTML;
  var nebraskacornhuskersSoloO = nebraskacornhuskersSoloO.replace(/[',()]/g, "");
  var nebraskacornhuskersHalftime = document.getElementById("NebraskaCornhuskersHalftime").innerHTML;
  var nebraskacornhuskersHalftimeO = document.getElementById("NebraskaCornhuskersHalftimeOU").innerHTML;
  var nebraskacornhuskersHalftimeO = nebraskacornhuskersHalftimeO.replace(/[',()]/g, "");

  var omahamaverickscover = document.getElementById("OmahaMavericksCover").innerHTML;
  var omahamavericksML = document.getElementById("OmahaMavericksML").innerHTML;
  var omahamavericksO = document.getElementById("OmahaMavericksOU").innerHTML;
  var omahamavericksO = omahamavericksO.replace(/[',()]/g, "");
  var omahamavericksSoloO = document.getElementById("OmahaMavericksSoloOU").innerHTML;
  var omahamavericksSoloO = omahamavericksSoloO.replace(/[',()]/g, "");
  var omahamavericksHalftime = document.getElementById("OmahaMavericksHalftime").innerHTML;
  var omahamavericksHalftimeO = document.getElementById("OmahaMavericksHalftimeOU").innerHTML;
  var omahamavericksHalftimeO = omahamavericksHalftimeO.replace(/[',()]/g, "");

  var unlvrebelscover = document.getElementById("UNLVRebelsCover").innerHTML;
  var unlvrebelsML = document.getElementById("UNLVRebelsML").innerHTML;
  var unlvrebelsO = document.getElementById("UNLVRebelsOU").innerHTML;
  var unlvrebelsO = unlvrebelsO.replace(/[',()]/g, "");
  var unlvrebelsSoloO = document.getElementById("UNLVRebelsSoloOU").innerHTML;
  var unlvrebelsSoloO = unlvrebelsSoloO.replace(/[',()]/g, "");
  var unlvrebelsHalftime = document.getElementById("UNLVRebelsHalftime").innerHTML;
  var unlvrebelsHalftimeO = document.getElementById("UNLVRebelsHalftimeOU").innerHTML;
  var unlvrebelsHalftimeO = unlvrebelsHalftimeO.replace(/[',()]/g, "");

  var nevadawolfpackcover = document.getElementById("NevadaWolfPackCover").innerHTML;
  var nevadawolfpackML = document.getElementById("NevadaWolfPackML").innerHTML;
  var nevadawolfpackO = document.getElementById("NevadaWolfPackOU").innerHTML;
  var nevadawolfpackO = nevadawolfpackO.replace(/[',()]/g, "");
  var nevadawolfpackSoloO = document.getElementById("NevadaWolfPackSoloOU").innerHTML;
  var nevadawolfpackSoloO = nevadawolfpackSoloO.replace(/[',()]/g, "");
  var nevadawolfpackHalftime = document.getElementById("NevadaWolfPackHalftime").innerHTML;
  var nevadawolfpackHalftimeO = document.getElementById("NevadaWolfPackHalftimeOU").innerHTML;
  var nevadawolfpackHalftimeO = nevadawolfpackHalftimeO.replace(/[',()]/g, "");

  var newhampshirewildcatscover = document.getElementById("NewHampshireWildcatsCover").innerHTML;
  var newhampshirewildcatsML = document.getElementById("NewHampshireWildcatsML").innerHTML;
  var newhampshirewildcatsO = document.getElementById("NewHampshireWildcatsOU").innerHTML;
  var newhampshirewildcatsO = newhampshirewildcatsO.replace(/[',()]/g, "");
  var newhampshirewildcatsSoloO = document.getElementById("NewHampshireWildcatsSoloOU").innerHTML;
  var newhampshirewildcatsSoloO = newhampshirewildcatsSoloO.replace(/[',()]/g, "");
  var newhampshirewildcatsHalftime = document.getElementById("NewHampshireWildcatsHalftime").innerHTML;
  var newhampshirewildcatsHalftimeO = document.getElementById("NewHampshireWildcatsHalftimeOU").innerHTML;
  var newhampshirewildcatsHalftimeO = newhampshirewildcatsHalftimeO.replace(/[',()]/g, "");

  var njithighlanderscover = document.getElementById("NJITHighlandersCover").innerHTML;
  var njithighlandersML = document.getElementById("NJITHighlandersML").innerHTML;
  var njithighlandersO = document.getElementById("NJITHighlandersOU").innerHTML;
  var njithighlandersO = njithighlandersO.replace(/[',()]/g, "");
  var njithighlandersSoloO = document.getElementById("NJITHighlandersSoloOU").innerHTML;
  var njithighlandersSoloO = njithighlandersSoloO.replace(/[',()]/g, "");
  var njithighlandersHalftime = document.getElementById("NJITHighlandersHalftime").innerHTML;
  var njithighlandersHalftimeO = document.getElementById("NJITHighlandersHalftimeOU").innerHTML;
  var njithighlandersHalftimeO = njithighlandersHalftimeO.replace(/[',()]/g, "");

  var newmexicoloboscover = document.getElementById("NewMexicoLobosCover").innerHTML;
  var newmexicolobosML = document.getElementById("NewMexicoLobosML").innerHTML;
  var newmexicolobosO = document.getElementById("NewMexicoLobosOU").innerHTML;
  var newmexicolobosO = newmexicolobosO.replace(/[',()]/g, "");
  var newmexicolobosSoloO = document.getElementById("NewMexicoLobosSoloOU").innerHTML;
  var newmexicolobosSoloO = newmexicolobosSoloO.replace(/[',()]/g, "");
  var newmexicolobosHalftime = document.getElementById("NewMexicoLobosHalftime").innerHTML;
  var newmexicolobosHalftimeO = document.getElementById("NewMexicoLobosHalftimeOU").innerHTML;
  var newmexicolobosHalftimeO = newmexicolobosHalftimeO.replace(/[',()]/g, "");

  var newmexicostateaggiescover = document.getElementById("NewMexicoStateAggiesCover").innerHTML;
  var newmexicostateaggiesML = document.getElementById("NewMexicoStateAggiesML").innerHTML;
  var newmexicostateaggiesO = document.getElementById("NewMexicoStateAggiesOU").innerHTML;
  var newmexicostateaggiesO = newmexicostateaggiesO.replace(/[',()]/g, "");
  var newmexicostateaggiesSoloO = document.getElementById("NewMexicoStateAggiesSoloOU").innerHTML;
  var newmexicostateaggiesSoloO = newmexicostateaggiesSoloO.replace(/[',()]/g, "");
  var newmexicostateaggiesHalftime = document.getElementById("NewMexicoStateAggiesHalftime").innerHTML;
  var newmexicostateaggiesHalftimeO = document.getElementById("NewMexicoStateAggiesHalftimeOU").innerHTML;
  var newmexicostateaggiesHalftimeO = newmexicostateaggiesHalftimeO.replace(/[',()]/g, "");

  var neworleansprivateerscover = document.getElementById("NewOrleansPrivateersCover").innerHTML;
  var neworleansprivateersML = document.getElementById("NewOrleansPrivateersML").innerHTML;
  var neworleansprivateersO = document.getElementById("NewOrleansPrivateersOU").innerHTML;
  var neworleansprivateersO = neworleansprivateersO.replace(/[',()]/g, "");
  var neworleansprivateersSoloO = document.getElementById("NewOrleansPrivateersSoloOU").innerHTML;
  var neworleansprivateersSoloO = neworleansprivateersSoloO.replace(/[',()]/g, "");
  var neworleansprivateersHalftime = document.getElementById("NewOrleansPrivateersHalftime").innerHTML;
  var neworleansprivateersHalftimeO = document.getElementById("NewOrleansPrivateersHalftimeOU").innerHTML;
  var neworleansprivateersHalftimeO = neworleansprivateersHalftimeO.replace(/[',()]/g, "");

  var niagarapurpleeaglescover = document.getElementById("NiagaraPurpleEaglesCover").innerHTML;
  var niagarapurpleeaglesML = document.getElementById("NiagaraPurpleEaglesML").innerHTML;
  var niagarapurpleeaglesO = document.getElementById("NiagaraPurpleEaglesOU").innerHTML;
  var niagarapurpleeaglesO = niagarapurpleeaglesO.replace(/[',()]/g, "");
  var niagarapurpleeaglesSoloO = document.getElementById("NiagaraPurpleEaglesSoloOU").innerHTML;
  var niagarapurpleeaglesSoloO = niagarapurpleeaglesSoloO.replace(/[',()]/g, "");
  var niagarapurpleeaglesHalftime = document.getElementById("NiagaraPurpleEaglesHalftime").innerHTML;
  var niagarapurpleeaglesHalftimeO = document.getElementById("NiagaraPurpleEaglesHalftimeOU").innerHTML;
  var niagarapurpleeaglesHalftimeO = niagarapurpleeaglesHalftimeO.replace(/[',()]/g, "");

  var nichollscolonelscover = document.getElementById("NichollsColonelsCover").innerHTML;
  var nichollscolonelsML = document.getElementById("NichollsColonelsML").innerHTML;
  var nichollscolonelsO = document.getElementById("NichollsColonelsOU").innerHTML;
  var nichollscolonelsO = nichollscolonelsO.replace(/[',()]/g, "");
  var nichollscolonelsSoloO = document.getElementById("NichollsColonelsSoloOU").innerHTML;
  var nichollscolonelsSoloO = nichollscolonelsSoloO.replace(/[',()]/g, "");
  var nichollscolonelsHalftime = document.getElementById("NichollsColonelsHalftime").innerHTML;
  var nichollscolonelsHalftimeO = document.getElementById("NichollsColonelsHalftimeOU").innerHTML;
  var nichollscolonelsHalftimeO = nichollscolonelsHalftimeO.replace(/[',()]/g, "");

  var norfolkstatespartanscover = document.getElementById("NorfolkStateSpartansCover").innerHTML;
  var norfolkstatespartansML = document.getElementById("NorfolkStateSpartansML").innerHTML;
  var norfolkstatespartansO = document.getElementById("NorfolkStateSpartansOU").innerHTML;
  var norfolkstatespartansO = norfolkstatespartansO.replace(/[',()]/g, "");
  var norfolkstatespartansSoloO = document.getElementById("NorfolkStateSpartansSoloOU").innerHTML;
  var norfolkstatespartansSoloO = norfolkstatespartansSoloO.replace(/[',()]/g, "");
  var norfolkstatespartansHalftime = document.getElementById("NorfolkStateSpartansHalftime").innerHTML;
  var norfolkstatespartansHalftimeO = document.getElementById("NorfolkStateSpartansHalftimeOU").innerHTML;
  var norfolkstatespartansHalftimeO = norfolkstatespartansHalftimeO.replace(/[',()]/g, "");

  var northcarolinaaandtaggiescover = document.getElementById("NorthCarolinaAandTAggiesCover").innerHTML;
  var northcarolinaaandtaggiesML = document.getElementById("NorthCarolinaAandTAggiesML").innerHTML;
  var northcarolinaaandtaggiesO = document.getElementById("NorthCarolinaAandTAggiesOU").innerHTML;
  var northcarolinaaandtaggiesO = northcarolinaaandtaggiesO.replace(/[',()]/g, "");
  var northcarolinaaandtaggiesSoloO = document.getElementById("NorthCarolinaAandTAggiesSoloOU").innerHTML;
  var northcarolinaaandtaggiesSoloO = northcarolinaaandtaggiesSoloO.replace(/[',()]/g, "");
  var northcarolinaaandtaggiesHalftime = document.getElementById("NorthCarolinaAandTAggiesHalftime").innerHTML;
  var northcarolinaaandtaggiesHalftimeO = document.getElementById("NorthCarolinaAandTAggiesHalftimeOU").innerHTML;
  var northcarolinaaandtaggiesHalftimeO = northcarolinaaandtaggiesHalftimeO.replace(/[',()]/g, "");

  var uncashevillebulldogscover = document.getElementById("UNCAshevilleBulldogsCover").innerHTML;
  var uncashevillebulldogsML = document.getElementById("UNCAshevilleBulldogsML").innerHTML;
  var uncashevillebulldogsO = document.getElementById("UNCAshevilleBulldogsOU").innerHTML;
  var uncashevillebulldogsO = uncashevillebulldogsO.replace(/[',()]/g, "");
  var uncashevillebulldogsSoloO = document.getElementById("UNCAshevilleBulldogsSoloOU").innerHTML;
  var uncashevillebulldogsSoloO = uncashevillebulldogsSoloO.replace(/[',()]/g, "");
  var uncashevillebulldogsHalftime = document.getElementById("UNCAshevilleBulldogsHalftime").innerHTML;
  var uncashevillebulldogsHalftimeO = document.getElementById("UNCAshevilleBulldogsHalftimeOU").innerHTML;
  var uncashevillebulldogsHalftimeO = uncashevillebulldogsHalftimeO.replace(/[',()]/g, "");

  var northcarolinacentraleaglescover = document.getElementById("NorthCarolinaCentralEaglesCover").innerHTML;
  var northcarolinacentraleaglesML = document.getElementById("NorthCarolinaCentralEaglesML").innerHTML;
  var northcarolinacentraleaglesO = document.getElementById("NorthCarolinaCentralEaglesOU").innerHTML;
  var northcarolinacentraleaglesO = northcarolinacentraleaglesO.replace(/[',()]/g, "");
  var northcarolinacentraleaglesSoloO = document.getElementById("NorthCarolinaCentralEaglesSoloOU").innerHTML;
  var northcarolinacentraleaglesSoloO = northcarolinacentraleaglesSoloO.replace(/[',()]/g, "");
  var northcarolinacentraleaglesHalftime = document.getElementById("NorthCarolinaCentralEaglesHalftime").innerHTML;
  var northcarolinacentraleaglesHalftimeO = document.getElementById("NorthCarolinaCentralEaglesHalftimeOU").innerHTML;
  var northcarolinacentraleaglesHalftimeO = northcarolinacentraleaglesHalftimeO.replace(/[',()]/g, "");

  var northcarolinatarheelscover = document.getElementById("NorthCarolinaTarHeelsCover").innerHTML;
  var northcarolinatarheelsML = document.getElementById("NorthCarolinaTarHeelsML").innerHTML;
  var northcarolinatarheelsO = document.getElementById("NorthCarolinaTarHeelsOU").innerHTML;
  var northcarolinatarheelsO = northcarolinatarheelsO.replace(/[',()]/g, "");
  var northcarolinatarheelsSoloO = document.getElementById("NorthCarolinaTarHeelsSoloOU").innerHTML;
  var northcarolinatarheelsSoloO = northcarolinatarheelsSoloO.replace(/[',()]/g, "");
  var northcarolinatarheelsHalftime = document.getElementById("NorthCarolinaTarHeelsHalftime").innerHTML;
  var northcarolinatarheelsHalftimeO = document.getElementById("NorthCarolinaTarHeelsHalftimeOU").innerHTML;
  var northcarolinatarheelsHalftimeO = northcarolinatarheelsHalftimeO.replace(/[',()]/g, "");

  var charlotte49erscover = document.getElementById("Charlotte49ersCover").innerHTML;
  var charlotte49ersML = document.getElementById("Charlotte49ersML").innerHTML;
  var charlotte49ersO = document.getElementById("Charlotte49ersOU").innerHTML;
  var charlotte49ersO = charlotte49ersO.replace(/[',()]/g, "");
  var charlotte49ersSoloO = document.getElementById("Charlotte49ersSoloOU").innerHTML;
  var charlotte49ersSoloO = charlotte49ersSoloO.replace(/[',()]/g, "");
  var charlotte49ersHalftime = document.getElementById("Charlotte49ersHalftime").innerHTML;
  var charlotte49ersHalftimeO = document.getElementById("Charlotte49ersHalftimeOU").innerHTML;
  var charlotte49ersHalftimeO = charlotte49ersHalftimeO.replace(/[',()]/g, "");

  var uncgreensborospartanscover = document.getElementById("UNCGreensboroSpartansCover").innerHTML;
  var uncgreensborospartansML = document.getElementById("UNCGreensboroSpartansML").innerHTML;
  var uncgreensborospartansO = document.getElementById("UNCGreensboroSpartansOU").innerHTML;
  var uncgreensborospartansO = uncgreensborospartansO.replace(/[',()]/g, "");
  var uncgreensborospartansSoloO = document.getElementById("UNCGreensboroSpartansSoloOU").innerHTML;
  var uncgreensborospartansSoloO = uncgreensborospartansSoloO.replace(/[',()]/g, "");
  var uncgreensborospartansHalftime = document.getElementById("UNCGreensboroSpartansHalftime").innerHTML;
  var uncgreensborospartansHalftimeO = document.getElementById("UNCGreensboroSpartansHalftimeOU").innerHTML;
  var uncgreensborospartansHalftimeO = uncgreensborospartansHalftimeO.replace(/[',()]/g, "");

  var ncstatewolfpackcover = document.getElementById("NCStateWolfpackCover").innerHTML;
  var ncstatewolfpackML = document.getElementById("NCStateWolfpackML").innerHTML;
  var ncstatewolfpackO = document.getElementById("NCStateWolfpackOU").innerHTML;
  var ncstatewolfpackO = ncstatewolfpackO.replace(/[',()]/g, "");
  var ncstatewolfpackSoloO = document.getElementById("NCStateWolfpackSoloOU").innerHTML;
  var ncstatewolfpackSoloO = ncstatewolfpackSoloO.replace(/[',()]/g, "");
  var ncstatewolfpackHalftime = document.getElementById("NCStateWolfpackHalftime").innerHTML;
  var ncstatewolfpackHalftimeO = document.getElementById("NCStateWolfpackHalftimeOU").innerHTML;
  var ncstatewolfpackHalftimeO = ncstatewolfpackHalftimeO.replace(/[',()]/g, "");

  var uncwilmingtonseahawkscover = document.getElementById("UNCWilmingtonSeahawksCover").innerHTML;
  var uncwilmingtonseahawksML = document.getElementById("UNCWilmingtonSeahawksML").innerHTML;
  var uncwilmingtonseahawksO = document.getElementById("UNCWilmingtonSeahawksOU").innerHTML;
  var uncwilmingtonseahawksO = uncwilmingtonseahawksO.replace(/[',()]/g, "");
  var uncwilmingtonseahawksSoloO = document.getElementById("UNCWilmingtonSeahawksSoloOU").innerHTML;
  var uncwilmingtonseahawksSoloO = uncwilmingtonseahawksSoloO.replace(/[',()]/g, "");
  var uncwilmingtonseahawksHalftime = document.getElementById("UNCWilmingtonSeahawksHalftime").innerHTML;
  var uncwilmingtonseahawksHalftimeO = document.getElementById("UNCWilmingtonSeahawksHalftimeOU").innerHTML;
  var uncwilmingtonseahawksHalftimeO = uncwilmingtonseahawksHalftimeO.replace(/[',()]/g, "");

  var northdakotafightinghawkscover = document.getElementById("NorthDakotaFightingHawksCover").innerHTML;
  var northdakotafightinghawksML = document.getElementById("NorthDakotaFightingHawksML").innerHTML;
  var northdakotafightinghawksO = document.getElementById("NorthDakotaFightingHawksOU").innerHTML;
  var northdakotafightinghawksO = northdakotafightinghawksO.replace(/[',()]/g, "");
  var northdakotafightinghawksSoloO = document.getElementById("NorthDakotaFightingHawksSoloOU").innerHTML;
  var northdakotafightinghawksSoloO = northdakotafightinghawksSoloO.replace(/[',()]/g, "");
  var northdakotafightinghawksHalftime = document.getElementById("NorthDakotaFightingHawksHalftime").innerHTML;
  var northdakotafightinghawksHalftimeO = document.getElementById("NorthDakotaFightingHawksHalftimeOU").innerHTML;
  var northdakotafightinghawksHalftimeO = northdakotafightinghawksHalftimeO.replace(/[',()]/g, "");

  var northdakotastatebisoncover = document.getElementById("NorthDakotaStateBisonCover").innerHTML;
  var northdakotastatebisonML = document.getElementById("NorthDakotaStateBisonML").innerHTML;
  var northdakotastatebisonO = document.getElementById("NorthDakotaStateBisonOU").innerHTML;
  var northdakotastatebisonO = northdakotastatebisonO.replace(/[',()]/g, "");
  var northdakotastatebisonSoloO = document.getElementById("NorthDakotaStateBisonSoloOU").innerHTML;
  var northdakotastatebisonSoloO = northdakotastatebisonSoloO.replace(/[',()]/g, "");
  var northdakotastatebisonHalftime = document.getElementById("NorthDakotaStateBisonHalftime").innerHTML;
  var northdakotastatebisonHalftimeO = document.getElementById("NorthDakotaStateBisonHalftimeOU").innerHTML;
  var northdakotastatebisonHalftimeO = northdakotastatebisonHalftimeO.replace(/[',()]/g, "");

  var northfloridaospreyscover = document.getElementById("NorthFloridaOspreysCover").innerHTML;
  var northfloridaospreysML = document.getElementById("NorthFloridaOspreysML").innerHTML;
  var northfloridaospreysO = document.getElementById("NorthFloridaOspreysOU").innerHTML;
  var northfloridaospreysO = northfloridaospreysO.replace(/[',()]/g, "");
  var northfloridaospreysSoloO = document.getElementById("NorthFloridaOspreysSoloOU").innerHTML;
  var northfloridaospreysSoloO = northfloridaospreysSoloO.replace(/[',()]/g, "");
  var northfloridaospreysHalftime = document.getElementById("NorthFloridaOspreysHalftime").innerHTML;
  var northfloridaospreysHalftimeO = document.getElementById("NorthFloridaOspreysHalftimeOU").innerHTML;
  var northfloridaospreysHalftimeO = northfloridaospreysHalftimeO.replace(/[',()]/g, "");

  var northtexasmeangreencover = document.getElementById("NorthTexasMeanGreenCover").innerHTML;
  var northtexasmeangreenML = document.getElementById("NorthTexasMeanGreenML").innerHTML;
  var northtexasmeangreenO = document.getElementById("NorthTexasMeanGreenOU").innerHTML;
  var northtexasmeangreenO = northtexasmeangreenO.replace(/[',()]/g, "");
  var northtexasmeangreenSoloO = document.getElementById("NorthTexasMeanGreenSoloOU").innerHTML;
  var northtexasmeangreenSoloO = northtexasmeangreenSoloO.replace(/[',()]/g, "");
  var northtexasmeangreenHalftime = document.getElementById("NorthTexasMeanGreenHalftime").innerHTML;
  var northtexasmeangreenHalftimeO = document.getElementById("NorthTexasMeanGreenHalftimeOU").innerHTML;
  var northtexasmeangreenHalftimeO = northtexasmeangreenHalftimeO.replace(/[',()]/g, "");

  var northeasternhuskiescover = document.getElementById("NortheasternHuskiesCover").innerHTML;
  var northeasternhuskiesML = document.getElementById("NortheasternHuskiesML").innerHTML;
  var northeasternhuskiesO = document.getElementById("NortheasternHuskiesOU").innerHTML;
  var northeasternhuskiesO = northeasternhuskiesO.replace(/[',()]/g, "");
  var northeasternhuskiesSoloO = document.getElementById("NortheasternHuskiesSoloOU").innerHTML;
  var northeasternhuskiesSoloO = northeasternhuskiesSoloO.replace(/[',()]/g, "");
  var northeasternhuskiesHalftime = document.getElementById("NortheasternHuskiesHalftime").innerHTML;
  var northeasternhuskiesHalftimeO = document.getElementById("NortheasternHuskiesHalftimeOU").innerHTML;
  var northeasternhuskiesHalftimeO = northeasternhuskiesHalftimeO.replace(/[',()]/g, "");

  var northernarizonalumberjackscover = document.getElementById("NorthernArizonaLumberjacksCover").innerHTML;
  var northernarizonalumberjacksML = document.getElementById("NorthernArizonaLumberjacksML").innerHTML;
  var northernarizonalumberjacksO = document.getElementById("NorthernArizonaLumberjacksOU").innerHTML;
  var northernarizonalumberjacksO = northernarizonalumberjacksO.replace(/[',()]/g, "");
  var northernarizonalumberjacksSoloO = document.getElementById("NorthernArizonaLumberjacksSoloOU").innerHTML;
  var northernarizonalumberjacksSoloO = northernarizonalumberjacksSoloO.replace(/[',()]/g, "");
  var northernarizonalumberjacksHalftime = document.getElementById("NorthernArizonaLumberjacksHalftime").innerHTML;
  var northernarizonalumberjacksHalftimeO = document.getElementById("NorthernArizonaLumberjacksHalftimeOU").innerHTML;
  var northernarizonalumberjacksHalftimeO = northernarizonalumberjacksHalftimeO.replace(/[',()]/g, "");

  var northerncoloradobearscover = document.getElementById("NorthernColoradoBearsCover").innerHTML;
  var northerncoloradobearsML = document.getElementById("NorthernColoradoBearsML").innerHTML;
  var northerncoloradobearsO = document.getElementById("NorthernColoradoBearsOU").innerHTML;
  var northerncoloradobearsO = northerncoloradobearsO.replace(/[',()]/g, "");
  var northerncoloradobearsSoloO = document.getElementById("NorthernColoradoBearsSoloOU").innerHTML;
  var northerncoloradobearsSoloO = northerncoloradobearsSoloO.replace(/[',()]/g, "");
  var northerncoloradobearsHalftime = document.getElementById("NorthernColoradoBearsHalftime").innerHTML;
  var northerncoloradobearsHalftimeO = document.getElementById("NorthernColoradoBearsHalftimeOU").innerHTML;
  var northerncoloradobearsHalftimeO = northerncoloradobearsHalftimeO.replace(/[',()]/g, "");

  var northernillinoishuskiescover = document.getElementById("NorthernIllinoisHuskiesCover").innerHTML;
  var northernillinoishuskiesML = document.getElementById("NorthernIllinoisHuskiesML").innerHTML;
  var northernillinoishuskiesO = document.getElementById("NorthernIllinoisHuskiesOU").innerHTML;
  var northernillinoishuskiesO = northernillinoishuskiesO.replace(/[',()]/g, "");
  var northernillinoishuskiesSoloO = document.getElementById("NorthernIllinoisHuskiesSoloOU").innerHTML;
  var northernillinoishuskiesSoloO = northernillinoishuskiesSoloO.replace(/[',()]/g, "");
  var northernillinoishuskiesHalftime = document.getElementById("NorthernIllinoisHuskiesHalftime").innerHTML;
  var northernillinoishuskiesHalftimeO = document.getElementById("NorthernIllinoisHuskiesHalftimeOU").innerHTML;
  var northernillinoishuskiesHalftimeO = northernillinoishuskiesHalftimeO.replace(/[',()]/g, "");

  var northerniowapantherscover = document.getElementById("NorthernIowaPanthersCover").innerHTML;
  var northerniowapanthersML = document.getElementById("NorthernIowaPanthersML").innerHTML;
  var northerniowapanthersO = document.getElementById("NorthernIowaPanthersOU").innerHTML;
  var northerniowapanthersO = northerniowapanthersO.replace(/[',()]/g, "");
  var northerniowapanthersSoloO = document.getElementById("NorthernIowaPanthersSoloOU").innerHTML;
  var northerniowapanthersSoloO = northerniowapanthersSoloO.replace(/[',()]/g, "");
  var northerniowapanthersHalftime = document.getElementById("NorthernIowaPanthersHalftime").innerHTML;
  var northerniowapanthersHalftimeO = document.getElementById("NorthernIowaPanthersHalftimeOU").innerHTML;
  var northerniowapanthersHalftimeO = northerniowapanthersHalftimeO.replace(/[',()]/g, "");

  var northernkentuckynorsecover = document.getElementById("NorthernKentuckyNorseCover").innerHTML;
  var northernkentuckynorseML = document.getElementById("NorthernKentuckyNorseML").innerHTML;
  var northernkentuckynorseO = document.getElementById("NorthernKentuckyNorseOU").innerHTML;
  var northernkentuckynorseO = northernkentuckynorseO.replace(/[',()]/g, "");
  var northernkentuckynorseSoloO = document.getElementById("NorthernKentuckyNorseSoloOU").innerHTML;
  var northernkentuckynorseSoloO = northernkentuckynorseSoloO.replace(/[',()]/g, "");
  var northernkentuckynorseHalftime = document.getElementById("NorthernKentuckyNorseHalftime").innerHTML;
  var northernkentuckynorseHalftimeO = document.getElementById("NorthernKentuckyNorseHalftimeOU").innerHTML;
  var northernkentuckynorseHalftimeO = northernkentuckynorseHalftimeO.replace(/[',()]/g, "");

  var northwesternwildcatscover = document.getElementById("NorthwesternWildcatsCover").innerHTML;
  var northwesternwildcatsML = document.getElementById("NorthwesternWildcatsML").innerHTML;
  var northwesternwildcatsO = document.getElementById("NorthwesternWildcatsOU").innerHTML;
  var northwesternwildcatsO = northwesternwildcatsO.replace(/[',()]/g, "");
  var northwesternwildcatsSoloO = document.getElementById("NorthwesternWildcatsSoloOU").innerHTML;
  var northwesternwildcatsSoloO = northwesternwildcatsSoloO.replace(/[',()]/g, "");
  var northwesternwildcatsHalftime = document.getElementById("NorthwesternWildcatsHalftime").innerHTML;
  var northwesternwildcatsHalftimeO = document.getElementById("NorthwesternWildcatsHalftimeOU").innerHTML;
  var northwesternwildcatsHalftimeO = northwesternwildcatsHalftimeO.replace(/[',()]/g, "");

  var northwesternstatedemonscover = document.getElementById("NorthwesternStateDemonsCover").innerHTML;
  var northwesternstatedemonsML = document.getElementById("NorthwesternStateDemonsML").innerHTML;
  var northwesternstatedemonsO = document.getElementById("NorthwesternStateDemonsOU").innerHTML;
  var northwesternstatedemonsO = northwesternstatedemonsO.replace(/[',()]/g, "");
  var northwesternstatedemonsSoloO = document.getElementById("NorthwesternStateDemonsSoloOU").innerHTML;
  var northwesternstatedemonsSoloO = northwesternstatedemonsSoloO.replace(/[',()]/g, "");
  var northwesternstatedemonsHalftime = document.getElementById("NorthwesternStateDemonsHalftime").innerHTML;
  var northwesternstatedemonsHalftimeO = document.getElementById("NorthwesternStateDemonsHalftimeOU").innerHTML;
  var northwesternstatedemonsHalftimeO = northwesternstatedemonsHalftimeO.replace(/[',()]/g, "");

  var notredamefightingirishcover = document.getElementById("NotreDameFightingIrishCover").innerHTML;
  var notredamefightingirishML = document.getElementById("NotreDameFightingIrishML").innerHTML;
  var notredamefightingirishO = document.getElementById("NotreDameFightingIrishOU").innerHTML;
  var notredamefightingirishO = notredamefightingirishO.replace(/[',()]/g, "");
  var notredamefightingirishSoloO = document.getElementById("NotreDameFightingIrishSoloOU").innerHTML;
  var notredamefightingirishSoloO = notredamefightingirishSoloO.replace(/[',()]/g, "");
  var notredamefightingirishHalftime = document.getElementById("NotreDameFightingIrishHalftime").innerHTML;
  var notredamefightingirishHalftimeO = document.getElementById("NotreDameFightingIrishHalftimeOU").innerHTML;
  var notredamefightingirishHalftimeO = notredamefightingirishHalftimeO.replace(/[',()]/g, "");

  var oaklandgoldengrizzliescover = document.getElementById("OaklandGoldenGrizzliesCover").innerHTML;
  var oaklandgoldengrizzliesML = document.getElementById("OaklandGoldenGrizzliesML").innerHTML;
  var oaklandgoldengrizzliesO = document.getElementById("OaklandGoldenGrizzliesOU").innerHTML;
  var oaklandgoldengrizzliesO = oaklandgoldengrizzliesO.replace(/[',()]/g, "");
  var oaklandgoldengrizzliesSoloO = document.getElementById("OaklandGoldenGrizzliesSoloOU").innerHTML;
  var oaklandgoldengrizzliesSoloO = oaklandgoldengrizzliesSoloO.replace(/[',()]/g, "");
  var oaklandgoldengrizzliesHalftime = document.getElementById("OaklandGoldenGrizzliesHalftime").innerHTML;
  var oaklandgoldengrizzliesHalftimeO = document.getElementById("OaklandGoldenGrizzliesHalftimeOU").innerHTML;
  var oaklandgoldengrizzliesHalftimeO = oaklandgoldengrizzliesHalftimeO.replace(/[',()]/g, "");

  var ohiobobcatscover = document.getElementById("OhioBobcatsCover").innerHTML;
  var ohiobobcatsML = document.getElementById("OhioBobcatsML").innerHTML;
  var ohiobobcatsO = document.getElementById("OhioBobcatsOU").innerHTML;
  var ohiobobcatsO = ohiobobcatsO.replace(/[',()]/g, "");
  var ohiobobcatsSoloO = document.getElementById("OhioBobcatsSoloOU").innerHTML;
  var ohiobobcatsSoloO = ohiobobcatsSoloO.replace(/[',()]/g, "");
  var ohiobobcatsHalftime = document.getElementById("OhioBobcatsHalftime").innerHTML;
  var ohiobobcatsHalftimeO = document.getElementById("OhioBobcatsHalftimeOU").innerHTML;
  var ohiobobcatsHalftimeO = ohiobobcatsHalftimeO.replace(/[',()]/g, "");

  var ohiostatebuckeyescover = document.getElementById("OhioStateBuckeyesCover").innerHTML;
  var ohiostatebuckeyesML = document.getElementById("OhioStateBuckeyesML").innerHTML;
  var ohiostatebuckeyesO = document.getElementById("OhioStateBuckeyesOU").innerHTML;
  var ohiostatebuckeyesO = ohiostatebuckeyesO.replace(/[',()]/g, "");
  var ohiostatebuckeyesSoloO = document.getElementById("OhioStateBuckeyesSoloOU").innerHTML;
  var ohiostatebuckeyesSoloO = ohiostatebuckeyesSoloO.replace(/[',()]/g, "");
  var ohiostatebuckeyesHalftime = document.getElementById("OhioStateBuckeyesHalftime").innerHTML;
  var ohiostatebuckeyesHalftimeO = document.getElementById("OhioStateBuckeyesHalftimeOU").innerHTML;
  var ohiostatebuckeyesHalftimeO = ohiostatebuckeyesHalftimeO.replace(/[',()]/g, "");

  var oklahomasoonerscover = document.getElementById("OklahomaSoonersCover").innerHTML;
  var oklahomasoonersML = document.getElementById("OklahomaSoonersML").innerHTML;
  var oklahomasoonersO = document.getElementById("OklahomaSoonersOU").innerHTML;
  var oklahomasoonersO = oklahomasoonersO.replace(/[',()]/g, "");
  var oklahomasoonersSoloO = document.getElementById("OklahomaSoonersSoloOU").innerHTML;
  var oklahomasoonersSoloO = oklahomasoonersSoloO.replace(/[',()]/g, "");
  var oklahomasoonersHalftime = document.getElementById("OklahomaSoonersHalftime").innerHTML;
  var oklahomasoonersHalftimeO = document.getElementById("OklahomaSoonersHalftimeOU").innerHTML;
  var oklahomasoonersHalftimeO = oklahomasoonersHalftimeO.replace(/[',()]/g, "");

  var oklahomastatecowboyscover = document.getElementById("OklahomaStateCowboysCover").innerHTML;
  var oklahomastatecowboysML = document.getElementById("OklahomaStateCowboysML").innerHTML;
  var oklahomastatecowboysO = document.getElementById("OklahomaStateCowboysOU").innerHTML;
  var oklahomastatecowboysO = oklahomastatecowboysO.replace(/[',()]/g, "");
  var oklahomastatecowboysSoloO = document.getElementById("OklahomaStateCowboysSoloOU").innerHTML;
  var oklahomastatecowboysSoloO = oklahomastatecowboysSoloO.replace(/[',()]/g, "");
  var oklahomastatecowboysHalftime = document.getElementById("OklahomaStateCowboysHalftime").innerHTML;
  var oklahomastatecowboysHalftimeO = document.getElementById("OklahomaStateCowboysHalftimeOU").innerHTML;
  var oklahomastatecowboysHalftimeO = oklahomastatecowboysHalftimeO.replace(/[',()]/g, "");

  var olddominionmonarchscover = document.getElementById("OldDominionMonarchsCover").innerHTML;
  var olddominionmonarchsML = document.getElementById("OldDominionMonarchsML").innerHTML;
  var olddominionmonarchsO = document.getElementById("OldDominionMonarchsOU").innerHTML;
  var olddominionmonarchsO = olddominionmonarchsO.replace(/[',()]/g, "");
  var olddominionmonarchsSoloO = document.getElementById("OldDominionMonarchsSoloOU").innerHTML;
  var olddominionmonarchsSoloO = olddominionmonarchsSoloO.replace(/[',()]/g, "");
  var olddominionmonarchsHalftime = document.getElementById("OldDominionMonarchsHalftime").innerHTML;
  var olddominionmonarchsHalftimeO = document.getElementById("OldDominionMonarchsHalftimeOU").innerHTML;
  var olddominionmonarchsHalftimeO = olddominionmonarchsHalftimeO.replace(/[',()]/g, "");

  var oralrobertsgoldeneaglescover = document.getElementById("OralRobertsGoldenEaglesCover").innerHTML;
  var oralrobertsgoldeneaglesML = document.getElementById("OralRobertsGoldenEaglesML").innerHTML;
  var oralrobertsgoldeneaglesO = document.getElementById("OralRobertsGoldenEaglesOU").innerHTML;
  var oralrobertsgoldeneaglesO = oralrobertsgoldeneaglesO.replace(/[',()]/g, "");
  var oralrobertsgoldeneaglesSoloO = document.getElementById("OralRobertsGoldenEaglesSoloOU").innerHTML;
  var oralrobertsgoldeneaglesSoloO = oralrobertsgoldeneaglesSoloO.replace(/[',()]/g, "");
  var oralrobertsgoldeneaglesHalftime = document.getElementById("OralRobertsGoldenEaglesHalftime").innerHTML;
  var oralrobertsgoldeneaglesHalftimeO = document.getElementById("OralRobertsGoldenEaglesHalftimeOU").innerHTML;
  var oralrobertsgoldeneaglesHalftimeO = oralrobertsgoldeneaglesHalftimeO.replace(/[',()]/g, "");

  var oregonduckscover = document.getElementById("OregonDucksCover").innerHTML;
  var oregonducksML = document.getElementById("OregonDucksML").innerHTML;
  var oregonducksO = document.getElementById("OregonDucksOU").innerHTML;
  var oregonducksO = oregonducksO.replace(/[',()]/g, "");
  var oregonducksSoloO = document.getElementById("OregonDucksSoloOU").innerHTML;
  var oregonducksSoloO = oregonducksSoloO.replace(/[',()]/g, "");
  var oregonducksHalftime = document.getElementById("OregonDucksHalftime").innerHTML;
  var oregonducksHalftimeO = document.getElementById("OregonDucksHalftimeOU").innerHTML;
  var oregonducksHalftimeO = oregonducksHalftimeO.replace(/[',()]/g, "");

  var oregonstatebeaverscover = document.getElementById("OregonStateBeaversCover").innerHTML;
  var oregonstatebeaversML = document.getElementById("OregonStateBeaversML").innerHTML;
  var oregonstatebeaversO = document.getElementById("OregonStateBeaversOU").innerHTML;
  var oregonstatebeaversO = oregonstatebeaversO.replace(/[',()]/g, "");
  var oregonstatebeaversSoloO = document.getElementById("OregonStateBeaversSoloOU").innerHTML;
  var oregonstatebeaversSoloO = oregonstatebeaversSoloO.replace(/[',()]/g, "");
  var oregonstatebeaversHalftime = document.getElementById("OregonStateBeaversHalftime").innerHTML;
  var oregonstatebeaversHalftimeO = document.getElementById("OregonStateBeaversHalftimeOU").innerHTML;
  var oregonstatebeaversHalftimeO = oregonstatebeaversHalftimeO.replace(/[',()]/g, "");

  var pacifictigerscover = document.getElementById("PacificTigersCover").innerHTML;
  var pacifictigersML = document.getElementById("PacificTigersML").innerHTML;
  var pacifictigersO = document.getElementById("PacificTigersOU").innerHTML;
  var pacifictigersO = pacifictigersO.replace(/[',()]/g, "");
  var pacifictigersSoloO = document.getElementById("PacificTigersSoloOU").innerHTML;
  var pacifictigersSoloO = pacifictigersSoloO.replace(/[',()]/g, "");
  var pacifictigersHalftime = document.getElementById("PacificTigersHalftime").innerHTML;
  var pacifictigersHalftimeO = document.getElementById("PacificTigersHalftimeOU").innerHTML;
  var pacifictigersHalftimeO = pacifictigersHalftimeO.replace(/[',()]/g, "");

  var pennsylvaniaquakerscover = document.getElementById("PennsylvaniaQuakersCover").innerHTML;
  var pennsylvaniaquakersML = document.getElementById("PennsylvaniaQuakersML").innerHTML;
  var pennsylvaniaquakersO = document.getElementById("PennsylvaniaQuakersOU").innerHTML;
  var pennsylvaniaquakersO = pennsylvaniaquakersO.replace(/[',()]/g, "");
  var pennsylvaniaquakersSoloO = document.getElementById("PennsylvaniaQuakersSoloOU").innerHTML;
  var pennsylvaniaquakersSoloO = pennsylvaniaquakersSoloO.replace(/[',()]/g, "");
  var pennsylvaniaquakersHalftime = document.getElementById("PennsylvaniaQuakersHalftime").innerHTML;
  var pennsylvaniaquakersHalftimeO = document.getElementById("PennsylvaniaQuakersHalftimeOU").innerHTML;
  var pennsylvaniaquakersHalftimeO = pennsylvaniaquakersHalftimeO.replace(/[',()]/g, "");

  var pennstatenittanylionscover = document.getElementById("PennStateNittanyLionsCover").innerHTML;
  var pennstatenittanylionsML = document.getElementById("PennStateNittanyLionsML").innerHTML;
  var pennstatenittanylionsO = document.getElementById("PennStateNittanyLionsOU").innerHTML;
  var pennstatenittanylionsO = pennstatenittanylionsO.replace(/[',()]/g, "");
  var pennstatenittanylionsSoloO = document.getElementById("PennStateNittanyLionsSoloOU").innerHTML;
  var pennstatenittanylionsSoloO = pennstatenittanylionsSoloO.replace(/[',()]/g, "");
  var pennstatenittanylionsHalftime = document.getElementById("PennStateNittanyLionsHalftime").innerHTML;
  var pennstatenittanylionsHalftimeO = document.getElementById("PennStateNittanyLionsHalftimeOU").innerHTML;
  var pennstatenittanylionsHalftimeO = pennstatenittanylionsHalftimeO.replace(/[',()]/g, "");

  var pepperdinewavescover = document.getElementById("PepperdineWavesCover").innerHTML;
  var pepperdinewavesML = document.getElementById("PepperdineWavesML").innerHTML;
  var pepperdinewavesO = document.getElementById("PepperdineWavesOU").innerHTML;
  var pepperdinewavesO = pepperdinewavesO.replace(/[',()]/g, "");
  var pepperdinewavesSoloO = document.getElementById("PepperdineWavesSoloOU").innerHTML;
  var pepperdinewavesSoloO = pepperdinewavesSoloO.replace(/[',()]/g, "");
  var pepperdinewavesHalftime = document.getElementById("PepperdineWavesHalftime").innerHTML;
  var pepperdinewavesHalftimeO = document.getElementById("PepperdineWavesHalftimeOU").innerHTML;
  var pepperdinewavesHalftimeO = pepperdinewavesHalftimeO.replace(/[',()]/g, "");

  var pittsburghpantherscover = document.getElementById("PittsburghPanthersCover").innerHTML;
  var pittsburghpanthersML = document.getElementById("PittsburghPanthersML").innerHTML;
  var pittsburghpanthersO = document.getElementById("PittsburghPanthersOU").innerHTML;
  var pittsburghpanthersO = pittsburghpanthersO.replace(/[',()]/g, "");
  var pittsburghpanthersSoloO = document.getElementById("PittsburghPanthersSoloOU").innerHTML;
  var pittsburghpanthersSoloO = pittsburghpanthersSoloO.replace(/[',()]/g, "");
  var pittsburghpanthersHalftime = document.getElementById("PittsburghPanthersHalftime").innerHTML;
  var pittsburghpanthersHalftimeO = document.getElementById("PittsburghPanthersHalftimeOU").innerHTML;
  var pittsburghpanthersHalftimeO = pittsburghpanthersHalftimeO.replace(/[',()]/g, "");

  var portlandpilotscover = document.getElementById("PortlandPilotsCover").innerHTML;
  var portlandpilotsML = document.getElementById("PortlandPilotsML").innerHTML;
  var portlandpilotsO = document.getElementById("PortlandPilotsOU").innerHTML;
  var portlandpilotsO = portlandpilotsO.replace(/[',()]/g, "");
  var portlandpilotsSoloO = document.getElementById("PortlandPilotsSoloOU").innerHTML;
  var portlandpilotsSoloO = portlandpilotsSoloO.replace(/[',()]/g, "");
  var portlandpilotsHalftime = document.getElementById("PortlandPilotsHalftime").innerHTML;
  var portlandpilotsHalftimeO = document.getElementById("PortlandPilotsHalftimeOU").innerHTML;
  var portlandpilotsHalftimeO = portlandpilotsHalftimeO.replace(/[',()]/g, "");

  var portlandstatevikingscover = document.getElementById("PortlandStateVikingsCover").innerHTML;
  var portlandstatevikingsML = document.getElementById("PortlandStateVikingsML").innerHTML;
  var portlandstatevikingsO = document.getElementById("PortlandStateVikingsOU").innerHTML;
  var portlandstatevikingsO = portlandstatevikingsO.replace(/[',()]/g, "");
  var portlandstatevikingsSoloO = document.getElementById("PortlandStateVikingsSoloOU").innerHTML;
  var portlandstatevikingsSoloO = portlandstatevikingsSoloO.replace(/[',()]/g, "");
  var portlandstatevikingsHalftime = document.getElementById("PortlandStateVikingsHalftime").innerHTML;
  var portlandstatevikingsHalftimeO = document.getElementById("PortlandStateVikingsHalftimeOU").innerHTML;
  var portlandstatevikingsHalftimeO = portlandstatevikingsHalftimeO.replace(/[',()]/g, "");

  var prairieviewaandmpantherscover = document.getElementById("PrairieViewAandMPanthersCover").innerHTML;
  var prairieviewaandmpanthersML = document.getElementById("PrairieViewAandMPanthersML").innerHTML;
  var prairieviewaandmpanthersO = document.getElementById("PrairieViewAandMPanthersOU").innerHTML;
  var prairieviewaandmpanthersO = prairieviewaandmpanthersO.replace(/[',()]/g, "");
  var prairieviewaandmpanthersSoloO = document.getElementById("PrairieViewAandMPanthersSoloOU").innerHTML;
  var prairieviewaandmpanthersSoloO = prairieviewaandmpanthersSoloO.replace(/[',()]/g, "");
  var prairieviewaandmpanthersHalftime = document.getElementById("PrairieViewAandMPanthersHalftime").innerHTML;
  var prairieviewaandmpanthersHalftimeO = document.getElementById("PrairieViewAandMPanthersHalftimeOU").innerHTML;
  var prairieviewaandmpanthersHalftimeO = prairieviewaandmpanthersHalftimeO.replace(/[',()]/g, "");

  var presbyterianbluehosecover = document.getElementById("PresbyterianBlueHoseCover").innerHTML;
  var presbyterianbluehoseML = document.getElementById("PresbyterianBlueHoseML").innerHTML;
  var presbyterianbluehoseO = document.getElementById("PresbyterianBlueHoseOU").innerHTML;
  var presbyterianbluehoseO = presbyterianbluehoseO.replace(/[',()]/g, "");
  var presbyterianbluehoseSoloO = document.getElementById("PresbyterianBlueHoseSoloOU").innerHTML;
  var presbyterianbluehoseSoloO = presbyterianbluehoseSoloO.replace(/[',()]/g, "");
  var presbyterianbluehoseHalftime = document.getElementById("PresbyterianBlueHoseHalftime").innerHTML;
  var presbyterianbluehoseHalftimeO = document.getElementById("PresbyterianBlueHoseHalftimeOU").innerHTML;
  var presbyterianbluehoseHalftimeO = presbyterianbluehoseHalftimeO.replace(/[',()]/g, "");

  var princetontigerscover = document.getElementById("PrincetonTigersCover").innerHTML;
  var princetontigersML = document.getElementById("PrincetonTigersML").innerHTML;
  var princetontigersO = document.getElementById("PrincetonTigersOU").innerHTML;
  var princetontigersO = princetontigersO.replace(/[',()]/g, "");
  var princetontigersSoloO = document.getElementById("PrincetonTigersSoloOU").innerHTML;
  var princetontigersSoloO = princetontigersSoloO.replace(/[',()]/g, "");
  var princetontigersHalftime = document.getElementById("PrincetonTigersHalftime").innerHTML;
  var princetontigersHalftimeO = document.getElementById("PrincetonTigersHalftimeOU").innerHTML;
  var princetontigersHalftimeO = princetontigersHalftimeO.replace(/[',()]/g, "");

  var providencefriarscover = document.getElementById("ProvidenceFriarsCover").innerHTML;
  var providencefriarsML = document.getElementById("ProvidenceFriarsML").innerHTML;
  var providencefriarsO = document.getElementById("ProvidenceFriarsOU").innerHTML;
  var providencefriarsO = providencefriarsO.replace(/[',()]/g, "");
  var providencefriarsSoloO = document.getElementById("ProvidenceFriarsSoloOU").innerHTML;
  var providencefriarsSoloO = providencefriarsSoloO.replace(/[',()]/g, "");
  var providencefriarsHalftime = document.getElementById("ProvidenceFriarsHalftime").innerHTML;
  var providencefriarsHalftimeO = document.getElementById("ProvidenceFriarsHalftimeOU").innerHTML;
  var providencefriarsHalftimeO = providencefriarsHalftimeO.replace(/[',()]/g, "");

  var purdueboilermakerscover = document.getElementById("PurdueBoilermakersCover").innerHTML;
  var purdueboilermakersML = document.getElementById("PurdueBoilermakersML").innerHTML;
  var purdueboilermakersO = document.getElementById("PurdueBoilermakersOU").innerHTML;
  var purdueboilermakersO = purdueboilermakersO.replace(/[',()]/g, "");
  var purdueboilermakersSoloO = document.getElementById("PurdueBoilermakersSoloOU").innerHTML;
  var purdueboilermakersSoloO = purdueboilermakersSoloO.replace(/[',()]/g, "");
  var purdueboilermakersHalftime = document.getElementById("PurdueBoilermakersHalftime").innerHTML;
  var purdueboilermakersHalftimeO = document.getElementById("PurdueBoilermakersHalftimeOU").innerHTML;
  var purdueboilermakersHalftimeO = purdueboilermakersHalftimeO.replace(/[',()]/g, "");

  var purduefortwaynemastodonscover = document.getElementById("PurdueFortWayneMastodonsCover").innerHTML;
  var purduefortwaynemastodonsML = document.getElementById("PurdueFortWayneMastodonsML").innerHTML;
  var purduefortwaynemastodonsO = document.getElementById("PurdueFortWayneMastodonsOU").innerHTML;
  var purduefortwaynemastodonsO = purduefortwaynemastodonsO.replace(/[',()]/g, "");
  var purduefortwaynemastodonsSoloO = document.getElementById("PurdueFortWayneMastodonsSoloOU").innerHTML;
  var purduefortwaynemastodonsSoloO = purduefortwaynemastodonsSoloO.replace(/[',()]/g, "");
  var purduefortwaynemastodonsHalftime = document.getElementById("PurdueFortWayneMastodonsHalftime").innerHTML;
  var purduefortwaynemastodonsHalftimeO = document.getElementById("PurdueFortWayneMastodonsHalftimeOU").innerHTML;
  var purduefortwaynemastodonsHalftimeO = purduefortwaynemastodonsHalftimeO.replace(/[',()]/g, "");

  var quinnipiacbobcatscover = document.getElementById("QuinnipiacBobcatsCover").innerHTML;
  var quinnipiacbobcatsML = document.getElementById("QuinnipiacBobcatsML").innerHTML;
  var quinnipiacbobcatsO = document.getElementById("QuinnipiacBobcatsOU").innerHTML;
  var quinnipiacbobcatsO = quinnipiacbobcatsO.replace(/[',()]/g, "");
  var quinnipiacbobcatsSoloO = document.getElementById("QuinnipiacBobcatsSoloOU").innerHTML;
  var quinnipiacbobcatsSoloO = quinnipiacbobcatsSoloO.replace(/[',()]/g, "");
  var quinnipiacbobcatsHalftime = document.getElementById("QuinnipiacBobcatsHalftime").innerHTML;
  var quinnipiacbobcatsHalftimeO = document.getElementById("QuinnipiacBobcatsHalftimeOU").innerHTML;
  var quinnipiacbobcatsHalftimeO = quinnipiacbobcatsHalftimeO.replace(/[',()]/g, "");

  var radfordhighlanderscover = document.getElementById("RadfordHighlandersCover").innerHTML;
  var radfordhighlandersML = document.getElementById("RadfordHighlandersML").innerHTML;
  var radfordhighlandersO = document.getElementById("RadfordHighlandersOU").innerHTML;
  var radfordhighlandersO = radfordhighlandersO.replace(/[',()]/g, "");
  var radfordhighlandersSoloO = document.getElementById("RadfordHighlandersSoloOU").innerHTML;
  var radfordhighlandersSoloO = radfordhighlandersSoloO.replace(/[',()]/g, "");
  var radfordhighlandersHalftime = document.getElementById("RadfordHighlandersHalftime").innerHTML;
  var radfordhighlandersHalftimeO = document.getElementById("RadfordHighlandersHalftimeOU").innerHTML;
  var radfordhighlandersHalftimeO = radfordhighlandersHalftimeO.replace(/[',()]/g, "");

  var rhodeislandramscover = document.getElementById("RhodeIslandRamsCover").innerHTML;
  var rhodeislandramsML = document.getElementById("RhodeIslandRamsML").innerHTML;
  var rhodeislandramsO = document.getElementById("RhodeIslandRamsOU").innerHTML;
  var rhodeislandramsO = rhodeislandramsO.replace(/[',()]/g, "");
  var rhodeislandramsSoloO = document.getElementById("RhodeIslandRamsSoloOU").innerHTML;
  var rhodeislandramsSoloO = rhodeislandramsSoloO.replace(/[',()]/g, "");
  var rhodeislandramsHalftime = document.getElementById("RhodeIslandRamsHalftime").innerHTML;
  var rhodeislandramsHalftimeO = document.getElementById("RhodeIslandRamsHalftimeOU").innerHTML;
  var rhodeislandramsHalftimeO = rhodeislandramsHalftimeO.replace(/[',()]/g, "");

  var riceowlscover = document.getElementById("RiceOwlsCover").innerHTML;
  var riceowlsML = document.getElementById("RiceOwlsML").innerHTML;
  var riceowlsO = document.getElementById("RiceOwlsOU").innerHTML;
  var riceowlsO = riceowlsO.replace(/[',()]/g, "");
  var riceowlsSoloO = document.getElementById("RiceOwlsSoloOU").innerHTML;
  var riceowlsSoloO = riceowlsSoloO.replace(/[',()]/g, "");
  var riceowlsHalftime = document.getElementById("RiceOwlsHalftime").innerHTML;
  var riceowlsHalftimeO = document.getElementById("RiceOwlsHalftimeOU").innerHTML;
  var riceowlsHalftimeO = riceowlsHalftimeO.replace(/[',()]/g, "");

  var richmondspiderscover = document.getElementById("RichmondSpidersCover").innerHTML;
  var richmondspidersML = document.getElementById("RichmondSpidersML").innerHTML;
  var richmondspidersO = document.getElementById("RichmondSpidersOU").innerHTML;
  var richmondspidersO = richmondspidersO.replace(/[',()]/g, "");
  var richmondspidersSoloO = document.getElementById("RichmondSpidersSoloOU").innerHTML;
  var richmondspidersSoloO = richmondspidersSoloO.replace(/[',()]/g, "");
  var richmondspidersHalftime = document.getElementById("RichmondSpidersHalftime").innerHTML;
  var richmondspidersHalftimeO = document.getElementById("RichmondSpidersHalftimeOU").innerHTML;
  var richmondspidersHalftimeO = richmondspidersHalftimeO.replace(/[',()]/g, "");

  var riderbroncscover = document.getElementById("RiderBroncsCover").innerHTML;
  var riderbroncsML = document.getElementById("RiderBroncsML").innerHTML;
  var riderbroncsO = document.getElementById("RiderBroncsOU").innerHTML;
  var riderbroncsO = riderbroncsO.replace(/[',()]/g, "");
  var riderbroncsSoloO = document.getElementById("RiderBroncsSoloOU").innerHTML;
  var riderbroncsSoloO = riderbroncsSoloO.replace(/[',()]/g, "");
  var riderbroncsHalftime = document.getElementById("RiderBroncsHalftime").innerHTML;
  var riderbroncsHalftimeO = document.getElementById("RiderBroncsHalftimeOU").innerHTML;
  var riderbroncsHalftimeO = riderbroncsHalftimeO.replace(/[',()]/g, "");

  var robertmorriscolonialscover = document.getElementById("RobertMorrisColonialsCover").innerHTML;
  var robertmorriscolonialsML = document.getElementById("RobertMorrisColonialsML").innerHTML;
  var robertmorriscolonialsO = document.getElementById("RobertMorrisColonialsOU").innerHTML;
  var robertmorriscolonialsO = robertmorriscolonialsO.replace(/[',()]/g, "");
  var robertmorriscolonialsSoloO = document.getElementById("RobertMorrisColonialsSoloOU").innerHTML;
  var robertmorriscolonialsSoloO = robertmorriscolonialsSoloO.replace(/[',()]/g, "");
  var robertmorriscolonialsHalftime = document.getElementById("RobertMorrisColonialsHalftime").innerHTML;
  var robertmorriscolonialsHalftimeO = document.getElementById("RobertMorrisColonialsHalftimeOU").innerHTML;
  var robertmorriscolonialsHalftimeO = robertmorriscolonialsHalftimeO.replace(/[',()]/g, "");

  var rutgersscarletknightscover = document.getElementById("RutgersScarletKnightsCover").innerHTML;
  var rutgersscarletknightsML = document.getElementById("RutgersScarletKnightsML").innerHTML;
  var rutgersscarletknightsO = document.getElementById("RutgersScarletKnightsOU").innerHTML;
  var rutgersscarletknightsO = rutgersscarletknightsO.replace(/[',()]/g, "");
  var rutgersscarletknightsSoloO = document.getElementById("RutgersScarletKnightsSoloOU").innerHTML;
  var rutgersscarletknightsSoloO = rutgersscarletknightsSoloO.replace(/[',()]/g, "");
  var rutgersscarletknightsHalftime = document.getElementById("RutgersScarletKnightsHalftime").innerHTML;
  var rutgersscarletknightsHalftimeO = document.getElementById("RutgersScarletKnightsHalftimeOU").innerHTML;
  var rutgersscarletknightsHalftimeO = rutgersscarletknightsHalftimeO.replace(/[',()]/g, "");

  var sacredheartpioneerscover = document.getElementById("SacredHeartPioneersCover").innerHTML;
  var sacredheartpioneersML = document.getElementById("SacredHeartPioneersML").innerHTML;
  var sacredheartpioneersO = document.getElementById("SacredHeartPioneersOU").innerHTML;
  var sacredheartpioneersO = sacredheartpioneersO.replace(/[',()]/g, "");
  var sacredheartpioneersSoloO = document.getElementById("SacredHeartPioneersSoloOU").innerHTML;
  var sacredheartpioneersSoloO = sacredheartpioneersSoloO.replace(/[',()]/g, "");
  var sacredheartpioneersHalftime = document.getElementById("SacredHeartPioneersHalftime").innerHTML;
  var sacredheartpioneersHalftimeO = document.getElementById("SacredHeartPioneersHalftimeOU").innerHTML;
  var sacredheartpioneersHalftimeO = sacredheartpioneersHalftimeO.replace(/[',()]/g, "");

  var stbonaventurebonniescover = document.getElementById("StBonaventureBonniesCover").innerHTML;
  var stbonaventurebonniesML = document.getElementById("StBonaventureBonniesML").innerHTML;
  var stbonaventurebonniesO = document.getElementById("StBonaventureBonniesOU").innerHTML;
  var stbonaventurebonniesO = stbonaventurebonniesO.replace(/[',()]/g, "");
  var stbonaventurebonniesSoloO = document.getElementById("StBonaventureBonniesSoloOU").innerHTML;
  var stbonaventurebonniesSoloO = stbonaventurebonniesSoloO.replace(/[',()]/g, "");
  var stbonaventurebonniesHalftime = document.getElementById("StBonaventureBonniesHalftime").innerHTML;
  var stbonaventurebonniesHalftimeO = document.getElementById("StBonaventureBonniesHalftimeOU").innerHTML;
  var stbonaventurebonniesHalftimeO = stbonaventurebonniesHalftimeO.replace(/[',()]/g, "");

  var stfrancisbknterrierscover = document.getElementById("StFrancisBKNTerriersCover").innerHTML;
  var stfrancisbknterriersML = document.getElementById("StFrancisBKNTerriersML").innerHTML;
  var stfrancisbknterriersO = document.getElementById("StFrancisBKNTerriersOU").innerHTML;
  var stfrancisbknterriersO = stfrancisbknterriersO.replace(/[',()]/g, "");
  var stfrancisbknterriersSoloO = document.getElementById("StFrancisBKNTerriersSoloOU").innerHTML;
  var stfrancisbknterriersSoloO = stfrancisbknterriersSoloO.replace(/[',()]/g, "");
  var stfrancisbknterriersHalftime = document.getElementById("StFrancisBKNTerriersHalftime").innerHTML;
  var stfrancisbknterriersHalftimeO = document.getElementById("StFrancisBKNTerriersHalftimeOU").innerHTML;
  var stfrancisbknterriersHalftimeO = stfrancisbknterriersHalftimeO.replace(/[',()]/g, "");

  var stfrancisparedflashcover = document.getElementById("StFrancisPARedFlashCover").innerHTML;
  var stfrancisparedflashML = document.getElementById("StFrancisPARedFlashML").innerHTML;
  var stfrancisparedflashO = document.getElementById("StFrancisPARedFlashOU").innerHTML;
  var stfrancisparedflashO = stfrancisparedflashO.replace(/[',()]/g, "");
  var stfrancisparedflashSoloO = document.getElementById("StFrancisPARedFlashSoloOU").innerHTML;
  var stfrancisparedflashSoloO = stfrancisparedflashSoloO.replace(/[',()]/g, "");
  var stfrancisparedflashHalftime = document.getElementById("StFrancisPARedFlashHalftime").innerHTML;
  var stfrancisparedflashHalftimeO = document.getElementById("StFrancisPARedFlashHalftimeOU").innerHTML;
  var stfrancisparedflashHalftimeO = stfrancisparedflashHalftimeO.replace(/[',()]/g, "");

  var stjohnsredstormcover = document.getElementById("StJohnsRedStormCover").innerHTML;
  var stjohnsredstormML = document.getElementById("StJohnsRedStormML").innerHTML;
  var stjohnsredstormO = document.getElementById("StJohnsRedStormOU").innerHTML;
  var stjohnsredstormO = stjohnsredstormO.replace(/[',()]/g, "");
  var stjohnsredstormSoloO = document.getElementById("StJohnsRedStormSoloOU").innerHTML;
  var stjohnsredstormSoloO = stjohnsredstormSoloO.replace(/[',()]/g, "");
  var stjohnsredstormHalftime = document.getElementById("StJohnsRedStormHalftime").innerHTML;
  var stjohnsredstormHalftimeO = document.getElementById("StJohnsRedStormHalftimeOU").innerHTML;
  var stjohnsredstormHalftimeO = stjohnsredstormHalftimeO.replace(/[',()]/g, "");

  var saintjosephshawkscover = document.getElementById("SaintJosephsHawksCover").innerHTML;
  var saintjosephshawksML = document.getElementById("SaintJosephsHawksML").innerHTML;
  var saintjosephshawksO = document.getElementById("SaintJosephsHawksOU").innerHTML;
  var saintjosephshawksO = saintjosephshawksO.replace(/[',()]/g, "");
  var saintjosephshawksSoloO = document.getElementById("SaintJosephsHawksSoloOU").innerHTML;
  var saintjosephshawksSoloO = saintjosephshawksSoloO.replace(/[',()]/g, "");
  var saintjosephshawksHalftime = document.getElementById("SaintJosephsHawksHalftime").innerHTML;
  var saintjosephshawksHalftimeO = document.getElementById("SaintJosephsHawksHalftimeOU").innerHTML;
  var saintjosephshawksHalftimeO = saintjosephshawksHalftimeO.replace(/[',()]/g, "");

  var saintlouisbillikenscover = document.getElementById("SaintLouisBillikensCover").innerHTML;
  var saintlouisbillikensML = document.getElementById("SaintLouisBillikensML").innerHTML;
  var saintlouisbillikensO = document.getElementById("SaintLouisBillikensOU").innerHTML;
  var saintlouisbillikensO = saintlouisbillikensO.replace(/[',()]/g, "");
  var saintlouisbillikensSoloO = document.getElementById("SaintLouisBillikensSoloOU").innerHTML;
  var saintlouisbillikensSoloO = saintlouisbillikensSoloO.replace(/[',()]/g, "");
  var saintlouisbillikensHalftime = document.getElementById("SaintLouisBillikensHalftime").innerHTML;
  var saintlouisbillikensHalftimeO = document.getElementById("SaintLouisBillikensHalftimeOU").innerHTML;
  var saintlouisbillikensHalftimeO = saintlouisbillikensHalftimeO.replace(/[',()]/g, "");

  var saintmarysgaelscover = document.getElementById("SaintMarysGaelsCover").innerHTML;
  var saintmarysgaelsML = document.getElementById("SaintMarysGaelsML").innerHTML;
  var saintmarysgaelsO = document.getElementById("SaintMarysGaelsOU").innerHTML;
  var saintmarysgaelsO = saintmarysgaelsO.replace(/[',()]/g, "");
  var saintmarysgaelsSoloO = document.getElementById("SaintMarysGaelsSoloOU").innerHTML;
  var saintmarysgaelsSoloO = saintmarysgaelsSoloO.replace(/[',()]/g, "");
  var saintmarysgaelsHalftime = document.getElementById("SaintMarysGaelsHalftime").innerHTML;
  var saintmarysgaelsHalftimeO = document.getElementById("SaintMarysGaelsHalftimeOU").innerHTML;
  var saintmarysgaelsHalftimeO = saintmarysgaelsHalftimeO.replace(/[',()]/g, "");

  var saintpeterspeacockscover = document.getElementById("SaintPetersPeacocksCover").innerHTML;
  var saintpeterspeacocksML = document.getElementById("SaintPetersPeacocksML").innerHTML;
  var saintpeterspeacocksO = document.getElementById("SaintPetersPeacocksOU").innerHTML;
  var saintpeterspeacocksO = saintpeterspeacocksO.replace(/[',()]/g, "");
  var saintpeterspeacocksSoloO = document.getElementById("SaintPetersPeacocksSoloOU").innerHTML;
  var saintpeterspeacocksSoloO = saintpeterspeacocksSoloO.replace(/[',()]/g, "");
  var saintpeterspeacocksHalftime = document.getElementById("SaintPetersPeacocksHalftime").innerHTML;
  var saintpeterspeacocksHalftimeO = document.getElementById("SaintPetersPeacocksHalftimeOU").innerHTML;
  var saintpeterspeacocksHalftimeO = saintpeterspeacocksHalftimeO.replace(/[',()]/g, "");

  var samhoustonbearkatscover = document.getElementById("SamHoustonStateBearkatsCover").innerHTML;
  var samhoustonbearkatsML = document.getElementById("SamHoustonStateBearkatsML").innerHTML;
  var samhoustonbearkatsO = document.getElementById("SamHoustonStateBearkatsOU").innerHTML;
  var samhoustonbearkatsO = samhoustonbearkatsO.replace(/[',()]/g, "");
  var samhoustonbearkatsSoloO = document.getElementById("SamHoustonStateBearkatsSoloOU").innerHTML;
  var samhoustonbearkatsSoloO = samhoustonbearkatsSoloO.replace(/[',()]/g, "");
  var samhoustonbearkatsHalftime = document.getElementById("SamHoustonStateBearkatsHalftime").innerHTML;
  var samhoustonbearkatsHalftimeO = document.getElementById("SamHoustonStateBearkatsHalftimeOU").innerHTML;
  var samhoustonbearkatsHalftimeO = samhoustonbearkatsHalftimeO.replace(/[',()]/g, "");

  var samfordbulldogscover = document.getElementById("SamfordBulldogsCover").innerHTML;
  var samfordbulldogsML = document.getElementById("SamfordBulldogsML").innerHTML;
  var samfordbulldogsO = document.getElementById("SamfordBulldogsOU").innerHTML;
  var samfordbulldogsO = samfordbulldogsO.replace(/[',()]/g, "");
  var samfordbulldogsSoloO = document.getElementById("SamfordBulldogsSoloOU").innerHTML;
  var samfordbulldogsSoloO = samfordbulldogsSoloO.replace(/[',()]/g, "");
  var samfordbulldogsHalftime = document.getElementById("SamfordBulldogsHalftime").innerHTML;
  var samfordbulldogsHalftimeO = document.getElementById("SamfordBulldogsHalftimeOU").innerHTML;
  var samfordbulldogsHalftimeO = samfordbulldogsHalftimeO.replace(/[',()]/g, "");

  var sandiegotoreroscover = document.getElementById("SanDiegoTorerosCover").innerHTML;
  var sandiegotorerosML = document.getElementById("SanDiegoTorerosML").innerHTML;
  var sandiegotorerosO = document.getElementById("SanDiegoTorerosOU").innerHTML;
  var sandiegotorerosO = sandiegotorerosO.replace(/[',()]/g, "");
  var sandiegotorerosSoloO = document.getElementById("SanDiegoTorerosSoloOU").innerHTML;
  var sandiegotorerosSoloO = sandiegotorerosSoloO.replace(/[',()]/g, "");
  var sandiegotorerosHalftime = document.getElementById("SanDiegoTorerosHalftime").innerHTML;
  var sandiegotorerosHalftimeO = document.getElementById("SanDiegoTorerosHalftimeOU").innerHTML;
  var sandiegotorerosHalftimeO = sandiegotorerosHalftimeO.replace(/[',()]/g, "");

  var sandiegostateaztecscover = document.getElementById("SanDiegoStateAztecsCover").innerHTML;
  var sandiegostateaztecsML = document.getElementById("SanDiegoStateAztecsML").innerHTML;
  var sandiegostateaztecsO = document.getElementById("SanDiegoStateAztecsOU").innerHTML;
  var sandiegostateaztecsO = sandiegostateaztecsO.replace(/[',()]/g, "");
  var sandiegostateaztecsSoloO = document.getElementById("SanDiegoStateAztecsSoloOU").innerHTML;
  var sandiegostateaztecsSoloO = sandiegostateaztecsSoloO.replace(/[',()]/g, "");
  var sandiegostateaztecsHalftime = document.getElementById("SanDiegoStateAztecsHalftime").innerHTML;
  var sandiegostateaztecsHalftimeO = document.getElementById("SanDiegoStateAztecsHalftimeOU").innerHTML;
  var sandiegostateaztecsHalftimeO = sandiegostateaztecsHalftimeO.replace(/[',()]/g, "");

  var sanfranciscodonscover = document.getElementById("SanFranciscoDonsCover").innerHTML;
  var sanfranciscodonsML = document.getElementById("SanFranciscoDonsML").innerHTML;
  var sanfranciscodonsO = document.getElementById("SanFranciscoDonsOU").innerHTML;
  var sanfranciscodonsO = sanfranciscodonsO.replace(/[',()]/g, "");
  var sanfranciscodonsSoloO = document.getElementById("SanFranciscoDonsSoloOU").innerHTML;
  var sanfranciscodonsSoloO = sanfranciscodonsSoloO.replace(/[',()]/g, "");
  var sanfranciscodonsHalftime = document.getElementById("SanFranciscoDonsHalftime").innerHTML;
  var sanfranciscodonsHalftimeO = document.getElementById("SanFranciscoDonsHalftimeOU").innerHTML;
  var sanfranciscodonsHalftimeO = sanfranciscodonsHalftimeO.replace(/[',()]/g, "");

  var sanjosestatespartanscover = document.getElementById("SanJoseStateSpartansCover").innerHTML;
  var sanjosestatespartansML = document.getElementById("SanJoseStateSpartansML").innerHTML;
  var sanjosestatespartansO = document.getElementById("SanJoseStateSpartansOU").innerHTML;
  var sanjosestatespartansO = sanjosestatespartansO.replace(/[',()]/g, "");
  var sanjosestatespartansSoloO = document.getElementById("SanJoseStateSpartansSoloOU").innerHTML;
  var sanjosestatespartansSoloO = sanjosestatespartansSoloO.replace(/[',()]/g, "");
  var sanjosestatespartansHalftime = document.getElementById("SanJoseStateSpartansHalftime").innerHTML;
  var sanjosestatespartansHalftimeO = document.getElementById("SanJoseStateSpartansHalftimeOU").innerHTML;
  var sanjosestatespartansHalftimeO = sanjosestatespartansHalftimeO.replace(/[',()]/g, "");

  var santaclarabroncoscover = document.getElementById("SantaClaraBroncosCover").innerHTML;
  var santaclarabroncosML = document.getElementById("SantaClaraBroncosML").innerHTML;
  var santaclarabroncosO = document.getElementById("SantaClaraBroncosOU").innerHTML;
  var santaclarabroncosO = santaclarabroncosO.replace(/[',()]/g, "");
  var santaclarabroncosSoloO = document.getElementById("SantaClaraBroncosSoloOU").innerHTML;
  var santaclarabroncosSoloO = santaclarabroncosSoloO.replace(/[',()]/g, "");
  var santaclarabroncosHalftime = document.getElementById("SantaClaraBroncosHalftime").innerHTML;
  var santaclarabroncosHalftimeO = document.getElementById("SantaClaraBroncosHalftimeOU").innerHTML;
  var santaclarabroncosHalftimeO = santaclarabroncosHalftimeO.replace(/[',()]/g, "");

  var seattleredhawkscover = document.getElementById("SeattleRedhawksCover").innerHTML;
  var seattleredhawksML = document.getElementById("SeattleRedhawksML").innerHTML;
  var seattleredhawksO = document.getElementById("SeattleRedhawksOU").innerHTML;
  var seattleredhawksO = seattleredhawksO.replace(/[',()]/g, "");
  var seattleredhawksSoloO = document.getElementById("SeattleRedhawksSoloOU").innerHTML;
  var seattleredhawksSoloO = seattleredhawksSoloO.replace(/[',()]/g, "");
  var seattleredhawksHalftime = document.getElementById("SeattleRedhawksHalftime").innerHTML;
  var seattleredhawksHalftimeO = document.getElementById("SeattleRedhawksHalftimeOU").innerHTML;
  var seattleredhawksHalftimeO = seattleredhawksHalftimeO.replace(/[',()]/g, "");

  var setonhallpiratescover = document.getElementById("SetonHallPiratesCover").innerHTML;
  var setonhallpiratesML = document.getElementById("SetonHallPiratesML").innerHTML;
  var setonhallpiratesO = document.getElementById("SetonHallPiratesOU").innerHTML;
  var setonhallpiratesO = setonhallpiratesO.replace(/[',()]/g, "");
  var setonhallpiratesSoloO = document.getElementById("SetonHallPiratesSoloOU").innerHTML;
  var setonhallpiratesSoloO = setonhallpiratesSoloO.replace(/[',()]/g, "");
  var setonhallpiratesHalftime = document.getElementById("SetonHallPiratesHalftime").innerHTML;
  var setonhallpiratesHalftimeO = document.getElementById("SetonHallPiratesHalftimeOU").innerHTML;
  var setonhallpiratesHalftimeO = setonhallpiratesHalftimeO.replace(/[',()]/g, "");

  var sienasaintscover = document.getElementById("SienaSaintsCover").innerHTML;
  var sienasaintsML = document.getElementById("SienaSaintsML").innerHTML;
  var sienasaintsO = document.getElementById("SienaSaintsOU").innerHTML;
  var sienasaintsO = sienasaintsO.replace(/[',()]/g, "");
  var sienasaintsSoloO = document.getElementById("SienaSaintsSoloOU").innerHTML;
  var sienasaintsSoloO = sienasaintsSoloO.replace(/[',()]/g, "");
  var sienasaintsHalftime = document.getElementById("SienaSaintsHalftime").innerHTML;
  var sienasaintsHalftimeO = document.getElementById("SienaSaintsHalftimeOU").innerHTML;
  var sienasaintsHalftimeO = sienasaintsHalftimeO.replace(/[',()]/g, "");

  var southalabamajaguarscover = document.getElementById("SouthAlabamaJaguarsCover").innerHTML;
  var southalabamajaguarsML = document.getElementById("SouthAlabamaJaguarsML").innerHTML;
  var southalabamajaguarsO = document.getElementById("SouthAlabamaJaguarsOU").innerHTML;
  var southalabamajaguarsO = southalabamajaguarsO.replace(/[',()]/g, "");
  var southalabamajaguarsSoloO = document.getElementById("SouthAlabamaJaguarsSoloOU").innerHTML;
  var southalabamajaguarsSoloO = southalabamajaguarsSoloO.replace(/[',()]/g, "");
  var southalabamajaguarsHalftime = document.getElementById("SouthAlabamaJaguarsHalftime").innerHTML;
  var southalabamajaguarsHalftimeO = document.getElementById("SouthAlabamaJaguarsHalftimeOU").innerHTML;
  var southalabamajaguarsHalftimeO = southalabamajaguarsHalftimeO.replace(/[',()]/g, "");

  var southcarolinagamecockscover = document.getElementById("SouthCarolinaGamecocksCover").innerHTML;
  var southcarolinagamecocksML = document.getElementById("SouthCarolinaGamecocksML").innerHTML;
  var southcarolinagamecocksO = document.getElementById("SouthCarolinaGamecocksOU").innerHTML;
  var southcarolinagamecocksO = southcarolinagamecocksO.replace(/[',()]/g, "");
  var southcarolinagamecocksSoloO = document.getElementById("SouthCarolinaGamecocksSoloOU").innerHTML;
  var southcarolinagamecocksSoloO = southcarolinagamecocksSoloO.replace(/[',()]/g, "");
  var southcarolinagamecocksHalftime = document.getElementById("SouthCarolinaGamecocksHalftime").innerHTML;
  var southcarolinagamecocksHalftimeO = document.getElementById("SouthCarolinaGamecocksHalftimeOU").innerHTML;
  var southcarolinagamecocksHalftimeO = southcarolinagamecocksHalftimeO.replace(/[',()]/g, "");

  var southcarolinastatebulldogscover = document.getElementById("SouthCarolinaStateBulldogsCover").innerHTML;
  var southcarolinastatebulldogsML = document.getElementById("SouthCarolinaStateBulldogsML").innerHTML;
  var southcarolinastatebulldogsO = document.getElementById("SouthCarolinaStateBulldogsOU").innerHTML;
  var southcarolinastatebulldogsO = southcarolinastatebulldogsO.replace(/[',()]/g, "");
  var southcarolinastatebulldogsSoloO = document.getElementById("SouthCarolinaStateBulldogsSoloOU").innerHTML;
  var southcarolinastatebulldogsSoloO = southcarolinastatebulldogsSoloO.replace(/[',()]/g, "");
  var southcarolinastatebulldogsHalftime = document.getElementById("SouthCarolinaStateBulldogsHalftime").innerHTML;
  var southcarolinastatebulldogsHalftimeO = document.getElementById("SouthCarolinaStateBulldogsHalftimeOU").innerHTML;
  var southcarolinastatebulldogsHalftimeO = southcarolinastatebulldogsHalftimeO.replace(/[',()]/g, "");

  var southcarolinaupstatespartanscover = document.getElementById("SouthCarolinaUpstateSpartansCover").innerHTML;
  var southcarolinaupstatespartansML = document.getElementById("SouthCarolinaUpstateSpartansML").innerHTML;
  var southcarolinaupstatespartansO = document.getElementById("SouthCarolinaUpstateSpartansOU").innerHTML;
  var southcarolinaupstatespartansO = southcarolinaupstatespartansO.replace(/[',()]/g, "");
  var southcarolinaupstatespartansSoloO = document.getElementById("SouthCarolinaUpstateSpartansSoloOU").innerHTML;
  var southcarolinaupstatespartansSoloO = southcarolinaupstatespartansSoloO.replace(/[',()]/g, "");
  var southcarolinaupstatespartansHalftime = document.getElementById("SouthCarolinaUpstateSpartansHalftime").innerHTML;
  var southcarolinaupstatespartansHalftimeO = document.getElementById("SouthCarolinaUpstateSpartansHalftimeOU").innerHTML;
  var southcarolinaupstatespartansHalftimeO = southcarolinaupstatespartansHalftimeO.replace(/[',()]/g, "");

  var southdakotacoyotescover = document.getElementById("SouthDakotaCoyotesCover").innerHTML;
  var southdakotacoyotesML = document.getElementById("SouthDakotaCoyotesML").innerHTML;
  var southdakotacoyotesO = document.getElementById("SouthDakotaCoyotesOU").innerHTML;
  var southdakotacoyotesO = southdakotacoyotesO.replace(/[',()]/g, "");
  var southdakotacoyotesSoloO = document.getElementById("SouthDakotaCoyotesSoloOU").innerHTML;
  var southdakotacoyotesSoloO = southdakotacoyotesSoloO.replace(/[',()]/g, "");
  var southdakotacoyotesHalftime = document.getElementById("SouthDakotaCoyotesHalftime").innerHTML;
  var southdakotacoyotesHalftimeO = document.getElementById("SouthDakotaCoyotesHalftimeOU").innerHTML;
  var southdakotacoyotesHalftimeO = southdakotacoyotesHalftimeO.replace(/[',()]/g, "");

  var southdakotastatejackrabbitscover = document.getElementById("SouthDakotaStateJackrabbitsCover").innerHTML;
  var southdakotastatejackrabbitsML = document.getElementById("SouthDakotaStateJackrabbitsML").innerHTML;
  var southdakotastatejackrabbitsO = document.getElementById("SouthDakotaStateJackrabbitsOU").innerHTML;
  var southdakotastatejackrabbitsO = southdakotastatejackrabbitsO.replace(/[',()]/g, "");
  var southdakotastatejackrabbitsSoloO = document.getElementById("SouthDakotaStateJackrabbitsSoloOU").innerHTML;
  var southdakotastatejackrabbitsSoloO = southdakotastatejackrabbitsSoloO.replace(/[',()]/g, "");
  var southdakotastatejackrabbitsHalftime = document.getElementById("SouthDakotaStateJackrabbitsHalftime").innerHTML;
  var southdakotastatejackrabbitsHalftimeO = document.getElementById("SouthDakotaStateJackrabbitsHalftimeOU").innerHTML;
  var southdakotastatejackrabbitsHalftimeO = southdakotastatejackrabbitsHalftimeO.replace(/[',()]/g, "");

  var southfloridabullscover = document.getElementById("SouthFloridaBullsCover").innerHTML;
  var southfloridabullsML = document.getElementById("SouthFloridaBullsML").innerHTML;
  var southfloridabullsO = document.getElementById("SouthFloridaBullsOU").innerHTML;
  var southfloridabullsO = southfloridabullsO.replace(/[',()]/g, "");
  var southfloridabullsSoloO = document.getElementById("SouthFloridaBullsSoloOU").innerHTML;
  var southfloridabullsSoloO = southfloridabullsSoloO.replace(/[',()]/g, "");
  var southfloridabullsHalftime = document.getElementById("SouthFloridaBullsHalftime").innerHTML;
  var southfloridabullsHalftimeO = document.getElementById("SouthFloridaBullsHalftimeOU").innerHTML;
  var southfloridabullsHalftimeO = southfloridabullsHalftimeO.replace(/[',()]/g, "");

  var semissouristredhawkscover = document.getElementById("SEMissouriStRedhawksCover").innerHTML;
  var semissouristredhawksML = document.getElementById("SEMissouriStRedhawksML").innerHTML;
  var semissouristredhawksO = document.getElementById("SEMissouriStRedhawksOU").innerHTML;
  var semissouristredhawksO = semissouristredhawksO.replace(/[',()]/g, "");
  var semissouristredhawksSoloO = document.getElementById("SEMissouriStRedhawksSoloOU").innerHTML;
  var semissouristredhawksSoloO = semissouristredhawksSoloO.replace(/[',()]/g, "");
  var semissouristredhawksHalftime = document.getElementById("SEMissouriStRedhawksHalftime").innerHTML;
  var semissouristredhawksHalftimeO = document.getElementById("SEMissouriStRedhawksHalftimeOU").innerHTML;
  var semissouristredhawksHalftimeO = semissouristredhawksHalftimeO.replace(/[',()]/g, "");

  var selouisianalionscover = document.getElementById("SELouisianaLionsCover").innerHTML;
  var selouisianalionsML = document.getElementById("SELouisianaLionsML").innerHTML;
  var selouisianalionsO = document.getElementById("SELouisianaLionsOU").innerHTML;
  var selouisianalionsO = selouisianalionsO.replace(/[',()]/g, "");
  var selouisianalionsSoloO = document.getElementById("SELouisianaLionsSoloOU").innerHTML;
  var selouisianalionsSoloO = selouisianalionsSoloO.replace(/[',()]/g, "");
  var selouisianalionsHalftime = document.getElementById("SELouisianaLionsHalftime").innerHTML;
  var selouisianalionsHalftimeO = document.getElementById("SELouisianaLionsHalftimeOU").innerHTML;
  var selouisianalionsHalftimeO = selouisianalionsHalftimeO.replace(/[',()]/g, "");

  var southernjaguarscover = document.getElementById("SouthernJaguarsCover").innerHTML;
  var southernjaguarsML = document.getElementById("SouthernJaguarsML").innerHTML;
  var southernjaguarsO = document.getElementById("SouthernJaguarsOU").innerHTML;
  var southernjaguarsO = southernjaguarsO.replace(/[',()]/g, "");
  var southernjaguarsSoloO = document.getElementById("SouthernJaguarsSoloOU").innerHTML;
  var southernjaguarsSoloO = southernjaguarsSoloO.replace(/[',()]/g, "");
  var southernjaguarsHalftime = document.getElementById("SouthernJaguarsHalftime").innerHTML;
  var southernjaguarsHalftimeO = document.getElementById("SouthernJaguarsHalftimeOU").innerHTML;
  var southernjaguarsHalftimeO = southernjaguarsHalftimeO.replace(/[',()]/g, "");

  var usctrojanscover = document.getElementById("USCTrojansCover").innerHTML;
  var usctrojansML = document.getElementById("USCTrojansML").innerHTML;
  var usctrojansO = document.getElementById("USCTrojansOU").innerHTML;
  var usctrojansO = usctrojansO.replace(/[',()]/g, "");
  var usctrojansSoloO = document.getElementById("USCTrojansSoloOU").innerHTML;
  var usctrojansSoloO = usctrojansSoloO.replace(/[',()]/g, "");
  var usctrojansHalftime = document.getElementById("USCTrojansHalftime").innerHTML;
  var usctrojansHalftimeO = document.getElementById("USCTrojansHalftimeOU").innerHTML;
  var usctrojansHalftimeO = usctrojansHalftimeO.replace(/[',()]/g, "");

  var southernillinoissalukiscover = document.getElementById("SouthernIllinoisSalukisCover").innerHTML;
  var southernillinoissalukisML = document.getElementById("SouthernIllinoisSalukisML").innerHTML;
  var southernillinoissalukisO = document.getElementById("SouthernIllinoisSalukisOU").innerHTML;
  var southernillinoissalukisO = southernillinoissalukisO.replace(/[',()]/g, "");
  var southernillinoissalukisSoloO = document.getElementById("SouthernIllinoisSalukisSoloOU").innerHTML;
  var southernillinoissalukisSoloO = southernillinoissalukisSoloO.replace(/[',()]/g, "");
  var southernillinoissalukisHalftime = document.getElementById("SouthernIllinoisSalukisHalftime").innerHTML;
  var southernillinoissalukisHalftimeO = document.getElementById("SouthernIllinoisSalukisHalftimeOU").innerHTML;
  var southernillinoissalukisHalftimeO = southernillinoissalukisHalftimeO.replace(/[',()]/g, "");

  var siuedwardsvillecougarscover = document.getElementById("SIUEdwardsvilleCougarsCover").innerHTML;
  var siuedwardsvillecougarsML = document.getElementById("SIUEdwardsvilleCougarsML").innerHTML;
  var siuedwardsvillecougarsO = document.getElementById("SIUEdwardsvilleCougarsOU").innerHTML;
  var siuedwardsvillecougarsO = siuedwardsvillecougarsO.replace(/[',()]/g, "");
  var siuedwardsvillecougarsSoloO = document.getElementById("SIUEdwardsvilleCougarsSoloOU").innerHTML;
  var siuedwardsvillecougarsSoloO = siuedwardsvillecougarsSoloO.replace(/[',()]/g, "");
  var siuedwardsvillecougarsHalftime = document.getElementById("SIUEdwardsvilleCougarsHalftime").innerHTML;
  var siuedwardsvillecougarsHalftimeO = document.getElementById("SIUEdwardsvilleCougarsHalftimeOU").innerHTML;
  var siuedwardsvillecougarsHalftimeO = siuedwardsvillecougarsHalftimeO.replace(/[',()]/g, "");

  var smumustangscover = document.getElementById("SMUMustangsCover").innerHTML;
  var smumustangsML = document.getElementById("SMUMustangsML").innerHTML;
  var smumustangsO = document.getElementById("SMUMustangsOU").innerHTML;
  var smumustangsO = smumustangsO.replace(/[',()]/g, "");
  var smumustangsSoloO = document.getElementById("SMUMustangsSoloOU").innerHTML;
  var smumustangsSoloO = smumustangsSoloO.replace(/[',()]/g, "");
  var smumustangsHalftime = document.getElementById("SMUMustangsHalftime").innerHTML;
  var smumustangsHalftimeO = document.getElementById("SMUMustangsHalftimeOU").innerHTML;
  var smumustangsHalftimeO = smumustangsHalftimeO.replace(/[',()]/g, "");

  var southernmissgoldeneaglescover = document.getElementById("SouthernMissGoldenEaglesCover").innerHTML;
  var southernmissgoldeneaglesML = document.getElementById("SouthernMissGoldenEaglesML").innerHTML;
  var southernmissgoldeneaglesO = document.getElementById("SouthernMissGoldenEaglesOU").innerHTML;
  var southernmissgoldeneaglesO = southernmissgoldeneaglesO.replace(/[',()]/g, "");
  var southernmissgoldeneaglesSoloO = document.getElementById("SouthernMissGoldenEaglesSoloOU").innerHTML;
  var southernmissgoldeneaglesSoloO = southernmissgoldeneaglesSoloO.replace(/[',()]/g, "");
  var southernmissgoldeneaglesHalftime = document.getElementById("SouthernMissGoldenEaglesHalftime").innerHTML;
  var southernmissgoldeneaglesHalftimeO = document.getElementById("SouthernMissGoldenEaglesHalftimeOU").innerHTML;
  var southernmissgoldeneaglesHalftimeO = southernmissgoldeneaglesHalftimeO.replace(/[',()]/g, "");

  var southernutahthunderbirdscover = document.getElementById("SouthernUtahThunderbirdsCover").innerHTML;
  var southernutahthunderbirdsML = document.getElementById("SouthernUtahThunderbirdsML").innerHTML;
  var southernutahthunderbirdsO = document.getElementById("SouthernUtahThunderbirdsOU").innerHTML;
  var southernutahthunderbirdsO = southernutahthunderbirdsO.replace(/[',()]/g, "");
  var southernutahthunderbirdsSoloO = document.getElementById("SouthernUtahThunderbirdsSoloOU").innerHTML;
  var southernutahthunderbirdsSoloO = southernutahthunderbirdsSoloO.replace(/[',()]/g, "");
  var southernutahthunderbirdsHalftime = document.getElementById("SouthernUtahThunderbirdsHalftime").innerHTML;
  var southernutahthunderbirdsHalftimeO = document.getElementById("SouthernUtahThunderbirdsHalftimeOU").innerHTML;
  var southernutahthunderbirdsHalftimeO = southernutahthunderbirdsHalftimeO.replace(/[',()]/g, "");

  var stanfordcardinalscover = document.getElementById("StanfordCardinalsCover").innerHTML;
  var stanfordcardinalsML = document.getElementById("StanfordCardinalsML").innerHTML;
  var stanfordcardinalsO = document.getElementById("StanfordCardinalsOU").innerHTML;
  var stanfordcardinalsO = stanfordcardinalsO.replace(/[',()]/g, "");
  var stanfordcardinalsSoloO = document.getElementById("StanfordCardinalsSoloOU").innerHTML;
  var stanfordcardinalsSoloO = stanfordcardinalsSoloO.replace(/[',()]/g, "");
  var stanfordcardinalsHalftime = document.getElementById("StanfordCardinalsHalftime").innerHTML;
  var stanfordcardinalsHalftimeO = document.getElementById("StanfordCardinalsHalftimeOU").innerHTML;
  var stanfordcardinalsHalftimeO = stanfordcardinalsHalftimeO.replace(/[',()]/g, "");

  var stephenfaustinlumberjackscover = document.getElementById("StephenFAustinLumberjacksCover").innerHTML;
  var stephenfaustinlumberjacksML = document.getElementById("StephenFAustinLumberjacksML").innerHTML;
  var stephenfaustinlumberjacksO = document.getElementById("StephenFAustinLumberjacksOU").innerHTML;
  var stephenfaustinlumberjacksO = stephenfaustinlumberjacksO.replace(/[',()]/g, "");
  var stephenfaustinlumberjacksSoloO = document.getElementById("StephenFAustinLumberjacksSoloOU").innerHTML;
  var stephenfaustinlumberjacksSoloO = stephenfaustinlumberjacksSoloO.replace(/[',()]/g, "");
  var stephenfaustinlumberjacksHalftime = document.getElementById("StephenFAustinLumberjacksHalftime").innerHTML;
  var stephenfaustinlumberjacksHalftimeO = document.getElementById("StephenFAustinLumberjacksHalftimeOU").innerHTML;
  var stephenfaustinlumberjacksHalftimeO = stephenfaustinlumberjacksHalftimeO.replace(/[',()]/g, "");

  var stetsonhatterscover = document.getElementById("StetsonHattersCover").innerHTML;
  var stetsonhattersML = document.getElementById("StetsonHattersML").innerHTML;
  var stetsonhattersO = document.getElementById("StetsonHattersOU").innerHTML;
  var stetsonhattersO = stetsonhattersO.replace(/[',()]/g, "");
  var stetsonhattersSoloO = document.getElementById("StetsonHattersSoloOU").innerHTML;
  var stetsonhattersSoloO = stetsonhattersSoloO.replace(/[',()]/g, "");
  var stetsonhattersHalftime = document.getElementById("StetsonHattersHalftime").innerHTML;
  var stetsonhattersHalftimeO = document.getElementById("StetsonHattersHalftimeOU").innerHTML;
  var stetsonhattersHalftimeO = stetsonhattersHalftimeO.replace(/[',()]/g, "");

  var stonybrookseawolvescover = document.getElementById("StonyBrookSeawolvesCover").innerHTML;
  var stonybrookseawolvesML = document.getElementById("StonyBrookSeawolvesML").innerHTML;
  var stonybrookseawolvesO = document.getElementById("StonyBrookSeawolvesOU").innerHTML;
  var stonybrookseawolvesO = stonybrookseawolvesO.replace(/[',()]/g, "");
  var stonybrookseawolvesSoloO = document.getElementById("StonyBrookSeawolvesSoloOU").innerHTML;
  var stonybrookseawolvesSoloO = stonybrookseawolvesSoloO.replace(/[',()]/g, "");
  var stonybrookseawolvesHalftime = document.getElementById("StonyBrookSeawolvesHalftime").innerHTML;
  var stonybrookseawolvesHalftimeO = document.getElementById("StonyBrookSeawolvesHalftimeOU").innerHTML;
  var stonybrookseawolvesHalftimeO = stonybrookseawolvesHalftimeO.replace(/[',()]/g, "");

  var syracuseorangecover = document.getElementById("SyracuseOrangeCover").innerHTML;
  var syracuseorangeML = document.getElementById("SyracuseOrangeML").innerHTML;
  var syracuseorangeO = document.getElementById("SyracuseOrangeOU").innerHTML;
  var syracuseorangeO = syracuseorangeO.replace(/[',()]/g, "");
  var syracuseorangeSoloO = document.getElementById("SyracuseOrangeSoloOU").innerHTML;
  var syracuseorangeSoloO = syracuseorangeSoloO.replace(/[',()]/g, "");
  var syracuseorangeHalftime = document.getElementById("SyracuseOrangeHalftime").innerHTML;
  var syracuseorangeHalftimeO = document.getElementById("SyracuseOrangeHalftimeOU").innerHTML;
  var syracuseorangeHalftimeO = syracuseorangeHalftimeO.replace(/[',()]/g, "");

  var templeowlscover = document.getElementById("TempleOwlsCover").innerHTML;
  var templeowlsML = document.getElementById("TempleOwlsML").innerHTML;
  var templeowlsO = document.getElementById("TempleOwlsOU").innerHTML;
  var templeowlsO = templeowlsO.replace(/[',()]/g, "");
  var templeowlsSoloO = document.getElementById("TempleOwlsSoloOU").innerHTML;
  var templeowlsSoloO = templeowlsSoloO.replace(/[',()]/g, "");
  var templeowlsHalftime = document.getElementById("TempleOwlsHalftime").innerHTML;
  var templeowlsHalftimeO = document.getElementById("TempleOwlsHalftimeOU").innerHTML;
  var templeowlsHalftimeO = templeowlsHalftimeO.replace(/[',()]/g, "");

  var tennesseevolunteerscover = document.getElementById("TennesseeVolunteersCover").innerHTML;
  var tennesseevolunteersML = document.getElementById("TennesseeVolunteersML").innerHTML;
  var tennesseevolunteersO = document.getElementById("TennesseeVolunteersOU").innerHTML;
  var tennesseevolunteersO = tennesseevolunteersO.replace(/[',()]/g, "");
  var tennesseevolunteersSoloO = document.getElementById("TennesseeVolunteersSoloOU").innerHTML;
  var tennesseevolunteersSoloO = tennesseevolunteersSoloO.replace(/[',()]/g, "");
  var tennesseevolunteersHalftime = document.getElementById("TennesseeVolunteersHalftime").innerHTML;
  var tennesseevolunteersHalftimeO = document.getElementById("TennesseeVolunteersHalftimeOU").innerHTML;
  var tennesseevolunteersHalftimeO = tennesseevolunteersHalftimeO.replace(/[',()]/g, "");

  var chattanoogamocscover = document.getElementById("ChattanoogaMocsCover").innerHTML;
  var chattanoogamocsML = document.getElementById("ChattanoogaMocsML").innerHTML;
  var chattanoogamocsO = document.getElementById("ChattanoogaMocsOU").innerHTML;
  var chattanoogamocsO = chattanoogamocsO.replace(/[',()]/g, "");
  var chattanoogamocsSoloO = document.getElementById("ChattanoogaMocsSoloOU").innerHTML;
  var chattanoogamocsSoloO = chattanoogamocsSoloO.replace(/[',()]/g, "");
  var chattanoogamocsHalftime = document.getElementById("ChattanoogaMocsHalftime").innerHTML;
  var chattanoogamocsHalftimeO = document.getElementById("ChattanoogaMocsHalftimeOU").innerHTML;
  var chattanoogamocsHalftimeO = chattanoogamocsHalftimeO.replace(/[',()]/g, "");

  var utmartinskyhawkscover = document.getElementById("UTMartinSkyhawksCover").innerHTML;
  var utmartinskyhawksML = document.getElementById("UTMartinSkyhawksML").innerHTML;
  var utmartinskyhawksO = document.getElementById("UTMartinSkyhawksOU").innerHTML;
  var utmartinskyhawksO = utmartinskyhawksO.replace(/[',()]/g, "");
  var utmartinskyhawksSoloO = document.getElementById("UTMartinSkyhawksSoloOU").innerHTML;
  var utmartinskyhawksSoloO = utmartinskyhawksSoloO.replace(/[',()]/g, "");
  var utmartinskyhawksHalftime = document.getElementById("UTMartinSkyhawksHalftime").innerHTML;
  var utmartinskyhawksHalftimeO = document.getElementById("UTMartinSkyhawksHalftimeOU").innerHTML;
  var utmartinskyhawksHalftimeO = utmartinskyhawksHalftimeO.replace(/[',()]/g, "");

  var tennesseestatetigerscover = document.getElementById("TennesseeStateTigersCover").innerHTML;
  var tennesseestatetigersML = document.getElementById("TennesseeStateTigersML").innerHTML;
  var tennesseestatetigersO = document.getElementById("TennesseeStateTigersOU").innerHTML;
  var tennesseestatetigersO = tennesseestatetigersO.replace(/[',()]/g, "");
  var tennesseestatetigersSoloO = document.getElementById("TennesseeStateTigersSoloOU").innerHTML;
  var tennesseestatetigersSoloO = tennesseestatetigersSoloO.replace(/[',()]/g, "");
  var tennesseestatetigersHalftime = document.getElementById("TennesseeStateTigersHalftime").innerHTML;
  var tennesseestatetigersHalftimeO = document.getElementById("TennesseeStateTigersHalftimeOU").innerHTML;
  var tennesseestatetigersHalftimeO = tennesseestatetigersHalftimeO.replace(/[',()]/g, "");

  var tennesseetechgoldeneaglescover = document.getElementById("TennesseeTechGoldenEaglesCover").innerHTML;
  var tennesseetechgoldeneaglesML = document.getElementById("TennesseeTechGoldenEaglesML").innerHTML;
  var tennesseetechgoldeneaglesO = document.getElementById("TennesseeTechGoldenEaglesOU").innerHTML;
  var tennesseetechgoldeneaglesO = tennesseetechgoldeneaglesO.replace(/[',()]/g, "");
  var tennesseetechgoldeneaglesSoloO = document.getElementById("TennesseeTechGoldenEaglesSoloOU").innerHTML;
  var tennesseetechgoldeneaglesSoloO = tennesseetechgoldeneaglesSoloO.replace(/[',()]/g, "");
  var tennesseetechgoldeneaglesHalftime = document.getElementById("TennesseeTechGoldenEaglesHalftime").innerHTML;
  var tennesseetechgoldeneaglesHalftimeO = document.getElementById("TennesseeTechGoldenEaglesHalftimeOU").innerHTML;
  var tennesseetechgoldeneaglesHalftimeO = tennesseetechgoldeneaglesHalftimeO.replace(/[',()]/g, "");

  var texasaandmaggiescover = document.getElementById("TexasAandMAggiesCover").innerHTML;
  var texasaandmaggiesML = document.getElementById("TexasAandMAggiesML").innerHTML;
  var texasaandmaggiesO = document.getElementById("TexasAandMAggiesOU").innerHTML;
  var texasaandmaggiesO = texasaandmaggiesO.replace(/[',()]/g, "");
  var texasaandmaggiesSoloO = document.getElementById("TexasAandMAggiesSoloOU").innerHTML;
  var texasaandmaggiesSoloO = texasaandmaggiesSoloO.replace(/[',()]/g, "");
  var texasaandmaggiesHalftime = document.getElementById("TexasAandMAggiesHalftime").innerHTML;
  var texasaandmaggiesHalftimeO = document.getElementById("TexasAandMAggiesHalftimeOU").innerHTML;
  var texasaandmaggiesHalftimeO = texasaandmaggiesHalftimeO.replace(/[',()]/g, "");

  var texasaandmccislanderscover = document.getElementById("TexasAandMCCIslandersCover").innerHTML;
  var texasaandmccislandersML = document.getElementById("TexasAandMCCIslandersML").innerHTML;
  var texasaandmccislandersO = document.getElementById("TexasAandMCCIslandersOU").innerHTML;
  var texasaandmccislandersO = texasaandmccislandersO.replace(/[',()]/g, "");
  var texasaandmccislandersSoloO = document.getElementById("TexasAandMCCIslandersSoloOU").innerHTML;
  var texasaandmccislandersSoloO = texasaandmccislandersSoloO.replace(/[',()]/g, "");
  var texasaandmccislandersHalftime = document.getElementById("TexasAandMCCIslandersHalftime").innerHTML;
  var texasaandmccislandersHalftimeO = document.getElementById("TexasAandMCCIslandersHalftimeOU").innerHTML;
  var texasaandmccislandersHalftimeO = texasaandmccislandersHalftimeO.replace(/[',()]/g, "");

  var utarlingtonmaverickscover = document.getElementById("UTArlingtonMavericksCover").innerHTML;
  var utarlingtonmavericksML = document.getElementById("UTArlingtonMavericksML").innerHTML;
  var utarlingtonmavericksO = document.getElementById("UTArlingtonMavericksOU").innerHTML;
  var utarlingtonmavericksO = utarlingtonmavericksO.replace(/[',()]/g, "");
  var utarlingtonmavericksSoloO = document.getElementById("UTArlingtonMavericksSoloOU").innerHTML;
  var utarlingtonmavericksSoloO = utarlingtonmavericksSoloO.replace(/[',()]/g, "");
  var utarlingtonmavericksHalftime = document.getElementById("UTArlingtonMavericksHalftime").innerHTML;
  var utarlingtonmavericksHalftimeO = document.getElementById("UTArlingtonMavericksHalftimeOU").innerHTML;
  var utarlingtonmavericksHalftimeO = utarlingtonmavericksHalftimeO.replace(/[',()]/g, "");

  var texaslonghornscover = document.getElementById("TexasLonghornsCover").innerHTML;
  var texaslonghornsML = document.getElementById("TexasLonghornsML").innerHTML;
  var texaslonghornsO = document.getElementById("TexasLonghornsOU").innerHTML;
  var texaslonghornsO = texaslonghornsO.replace(/[',()]/g, "");
  var texaslonghornsSoloO = document.getElementById("TexasLonghornsSoloOU").innerHTML;
  var texaslonghornsSoloO = texaslonghornsSoloO.replace(/[',()]/g, "");
  var texaslonghornsHalftime = document.getElementById("TexasLonghornsHalftime").innerHTML;
  var texaslonghornsHalftimeO = document.getElementById("TexasLonghornsHalftimeOU").innerHTML;
  var texaslonghornsHalftimeO = texaslonghornsHalftimeO.replace(/[',()]/g, "");

  var tcuhornedfrogscover = document.getElementById("TCUHornedFrogsCover").innerHTML;
  var tcuhornedfrogsML = document.getElementById("TCUHornedFrogsML").innerHTML;
  var tcuhornedfrogsO = document.getElementById("TCUHornedFrogsOU").innerHTML;
  var tcuhornedfrogsO = tcuhornedfrogsO.replace(/[',()]/g, "");
  var tcuhornedfrogsSoloO = document.getElementById("TCUHornedFrogsSoloOU").innerHTML;
  var tcuhornedfrogsSoloO = tcuhornedfrogsSoloO.replace(/[',()]/g, "");
  var tcuhornedfrogsHalftime = document.getElementById("TCUHornedFrogsHalftime").innerHTML;
  var tcuhornedfrogsHalftimeO = document.getElementById("TCUHornedFrogsHalftimeOU").innerHTML;
  var tcuhornedfrogsHalftimeO = tcuhornedfrogsHalftimeO.replace(/[',()]/g, "");

  var utepminerscover = document.getElementById("UTEPMinersCover").innerHTML;
  var utepminersML = document.getElementById("UTEPMinersML").innerHTML;
  var utepminersO = document.getElementById("UTEPMinersOU").innerHTML;
  var utepminersO = utepminersO.replace(/[',()]/g, "");
  var utepminersSoloO = document.getElementById("UTEPMinersSoloOU").innerHTML;
  var utepminersSoloO = utepminersSoloO.replace(/[',()]/g, "");
  var utepminersHalftime = document.getElementById("UTEPMinersHalftime").innerHTML;
  var utepminersHalftimeO = document.getElementById("UTEPMinersHalftimeOU").innerHTML;
  var utepminersHalftimeO = utepminersHalftimeO.replace(/[',()]/g, "");

  var utriograndevalleyvaqueroscover = document.getElementById("UTRioGrandeValleyVaquerosCover").innerHTML;
  var utriograndevalleyvaquerosML = document.getElementById("UTRioGrandeValleyVaquerosML").innerHTML;
  var utriograndevalleyvaquerosO = document.getElementById("UTRioGrandeValleyVaquerosOU").innerHTML;
  var utriograndevalleyvaquerosO = utriograndevalleyvaquerosO.replace(/[',()]/g, "");
  var utriograndevalleyvaquerosSoloO = document.getElementById("UTRioGrandeValleyVaquerosSoloOU").innerHTML;
  var utriograndevalleyvaquerosSoloO = utriograndevalleyvaquerosSoloO.replace(/[',()]/g, "");
  var utriograndevalleyvaquerosHalftime = document.getElementById("UTRioGrandeValleyVaquerosHalftime").innerHTML;
  var utriograndevalleyvaquerosHalftimeO = document.getElementById("UTRioGrandeValleyVaquerosHalftimeOU").innerHTML;
  var utriograndevalleyvaquerosHalftimeO = utriograndevalleyvaquerosHalftimeO.replace(/[',()]/g, "");

  var utsaroadrunnerscover = document.getElementById("UTSARoadrunnersCover").innerHTML;
  var utsaroadrunnersML = document.getElementById("UTSARoadrunnersML").innerHTML;
  var utsaroadrunnersO = document.getElementById("UTSARoadrunnersOU").innerHTML;
  var utsaroadrunnersO = utsaroadrunnersO.replace(/[',()]/g, "");
  var utsaroadrunnersSoloO = document.getElementById("UTSARoadrunnersSoloOU").innerHTML;
  var utsaroadrunnersSoloO = utsaroadrunnersSoloO.replace(/[',()]/g, "");
  var utsaroadrunnersHalftime = document.getElementById("UTSARoadrunnersHalftime").innerHTML;
  var utsaroadrunnersHalftimeO = document.getElementById("UTSARoadrunnersHalftimeOU").innerHTML;
  var utsaroadrunnersHalftimeO = utsaroadrunnersHalftimeO.replace(/[',()]/g, "");

  var texassoutherntigerscover = document.getElementById("TexasSouthernTigersCover").innerHTML;
  var texassoutherntigersML = document.getElementById("TexasSouthernTigersML").innerHTML;
  var texassoutherntigersO = document.getElementById("TexasSouthernTigersOU").innerHTML;
  var texassoutherntigersO = texassoutherntigersO.replace(/[',()]/g, "");
  var texassoutherntigersSoloO = document.getElementById("TexasSouthernTigersSoloOU").innerHTML;
  var texassoutherntigersSoloO = texassoutherntigersSoloO.replace(/[',()]/g, "");
  var texassoutherntigersHalftime = document.getElementById("TexasSouthernTigersHalftime").innerHTML;
  var texassoutherntigersHalftimeO = document.getElementById("TexasSouthernTigersHalftimeOU").innerHTML;
  var texassoutherntigersHalftimeO = texassoutherntigersHalftimeO.replace(/[',()]/g, "");

  var texasstatebobcatscover = document.getElementById("TexasStateBobcatsCover").innerHTML;
  var texasstatebobcatsML = document.getElementById("TexasStateBobcatsML").innerHTML;
  var texasstatebobcatsO = document.getElementById("TexasStateBobcatsOU").innerHTML;
  var texasstatebobcatsO = texasstatebobcatsO.replace(/[',()]/g, "");
  var texasstatebobcatsSoloO = document.getElementById("TexasStateBobcatsSoloOU").innerHTML;
  var texasstatebobcatsSoloO = texasstatebobcatsSoloO.replace(/[',()]/g, "");
  var texasstatebobcatsHalftime = document.getElementById("TexasStateBobcatsHalftime").innerHTML;
  var texasstatebobcatsHalftimeO = document.getElementById("TexasStateBobcatsHalftimeOU").innerHTML;
  var texasstatebobcatsHalftimeO = texasstatebobcatsHalftimeO.replace(/[',()]/g, "");

  var texastechredraiderscover = document.getElementById("TexasTechRedRaidersCover").innerHTML;
  var texastechredraidersML = document.getElementById("TexasTechRedRaidersML").innerHTML;
  var texastechredraidersO = document.getElementById("TexasTechRedRaidersOU").innerHTML;
  var texastechredraidersO = texastechredraidersO.replace(/[',()]/g, "");
  var texastechredraidersSoloO = document.getElementById("TexasTechRedRaidersSoloOU").innerHTML;
  var texastechredraidersSoloO = texastechredraidersSoloO.replace(/[',()]/g, "");
  var texastechredraidersHalftime = document.getElementById("TexasTechRedRaidersHalftime").innerHTML;
  var texastechredraidersHalftimeO = document.getElementById("TexasTechRedRaidersHalftimeOU").innerHTML;
  var texastechredraidersHalftimeO = texastechredraidersHalftimeO.replace(/[',()]/g, "");

  var toledorocketscover = document.getElementById("ToledoRocketsCover").innerHTML;
  var toledorocketsML = document.getElementById("ToledoRocketsML").innerHTML;
  var toledorocketsO = document.getElementById("ToledoRocketsOU").innerHTML;
  var toledorocketsO = toledorocketsO.replace(/[',()]/g, "");
  var toledorocketsSoloO = document.getElementById("ToledoRocketsSoloOU").innerHTML;
  var toledorocketsSoloO = toledorocketsSoloO.replace(/[',()]/g, "");
  var toledorocketsHalftime = document.getElementById("ToledoRocketsHalftime").innerHTML;
  var toledorocketsHalftimeO = document.getElementById("ToledoRocketsHalftimeOU").innerHTML;
  var toledorocketsHalftimeO = toledorocketsHalftimeO.replace(/[',()]/g, "");

  var towsontigerscover = document.getElementById("TowsonTigersCover").innerHTML;
  var towsontigersML = document.getElementById("TowsonTigersML").innerHTML;
  var towsontigersO = document.getElementById("TowsonTigersOU").innerHTML;
  var towsontigersO = towsontigersO.replace(/[',()]/g, "");
  var towsontigersSoloO = document.getElementById("TowsonTigersSoloOU").innerHTML;
  var towsontigersSoloO = towsontigersSoloO.replace(/[',()]/g, "");
  var towsontigersHalftime = document.getElementById("TowsonTigersHalftime").innerHTML;
  var towsontigersHalftimeO = document.getElementById("TowsonTigersHalftimeOU").innerHTML;
  var towsontigersHalftimeO = towsontigersHalftimeO.replace(/[',()]/g, "");

  var troytrojanscover = document.getElementById("TroyTrojansCover").innerHTML;
  var troytrojansML = document.getElementById("TroyTrojansML").innerHTML;
  var troytrojansO = document.getElementById("TroyTrojansOU").innerHTML;
  var troytrojansO = troytrojansO.replace(/[',()]/g, "");
  var troytrojansSoloO = document.getElementById("TroyTrojansSoloOU").innerHTML;
  var troytrojansSoloO = troytrojansSoloO.replace(/[',()]/g, "");
  var troytrojansHalftime = document.getElementById("TroyTrojansHalftime").innerHTML;
  var troytrojansHalftimeO = document.getElementById("TroyTrojansHalftimeOU").innerHTML;
  var troytrojansHalftimeO = troytrojansHalftimeO.replace(/[',()]/g, "");

  var tulanegreenwavecover = document.getElementById("TulaneGreenWaveCover").innerHTML;
  var tulanegreenwaveML = document.getElementById("TulaneGreenWaveML").innerHTML;
  var tulanegreenwaveO = document.getElementById("TulaneGreenWaveOU").innerHTML;
  var tulanegreenwaveO = tulanegreenwaveO.replace(/[',()]/g, "");
  var tulanegreenwaveSoloO = document.getElementById("TulaneGreenWaveSoloOU").innerHTML;
  var tulanegreenwaveSoloO = tulanegreenwaveSoloO.replace(/[',()]/g, "");
  var tulanegreenwaveHalftime = document.getElementById("TulaneGreenWaveHalftime").innerHTML;
  var tulanegreenwaveHalftimeO = document.getElementById("TulaneGreenWaveHalftimeOU").innerHTML;
  var tulanegreenwaveHalftimeO = tulanegreenwaveHalftimeO.replace(/[',()]/g, "");

  var tulsagoldenhurricanecover = document.getElementById("TulsaGoldenHurricaneCover").innerHTML;
  var tulsagoldenhurricaneML = document.getElementById("TulsaGoldenHurricaneML").innerHTML;
  var tulsagoldenhurricaneO = document.getElementById("TulsaGoldenHurricaneOU").innerHTML;
  var tulsagoldenhurricaneO = tulsagoldenhurricaneO.replace(/[',()]/g, "");
  var tulsagoldenhurricaneSoloO = document.getElementById("TulsaGoldenHurricaneSoloOU").innerHTML;
  var tulsagoldenhurricaneSoloO = tulsagoldenhurricaneSoloO.replace(/[',()]/g, "");
  var tulsagoldenhurricaneHalftime = document.getElementById("TulsaGoldenHurricaneHalftime").innerHTML;
  var tulsagoldenhurricaneHalftimeO = document.getElementById("TulsaGoldenHurricaneHalftimeOU").innerHTML;
  var tulsagoldenhurricaneHalftimeO = tulsagoldenhurricaneHalftimeO.replace(/[',()]/g, "");

  var airforcefalconscover = document.getElementById("AirForceFalconsCover").innerHTML;
  var airforcefalconsML = document.getElementById("AirForceFalconsML").innerHTML;
  var airforcefalconsO = document.getElementById("AirForceFalconsOU").innerHTML;
  var airforcefalconsO = airforcefalconsO.replace(/[',()]/g, "");
  var airforcefalconsSoloO = document.getElementById("AirForceFalconsSoloOU").innerHTML;
  var airforcefalconsSoloO = airforcefalconsSoloO.replace(/[',()]/g, "");
  var airforcefalconsHalftime = document.getElementById("AirForceFalconsHalftime").innerHTML;
  var airforcefalconsHalftimeO = document.getElementById("AirForceFalconsHalftimeOU").innerHTML;
  var airforcefalconsHalftimeO = airforcefalconsHalftimeO.replace(/[',()]/g, "");

  var armyblackknightscover = document.getElementById("ArmyBlackKnightsCover").innerHTML;
  var armyblackknightsML = document.getElementById("ArmyBlackKnightsML").innerHTML;
  var armyblackknightsO = document.getElementById("ArmyBlackKnightsOU").innerHTML;
  var armyblackknightsO = armyblackknightsO.replace(/[',()]/g, "");
  var armyblackknightsSoloO = document.getElementById("ArmyBlackKnightsSoloOU").innerHTML;
  var armyblackknightsSoloO = armyblackknightsSoloO.replace(/[',()]/g, "");
  var armyblackknightsHalftime = document.getElementById("ArmyBlackKnightsHalftime").innerHTML;
  var armyblackknightsHalftimeO = document.getElementById("ArmyBlackKnightsHalftimeOU").innerHTML;
  var armyblackknightsHalftimeO = armyblackknightsHalftimeO.replace(/[',()]/g, "");

  var navymidshipmencover = document.getElementById("NavyMidshipmenCover").innerHTML;
  var navymidshipmenML = document.getElementById("NavyMidshipmenML").innerHTML;
  var navymidshipmenO = document.getElementById("NavyMidshipmenOU").innerHTML;
  var navymidshipmenO = navymidshipmenO.replace(/[',()]/g, "");
  var navymidshipmenSoloO = document.getElementById("NavyMidshipmenSoloOU").innerHTML;
  var navymidshipmenSoloO = navymidshipmenSoloO.replace(/[',()]/g, "");
  var navymidshipmenHalftime = document.getElementById("NavyMidshipmenHalftime").innerHTML;
  var navymidshipmenHalftimeO = document.getElementById("NavyMidshipmenHalftimeOU").innerHTML;
  var navymidshipmenHalftimeO = navymidshipmenHalftimeO.replace(/[',()]/g, "");

  var utahutescover = document.getElementById("UtahUtesCover").innerHTML;
  var utahutesML = document.getElementById("UtahUtesML").innerHTML;
  var utahutesO = document.getElementById("UtahUtesOU").innerHTML;
  var utahutesO = utahutesO.replace(/[',()]/g, "");
  var utahutesSoloO = document.getElementById("UtahUtesSoloOU").innerHTML;
  var utahutesSoloO = utahutesSoloO.replace(/[',()]/g, "");
  var utahutesHalftime = document.getElementById("UtahUtesHalftime").innerHTML;
  var utahutesHalftimeO = document.getElementById("UtahUtesHalftimeOU").innerHTML;
  var utahutesHalftimeO = utahutesHalftimeO.replace(/[',()]/g, "");

  var utahstateaggiescover = document.getElementById("UtahStateAggiesCover").innerHTML;
  var utahstateaggiesML = document.getElementById("UtahStateAggiesML").innerHTML;
  var utahstateaggiesO = document.getElementById("UtahStateAggiesOU").innerHTML;
  var utahstateaggiesO = utahstateaggiesO.replace(/[',()]/g, "");
  var utahstateaggiesSoloO = document.getElementById("UtahStateAggiesSoloOU").innerHTML;
  var utahstateaggiesSoloO = utahstateaggiesSoloO.replace(/[',()]/g, "");
  var utahstateaggiesHalftime = document.getElementById("UtahStateAggiesHalftime").innerHTML;
  var utahstateaggiesHalftimeO = document.getElementById("UtahStateAggiesHalftimeOU").innerHTML;
  var utahstateaggiesHalftimeO = utahstateaggiesHalftimeO.replace(/[',()]/g, "");

  var utahvalleywolverinescover = document.getElementById("UtahValleyWolverinesCover").innerHTML;
  var utahvalleywolverinesML = document.getElementById("UtahValleyWolverinesML").innerHTML;
  var utahvalleywolverinesO = document.getElementById("UtahValleyWolverinesOU").innerHTML;
  var utahvalleywolverinesO = utahvalleywolverinesO.replace(/[',()]/g, "");
  var utahvalleywolverinesSoloO = document.getElementById("UtahValleyWolverinesSoloOU").innerHTML;
  var utahvalleywolverinesSoloO = utahvalleywolverinesSoloO.replace(/[',()]/g, "");
  var utahvalleywolverinesHalftime = document.getElementById("UtahValleyWolverinesHalftime").innerHTML;
  var utahvalleywolverinesHalftimeO = document.getElementById("UtahValleyWolverinesHalftimeOU").innerHTML;
  var utahvalleywolverinesHalftimeO = utahvalleywolverinesHalftimeO.replace(/[',()]/g, "");

  var valparaisocrusaderscover = document.getElementById("ValparaisoCrusadersCover").innerHTML;
  var valparaisocrusadersML = document.getElementById("ValparaisoCrusadersML").innerHTML;
  var valparaisocrusadersO = document.getElementById("ValparaisoCrusadersOU").innerHTML;
  var valparaisocrusadersO = valparaisocrusadersO.replace(/[',()]/g, "");
  var valparaisocrusadersSoloO = document.getElementById("ValparaisoCrusadersSoloOU").innerHTML;
  var valparaisocrusadersSoloO = valparaisocrusadersSoloO.replace(/[',()]/g, "");
  var valparaisocrusadersHalftime = document.getElementById("ValparaisoCrusadersHalftime").innerHTML;
  var valparaisocrusadersHalftimeO = document.getElementById("ValparaisoCrusadersHalftimeOU").innerHTML;
  var valparaisocrusadersHalftimeO = valparaisocrusadersHalftimeO.replace(/[',()]/g, "");

  var vanderbiltcommodorescover = document.getElementById("VanderbiltCommodoresCover").innerHTML;
  var vanderbiltcommodoresML = document.getElementById("VanderbiltCommodoresML").innerHTML;
  var vanderbiltcommodoresO = document.getElementById("VanderbiltCommodoresOU").innerHTML;
  var vanderbiltcommodoresO = vanderbiltcommodoresO.replace(/[',()]/g, "");
  var vanderbiltcommodoresSoloO = document.getElementById("VanderbiltCommodoresSoloOU").innerHTML;
  var vanderbiltcommodoresSoloO = vanderbiltcommodoresSoloO.replace(/[',()]/g, "");
  var vanderbiltcommodoresHalftime = document.getElementById("VanderbiltCommodoresHalftime").innerHTML;
  var vanderbiltcommodoresHalftimeO = document.getElementById("VanderbiltCommodoresHalftimeOU").innerHTML;
  var vanderbiltcommodoresHalftimeO = vanderbiltcommodoresHalftimeO.replace(/[',()]/g, "");

  var vermontcatamountscover = document.getElementById("VermontCatamountsCover").innerHTML;
  var vermontcatamountsML = document.getElementById("VermontCatamountsML").innerHTML;
  var vermontcatamountsO = document.getElementById("VermontCatamountsOU").innerHTML;
  var vermontcatamountsO = vermontcatamountsO.replace(/[',()]/g, "");
  var vermontcatamountsSoloO = document.getElementById("VermontCatamountsSoloOU").innerHTML;
  var vermontcatamountsSoloO = vermontcatamountsSoloO.replace(/[',()]/g, "");
  var vermontcatamountsHalftime = document.getElementById("VermontCatamountsHalftime").innerHTML;
  var vermontcatamountsHalftimeO = document.getElementById("VermontCatamountsHalftimeOU").innerHTML;
  var vermontcatamountsHalftimeO = vermontcatamountsHalftimeO.replace(/[',()]/g, "");

  var villanovawildcatscover = document.getElementById("VillanovaWildcatsCover").innerHTML;
  var villanovawildcatsML = document.getElementById("VillanovaWildcatsML").innerHTML;
  var villanovawildcatsO = document.getElementById("VillanovaWildcatsOU").innerHTML;
  var villanovawildcatsO = villanovawildcatsO.replace(/[',()]/g, "");
  var villanovawildcatsSoloO = document.getElementById("VillanovaWildcatsSoloOU").innerHTML;
  var villanovawildcatsSoloO = villanovawildcatsSoloO.replace(/[',()]/g, "");
  var villanovawildcatsHalftime = document.getElementById("VillanovaWildcatsHalftime").innerHTML;
  var villanovawildcatsHalftimeO = document.getElementById("VillanovaWildcatsHalftimeOU").innerHTML;
  var villanovawildcatsHalftimeO = villanovawildcatsHalftimeO.replace(/[',()]/g, "");

  var virginiacavalierscover = document.getElementById("VirginiaCavaliersCover").innerHTML;
  var virginiacavaliersML = document.getElementById("VirginiaCavaliersML").innerHTML;
  var virginiacavaliersO = document.getElementById("VirginiaCavaliersOU").innerHTML;
  var virginiacavaliersO = virginiacavaliersO.replace(/[',()]/g, "");
  var virginiacavaliersSoloO = document.getElementById("VirginiaCavaliersSoloOU").innerHTML;
  var virginiacavaliersSoloO = virginiacavaliersSoloO.replace(/[',()]/g, "");
  var virginiacavaliersHalftime = document.getElementById("VirginiaCavaliersHalftime").innerHTML;
  var virginiacavaliersHalftimeO = document.getElementById("VirginiaCavaliersHalftimeOU").innerHTML;
  var virginiacavaliersHalftimeO = virginiacavaliersHalftimeO.replace(/[',()]/g, "");

  var vcuramscover = document.getElementById("VCURamsCover").innerHTML;
  var vcuramsML = document.getElementById("VCURamsML").innerHTML;
  var vcuramsO = document.getElementById("VCURamsOU").innerHTML;
  var vcuramsO = vcuramsO.replace(/[',()]/g, "");
  var vcuramsSoloO = document.getElementById("VCURamsSoloOU").innerHTML;
  var vcuramsSoloO = vcuramsSoloO.replace(/[',()]/g, "");
  var vcuramsHalftime = document.getElementById("VCURamsHalftime").innerHTML;
  var vcuramsHalftimeO = document.getElementById("VCURamsHalftimeOU").innerHTML;
  var vcuramsHalftimeO = vcuramsHalftimeO.replace(/[',()]/g, "");

  var vmikeydetscover = document.getElementById("VMIKeydetsCover").innerHTML;
  var vmikeydetsML = document.getElementById("VMIKeydetsML").innerHTML;
  var vmikeydetsO = document.getElementById("VMIKeydetsOU").innerHTML;
  var vmikeydetsO = vmikeydetsO.replace(/[',()]/g, "");
  var vmikeydetsSoloO = document.getElementById("VMIKeydetsSoloOU").innerHTML;
  var vmikeydetsSoloO = vmikeydetsSoloO.replace(/[',()]/g, "");
  var vmikeydetsHalftime = document.getElementById("VMIKeydetsHalftime").innerHTML;
  var vmikeydetsHalftimeO = document.getElementById("VMIKeydetsHalftimeOU").innerHTML;
  var vmikeydetsHalftimeO = vmikeydetsHalftimeO.replace(/[',()]/g, "");

  var virginiatechhokiescover = document.getElementById("VirginiaTechHokiesCover").innerHTML;
  var virginiatechhokiesML = document.getElementById("VirginiaTechHokiesML").innerHTML;
  var virginiatechhokiesO = document.getElementById("VirginiaTechHokiesOU").innerHTML;
  var virginiatechhokiesO = virginiatechhokiesO.replace(/[',()]/g, "");
  var virginiatechhokiesSoloO = document.getElementById("VirginiaTechHokiesSoloOU").innerHTML;
  var virginiatechhokiesSoloO = virginiatechhokiesSoloO.replace(/[',()]/g, "");
  var virginiatechhokiesHalftime = document.getElementById("VirginiaTechHokiesHalftime").innerHTML;
  var virginiatechhokiesHalftimeO = document.getElementById("VirginiaTechHokiesHalftimeOU").innerHTML;
  var virginiatechhokiesHalftimeO = virginiatechhokiesHalftimeO.replace(/[',()]/g, "");

  var wagnerseahawkscover = document.getElementById("WagnerSeahawksCover").innerHTML;
  var wagnerseahawksML = document.getElementById("WagnerSeahawksML").innerHTML;
  var wagnerseahawksO = document.getElementById("WagnerSeahawksOU").innerHTML;
  var wagnerseahawksO = wagnerseahawksO.replace(/[',()]/g, "");
  var wagnerseahawksSoloO = document.getElementById("WagnerSeahawksSoloOU").innerHTML;
  var wagnerseahawksSoloO = wagnerseahawksSoloO.replace(/[',()]/g, "");
  var wagnerseahawksHalftime = document.getElementById("WagnerSeahawksHalftime").innerHTML;
  var wagnerseahawksHalftimeO = document.getElementById("WagnerSeahawksHalftimeOU").innerHTML;
  var wagnerseahawksHalftimeO = wagnerseahawksHalftimeO.replace(/[',()]/g, "");

  var wakeforestdemondeaconscover = document.getElementById("WakeForestDemonDeaconsCover").innerHTML;
  var wakeforestdemondeaconsML = document.getElementById("WakeForestDemonDeaconsML").innerHTML;
  var wakeforestdemondeaconsO = document.getElementById("WakeForestDemonDeaconsOU").innerHTML;
  var wakeforestdemondeaconsO = wakeforestdemondeaconsO.replace(/[',()]/g, "");
  var wakeforestdemondeaconsSoloO = document.getElementById("WakeForestDemonDeaconsSoloOU").innerHTML;
  var wakeforestdemondeaconsSoloO = wakeforestdemondeaconsSoloO.replace(/[',()]/g, "");
  var wakeforestdemondeaconsHalftime = document.getElementById("WakeForestDemonDeaconsHalftime").innerHTML;
  var wakeforestdemondeaconsHalftimeO = document.getElementById("WakeForestDemonDeaconsHalftimeOU").innerHTML;
  var wakeforestdemondeaconsHalftimeO = wakeforestdemondeaconsHalftimeO.replace(/[',()]/g, "");

  var washingtonhuskiescover = document.getElementById("WashingtonHuskiesCover").innerHTML;
  var washingtonhuskiesML = document.getElementById("WashingtonHuskiesML").innerHTML;
  var washingtonhuskiesO = document.getElementById("WashingtonHuskiesOU").innerHTML;
  var washingtonhuskiesO = washingtonhuskiesO.replace(/[',()]/g, "");
  var washingtonhuskiesSoloO = document.getElementById("WashingtonHuskiesSoloOU").innerHTML;
  var washingtonhuskiesSoloO = washingtonhuskiesSoloO.replace(/[',()]/g, "");
  var washingtonhuskiesHalftime = document.getElementById("WashingtonHuskiesHalftime").innerHTML;
  var washingtonhuskiesHalftimeO = document.getElementById("WashingtonHuskiesHalftimeOU").innerHTML;
  var washingtonhuskiesHalftimeO = washingtonhuskiesHalftimeO.replace(/[',()]/g, "");

  var washingtonstatecougarscover = document.getElementById("WashingtonStateCougarsCover").innerHTML;
  var washingtonstatecougarsML = document.getElementById("WashingtonStateCougarsML").innerHTML;
  var washingtonstatecougarsO = document.getElementById("WashingtonStateCougarsOU").innerHTML;
  var washingtonstatecougarsO = washingtonstatecougarsO.replace(/[',()]/g, "");
  var washingtonstatecougarsSoloO = document.getElementById("WashingtonStateCougarsSoloOU").innerHTML;
  var washingtonstatecougarsSoloO = washingtonstatecougarsSoloO.replace(/[',()]/g, "");
  var washingtonstatecougarsHalftime = document.getElementById("WashingtonStateCougarsHalftime").innerHTML;
  var washingtonstatecougarsHalftimeO = document.getElementById("WashingtonStateCougarsHalftimeOU").innerHTML;
  var washingtonstatecougarsHalftimeO = washingtonstatecougarsHalftimeO.replace(/[',()]/g, "");

  var weberstatewildcatscover = document.getElementById("WeberStateWildcatsCover").innerHTML;
  var weberstatewildcatsML = document.getElementById("WeberStateWildcatsML").innerHTML;
  var weberstatewildcatsO = document.getElementById("WeberStateWildcatsOU").innerHTML;
  var weberstatewildcatsO = weberstatewildcatsO.replace(/[',()]/g, "");
  var weberstatewildcatsSoloO = document.getElementById("WeberStateWildcatsSoloOU").innerHTML;
  var weberstatewildcatsSoloO = weberstatewildcatsSoloO.replace(/[',()]/g, "");
  var weberstatewildcatsHalftime = document.getElementById("WeberStateWildcatsHalftime").innerHTML;
  var weberstatewildcatsHalftimeO = document.getElementById("WeberStateWildcatsHalftimeOU").innerHTML;
  var weberstatewildcatsHalftimeO = weberstatewildcatsHalftimeO.replace(/[',()]/g, "");

  var westvirginiamountaineerscover = document.getElementById("WestVirginiaMountaineersCover").innerHTML;
  var westvirginiamountaineersML = document.getElementById("WestVirginiaMountaineersML").innerHTML;
  var westvirginiamountaineersO = document.getElementById("WestVirginiaMountaineersOU").innerHTML;
  var westvirginiamountaineersO = westvirginiamountaineersO.replace(/[',()]/g, "");
  var westvirginiamountaineersSoloO = document.getElementById("WestVirginiaMountaineersSoloOU").innerHTML;
  var westvirginiamountaineersSoloO = westvirginiamountaineersSoloO.replace(/[',()]/g, "");
  var westvirginiamountaineersHalftime = document.getElementById("WestVirginiaMountaineersHalftime").innerHTML;
  var westvirginiamountaineersHalftimeO = document.getElementById("WestVirginiaMountaineersHalftimeOU").innerHTML;
  var westvirginiamountaineersHalftimeO = westvirginiamountaineersHalftimeO.replace(/[',()]/g, "");

  var westerncarolinacatamountscover = document.getElementById("WesternCarolinaCatamountsCover").innerHTML;
  var westerncarolinacatamountsML = document.getElementById("WesternCarolinaCatamountsML").innerHTML;
  var westerncarolinacatamountsO = document.getElementById("WesternCarolinaCatamountsOU").innerHTML;
  var westerncarolinacatamountsO = westerncarolinacatamountsO.replace(/[',()]/g, "");
  var westerncarolinacatamountsSoloO = document.getElementById("WesternCarolinaCatamountsSoloOU").innerHTML;
  var westerncarolinacatamountsSoloO = westerncarolinacatamountsSoloO.replace(/[',()]/g, "");
  var westerncarolinacatamountsHalftime = document.getElementById("WesternCarolinaCatamountsHalftime").innerHTML;
  var westerncarolinacatamountsHalftimeO = document.getElementById("WesternCarolinaCatamountsHalftimeOU").innerHTML;
  var westerncarolinacatamountsHalftimeO = westerncarolinacatamountsHalftimeO.replace(/[',()]/g, "");

  var westernillinoisleatherneckscover = document.getElementById("WesternIllinoisLeathernecksCover").innerHTML;
  var westernillinoisleathernecksML = document.getElementById("WesternIllinoisLeathernecksML").innerHTML;
  var westernillinoisleathernecksO = document.getElementById("WesternIllinoisLeathernecksOU").innerHTML;
  var westernillinoisleathernecksO = westernillinoisleathernecksO.replace(/[',()]/g, "");
  var westernillinoisleathernecksSoloO = document.getElementById("WesternIllinoisLeathernecksSoloOU").innerHTML;
  var westernillinoisleathernecksSoloO = westernillinoisleathernecksSoloO.replace(/[',()]/g, "");
  var westernillinoisleathernecksHalftime = document.getElementById("WesternIllinoisLeathernecksHalftime").innerHTML;
  var westernillinoisleathernecksHalftimeO = document.getElementById("WesternIllinoisLeathernecksHalftimeOU").innerHTML;
  var westernillinoisleathernecksHalftimeO = westernillinoisleathernecksHalftimeO.replace(/[',()]/g, "");

  var westernkentuckyhilltopperscover = document.getElementById("WesternKentuckyHilltoppersCover").innerHTML;
  var westernkentuckyhilltoppersML = document.getElementById("WesternKentuckyHilltoppersML").innerHTML;
  var westernkentuckyhilltoppersO = document.getElementById("WesternKentuckyHilltoppersOU").innerHTML;
  var westernkentuckyhilltoppersO = westernkentuckyhilltoppersO.replace(/[',()]/g, "");
  var westernkentuckyhilltoppersSoloO = document.getElementById("WesternKentuckyHilltoppersSoloOU").innerHTML;
  var westernkentuckyhilltoppersSoloO = westernkentuckyhilltoppersSoloO.replace(/[',()]/g, "");
  var westernkentuckyhilltoppersHalftime = document.getElementById("WesternKentuckyHilltoppersHalftime").innerHTML;
  var westernkentuckyhilltoppersHalftimeO = document.getElementById("WesternKentuckyHilltoppersHalftimeOU").innerHTML;
  var westernkentuckyhilltoppersHalftimeO = westernkentuckyhilltoppersHalftimeO.replace(/[',()]/g, "");

  var westernmichiganbroncoscover = document.getElementById("WesternMichiganBroncosCover").innerHTML;
  var westernmichiganbroncosML = document.getElementById("WesternMichiganBroncosML").innerHTML;
  var westernmichiganbroncosO = document.getElementById("WesternMichiganBroncosOU").innerHTML;
  var westernmichiganbroncosO = westernmichiganbroncosO.replace(/[',()]/g, "");
  var westernmichiganbroncosSoloO = document.getElementById("WesternMichiganBroncosSoloOU").innerHTML;
  var westernmichiganbroncosSoloO = westernmichiganbroncosSoloO.replace(/[',()]/g, "");
  var westernmichiganbroncosHalftime = document.getElementById("WesternMichiganBroncosHalftime").innerHTML;
  var westernmichiganbroncosHalftimeO = document.getElementById("WesternMichiganBroncosHalftimeOU").innerHTML;
  var westernmichiganbroncosHalftimeO = westernmichiganbroncosHalftimeO.replace(/[',()]/g, "");

  var wichitastateshockerscover = document.getElementById("WichitaStateShockersCover").innerHTML;
  var wichitastateshockersML = document.getElementById("WichitaStateShockersML").innerHTML;
  var wichitastateshockersO = document.getElementById("WichitaStateShockersOU").innerHTML;
  var wichitastateshockersO = wichitastateshockersO.replace(/[',()]/g, "");
  var wichitastateshockersSoloO = document.getElementById("WichitaStateShockersSoloOU").innerHTML;
  var wichitastateshockersSoloO = wichitastateshockersSoloO.replace(/[',()]/g, "");
  var wichitastateshockersHalftime = document.getElementById("WichitaStateShockersHalftime").innerHTML;
  var wichitastateshockersHalftimeO = document.getElementById("WichitaStateShockersHalftimeOU").innerHTML;
  var wichitastateshockersHalftimeO = wichitastateshockersHalftimeO.replace(/[',()]/g, "");

  var williamandmarytribecover = document.getElementById("WilliamandMaryTribeCover").innerHTML;
  var williamandmarytribeML = document.getElementById("WilliamandMaryTribeML").innerHTML;
  var williamandmarytribeO = document.getElementById("WilliamandMaryTribeOU").innerHTML;
  var williamandmarytribeO = williamandmarytribeO.replace(/[',()]/g, "");
  var williamandmarytribeSoloO = document.getElementById("WilliamandMaryTribeSoloOU").innerHTML;
  var williamandmarytribeSoloO = williamandmarytribeSoloO.replace(/[',()]/g, "");
  var williamandmarytribeHalftime = document.getElementById("WilliamandMaryTribeHalftime").innerHTML;
  var williamandmarytribeHalftimeO = document.getElementById("WilliamandMaryTribeHalftimeOU").innerHTML;
  var williamandmarytribeHalftimeO = williamandmarytribeHalftimeO.replace(/[',()]/g, "");

  var winthropeaglescover = document.getElementById("WinthropEaglesCover").innerHTML;
  var winthropeaglesML = document.getElementById("WinthropEaglesML").innerHTML;
  var winthropeaglesO = document.getElementById("WinthropEaglesOU").innerHTML;
  var winthropeaglesO = winthropeaglesO.replace(/[',()]/g, "");
  var winthropeaglesSoloO = document.getElementById("WinthropEaglesSoloOU").innerHTML;
  var winthropeaglesSoloO = winthropeaglesSoloO.replace(/[',()]/g, "");
  var winthropeaglesHalftime = document.getElementById("WinthropEaglesHalftime").innerHTML;
  var winthropeaglesHalftimeO = document.getElementById("WinthropEaglesHalftimeOU").innerHTML;
  var winthropeaglesHalftimeO = winthropeaglesHalftimeO.replace(/[',()]/g, "");

  var greenbayphoenixcover = document.getElementById("GreenBayPhoenixCover").innerHTML;
  var greenbayphoenixML = document.getElementById("GreenBayPhoenixML").innerHTML;
  var greenbayphoenixO = document.getElementById("GreenBayPhoenixOU").innerHTML;
  var greenbayphoenixO = greenbayphoenixO.replace(/[',()]/g, "");
  var greenbayphoenixSoloO = document.getElementById("GreenBayPhoenixSoloOU").innerHTML;
  var greenbayphoenixSoloO = greenbayphoenixSoloO.replace(/[',()]/g, "");
  var greenbayphoenixHalftime = document.getElementById("GreenBayPhoenixHalftime").innerHTML;
  var greenbayphoenixHalftimeO = document.getElementById("GreenBayPhoenixHalftimeOU").innerHTML;
  var greenbayphoenixHalftimeO = greenbayphoenixHalftimeO.replace(/[',()]/g, "");

  var wisconsinbadgerscover = document.getElementById("WisconsinBadgersCover").innerHTML;
  var wisconsinbadgersML = document.getElementById("WisconsinBadgersML").innerHTML;
  var wisconsinbadgersO = document.getElementById("WisconsinBadgersOU").innerHTML;
  var wisconsinbadgersO = wisconsinbadgersO.replace(/[',()]/g, "");
  var wisconsinbadgersSoloO = document.getElementById("WisconsinBadgersSoloOU").innerHTML;
  var wisconsinbadgersSoloO = wisconsinbadgersSoloO.replace(/[',()]/g, "");
  var wisconsinbadgersHalftime = document.getElementById("WisconsinBadgersHalftime").innerHTML;
  var wisconsinbadgersHalftimeO = document.getElementById("WisconsinBadgersHalftimeOU").innerHTML;
  var wisconsinbadgersHalftimeO = wisconsinbadgersHalftimeO.replace(/[',()]/g, "");

  var milwaukeepantherscover = document.getElementById("MilwaukeePanthersCover").innerHTML;
  var milwaukeepanthersML = document.getElementById("MilwaukeePanthersML").innerHTML;
  var milwaukeepanthersO = document.getElementById("MilwaukeePanthersOU").innerHTML;
  var milwaukeepanthersO = milwaukeepanthersO.replace(/[',()]/g, "");
  var milwaukeepanthersSoloO = document.getElementById("MilwaukeePanthersSoloOU").innerHTML;
  var milwaukeepanthersSoloO = milwaukeepanthersSoloO.replace(/[',()]/g, "");
  var milwaukeepanthersHalftime = document.getElementById("MilwaukeePanthersHalftime").innerHTML;
  var milwaukeepanthersHalftimeO = document.getElementById("MilwaukeePanthersHalftimeOU").innerHTML;
  var milwaukeepanthersHalftimeO = milwaukeepanthersHalftimeO.replace(/[',()]/g, "");

  var woffordterrierscover = document.getElementById("WoffordTerriersCover").innerHTML;
  var woffordterriersML = document.getElementById("WoffordTerriersML").innerHTML;
  var woffordterriersO = document.getElementById("WoffordTerriersOU").innerHTML;
  var woffordterriersO = woffordterriersO.replace(/[',()]/g, "");
  var woffordterriersSoloO = document.getElementById("WoffordTerriersSoloOU").innerHTML;
  var woffordterriersSoloO = woffordterriersSoloO.replace(/[',()]/g, "");
  var woffordterriersHalftime = document.getElementById("WoffordTerriersHalftime").innerHTML;
  var woffordterriersHalftimeO = document.getElementById("WoffordTerriersHalftimeOU").innerHTML;
  var woffordterriersHalftimeO = woffordterriersHalftimeO.replace(/[',()]/g, "");

  var wrightstateraiderscover = document.getElementById("WrightStateRaidersCover").innerHTML;
  var wrightstateraidersML = document.getElementById("WrightStateRaidersML").innerHTML;
  var wrightstateraidersO = document.getElementById("WrightStateRaidersOU").innerHTML;
  var wrightstateraidersO = wrightstateraidersO.replace(/[',()]/g, "");
  var wrightstateraidersSoloO = document.getElementById("WrightStateRaidersSoloOU").innerHTML;
  var wrightstateraidersSoloO = wrightstateraidersSoloO.replace(/[',()]/g, "");
  var wrightstateraidersHalftime = document.getElementById("WrightStateRaidersHalftime").innerHTML;
  var wrightstateraidersHalftimeO = document.getElementById("WrightStateRaidersHalftimeOU").innerHTML;
  var wrightstateraidersHalftimeO = wrightstateraidersHalftimeO.replace(/[',()]/g, "");

  var wyomingcowboyscover = document.getElementById("WyomingCowboysCover").innerHTML;
  var wyomingcowboysML = document.getElementById("WyomingCowboysML").innerHTML;
  var wyomingcowboysO = document.getElementById("WyomingCowboysOU").innerHTML;
  var wyomingcowboysO = wyomingcowboysO.replace(/[',()]/g, "");
  var wyomingcowboysSoloO = document.getElementById("WyomingCowboysSoloOU").innerHTML;
  var wyomingcowboysSoloO = wyomingcowboysSoloO.replace(/[',()]/g, "");
  var wyomingcowboysHalftime = document.getElementById("WyomingCowboysHalftime").innerHTML;
  var wyomingcowboysHalftimeO = document.getElementById("WyomingCowboysHalftimeOU").innerHTML;
  var wyomingcowboysHalftimeO = wyomingcowboysHalftimeO.replace(/[',()]/g, "");

  var xaviermusketeerscover = document.getElementById("XavierMusketeersCover").innerHTML;
  var xaviermusketeersML = document.getElementById("XavierMusketeersML").innerHTML;
  var xaviermusketeersO = document.getElementById("XavierMusketeersOU").innerHTML;
  var xaviermusketeersO = xaviermusketeersO.replace(/[',()]/g, "");
  var xaviermusketeersSoloO = document.getElementById("XavierMusketeersSoloOU").innerHTML;
  var xaviermusketeersSoloO = xaviermusketeersSoloO.replace(/[',()]/g, "");
  var xaviermusketeersHalftime = document.getElementById("XavierMusketeersHalftime").innerHTML;
  var xaviermusketeersHalftimeO = document.getElementById("XavierMusketeersHalftimeOU").innerHTML;
  var xaviermusketeersHalftimeO = xaviermusketeersHalftimeO.replace(/[',()]/g, "");

  var yalebulldogscover = document.getElementById("YaleBulldogsCover").innerHTML;
  var yalebulldogsML = document.getElementById("YaleBulldogsML").innerHTML;
  var yalebulldogsO = document.getElementById("YaleBulldogsOU").innerHTML;
  var yalebulldogsO = yalebulldogsO.replace(/[',()]/g, "");
  var yalebulldogsSoloO = document.getElementById("YaleBulldogsSoloOU").innerHTML;
  var yalebulldogsSoloO = yalebulldogsSoloO.replace(/[',()]/g, "");
  var yalebulldogsHalftime = document.getElementById("YaleBulldogsHalftime").innerHTML;
  var yalebulldogsHalftimeO = document.getElementById("YaleBulldogsHalftimeOU").innerHTML;
  var yalebulldogsHalftimeO = yalebulldogsHalftimeO.replace(/[',()]/g, "");

  var youngstownstpenguinscover = document.getElementById("YoungstownStPenguinsCover").innerHTML;
  var youngstownstpenguinsML = document.getElementById("YoungstownStPenguinsML").innerHTML;
  var youngstownstpenguinsO = document.getElementById("YoungstownStPenguinsOU").innerHTML;
  var youngstownstpenguinsO = youngstownstpenguinsO.replace(/[',()]/g, "");
  var youngstownstpenguinsSoloO = document.getElementById("YoungstownStPenguinsSoloOU").innerHTML;
  var youngstownstpenguinsSoloO = youngstownstpenguinsSoloO.replace(/[',()]/g, "");
  var youngstownstpenguinsHalftime = document.getElementById("YoungstownStPenguinsHalftime").innerHTML;
  var youngstownstpenguinsHalftimeO = document.getElementById("YoungstownStPenguinsHalftimeOU").innerHTML;
  var youngstownstpenguinsHalftimeO = youngstownstpenguinsHalftimeO.replace(/[',()]/g, "");

  // How to get the under of a team

  // turn the variable into an integer

  var abilenechristianwildcatsUnder = parseFloat(abilenechristianwildcatsO, 10);
  var abilenechristianwildcatsSoloUnder = parseFloat(abilenechristianwildcatsSoloO,10);
  var abilenechristianwildcatsHalftimeUnder = parseFloat(abilenechristianwildcatsHalftimeO,10);

  var akronzipsUnder = parseFloat(akronzipsO, 10);
  var akronzipsSoloUnder = parseFloat(akronzipsSoloO,10);
  var akronzipsHalftimeUnder = parseFloat(akronzipsHalftimeO,10);

  var alabamacrimsontideUnder = parseFloat(alabamacrimsontideO, 10);
  var alabamacrimsontideSoloUnder = parseFloat(alabamacrimsontideSoloO,10);
  var alabamacrimsontideHalftimeUnder = parseFloat(alabamacrimsontideHalftimeO,10);

  var alabamaaandmbulldogsUnder = parseFloat(alabamaaandmbulldogsO, 10);
  var alabamaaandmbulldogsSoloUnder = parseFloat(alabamaaandmbulldogsSoloO,10);
  var alabamaaandmbulldogsHalftimeUnder = parseFloat(alabamaaandmbulldogsHalftimeO,10);

  var uabblazersUnder = parseFloat(uabblazersO, 10);
  var uabblazersSoloUnder = parseFloat(uabblazersSoloO,10);
  var uabblazersHalftimeUnder = parseFloat(uabblazersHalftimeO,10);

  var alabamastatehornetsUnder = parseFloat(alabamastatehornetsO, 10);
  var alabamastatehornetsSoloUnder = parseFloat(alabamastatehornetsSoloO,10);
  var alabamastatehornetsHalftimeUnder = parseFloat(alabamastatehornetsHalftimeO,10);

  var albanygreatdanesUnder = parseFloat(albanygreatdanesO, 10);
  var albanygreatdanesSoloUnder = parseFloat(albanygreatdanesSoloO,10);
  var albanygreatdanesHalftimeUnder = parseFloat(albanygreatdanesHalftimeO,10);

  var alcornstatebravesUnder = parseFloat(alcornstatebravesO, 10);
  var alcornstatebravesSoloUnder = parseFloat(alcornstatebravesSoloO,10);
  var alcornstatebravesHalftimeUnder = parseFloat(alcornstatebravesHalftimeO,10);

  var americaneaglesUnder = parseFloat(americaneaglesO, 10);
  var americaneaglesSoloUnder = parseFloat(americaneaglesSoloO,10);
  var americaneaglesHalftimeUnder = parseFloat(americaneaglesHalftimeO,10);

  var appalachianstatemountaineersUnder = parseFloat(appalachianstatemountaineersO, 10);
  var appalachianstatemountaineersSoloUnder = parseFloat(appalachianstatemountaineersSoloO,10);
  var appalachianstatemountaineersHalftimeUnder = parseFloat(appalachianstatemountaineersHalftimeO,10);

  var arizonawildcatsUnder = parseFloat(arizonawildcatsO, 10);
  var arizonawildcatsSoloUnder = parseFloat(arizonawildcatsSoloO,10);
  var arizonawildcatsHalftimeUnder = parseFloat(arizonawildcatsHalftimeO,10);

  var arizonastatesundevilsUnder = parseFloat(arizonastatesundevilsO, 10);
  var arizonastatesundevilsSoloUnder = parseFloat(arizonastatesundevilsSoloO,10);
  var arizonastatesundevilsHalftimeUnder = parseFloat(arizonastatesundevilsHalftimeO,10);

  var arkansasrazorbacksUnder = parseFloat(arkansasrazorbacksO, 10);
  var arkansasrazorbacksSoloUnder = parseFloat(arkansasrazorbacksSoloO,10);
  var arkansasrazorbacksHalftimeUnder = parseFloat(arkansasrazorbacksHalftimeO,10);

  var littlerocktrojansUnder = parseFloat(littlerocktrojansO, 10);
  var littlerocktrojansSoloUnder = parseFloat(littlerocktrojansSoloO,10);
  var littlerocktrojansHalftimeUnder = parseFloat(littlerocktrojansHalftimeO,10);

  var arkansaspinebluffgoldenlionsUnder = parseFloat(arkansaspinebluffgoldenlionsO, 10);
  var arkansaspinebluffgoldenlionsSoloUnder = parseFloat(arkansaspinebluffgoldenlionsSoloO,10);
  var arkansaspinebluffgoldenlionsHalftimeUnder = parseFloat(arkansaspinebluffgoldenlionsHalftimeO,10);

  var arkansasstredwolvesUnder = parseFloat(arkansasstredwolvesO, 10);
  var arkansasstredwolvesSoloUnder = parseFloat(arkansasstredwolvesSoloO,10);
  var arkansasstredwolvesHalftimeUnder = parseFloat(arkansasstredwolvesHalftimeO,10);

  var auburntigersUnder = parseFloat(auburntigersO, 10);
  var auburntigersSoloUnder = parseFloat(auburntigersSoloO,10);
  var auburntigersHalftimeUnder = parseFloat(auburntigersHalftimeO,10);

  var austinpeaygovernorsUnder = parseFloat(austinpeaygovernorsO, 10);
  var austinpeaygovernorsSoloUnder = parseFloat(austinpeaygovernorsSoloO,10);
  var austinpeaygovernorsHalftimeUnder = parseFloat(austinpeaygovernorsHalftimeO,10);

  var ballstatecardinalsUnder = parseFloat(ballstatecardinalsO, 10);
  var ballstatecardinalsSoloUnder = parseFloat(ballstatecardinalsSoloO,10);
  var ballstatecardinalsHalftimeUnder = parseFloat(ballstatecardinalsHalftimeO,10);

  var baylorbearsUnder = parseFloat(baylorbearsO, 10);
  var baylorbearsSoloUnder = parseFloat(baylorbearsSoloO,10);
  var baylorbearsHalftimeUnder = parseFloat(baylorbearsHalftimeO,10);

  var belmontbruinsUnder = parseFloat(belmontbruinsO, 10);
  var belmontbruinsSoloUnder = parseFloat(belmontbruinsSoloO,10);
  var belmontbruinsHalftimeUnder = parseFloat(belmontbruinsHalftimeO,10);

  var bethunecookmanwildcatsUnder = parseFloat(bethunecookmanwildcatsO, 10);
  var bethunecookmanwildcatsSoloUnder = parseFloat(bethunecookmanwildcatsSoloO,10);
  var bethunecookmanwildcatsHalftimeUnder = parseFloat(bethunecookmanwildcatsHalftimeO,10);

  var binghamtonbearcatsUnder = parseFloat(binghamtonbearcatsO, 10);
  var binghamtonbearcatsSoloUnder = parseFloat(binghamtonbearcatsSoloO,10);
  var binghamtonbearcatsHalftimeUnder = parseFloat(binghamtonbearcatsHalftimeO,10);

  var boisestatebroncosUnder = parseFloat(boisestatebroncosO, 10);
  var boisestatebroncosSoloUnder = parseFloat(boisestatebroncosSoloO,10);
  var boisestatebroncosHalftimeUnder = parseFloat(boisestatebroncosHalftimeO,10);

  var bostoncollegeeaglesUnder = parseFloat(bostoncollegeeaglesO, 10);
  var bostoncollegeeaglesSoloUnder = parseFloat(bostoncollegeeaglesSoloO,10);
  var bostoncollegeeaglesHalftimeUnder = parseFloat(bostoncollegeeaglesHalftimeO,10);

  var bostonunivterriersUnder = parseFloat(bostonunivterriersO, 10);
  var bostonunivterriersSoloUnder = parseFloat(bostonunivterriersSoloO,10);
  var bostonunivterriersHalftimeUnder = parseFloat(bostonunivterriersHalftimeO,10);

  var bowlinggreenfalconsUnder = parseFloat(bowlinggreenfalconsO, 10);
  var bowlinggreenfalconsSoloUnder = parseFloat(bowlinggreenfalconsSoloO,10);
  var bowlinggreenfalconsHalftimeUnder = parseFloat(bowlinggreenfalconsHalftimeO,10);

  var bradleybravesUnder = parseFloat(bradleybravesO, 10);
  var bradleybravesSoloUnder = parseFloat(bradleybravesSoloO,10);
  var bradleybravesHalftimeUnder = parseFloat(bradleybravesHalftimeO,10);

  var byucougarsUnder = parseFloat(byucougarsO, 10);
  var byucougarsSoloUnder = parseFloat(byucougarsSoloO,10);
  var byucougarsHalftimeUnder = parseFloat(byucougarsHalftimeO,10);

  var brownbearsUnder = parseFloat(brownbearsO, 10);
  var brownbearsSoloUnder = parseFloat(brownbearsSoloO,10);
  var brownbearsHalftimeUnder = parseFloat(brownbearsHalftimeO,10);

  var bryantbulldogsUnder = parseFloat(bryantbulldogsO, 10);
  var bryantbulldogsSoloUnder = parseFloat(bryantbulldogsSoloO,10);
  var bryantbulldogsHalftimeUnder = parseFloat(bryantbulldogsHalftimeO,10);

  var bucknellbisonUnder = parseFloat(bucknellbisonO, 10);
  var bucknellbisonSoloUnder = parseFloat(bucknellbisonSoloO,10);
  var bucknellbisonHalftimeUnder = parseFloat(bucknellbisonHalftimeO,10);

  var buffalobullsUnder = parseFloat(buffalobullsO, 10);
  var buffalobullsSoloUnder = parseFloat(buffalobullsSoloO,10);
  var buffalobullsHalftimeUnder = parseFloat(buffalobullsHalftimeO,10);

  var butlerbulldogsUnder = parseFloat(butlerbulldogsO, 10);
  var butlerbulldogsSoloUnder = parseFloat(butlerbulldogsSoloO,10);
  var butlerbulldogsHalftimeUnder = parseFloat(butlerbulldogsHalftimeO,10);

  var californiagoldenbearsUnder = parseFloat(californiagoldenbearsO, 10);
  var californiagoldenbearsSoloUnder = parseFloat(californiagoldenbearsSoloO,10);
  var californiagoldenbearsHalftimeUnder = parseFloat(californiagoldenbearsHalftimeO,10);

  var ucdavisaggiesUnder = parseFloat(ucdavisaggiesO, 10);
  var ucdavisaggiesSoloUnder = parseFloat(ucdavisaggiesSoloO,10);
  var ucdavisaggiesHalftimeUnder = parseFloat(ucdavisaggiesHalftimeO,10);

  var ucirvineanteatersUnder = parseFloat(ucirvineanteatersO, 10);
  var ucirvineanteatersSoloUnder = parseFloat(ucirvineanteatersSoloO,10);
  var ucirvineanteatersHalftimeUnder = parseFloat(ucirvineanteatersHalftimeO,10);

  var uclabruinsUnder = parseFloat(uclabruinsO, 10);
  var uclabruinsSoloUnder = parseFloat(uclabruinsSoloO,10);
  var uclabruinsHalftimeUnder = parseFloat(uclabruinsHalftimeO,10);

  var calpolymustangsUnder = parseFloat(calpolymustangsO, 10);
  var calpolymustangsSoloUnder = parseFloat(calpolymustangsSoloO,10);
  var calpolymustangsHalftimeUnder = parseFloat(calpolymustangsHalftimeO,10);

  var ucriversidehighlandersUnder = parseFloat(ucriversidehighlandersO, 10);
  var ucriversidehighlandersSoloUnder = parseFloat(ucriversidehighlandersSoloO,10);
  var ucriversidehighlandersHalftimeUnder = parseFloat(ucriversidehighlandersHalftimeO,10);

  var ucsantabarbaragauchosUnder = parseFloat(ucsantabarbaragauchosO, 10);
  var ucsantabarbaragauchosSoloUnder = parseFloat(ucsantabarbaragauchosSoloO,10);
  var ucsantabarbaragauchosHalftimeUnder = parseFloat(ucsantabarbaragauchosHalftimeO,10);

  var csubakersfieldroadrunnersUnder = parseFloat(csubakersfieldroadrunnersO, 10);
  var csubakersfieldroadrunnersSoloUnder = parseFloat(csubakersfieldroadrunnersSoloO,10);
  var csubakersfieldroadrunnersHalftimeUnder = parseFloat(csubakersfieldroadrunnersHalftimeO,10);

  var fresnostatebulldogsUnder = parseFloat(fresnostatebulldogsO, 10);
  var fresnostatebulldogsSoloUnder = parseFloat(fresnostatebulldogsSoloO,10);
  var fresnostatebulldogsHalftimeUnder = parseFloat(fresnostatebulldogsHalftimeO,10);

  var csufullertontitansUnder = parseFloat(csufullertontitansO, 10);
  var csufullertontitansSoloUnder = parseFloat(csufullertontitansSoloO,10);
  var csufullertontitansHalftimeUnder = parseFloat(csufullertontitansHalftimeO,10);

  var longbeachstate49ersUnder = parseFloat(longbeachstate49ersO, 10);
  var longbeachstate49ersSoloUnder = parseFloat(longbeachstate49ersSoloO,10);
  var longbeachstate49ersHalftimeUnder = parseFloat(longbeachstate49ersHalftimeO,10);

  var csunorthridgematadorsUnder = parseFloat(csunorthridgematadorsO, 10);
  var csunorthridgematadorsSoloUnder = parseFloat(csunorthridgematadorsSoloO,10);
  var csunorthridgematadorsHalftimeUnder = parseFloat(csunorthridgematadorsHalftimeO,10);

  var sacramentostatehornetsUnder = parseFloat(sacramentostatehornetsO, 10);
  var sacramentostatehornetsSoloUnder = parseFloat(sacramentostatehornetsSoloO,10);
  var sacramentostatehornetsHalftimeUnder = parseFloat(sacramentostatehornetsHalftimeO,10);

  var campbellfightingcamelsUnder = parseFloat(campbellfightingcamelsO, 10);
  var campbellfightingcamelsSoloUnder = parseFloat(campbellfightingcamelsSoloO,10);
  var campbellfightingcamelsHalftimeUnder = parseFloat(campbellfightingcamelsHalftimeO,10);

  var canisiusgoldengriffinsUnder = parseFloat(canisiusgoldengriffinsO, 10);
  var canisiusgoldengriffinsSoloUnder = parseFloat(canisiusgoldengriffinsSoloO,10);
  var canisiusgoldengriffinsHalftimeUnder = parseFloat(canisiusgoldengriffinsHalftimeO,10);

  var centralarkansasbearsUnder = parseFloat(centralarkansasbearsO, 10);
  var centralarkansasbearsSoloUnder = parseFloat(centralarkansasbearsSoloO,10);
  var centralarkansasbearsHalftimeUnder = parseFloat(centralarkansasbearsHalftimeO,10);

  var centralconnecticutbluedevilsUnder = parseFloat(centralconnecticutbluedevilsO, 10);
  var centralconnecticutbluedevilsSoloUnder = parseFloat(centralconnecticutbluedevilsSoloO,10);
  var centralconnecticutbluedevilsHalftimeUnder = parseFloat(centralconnecticutbluedevilsHalftimeO,10);

  var ucfknightsUnder = parseFloat(ucfknightsO, 10);
  var ucfknightsSoloUnder = parseFloat(ucfknightsSoloO,10);
  var ucfknightsHalftimeUnder = parseFloat(ucfknightsHalftimeO,10);

  var centralmichiganchippewasUnder = parseFloat(centralmichiganchippewasO, 10);
  var centralmichiganchippewasSoloUnder = parseFloat(centralmichiganchippewasSoloO,10);
  var centralmichiganchippewasHalftimeUnder = parseFloat(centralmichiganchippewasHalftimeO,10);

  var charlestoncougarsUnder = parseFloat(charlestoncougarsO, 10);
  var charlestoncougarsSoloUnder = parseFloat(charlestoncougarsSoloO,10);
  var charlestoncougarsHalftimeUnder = parseFloat(charlestoncougarsHalftimeO,10);

  var charlestonsouthernbuccaneersUnder = parseFloat(charlestonsouthernbuccaneersO, 10);
  var charlestonsouthernbuccaneersSoloUnder = parseFloat(charlestonsouthernbuccaneersSoloO,10);
  var charlestonsouthernbuccaneersHalftimeUnder = parseFloat(charlestonsouthernbuccaneersHalftimeO,10);

  var chicagostatecougarsUnder = parseFloat(chicagostatecougarsO, 10);
  var chicagostatecougarsSoloUnder = parseFloat(chicagostatecougarsSoloO,10);
  var chicagostatecougarsHalftimeUnder = parseFloat(chicagostatecougarsHalftimeO,10);

  var cincinnatibearcatsUnder = parseFloat(cincinnatibearcatsO, 10);
  var cincinnatibearcatsSoloUnder = parseFloat(cincinnatibearcatsSoloO,10);
  var cincinnatibearcatsHalftimeUnder = parseFloat(cincinnatibearcatsHalftimeO,10);

  var thecitadelbulldogsUnder = parseFloat(thecitadelbulldogsO, 10);
  var thecitadelbulldogsSoloUnder = parseFloat(thecitadelbulldogsSoloO,10);
  var thecitadelbulldogsHalftimeUnder = parseFloat(thecitadelbulldogsHalftimeO,10);

  var clemsontigersUnder = parseFloat(clemsontigersO, 10);
  var clemsontigersSoloUnder = parseFloat(clemsontigersSoloO,10);
  var clemsontigersHalftimeUnder = parseFloat(clemsontigersHalftimeO,10);

  var clevelandstatevikingsUnder = parseFloat(clevelandstatevikingsO, 10);
  var clevelandstatevikingsSoloUnder = parseFloat(clevelandstatevikingsSoloO,10);
  var clevelandstatevikingsHalftimeUnder = parseFloat(clevelandstatevikingsHalftimeO,10);

  var coastalcarolinachanticleersUnder = parseFloat(coastalcarolinachanticleersO, 10);
  var coastalcarolinachanticleersSoloUnder = parseFloat(coastalcarolinachanticleersSoloO,10);
  var coastalcarolinachanticleersHalftimeUnder = parseFloat(coastalcarolinachanticleersHalftimeO,10);

  var colgateraidersUnder = parseFloat(colgateraidersO, 10);
  var colgateraidersSoloUnder = parseFloat(colgateraidersSoloO,10);
  var colgateraidersHalftimeUnder = parseFloat(colgateraidersHalftimeO,10);

  var coloradobuffaloesUnder = parseFloat(coloradobuffaloesO, 10);
  var coloradobuffaloesSoloUnder = parseFloat(coloradobuffaloesSoloO,10);
  var coloradobuffaloesHalftimeUnder = parseFloat(coloradobuffaloesHalftimeO,10);

  var coloradostateramsUnder = parseFloat(coloradostateramsO, 10);
  var coloradostateramsSoloUnder = parseFloat(coloradostateramsSoloO,10);
  var coloradostateramsHalftimeUnder = parseFloat(coloradostateramsHalftimeO,10);

  var columbialionsUnder = parseFloat(columbialionsO, 10);
  var columbialionsSoloUnder = parseFloat(columbialionsSoloO,10);
  var columbialionsHalftimeUnder = parseFloat(columbialionsHalftimeO,10);

  var uconnhuskiesUnder = parseFloat(uconnhuskiesO, 10);
  var uconnhuskiesSoloUnder = parseFloat(uconnhuskiesSoloO,10);
  var uconnhuskiesHalftimeUnder = parseFloat(uconnhuskiesHalftimeO,10);

  var coppinstateeaglesUnder = parseFloat(coppinstateeaglesO, 10);
  var coppinstateeaglesSoloUnder = parseFloat(coppinstateeaglesSoloO,10);
  var coppinstateeaglesHalftimeUnder = parseFloat(coppinstateeaglesHalftimeO,10);

  var cornellbigredUnder = parseFloat(cornellbigredO, 10);
  var cornellbigredSoloUnder = parseFloat(cornellbigredSoloO,10);
  var cornellbigredHalftimeUnder = parseFloat(cornellbigredHalftimeO,10);

  var creightonbluejaysUnder = parseFloat(creightonbluejaysO, 10);
  var creightonbluejaysSoloUnder = parseFloat(creightonbluejaysSoloO,10);
  var creightonbluejaysHalftimeUnder = parseFloat(creightonbluejaysHalftimeO,10);

  var dartmouthbiggreenUnder = parseFloat(dartmouthbiggreenO, 10);
  var dartmouthbiggreenSoloUnder = parseFloat(dartmouthbiggreenSoloO,10);
  var dartmouthbiggreenHalftimeUnder = parseFloat(dartmouthbiggreenHalftimeO,10);

  var davidsonwildcatsUnder = parseFloat(davidsonwildcatsO, 10);
  var davidsonwildcatsSoloUnder = parseFloat(davidsonwildcatsSoloO,10);
  var davidsonwildcatsHalftimeUnder = parseFloat(davidsonwildcatsHalftimeO,10);

  var daytonflyersUnder = parseFloat(daytonflyersO, 10);
  var daytonflyersSoloUnder = parseFloat(daytonflyersSoloO,10);
  var daytonflyersHalftimeUnder = parseFloat(daytonflyersHalftimeO,10);

  var delawarebluehensUnder = parseFloat(delawarebluehensO, 10);
  var delawarebluehensSoloUnder = parseFloat(delawarebluehensSoloO,10);
  var delawarebluehensHalftimeUnder = parseFloat(delawarebluehensHalftimeO,10);

  var delawarestatehornetsUnder = parseFloat(delawarestatehornetsO, 10);
  var delawarestatehornetsSoloUnder = parseFloat(delawarestatehornetsSoloO,10);
  var delawarestatehornetsHalftimeUnder = parseFloat(delawarestatehornetsHalftimeO,10);

  var denverpioneersUnder = parseFloat(denverpioneersO, 10);
  var denverpioneersSoloUnder = parseFloat(denverpioneersSoloO,10);
  var denverpioneersHalftimeUnder = parseFloat(denverpioneersHalftimeO,10);

  var depaulbluedemonsUnder = parseFloat(depaulbluedemonsO, 10);
  var depaulbluedemonsSoloUnder = parseFloat(depaulbluedemonsSoloO,10);
  var depaulbluedemonsHalftimeUnder = parseFloat(depaulbluedemonsHalftimeO,10);

  var detroitmercytitansUnder = parseFloat(detroitmercytitansO, 10);
  var detroitmercytitansSoloUnder = parseFloat(detroitmercytitansSoloO,10);
  var detroitmercytitansHalftimeUnder = parseFloat(detroitmercytitansHalftimeO,10);

  var drakebulldogsUnder = parseFloat(drakebulldogsO, 10);
  var drakebulldogsSoloUnder = parseFloat(drakebulldogsSoloO,10);
  var drakebulldogsHalftimeUnder = parseFloat(drakebulldogsHalftimeO,10);

  var drexeldragonsUnder = parseFloat(drexeldragonsO, 10);
  var drexeldragonsSoloUnder = parseFloat(drexeldragonsSoloO,10);
  var drexeldragonsHalftimeUnder = parseFloat(drexeldragonsHalftimeO,10);

  var dukebluedevilsUnder = parseFloat(dukebluedevilsO, 10);
  var dukebluedevilsSoloUnder = parseFloat(dukebluedevilsSoloO,10);
  var dukebluedevilsHalftimeUnder = parseFloat(dukebluedevilsHalftimeO,10);

  var duquesnedukesUnder = parseFloat(duquesnedukesO, 10);
  var duquesnedukesSoloUnder = parseFloat(duquesnedukesSoloO,10);
  var duquesnedukesHalftimeUnder = parseFloat(duquesnedukesHalftimeO,10);

  var easttennesseestatebuccaneersUnder = parseFloat(easttennesseestatebuccaneersO, 10);
  var easttennesseestatebuccaneersSoloUnder = parseFloat(easttennesseestatebuccaneersSoloO,10);
  var easttennesseestatebuccaneersHalftimeUnder = parseFloat(easttennesseestatebuccaneersHalftimeO,10);

  var easternillinoispanthersUnder = parseFloat(easternillinoispanthersO, 10);
  var easternillinoispanthersSoloUnder = parseFloat(easternillinoispanthersSoloO,10);
  var easternillinoispanthersHalftimeUnder = parseFloat(easternillinoispanthersHalftimeO,10);

  var easternkentuckycolonelsUnder = parseFloat(easternkentuckycolonelsO, 10);
  var easternkentuckycolonelsSoloUnder = parseFloat(easternkentuckycolonelsSoloO,10);
  var easternkentuckycolonelsHalftimeUnder = parseFloat(easternkentuckycolonelsHalftimeO,10);

  var easternmichiganeaglesUnder = parseFloat(easternmichiganeaglesO, 10);
  var easternmichiganeaglesSoloUnder = parseFloat(easternmichiganeaglesSoloO,10);
  var easternmichiganeaglesHalftimeUnder = parseFloat(easternmichiganeaglesHalftimeO,10);

  var elonphoenixUnder = parseFloat(elonphoenixO, 10);
  var elonphoenixSoloUnder = parseFloat(elonphoenixSoloO,10);
  var elonphoenixHalftimeUnder = parseFloat(elonphoenixHalftimeO,10);

  var evansvillepurpleacesUnder = parseFloat(evansvillepurpleacesO, 10);
  var evansvillepurpleacesSoloUnder = parseFloat(evansvillepurpleacesSoloO,10);
  var evansvillepurpleacesHalftimeUnder = parseFloat(evansvillepurpleacesHalftimeO,10);

  var fairfieldstagsUnder = parseFloat(fairfieldstagsO, 10);
  var fairfieldstagsSoloUnder = parseFloat(fairfieldstagsSoloO,10);
  var fairfieldstagsHalftimeUnder = parseFloat(fairfieldstagsHalftimeO,10);

  var fairleighdickinsonknightsUnder = parseFloat(fairleighdickinsonknightsO, 10);
  var fairleighdickinsonknightsSoloUnder = parseFloat(fairleighdickinsonknightsSoloO,10);
  var fairleighdickinsonknightsHalftimeUnder = parseFloat(fairleighdickinsonknightsHalftimeO,10);

  var floridagatorsUnder = parseFloat(floridagatorsO, 10);
  var floridagatorsSoloUnder = parseFloat(floridagatorsSoloO,10);
  var floridagatorsHalftimeUnder = parseFloat(floridagatorsHalftimeO,10);

  var floridaaandmrattlersUnder = parseFloat(floridaaandmrattlersO, 10);
  var floridaaandmrattlersSoloUnder = parseFloat(floridaaandmrattlersSoloO,10);
  var floridaaandmrattlersHalftimeUnder = parseFloat(floridaaandmrattlersHalftimeO,10);

  var floridaatlanticowlsUnder = parseFloat(floridaatlanticowlsO, 10);
  var floridaatlanticowlsSoloUnder = parseFloat(floridaatlanticowlsSoloO,10);
  var floridaatlanticowlsHalftimeUnder = parseFloat(floridaatlanticowlsHalftimeO,10);

  var floridagulfcoasteaglesUnder = parseFloat(floridagulfcoasteaglesO, 10);
  var floridagulfcoasteaglesSoloUnder = parseFloat(floridagulfcoasteaglesSoloO,10);
  var floridagulfcoasteaglesHalftimeUnder = parseFloat(floridagulfcoasteaglesHalftimeO,10);

  var floridainternationalpanthersUnder = parseFloat(floridainternationalpanthersO, 10);
  var floridainternationalpanthersSoloUnder = parseFloat(floridainternationalpanthersSoloO,10);
  var floridainternationalpanthersHalftimeUnder = parseFloat(floridainternationalpanthersHalftimeO,10);

  var floridastateseminolesUnder = parseFloat(floridastateseminolesO, 10);
  var floridastateseminolesSoloUnder = parseFloat(floridastateseminolesSoloO,10);
  var floridastateseminolesHalftimeUnder = parseFloat(floridastateseminolesHalftimeO,10);

  var fordhamramsUnder = parseFloat(fordhamramsO, 10);
  var fordhamramsSoloUnder = parseFloat(fordhamramsSoloO,10);
  var fordhamramsHalftimeUnder = parseFloat(fordhamramsHalftimeO,10);

  var furmanpaladinsUnder = parseFloat(furmanpaladinsO, 10);
  var furmanpaladinsSoloUnder = parseFloat(furmanpaladinsSoloO,10);
  var furmanpaladinsHalftimeUnder = parseFloat(furmanpaladinsHalftimeO,10);

  var gardnerwebbbulldogsUnder = parseFloat(gardnerwebbbulldogsO, 10);
  var gardnerwebbbulldogsSoloUnder = parseFloat(gardnerwebbbulldogsSoloO,10);
  var gardnerwebbbulldogsHalftimeUnder = parseFloat(gardnerwebbbulldogsHalftimeO,10);

  var georgemasonpatriotsUnder = parseFloat(georgemasonpatriotsO, 10);
  var georgemasonpatriotsSoloUnder = parseFloat(georgemasonpatriotsSoloO,10);
  var georgemasonpatriotsHalftimeUnder = parseFloat(georgemasonpatriotsHalftimeO,10);

  var georgewashingtoncolonialsUnder = parseFloat(georgewashingtoncolonialsO, 10);
  var georgewashingtoncolonialsSoloUnder = parseFloat(georgewashingtoncolonialsSoloO,10);
  var georgewashingtoncolonialsHalftimeUnder = parseFloat(georgewashingtoncolonialsHalftimeO,10);

  var georgetownhoyasUnder = parseFloat(georgetownhoyasO, 10);
  var georgetownhoyasSoloUnder = parseFloat(georgetownhoyasSoloO,10);
  var georgetownhoyasHalftimeUnder = parseFloat(georgetownhoyasHalftimeO,10);

  var georgiabulldogsUnder = parseFloat(georgiabulldogsO, 10);
  var georgiabulldogsSoloUnder = parseFloat(georgiabulldogsSoloO,10);
  var georgiabulldogsHalftimeUnder = parseFloat(georgiabulldogsHalftimeO,10);

  var georgiatechyellowjacketsUnder = parseFloat(georgiatechyellowjacketsO, 10);
  var georgiatechyellowjacketsSoloUnder = parseFloat(georgiatechyellowjacketsSoloO,10);
  var georgiatechyellowjacketsHalftimeUnder = parseFloat(georgiatechyellowjacketsHalftimeO,10);

  var georgiasoutherneaglesUnder = parseFloat(georgiasoutherneaglesO, 10);
  var georgiasoutherneaglesSoloUnder = parseFloat(georgiasoutherneaglesSoloO,10);
  var georgiasoutherneaglesHalftimeUnder = parseFloat(georgiasoutherneaglesHalftimeO,10);

  var georgiastatepanthersUnder = parseFloat(georgiastatepanthersO, 10);
  var georgiastatepanthersSoloUnder = parseFloat(georgiastatepanthersSoloO,10);
  var georgiastatepanthersHalftimeUnder = parseFloat(georgiastatepanthersHalftimeO,10);

  var gonzagabulldogsUnder = parseFloat(gonzagabulldogsO, 10);
  var gonzagabulldogsSoloUnder = parseFloat(gonzagabulldogsSoloO,10);
  var gonzagabulldogsHalftimeUnder = parseFloat(gonzagabulldogsHalftimeO,10);

  var gramblingtigersUnder = parseFloat(gramblingtigersO, 10);
  var gramblingtigersSoloUnder = parseFloat(gramblingtigersSoloO,10);
  var gramblingtigersHalftimeUnder = parseFloat(gramblingtigersHalftimeO,10);

  var grandcanyonantelopesUnder = parseFloat(grandcanyonantelopesO, 10);
  var grandcanyonantelopesSoloUnder = parseFloat(grandcanyonantelopesSoloO,10);
  var grandcanyonantelopesHalftimeUnder = parseFloat(grandcanyonantelopesHalftimeO,10);

  var hamptonpiratesUnder = parseFloat(hamptonpiratesO, 10);
  var hamptonpiratesSoloUnder = parseFloat(hamptonpiratesSoloO,10);
  var hamptonpiratesHalftimeUnder = parseFloat(hamptonpiratesHalftimeO,10);

  var hartfordhawksUnder = parseFloat(hartfordhawksO, 10);
  var hartfordhawksSoloUnder = parseFloat(hartfordhawksSoloO,10);
  var hartfordhawksHalftimeUnder = parseFloat(hartfordhawksHalftimeO,10);

  var harvardcrimsonUnder = parseFloat(harvardcrimsonO, 10);
  var harvardcrimsonSoloUnder = parseFloat(harvardcrimsonSoloO,10);
  var harvardcrimsonHalftimeUnder = parseFloat(harvardcrimsonHalftimeO,10);

  var hawaiirainbowwarriorsUnder = parseFloat(hawaiirainbowwarriorsO, 10);
  var hawaiirainbowwarriorsSoloUnder = parseFloat(hawaiirainbowwarriorsSoloO,10);
  var hawaiirainbowwarriorsHalftimeUnder = parseFloat(hawaiirainbowwarriorsHalftimeO,10);

  var highpointpanthersUnder = parseFloat(highpointpanthersO, 10);
  var highpointpanthersSoloUnder = parseFloat(highpointpanthersSoloO,10);
  var highpointpanthersHalftimeUnder = parseFloat(highpointpanthersHalftimeO,10);

  var hofstraprideUnder = parseFloat(hofstraprideO, 10);
  var hofstraprideSoloUnder = parseFloat(hofstraprideSoloO,10);
  var hofstraprideHalftimeUnder = parseFloat(hofstraprideHalftimeO,10);

  var holycrosscrusadersUnder = parseFloat(holycrosscrusadersO, 10);
  var holycrosscrusadersSoloUnder = parseFloat(holycrosscrusadersSoloO,10);
  var holycrosscrusadersHalftimeUnder = parseFloat(holycrosscrusadersHalftimeO,10);

  var houstoncougarsUnder = parseFloat(houstoncougarsO, 10);
  var houstoncougarsSoloUnder = parseFloat(houstoncougarsSoloO,10);
  var houstoncougarsHalftimeUnder = parseFloat(houstoncougarsHalftimeO,10);

  var houstonbaptisthuskiesUnder = parseFloat(houstonbaptisthuskiesO, 10);
  var houstonbaptisthuskiesSoloUnder = parseFloat(houstonbaptisthuskiesSoloO,10);
  var houstonbaptisthuskiesHalftimeUnder = parseFloat(houstonbaptisthuskiesHalftimeO,10);

  var howardbisonUnder = parseFloat(howardbisonO, 10);
  var howardbisonSoloUnder = parseFloat(howardbisonSoloO,10);
  var howardbisonHalftimeUnder = parseFloat(howardbisonHalftimeO,10);

  var idahovandalsUnder = parseFloat(idahovandalsO, 10);
  var idahovandalsSoloUnder = parseFloat(idahovandalsSoloO,10);
  var idahovandalsHalftimeUnder = parseFloat(idahovandalsHalftimeO,10);

  var idahostatebengalsUnder = parseFloat(idahostatebengalsO, 10);
  var idahostatebengalsSoloUnder = parseFloat(idahostatebengalsSoloO,10);
  var idahostatebengalsHalftimeUnder = parseFloat(idahostatebengalsHalftimeO,10);

  var uicflamesUnder = parseFloat(uicflamesO, 10);
  var uicflamesSoloUnder = parseFloat(uicflamesSoloO,10);
  var uicflamesHalftimeUnder = parseFloat(uicflamesHalftimeO,10);

  var illinoisstateredbirdsUnder = parseFloat(illinoisstateredbirdsO, 10);
  var illinoisstateredbirdsSoloUnder = parseFloat(illinoisstateredbirdsSoloO,10);
  var illinoisstateredbirdsHalftimeUnder = parseFloat(illinoisstateredbirdsHalftimeO,10);

  var illinoisfightingilliniUnder = parseFloat(illinoisfightingilliniO, 10);
  var illinoisfightingilliniSoloUnder = parseFloat(illinoisfightingilliniSoloO,10);
  var illinoisfightingilliniHalftimeUnder = parseFloat(illinoisfightingilliniHalftimeO,10);

  var incarnatewordcardinalsUnder = parseFloat(incarnatewordcardinalsO, 10);
  var incarnatewordcardinalsSoloUnder = parseFloat(incarnatewordcardinalsSoloO,10);
  var incarnatewordcardinalsHalftimeUnder = parseFloat(incarnatewordcardinalsHalftimeO,10);

  var indianahoosiersUnder = parseFloat(indianahoosiersO, 10);
  var indianahoosiersSoloUnder = parseFloat(indianahoosiersSoloO,10);
  var indianahoosiersHalftimeUnder = parseFloat(indianahoosiersHalftimeO,10);

  var indianastatesycamoresUnder = parseFloat(indianastatesycamoresO, 10);
  var indianastatesycamoresSoloUnder = parseFloat(indianastatesycamoresSoloO,10);
  var indianastatesycamoresHalftimeUnder = parseFloat(indianastatesycamoresHalftimeO,10);

  var iupuijaguarsUnder = parseFloat(iupuijaguarsO, 10);
  var iupuijaguarsSoloUnder = parseFloat(iupuijaguarsSoloO,10);
  var iupuijaguarsHalftimeUnder = parseFloat(iupuijaguarsHalftimeO,10);

  var ionagaelsUnder = parseFloat(ionagaelsO, 10);
  var ionagaelsSoloUnder = parseFloat(ionagaelsSoloO,10);
  var ionagaelsHalftimeUnder = parseFloat(ionagaelsHalftimeO,10);

  var iowahawkeyesUnder = parseFloat(iowahawkeyesO, 10);
  var iowahawkeyesSoloUnder = parseFloat(iowahawkeyesSoloO,10);
  var iowahawkeyesHalftimeUnder = parseFloat(iowahawkeyesHalftimeO,10);

  var iowastatecyclonesUnder = parseFloat(iowastatecyclonesO, 10);
  var iowastatecyclonesSoloUnder = parseFloat(iowastatecyclonesSoloO,10);
  var iowastatecyclonesHalftimeUnder = parseFloat(iowastatecyclonesHalftimeO,10);

  var jacksonstatetigersUnder = parseFloat(jacksonstatetigersO, 10);
  var jacksonstatetigersSoloUnder = parseFloat(jacksonstatetigersSoloO,10);
  var jacksonstatetigersHalftimeUnder = parseFloat(jacksonstatetigersHalftimeO,10);

  var jacksonvilledolphinsUnder = parseFloat(jacksonvilledolphinsO, 10);
  var jacksonvilledolphinsSoloUnder = parseFloat(jacksonvilledolphinsSoloO,10);
  var jacksonvilledolphinsHalftimeUnder = parseFloat(jacksonvilledolphinsHalftimeO,10);

  var jacksonvillestategamecocksUnder = parseFloat(jacksonvillestategamecocksO, 10);
  var jacksonvillestategamecocksSoloUnder = parseFloat(jacksonvillestategamecocksSoloO,10);
  var jacksonvillestategamecocksHalftimeUnder = parseFloat(jacksonvillestategamecocksHalftimeO,10);

  var jamesmadisondukesUnder = parseFloat(jamesmadisondukesO, 10);
  var jamesmadisondukesSoloUnder = parseFloat(jamesmadisondukesSoloO,10);
  var jamesmadisondukesHalftimeUnder = parseFloat(jamesmadisondukesHalftimeO,10);

  var kansasjayhawksUnder = parseFloat(kansasjayhawksO, 10);
  var kansasjayhawksSoloUnder = parseFloat(kansasjayhawksSoloO,10);
  var kansasjayhawksHalftimeUnder = parseFloat(kansasjayhawksHalftimeO,10);

  var kansasstatewildcatsUnder = parseFloat(kansasstatewildcatsO, 10);
  var kansasstatewildcatsSoloUnder = parseFloat(kansasstatewildcatsSoloO,10);
  var kansasstatewildcatsHalftimeUnder = parseFloat(kansasstatewildcatsHalftimeO,10);

  var kennesawstateowlsUnder = parseFloat(kennesawstateowlsO, 10);
  var kennesawstateowlsSoloUnder = parseFloat(kennesawstateowlsSoloO,10);
  var kennesawstateowlsHalftimeUnder = parseFloat(kennesawstateowlsHalftimeO,10);

  var kentstategoldenflashesUnder = parseFloat(kentstategoldenflashesO, 10);
  var kentstategoldenflashesSoloUnder = parseFloat(kentstategoldenflashesSoloO,10);
  var kentstategoldenflashesHalftimeUnder = parseFloat(kentstategoldenflashesHalftimeO,10);

  var kentuckywildcatsUnder = parseFloat(kentuckywildcatsO, 10);
  var kentuckywildcatsSoloUnder = parseFloat(kentuckywildcatsSoloO,10);
  var kentuckywildcatsHalftimeUnder = parseFloat(kentuckywildcatsHalftimeO,10);

  var lasalleexplorersUnder = parseFloat(lasalleexplorersO, 10);
  var lasalleexplorersSoloUnder = parseFloat(lasalleexplorersSoloO,10);
  var lasalleexplorersHalftimeUnder = parseFloat(lasalleexplorersHalftimeO,10);

  var lafayetteleopardsUnder = parseFloat(lafayetteleopardsO, 10);
  var lafayetteleopardsSoloUnder = parseFloat(lafayetteleopardsSoloO,10);
  var lafayetteleopardsHalftimeUnder = parseFloat(lafayetteleopardsHalftimeO,10);

  var lamarcardinalsUnder = parseFloat(lamarcardinalsO, 10);
  var lamarcardinalsSoloUnder = parseFloat(lamarcardinalsSoloO,10);
  var lamarcardinalsHalftimeUnder = parseFloat(lamarcardinalsHalftimeO,10);

  var lehighmountainhawksUnder = parseFloat(lehighmountainhawksO, 10);
  var lehighmountainhawksSoloUnder = parseFloat(lehighmountainhawksSoloO,10);
  var lehighmountainhawksHalftimeUnder = parseFloat(lehighmountainhawksHalftimeO,10);

  var libertyflamesUnder = parseFloat(libertyflamesO, 10);
  var libertyflamesSoloUnder = parseFloat(libertyflamesSoloO,10);
  var libertyflamesHalftimeUnder = parseFloat(libertyflamesHalftimeO,10);

  var lipscombbisonsUnder = parseFloat(lipscombbisonsO, 10);
  var lipscombbisonsSoloUnder = parseFloat(lipscombbisonsSoloO,10);
  var lipscombbisonsHalftimeUnder = parseFloat(lipscombbisonsHalftimeO,10);

  var longislanduniversitysharksUnder = parseFloat(longislanduniversitysharksO, 10);
  var longislanduniversitysharksSoloUnder = parseFloat(longislanduniversitysharksSoloO,10);
  var longislanduniversitysharksHalftimeUnder = parseFloat(longislanduniversitysharksHalftimeO,10);

  var longwoodlancersUnder = parseFloat(longwoodlancersO, 10);
  var longwoodlancersSoloUnder = parseFloat(longwoodlancersSoloO,10);
  var longwoodlancersHalftimeUnder = parseFloat(longwoodlancersHalftimeO,10);

  var louisianaragincajunsUnder = parseFloat(louisianaragincajunsO, 10);
  var louisianaragincajunsSoloUnder = parseFloat(louisianaragincajunsSoloO,10);
  var louisianaragincajunsHalftimeUnder = parseFloat(louisianaragincajunsHalftimeO,10);

  var ulmonroewarhawksUnder = parseFloat(ulmonroewarhawksO, 10);
  var ulmonroewarhawksSoloUnder = parseFloat(ulmonroewarhawksSoloO,10);
  var ulmonroewarhawksHalftimeUnder = parseFloat(ulmonroewarhawksHalftimeO,10);

  var lsutigersUnder = parseFloat(lsutigersO, 10);
  var lsutigersSoloUnder = parseFloat(lsutigersSoloO,10);
  var lsutigersHalftimeUnder = parseFloat(lsutigersHalftimeO,10);

  var louisianatechbulldogsUnder = parseFloat(louisianatechbulldogsO, 10);
  var louisianatechbulldogsSoloUnder = parseFloat(louisianatechbulldogsSoloO,10);
  var louisianatechbulldogsHalftimeUnder = parseFloat(louisianatechbulldogsHalftimeO,10);

  var louisvillecardinalsUnder = parseFloat(louisvillecardinalsO, 10);
  var louisvillecardinalsSoloUnder = parseFloat(louisvillecardinalsSoloO,10);
  var louisvillecardinalsHalftimeUnder = parseFloat(louisvillecardinalsHalftimeO,10);

  var loyolachicagoramblersUnder = parseFloat(loyolachicagoramblersO, 10);
  var loyolachicagoramblersSoloUnder = parseFloat(loyolachicagoramblersSoloO,10);
  var loyolachicagoramblersHalftimeUnder = parseFloat(loyolachicagoramblersHalftimeO,10);

  var loyolamdgreyhoundsUnder = parseFloat(loyolamdgreyhoundsO, 10);
  var loyolamdgreyhoundsSoloUnder = parseFloat(loyolamdgreyhoundsSoloO,10);
  var loyolamdgreyhoundsHalftimeUnder = parseFloat(loyolamdgreyhoundsHalftimeO,10);

  var loyolamarymountlionsUnder = parseFloat(loyolamarymountlionsO, 10);
  var loyolamarymountlionsSoloUnder = parseFloat(loyolamarymountlionsSoloO,10);
  var loyolamarymountlionsHalftimeUnder = parseFloat(loyolamarymountlionsHalftimeO,10);

  var maineblackbearsUnder = parseFloat(maineblackbearsO, 10);
  var maineblackbearsSoloUnder = parseFloat(maineblackbearsSoloO,10);
  var maineblackbearsHalftimeUnder = parseFloat(maineblackbearsHalftimeO,10);

  var manhattanjaspersUnder = parseFloat(manhattanjaspersO, 10);
  var manhattanjaspersSoloUnder = parseFloat(manhattanjaspersSoloO,10);
  var manhattanjaspersHalftimeUnder = parseFloat(manhattanjaspersHalftimeO,10);

  var maristredfoxesUnder = parseFloat(maristredfoxesO, 10);
  var maristredfoxesSoloUnder = parseFloat(maristredfoxesSoloO,10);
  var maristredfoxesHalftimeUnder = parseFloat(maristredfoxesHalftimeO,10);

  var marquettegoldeneaglesUnder = parseFloat(marquettegoldeneaglesO, 10);
  var marquettegoldeneaglesSoloUnder = parseFloat(marquettegoldeneaglesSoloO,10);
  var marquettegoldeneaglesHalftimeUnder = parseFloat(marquettegoldeneaglesHalftimeO,10);

  var marshallthunderingherdUnder = parseFloat(marshallthunderingherdO, 10);
  var marshallthunderingherdSoloUnder = parseFloat(marshallthunderingherdSoloO,10);
  var marshallthunderingherdHalftimeUnder = parseFloat(marshallthunderingherdHalftimeO,10);

  var umbcretrieversUnder = parseFloat(umbcretrieversO, 10);
  var umbcretrieversSoloUnder = parseFloat(umbcretrieversSoloO,10);
  var umbcretrieversHalftimeUnder = parseFloat(umbcretrieversHalftimeO,10);

  var marylandterrapinsUnder = parseFloat(marylandterrapinsO, 10);
  var marylandterrapinsSoloUnder = parseFloat(marylandterrapinsSoloO,10);
  var marylandterrapinsHalftimeUnder = parseFloat(marylandterrapinsHalftimeO,10);

  var marylandeasternshorehawksUnder = parseFloat(marylandeasternshorehawksO, 10);
  var marylandeasternshorehawksSoloUnder = parseFloat(marylandeasternshorehawksSoloO,10);
  var marylandeasternshorehawksHalftimeUnder = parseFloat(marylandeasternshorehawksHalftimeO,10);

  var umassminutemenUnder = parseFloat(umassminutemenO, 10);
  var umassminutemenSoloUnder = parseFloat(umassminutemenSoloO,10);
  var umassminutemenHalftimeUnder = parseFloat(umassminutemenHalftimeO,10);

  var umasslowellriverhawksUnder = parseFloat(umasslowellriverhawksO, 10);
  var umasslowellriverhawksSoloUnder = parseFloat(umasslowellriverhawksSoloO,10);
  var umasslowellriverhawksHalftimeUnder = parseFloat(umasslowellriverhawksHalftimeO,10);

  var mcneesestatecowboysUnder = parseFloat(mcneesestatecowboysO, 10);
  var mcneesestatecowboysSoloUnder = parseFloat(mcneesestatecowboysSoloO,10);
  var mcneesestatecowboysHalftimeUnder = parseFloat(mcneesestatecowboysHalftimeO,10);

  var memphistigersUnder = parseFloat(memphistigersO, 10);
  var memphistigersSoloUnder = parseFloat(memphistigersSoloO,10);
  var memphistigersHalftimeUnder = parseFloat(memphistigersHalftimeO,10);

  var mercerbearsUnder = parseFloat(mercerbearsO, 10);
  var mercerbearsSoloUnder = parseFloat(mercerbearsSoloO,10);
  var mercerbearsHalftimeUnder = parseFloat(mercerbearsHalftimeO,10);

  var miamihurricanesUnder = parseFloat(miamihurricanesO, 10);
  var miamihurricanesSoloUnder = parseFloat(miamihurricanesSoloO,10);
  var miamihurricanesHalftimeUnder = parseFloat(miamihurricanesHalftimeO,10);

  var miamiohredhawksUnder = parseFloat(miamiohredhawksO, 10);
  var miamiohredhawksSoloUnder = parseFloat(miamiohredhawksSoloO,10);
  var miamiohredhawksHalftimeUnder = parseFloat(miamiohredhawksHalftimeO,10);

  var michiganwolverinesUnder = parseFloat(michiganwolverinesO, 10);
  var michiganwolverinesSoloUnder = parseFloat(michiganwolverinesSoloO,10);
  var michiganwolverinesHalftimeUnder = parseFloat(michiganwolverinesHalftimeO,10);

  var michiganstatespartansUnder = parseFloat(michiganstatespartansO, 10);
  var michiganstatespartansSoloUnder = parseFloat(michiganstatespartansSoloO,10);
  var michiganstatespartansHalftimeUnder = parseFloat(michiganstatespartansHalftimeO,10);

  var middletennesseeblueraidersUnder = parseFloat(middletennesseeblueraidersO, 10);
  var middletennesseeblueraidersSoloUnder = parseFloat(middletennesseeblueraidersSoloO,10);
  var middletennesseeblueraidersHalftimeUnder = parseFloat(middletennesseeblueraidersHalftimeO,10);

  var minnesotagoldengophersUnder = parseFloat(minnesotagoldengophersO, 10);
  var minnesotagoldengophersSoloUnder = parseFloat(minnesotagoldengophersSoloO,10);
  var minnesotagoldengophersHalftimeUnder = parseFloat(minnesotagoldengophersHalftimeO,10);

  var olemissrebelsUnder = parseFloat(olemissrebelsO, 10);
  var olemissrebelsSoloUnder = parseFloat(olemissrebelsSoloO,10);
  var olemissrebelsHalftimeUnder = parseFloat(olemissrebelsHalftimeO,10);

  var mississippistatebulldogsUnder = parseFloat(mississippistatebulldogsO, 10);
  var mississippistatebulldogsSoloUnder = parseFloat(mississippistatebulldogsSoloO,10);
  var mississippistatebulldogsHalftimeUnder = parseFloat(mississippistatebulldogsHalftimeO,10);

  var mississippivalleystatedeltadevilsUnder = parseFloat(mississippivalleystatedeltadevilsO, 10);
  var mississippivalleystatedeltadevilsSoloUnder = parseFloat(mississippivalleystatedeltadevilsSoloO,10);
  var mississippivalleystatedeltadevilsHalftimeUnder = parseFloat(mississippivalleystatedeltadevilsHalftimeO,10);

  var missouritigersUnder = parseFloat(missouritigersO, 10);
  var missouritigersSoloUnder = parseFloat(missouritigersSoloO,10);
  var missouritigersHalftimeUnder = parseFloat(missouritigersHalftimeO,10);

  var umkckangaroosUnder = parseFloat(umkckangaroosO, 10);
  var umkckangaroosSoloUnder = parseFloat(umkckangaroosSoloO,10);
  var umkckangaroosHalftimeUnder = parseFloat(umkckangaroosHalftimeO,10);

  var missouristatebearsUnder = parseFloat(missouristatebearsO, 10);
  var missouristatebearsSoloUnder = parseFloat(missouristatebearsSoloO,10);
  var missouristatebearsHalftimeUnder = parseFloat(missouristatebearsHalftimeO,10);

  var monmouthhawksUnder = parseFloat(monmouthhawksO, 10);
  var monmouthhawksSoloUnder = parseFloat(monmouthhawksSoloO,10);
  var monmouthhawksHalftimeUnder = parseFloat(monmouthhawksHalftimeO,10);

  var montanagrizzliesUnder = parseFloat(montanagrizzliesO, 10);
  var montanagrizzliesSoloUnder = parseFloat(montanagrizzliesSoloO,10);
  var montanagrizzliesHalftimeUnder = parseFloat(montanagrizzliesHalftimeO,10);

  var montanastatebobcatsUnder = parseFloat(montanastatebobcatsO, 10);
  var montanastatebobcatsSoloUnder = parseFloat(montanastatebobcatsSoloO,10);
  var montanastatebobcatsHalftimeUnder = parseFloat(montanastatebobcatsHalftimeO,10);

  var moreheadstateeaglesUnder = parseFloat(moreheadstateeaglesO, 10);
  var moreheadstateeaglesSoloUnder = parseFloat(moreheadstateeaglesSoloO,10);
  var moreheadstateeaglesHalftimeUnder = parseFloat(moreheadstateeaglesHalftimeO,10);

  var morganstatebearsUnder = parseFloat(morganstatebearsO, 10);
  var morganstatebearsSoloUnder = parseFloat(morganstatebearsSoloO,10);
  var morganstatebearsHalftimeUnder = parseFloat(morganstatebearsHalftimeO,10);

  var mtstmarysmountaineersUnder = parseFloat(mtstmarysmountaineersO, 10);
  var mtstmarysmountaineersSoloUnder = parseFloat(mtstmarysmountaineersSoloO,10);
  var mtstmarysmountaineersHalftimeUnder = parseFloat(mtstmarysmountaineersHalftimeO,10);

  var murraystateracersUnder = parseFloat(murraystateracersO, 10);
  var murraystateracersSoloUnder = parseFloat(murraystateracersSoloO,10);
  var murraystateracersHalftimeUnder = parseFloat(murraystateracersHalftimeO,10);

  var nebraskacornhuskersUnder = parseFloat(nebraskacornhuskersO, 10);
  var nebraskacornhuskersSoloUnder = parseFloat(nebraskacornhuskersSoloO,10);
  var nebraskacornhuskersHalftimeUnder = parseFloat(nebraskacornhuskersHalftimeO,10);

  var omahamavericksUnder = parseFloat(omahamavericksO, 10);
  var omahamavericksSoloUnder = parseFloat(omahamavericksSoloO,10);
  var omahamavericksHalftimeUnder = parseFloat(omahamavericksHalftimeO,10);

  var unlvrebelsUnder = parseFloat(unlvrebelsO, 10);
  var unlvrebelsSoloUnder = parseFloat(unlvrebelsSoloO,10);
  var unlvrebelsHalftimeUnder = parseFloat(unlvrebelsHalftimeO,10);

  var nevadawolfpackUnder = parseFloat(nevadawolfpackO, 10);
  var nevadawolfpackSoloUnder = parseFloat(nevadawolfpackSoloO,10);
  var nevadawolfpackHalftimeUnder = parseFloat(nevadawolfpackHalftimeO,10);

  var newhampshirewildcatsUnder = parseFloat(newhampshirewildcatsO, 10);
  var newhampshirewildcatsSoloUnder = parseFloat(newhampshirewildcatsSoloO,10);
  var newhampshirewildcatsHalftimeUnder = parseFloat(newhampshirewildcatsHalftimeO,10);

  var njithighlandersUnder = parseFloat(njithighlandersO, 10);
  var njithighlandersSoloUnder = parseFloat(njithighlandersSoloO,10);
  var njithighlandersHalftimeUnder = parseFloat(njithighlandersHalftimeO,10);

  var newmexicolobosUnder = parseFloat(newmexicolobosO, 10);
  var newmexicolobosSoloUnder = parseFloat(newmexicolobosSoloO,10);
  var newmexicolobosHalftimeUnder = parseFloat(newmexicolobosHalftimeO,10);

  var newmexicostateaggiesUnder = parseFloat(newmexicostateaggiesO, 10);
  var newmexicostateaggiesSoloUnder = parseFloat(newmexicostateaggiesSoloO,10);
  var newmexicostateaggiesHalftimeUnder = parseFloat(newmexicostateaggiesHalftimeO,10);

  var neworleansprivateersUnder = parseFloat(neworleansprivateersO, 10);
  var neworleansprivateersSoloUnder = parseFloat(neworleansprivateersSoloO,10);
  var neworleansprivateersHalftimeUnder = parseFloat(neworleansprivateersHalftimeO,10);

  var niagarapurpleeaglesUnder = parseFloat(niagarapurpleeaglesO, 10);
  var niagarapurpleeaglesSoloUnder = parseFloat(niagarapurpleeaglesSoloO,10);
  var niagarapurpleeaglesHalftimeUnder = parseFloat(niagarapurpleeaglesHalftimeO,10);

  var nichollscolonelsUnder = parseFloat(nichollscolonelsO, 10);
  var nichollscolonelsSoloUnder = parseFloat(nichollscolonelsSoloO,10);
  var nichollscolonelsHalftimeUnder = parseFloat(nichollscolonelsHalftimeO,10);

  var norfolkstatespartansUnder = parseFloat(norfolkstatespartansO, 10);
  var norfolkstatespartansSoloUnder = parseFloat(norfolkstatespartansSoloO,10);
  var norfolkstatespartansHalftimeUnder = parseFloat(norfolkstatespartansHalftimeO,10);

  var northcarolinaaandtaggiesUnder = parseFloat(northcarolinaaandtaggiesO, 10);
  var northcarolinaaandtaggiesSoloUnder = parseFloat(northcarolinaaandtaggiesSoloO,10);
  var northcarolinaaandtaggiesHalftimeUnder = parseFloat(northcarolinaaandtaggiesHalftimeO,10);

  var uncashevillebulldogsUnder = parseFloat(uncashevillebulldogsO, 10);
  var uncashevillebulldogsSoloUnder = parseFloat(uncashevillebulldogsSoloO,10);
  var uncashevillebulldogsHalftimeUnder = parseFloat(uncashevillebulldogsHalftimeO,10);

  var northcarolinacentraleaglesUnder = parseFloat(northcarolinacentraleaglesO, 10);
  var northcarolinacentraleaglesSoloUnder = parseFloat(northcarolinacentraleaglesSoloO,10);
  var northcarolinacentraleaglesHalftimeUnder = parseFloat(northcarolinacentraleaglesHalftimeO,10);

  var northcarolinatarheelsUnder = parseFloat(northcarolinatarheelsO, 10);
  var northcarolinatarheelsSoloUnder = parseFloat(northcarolinatarheelsSoloO,10);
  var northcarolinatarheelsHalftimeUnder = parseFloat(northcarolinatarheelsHalftimeO,10);

  var charlotte49ersUnder = parseFloat(charlotte49ersO, 10);
  var charlotte49ersSoloUnder = parseFloat(charlotte49ersSoloO,10);
  var charlotte49ersHalftimeUnder = parseFloat(charlotte49ersHalftimeO,10);

  var uncgreensborospartansUnder = parseFloat(uncgreensborospartansO, 10);
  var uncgreensborospartansSoloUnder = parseFloat(uncgreensborospartansSoloO,10);
  var uncgreensborospartansHalftimeUnder = parseFloat(uncgreensborospartansHalftimeO,10);

  var ncstatewolfpackUnder = parseFloat(ncstatewolfpackO, 10);
  var ncstatewolfpackSoloUnder = parseFloat(ncstatewolfpackSoloO,10);
  var ncstatewolfpackHalftimeUnder = parseFloat(ncstatewolfpackHalftimeO,10);

  var uncwilmingtonseahawksUnder = parseFloat(uncwilmingtonseahawksO, 10);
  var uncwilmingtonseahawksSoloUnder = parseFloat(uncwilmingtonseahawksSoloO,10);
  var uncwilmingtonseahawksHalftimeUnder = parseFloat(uncwilmingtonseahawksHalftimeO,10);

  var northdakotafightinghawksUnder = parseFloat(northdakotafightinghawksO, 10);
  var northdakotafightinghawksSoloUnder = parseFloat(northdakotafightinghawksSoloO,10);
  var northdakotafightinghawksHalftimeUnder = parseFloat(northdakotafightinghawksHalftimeO,10);

  var northdakotastatebisonUnder = parseFloat(northdakotastatebisonO, 10);
  var northdakotastatebisonSoloUnder = parseFloat(northdakotastatebisonSoloO,10);
  var northdakotastatebisonHalftimeUnder = parseFloat(northdakotastatebisonHalftimeO,10);

  var northfloridaospreysUnder = parseFloat(northfloridaospreysO, 10);
  var northfloridaospreysSoloUnder = parseFloat(northfloridaospreysSoloO,10);
  var northfloridaospreysHalftimeUnder = parseFloat(northfloridaospreysHalftimeO,10);

  var northtexasmeangreenUnder = parseFloat(northtexasmeangreenO, 10);
  var northtexasmeangreenSoloUnder = parseFloat(northtexasmeangreenSoloO,10);
  var northtexasmeangreenHalftimeUnder = parseFloat(northtexasmeangreenHalftimeO,10);

  var northeasternhuskiesUnder = parseFloat(northeasternhuskiesO, 10);
  var northeasternhuskiesSoloUnder = parseFloat(northeasternhuskiesSoloO,10);
  var northeasternhuskiesHalftimeUnder = parseFloat(northeasternhuskiesHalftimeO,10);

  var northernarizonalumberjacksUnder = parseFloat(northernarizonalumberjacksO, 10);
  var northernarizonalumberjacksSoloUnder = parseFloat(northernarizonalumberjacksSoloO,10);
  var northernarizonalumberjacksHalftimeUnder = parseFloat(northernarizonalumberjacksHalftimeO,10);

  var northerncoloradobearsUnder = parseFloat(northerncoloradobearsO, 10);
  var northerncoloradobearsSoloUnder = parseFloat(northerncoloradobearsSoloO,10);
  var northerncoloradobearsHalftimeUnder = parseFloat(northerncoloradobearsHalftimeO,10);

  var northernillinoishuskiesUnder = parseFloat(northernillinoishuskiesO, 10);
  var northernillinoishuskiesSoloUnder = parseFloat(northernillinoishuskiesSoloO,10);
  var northernillinoishuskiesHalftimeUnder = parseFloat(northernillinoishuskiesHalftimeO,10);

  var northerniowapanthersUnder = parseFloat(northerniowapanthersO, 10);
  var northerniowapanthersSoloUnder = parseFloat(northerniowapanthersSoloO,10);
  var northerniowapanthersHalftimeUnder = parseFloat(northerniowapanthersHalftimeO,10);

  var northernkentuckynorseUnder = parseFloat(northernkentuckynorseO, 10);
  var northernkentuckynorseSoloUnder = parseFloat(northernkentuckynorseSoloO,10);
  var northernkentuckynorseHalftimeUnder = parseFloat(northernkentuckynorseHalftimeO,10);

  var northwesternwildcatsUnder = parseFloat(northwesternwildcatsO, 10);
  var northwesternwildcatsSoloUnder = parseFloat(northwesternwildcatsSoloO,10);
  var northwesternwildcatsHalftimeUnder = parseFloat(northwesternwildcatsHalftimeO,10);

  var northwesternstatedemonsUnder = parseFloat(northwesternstatedemonsO, 10);
  var northwesternstatedemonsSoloUnder = parseFloat(northwesternstatedemonsSoloO,10);
  var northwesternstatedemonsHalftimeUnder = parseFloat(northwesternstatedemonsHalftimeO,10);

  var notredamefightingirishUnder = parseFloat(notredamefightingirishO, 10);
  var notredamefightingirishSoloUnder = parseFloat(notredamefightingirishSoloO,10);
  var notredamefightingirishHalftimeUnder = parseFloat(notredamefightingirishHalftimeO,10);

  var oaklandgoldengrizzliesUnder = parseFloat(oaklandgoldengrizzliesO, 10);
  var oaklandgoldengrizzliesSoloUnder = parseFloat(oaklandgoldengrizzliesSoloO,10);
  var oaklandgoldengrizzliesHalftimeUnder = parseFloat(oaklandgoldengrizzliesHalftimeO,10);

  var ohiobobcatsUnder = parseFloat(ohiobobcatsO, 10);
  var ohiobobcatsSoloUnder = parseFloat(ohiobobcatsSoloO,10);
  var ohiobobcatsHalftimeUnder = parseFloat(ohiobobcatsHalftimeO,10);

  var ohiostatebuckeyesUnder = parseFloat(ohiostatebuckeyesO, 10);
  var ohiostatebuckeyesSoloUnder = parseFloat(ohiostatebuckeyesSoloO,10);
  var ohiostatebuckeyesHalftimeUnder = parseFloat(ohiostatebuckeyesHalftimeO,10);

  var oklahomasoonersUnder = parseFloat(oklahomasoonersO, 10);
  var oklahomasoonersSoloUnder = parseFloat(oklahomasoonersSoloO,10);
  var oklahomasoonersHalftimeUnder = parseFloat(oklahomasoonersHalftimeO,10);

  var oklahomastatecowboysUnder = parseFloat(oklahomastatecowboysO, 10);
  var oklahomastatecowboysSoloUnder = parseFloat(oklahomastatecowboysSoloO,10);
  var oklahomastatecowboysHalftimeUnder = parseFloat(oklahomastatecowboysHalftimeO,10);

  var olddominionmonarchsUnder = parseFloat(olddominionmonarchsO, 10);
  var olddominionmonarchsSoloUnder = parseFloat(olddominionmonarchsSoloO,10);
  var olddominionmonarchsHalftimeUnder = parseFloat(olddominionmonarchsHalftimeO,10);

  var oralrobertsgoldeneaglesUnder = parseFloat(oralrobertsgoldeneaglesO, 10);
  var oralrobertsgoldeneaglesSoloUnder = parseFloat(oralrobertsgoldeneaglesSoloO,10);
  var oralrobertsgoldeneaglesHalftimeUnder = parseFloat(oralrobertsgoldeneaglesHalftimeO,10);

  var oregonducksUnder = parseFloat(oregonducksO, 10);
  var oregonducksSoloUnder = parseFloat(oregonducksSoloO,10);
  var oregonducksHalftimeUnder = parseFloat(oregonducksHalftimeO,10);

  var oregonstatebeaversUnder = parseFloat(oregonstatebeaversO, 10);
  var oregonstatebeaversSoloUnder = parseFloat(oregonstatebeaversSoloO,10);
  var oregonstatebeaversHalftimeUnder = parseFloat(oregonstatebeaversHalftimeO,10);

  var pacifictigersUnder = parseFloat(pacifictigersO, 10);
  var pacifictigersSoloUnder = parseFloat(pacifictigersSoloO,10);
  var pacifictigersHalftimeUnder = parseFloat(pacifictigersHalftimeO,10);

  var pennsylvaniaquakersUnder = parseFloat(pennsylvaniaquakersO, 10);
  var pennsylvaniaquakersSoloUnder = parseFloat(pennsylvaniaquakersSoloO,10);
  var pennsylvaniaquakersHalftimeUnder = parseFloat(pennsylvaniaquakersHalftimeO,10);

  var pennstatenittanylionsUnder = parseFloat(pennstatenittanylionsO, 10);
  var pennstatenittanylionsSoloUnder = parseFloat(pennstatenittanylionsSoloO,10);
  var pennstatenittanylionsHalftimeUnder = parseFloat(pennstatenittanylionsHalftimeO,10);

  var pepperdinewavesUnder = parseFloat(pepperdinewavesO, 10);
  var pepperdinewavesSoloUnder = parseFloat(pepperdinewavesSoloO,10);
  var pepperdinewavesHalftimeUnder = parseFloat(pepperdinewavesHalftimeO,10);

  var pittsburghpanthersUnder = parseFloat(pittsburghpanthersO, 10);
  var pittsburghpanthersSoloUnder = parseFloat(pittsburghpanthersSoloO,10);
  var pittsburghpanthersHalftimeUnder = parseFloat(pittsburghpanthersHalftimeO,10);

  var portlandpilotsUnder = parseFloat(portlandpilotsO, 10);
  var portlandpilotsSoloUnder = parseFloat(portlandpilotsSoloO,10);
  var portlandpilotsHalftimeUnder = parseFloat(portlandpilotsHalftimeO,10);

  var portlandstatevikingsUnder = parseFloat(portlandstatevikingsO, 10);
  var portlandstatevikingsSoloUnder = parseFloat(portlandstatevikingsSoloO,10);
  var portlandstatevikingsHalftimeUnder = parseFloat(portlandstatevikingsHalftimeO,10);

  var prairieviewaandmpanthersUnder = parseFloat(prairieviewaandmpanthersO, 10);
  var prairieviewaandmpanthersSoloUnder = parseFloat(prairieviewaandmpanthersSoloO,10);
  var prairieviewaandmpanthersHalftimeUnder = parseFloat(prairieviewaandmpanthersHalftimeO,10);

  var presbyterianbluehoseUnder = parseFloat(presbyterianbluehoseO, 10);
  var presbyterianbluehoseSoloUnder = parseFloat(presbyterianbluehoseSoloO,10);
  var presbyterianbluehoseHalftimeUnder = parseFloat(presbyterianbluehoseHalftimeO,10);

  var princetontigersUnder = parseFloat(princetontigersO, 10);
  var princetontigersSoloUnder = parseFloat(princetontigersSoloO,10);
  var princetontigersHalftimeUnder = parseFloat(princetontigersHalftimeO,10);

  var providencefriarsUnder = parseFloat(providencefriarsO, 10);
  var providencefriarsSoloUnder = parseFloat(providencefriarsSoloO,10);
  var providencefriarsHalftimeUnder = parseFloat(providencefriarsHalftimeO,10);

  var purdueboilermakersUnder = parseFloat(purdueboilermakersO, 10);
  var purdueboilermakersSoloUnder = parseFloat(purdueboilermakersSoloO,10);
  var purdueboilermakersHalftimeUnder = parseFloat(purdueboilermakersHalftimeO,10);

  var purduefortwaynemastodonsUnder = parseFloat(purduefortwaynemastodonsO, 10);
  var purduefortwaynemastodonsSoloUnder = parseFloat(purduefortwaynemastodonsSoloO,10);
  var purduefortwaynemastodonsHalftimeUnder = parseFloat(purduefortwaynemastodonsHalftimeO,10);

  var quinnipiacbobcatsUnder = parseFloat(quinnipiacbobcatsO, 10);
  var quinnipiacbobcatsSoloUnder = parseFloat(quinnipiacbobcatsSoloO,10);
  var quinnipiacbobcatsHalftimeUnder = parseFloat(quinnipiacbobcatsHalftimeO,10);

  var radfordhighlandersUnder = parseFloat(radfordhighlandersO, 10);
  var radfordhighlandersSoloUnder = parseFloat(radfordhighlandersSoloO,10);
  var radfordhighlandersHalftimeUnder = parseFloat(radfordhighlandersHalftimeO,10);

  var rhodeislandramsUnder = parseFloat(rhodeislandramsO, 10);
  var rhodeislandramsSoloUnder = parseFloat(rhodeislandramsSoloO,10);
  var rhodeislandramsHalftimeUnder = parseFloat(rhodeislandramsHalftimeO,10);

  var riceowlsUnder = parseFloat(riceowlsO, 10);
  var riceowlsSoloUnder = parseFloat(riceowlsSoloO,10);
  var riceowlsHalftimeUnder = parseFloat(riceowlsHalftimeO,10);

  var richmondspidersUnder = parseFloat(richmondspidersO, 10);
  var richmondspidersSoloUnder = parseFloat(richmondspidersSoloO,10);
  var richmondspidersHalftimeUnder = parseFloat(richmondspidersHalftimeO,10);

  var riderbroncsUnder = parseFloat(riderbroncsO, 10);
  var riderbroncsSoloUnder = parseFloat(riderbroncsSoloO,10);
  var riderbroncsHalftimeUnder = parseFloat(riderbroncsHalftimeO,10);

  var robertmorriscolonialsUnder = parseFloat(robertmorriscolonialsO, 10);
  var robertmorriscolonialsSoloUnder = parseFloat(robertmorriscolonialsSoloO,10);
  var robertmorriscolonialsHalftimeUnder = parseFloat(robertmorriscolonialsHalftimeO,10);

  var rutgersscarletknightsUnder = parseFloat(rutgersscarletknightsO, 10);
  var rutgersscarletknightsSoloUnder = parseFloat(rutgersscarletknightsSoloO,10);
  var rutgersscarletknightsHalftimeUnder = parseFloat(rutgersscarletknightsHalftimeO,10);

  var sacredheartpioneersUnder = parseFloat(sacredheartpioneersO, 10);
  var sacredheartpioneersSoloUnder = parseFloat(sacredheartpioneersSoloO,10);
  var sacredheartpioneersHalftimeUnder = parseFloat(sacredheartpioneersHalftimeO,10);

  var stbonaventurebonniesUnder = parseFloat(stbonaventurebonniesO, 10);
  var stbonaventurebonniesSoloUnder = parseFloat(stbonaventurebonniesSoloO,10);
  var stbonaventurebonniesHalftimeUnder = parseFloat(stbonaventurebonniesHalftimeO,10);

  var stfrancisbknterriersUnder = parseFloat(stfrancisbknterriersO, 10);
  var stfrancisbknterriersSoloUnder = parseFloat(stfrancisbknterriersSoloO,10);
  var stfrancisbknterriersHalftimeUnder = parseFloat(stfrancisbknterriersHalftimeO,10);

  var stfrancisparedflashUnder = parseFloat(stfrancisparedflashO, 10);
  var stfrancisparedflashSoloUnder = parseFloat(stfrancisparedflashSoloO,10);
  var stfrancisparedflashHalftimeUnder = parseFloat(stfrancisparedflashHalftimeO,10);

  var stjohnsredstormUnder = parseFloat(stjohnsredstormO, 10);
  var stjohnsredstormSoloUnder = parseFloat(stjohnsredstormSoloO,10);
  var stjohnsredstormHalftimeUnder = parseFloat(stjohnsredstormHalftimeO,10);

  var saintjosephshawksUnder = parseFloat(saintjosephshawksO, 10);
  var saintjosephshawksSoloUnder = parseFloat(saintjosephshawksSoloO,10);
  var saintjosephshawksHalftimeUnder = parseFloat(saintjosephshawksHalftimeO,10);

  var saintlouisbillikensUnder = parseFloat(saintlouisbillikensO, 10);
  var saintlouisbillikensSoloUnder = parseFloat(saintlouisbillikensSoloO,10);
  var saintlouisbillikensHalftimeUnder = parseFloat(saintlouisbillikensHalftimeO,10);

  var saintmarysgaelsUnder = parseFloat(saintmarysgaelsO, 10);
  var saintmarysgaelsSoloUnder = parseFloat(saintmarysgaelsSoloO,10);
  var saintmarysgaelsHalftimeUnder = parseFloat(saintmarysgaelsHalftimeO,10);

  var saintpeterspeacocksUnder = parseFloat(saintpeterspeacocksO, 10);
  var saintpeterspeacocksSoloUnder = parseFloat(saintpeterspeacocksSoloO,10);
  var saintpeterspeacocksHalftimeUnder = parseFloat(saintpeterspeacocksHalftimeO,10);

  var samhoustonbearkatsUnder = parseFloat(samhoustonbearkatsO, 10);
  var samhoustonbearkatsSoloUnder = parseFloat(samhoustonbearkatsSoloO,10);
  var samhoustonbearkatsHalftimeUnder = parseFloat(samhoustonbearkatsHalftimeO,10);

  var samfordbulldogsUnder = parseFloat(samfordbulldogsO, 10);
  var samfordbulldogsSoloUnder = parseFloat(samfordbulldogsSoloO,10);
  var samfordbulldogsHalftimeUnder = parseFloat(samfordbulldogsHalftimeO,10);

  var sandiegotorerosUnder = parseFloat(sandiegotorerosO, 10);
  var sandiegotorerosSoloUnder = parseFloat(sandiegotorerosSoloO,10);
  var sandiegotorerosHalftimeUnder = parseFloat(sandiegotorerosHalftimeO,10);

  var sandiegostateaztecsUnder = parseFloat(sandiegostateaztecsO, 10);
  var sandiegostateaztecsSoloUnder = parseFloat(sandiegostateaztecsSoloO,10);
  var sandiegostateaztecsHalftimeUnder = parseFloat(sandiegostateaztecsHalftimeO,10);

  var sanfranciscodonsUnder = parseFloat(sanfranciscodonsO, 10);
  var sanfranciscodonsSoloUnder = parseFloat(sanfranciscodonsSoloO,10);
  var sanfranciscodonsHalftimeUnder = parseFloat(sanfranciscodonsHalftimeO,10);

  var sanjosestatespartansUnder = parseFloat(sanjosestatespartansO, 10);
  var sanjosestatespartansSoloUnder = parseFloat(sanjosestatespartansSoloO,10);
  var sanjosestatespartansHalftimeUnder = parseFloat(sanjosestatespartansHalftimeO,10);

  var santaclarabroncosUnder = parseFloat(santaclarabroncosO, 10);
  var santaclarabroncosSoloUnder = parseFloat(santaclarabroncosSoloO,10);
  var santaclarabroncosHalftimeUnder = parseFloat(santaclarabroncosHalftimeO,10);

  var seattleredhawksUnder = parseFloat(seattleredhawksO, 10);
  var seattleredhawksSoloUnder = parseFloat(seattleredhawksSoloO,10);
  var seattleredhawksHalftimeUnder = parseFloat(seattleredhawksHalftimeO,10);

  var setonhallpiratesUnder = parseFloat(setonhallpiratesO, 10);
  var setonhallpiratesSoloUnder = parseFloat(setonhallpiratesSoloO,10);
  var setonhallpiratesHalftimeUnder = parseFloat(setonhallpiratesHalftimeO,10);

  var sienasaintsUnder = parseFloat(sienasaintsO, 10);
  var sienasaintsSoloUnder = parseFloat(sienasaintsSoloO,10);
  var sienasaintsHalftimeUnder = parseFloat(sienasaintsHalftimeO,10);

  var southalabamajaguarsUnder = parseFloat(southalabamajaguarsO, 10);
  var southalabamajaguarsSoloUnder = parseFloat(southalabamajaguarsSoloO,10);
  var southalabamajaguarsHalftimeUnder = parseFloat(southalabamajaguarsHalftimeO,10);

  var southcarolinagamecocksUnder = parseFloat(southcarolinagamecocksO, 10);
  var southcarolinagamecocksSoloUnder = parseFloat(southcarolinagamecocksSoloO,10);
  var southcarolinagamecocksHalftimeUnder = parseFloat(southcarolinagamecocksHalftimeO,10);

  var southcarolinastatebulldogsUnder = parseFloat(southcarolinastatebulldogsO, 10);
  var southcarolinastatebulldogsSoloUnder = parseFloat(southcarolinastatebulldogsSoloO,10);
  var southcarolinastatebulldogsHalftimeUnder = parseFloat(southcarolinastatebulldogsHalftimeO,10);

  var southcarolinaupstatespartansUnder = parseFloat(southcarolinaupstatespartansO, 10);
  var southcarolinaupstatespartansSoloUnder = parseFloat(southcarolinaupstatespartansSoloO,10);
  var southcarolinaupstatespartansHalftimeUnder = parseFloat(southcarolinaupstatespartansHalftimeO,10);

  var southdakotacoyotesUnder = parseFloat(southdakotacoyotesO, 10);
  var southdakotacoyotesSoloUnder = parseFloat(southdakotacoyotesSoloO,10);
  var southdakotacoyotesHalftimeUnder = parseFloat(southdakotacoyotesHalftimeO,10);

  var southdakotastatejackrabbitsUnder = parseFloat(southdakotastatejackrabbitsO, 10);
  var southdakotastatejackrabbitsSoloUnder = parseFloat(southdakotastatejackrabbitsSoloO,10);
  var southdakotastatejackrabbitsHalftimeUnder = parseFloat(southdakotastatejackrabbitsHalftimeO,10);

  var southfloridabullsUnder = parseFloat(southfloridabullsO, 10);
  var southfloridabullsSoloUnder = parseFloat(southfloridabullsSoloO,10);
  var southfloridabullsHalftimeUnder = parseFloat(southfloridabullsHalftimeO,10);

  var semissouristredhawksUnder = parseFloat(semissouristredhawksO, 10);
  var semissouristredhawksSoloUnder = parseFloat(semissouristredhawksSoloO,10);
  var semissouristredhawksHalftimeUnder = parseFloat(semissouristredhawksHalftimeO,10);

  var selouisianalionsUnder = parseFloat(selouisianalionsO, 10);
  var selouisianalionsSoloUnder = parseFloat(selouisianalionsSoloO,10);
  var selouisianalionsHalftimeUnder = parseFloat(selouisianalionsHalftimeO,10);

  var southernjaguarsUnder = parseFloat(southernjaguarsO, 10);
  var southernjaguarsSoloUnder = parseFloat(southernjaguarsSoloO,10);
  var southernjaguarsHalftimeUnder = parseFloat(southernjaguarsHalftimeO,10);

  var usctrojansUnder = parseFloat(usctrojansO, 10);
  var usctrojansSoloUnder = parseFloat(usctrojansSoloO,10);
  var usctrojansHalftimeUnder = parseFloat(usctrojansHalftimeO,10);

  var southernillinoissalukisUnder = parseFloat(southernillinoissalukisO, 10);
  var southernillinoissalukisSoloUnder = parseFloat(southernillinoissalukisSoloO,10);
  var southernillinoissalukisHalftimeUnder = parseFloat(southernillinoissalukisHalftimeO,10);

  var siuedwardsvillecougarsUnder = parseFloat(siuedwardsvillecougarsO, 10);
  var siuedwardsvillecougarsSoloUnder = parseFloat(siuedwardsvillecougarsSoloO,10);
  var siuedwardsvillecougarsHalftimeUnder = parseFloat(siuedwardsvillecougarsHalftimeO,10);

  var smumustangsUnder = parseFloat(smumustangsO, 10);
  var smumustangsSoloUnder = parseFloat(smumustangsSoloO,10);
  var smumustangsHalftimeUnder = parseFloat(smumustangsHalftimeO,10);

  var southernmissgoldeneaglesUnder = parseFloat(southernmissgoldeneaglesO, 10);
  var southernmissgoldeneaglesSoloUnder = parseFloat(southernmissgoldeneaglesSoloO,10);
  var southernmissgoldeneaglesHalftimeUnder = parseFloat(southernmissgoldeneaglesHalftimeO,10);

  var southernutahthunderbirdsUnder = parseFloat(southernutahthunderbirdsO, 10);
  var southernutahthunderbirdsSoloUnder = parseFloat(southernutahthunderbirdsSoloO,10);
  var southernutahthunderbirdsHalftimeUnder = parseFloat(southernutahthunderbirdsHalftimeO,10);

  var stanfordcardinalsUnder = parseFloat(stanfordcardinalsO, 10);
  var stanfordcardinalsSoloUnder = parseFloat(stanfordcardinalsSoloO,10);
  var stanfordcardinalsHalftimeUnder = parseFloat(stanfordcardinalsHalftimeO,10);

  var stephenfaustinlumberjacksUnder = parseFloat(stephenfaustinlumberjacksO, 10);
  var stephenfaustinlumberjacksSoloUnder = parseFloat(stephenfaustinlumberjacksSoloO,10);
  var stephenfaustinlumberjacksHalftimeUnder = parseFloat(stephenfaustinlumberjacksHalftimeO,10);

  var stetsonhattersUnder = parseFloat(stetsonhattersO, 10);
  var stetsonhattersSoloUnder = parseFloat(stetsonhattersSoloO,10);
  var stetsonhattersHalftimeUnder = parseFloat(stetsonhattersHalftimeO,10);

  var stonybrookseawolvesUnder = parseFloat(stonybrookseawolvesO, 10);
  var stonybrookseawolvesSoloUnder = parseFloat(stonybrookseawolvesSoloO,10);
  var stonybrookseawolvesHalftimeUnder = parseFloat(stonybrookseawolvesHalftimeO,10);

  var syracuseorangeUnder = parseFloat(syracuseorangeO, 10);
  var syracuseorangeSoloUnder = parseFloat(syracuseorangeSoloO,10);
  var syracuseorangeHalftimeUnder = parseFloat(syracuseorangeHalftimeO,10);

  var templeowlsUnder = parseFloat(templeowlsO, 10);
  var templeowlsSoloUnder = parseFloat(templeowlsSoloO,10);
  var templeowlsHalftimeUnder = parseFloat(templeowlsHalftimeO,10);

  var tennesseevolunteersUnder = parseFloat(tennesseevolunteersO, 10);
  var tennesseevolunteersSoloUnder = parseFloat(tennesseevolunteersSoloO,10);
  var tennesseevolunteersHalftimeUnder = parseFloat(tennesseevolunteersHalftimeO,10);

  var chattanoogamocsUnder = parseFloat(chattanoogamocsO, 10);
  var chattanoogamocsSoloUnder = parseFloat(chattanoogamocsSoloO,10);
  var chattanoogamocsHalftimeUnder = parseFloat(chattanoogamocsHalftimeO,10);

  var utmartinskyhawksUnder = parseFloat(utmartinskyhawksO, 10);
  var utmartinskyhawksSoloUnder = parseFloat(utmartinskyhawksSoloO,10);
  var utmartinskyhawksHalftimeUnder = parseFloat(utmartinskyhawksHalftimeO,10);

  var tennesseestatetigersUnder = parseFloat(tennesseestatetigersO, 10);
  var tennesseestatetigersSoloUnder = parseFloat(tennesseestatetigersSoloO,10);
  var tennesseestatetigersHalftimeUnder = parseFloat(tennesseestatetigersHalftimeO,10);

  var tennesseetechgoldeneaglesUnder = parseFloat(tennesseetechgoldeneaglesO, 10);
  var tennesseetechgoldeneaglesSoloUnder = parseFloat(tennesseetechgoldeneaglesSoloO,10);
  var tennesseetechgoldeneaglesHalftimeUnder = parseFloat(tennesseetechgoldeneaglesHalftimeO,10);

  var texasaandmaggiesUnder = parseFloat(texasaandmaggiesO, 10);
  var texasaandmaggiesSoloUnder = parseFloat(texasaandmaggiesSoloO,10);
  var texasaandmaggiesHalftimeUnder = parseFloat(texasaandmaggiesHalftimeO,10);

  var texasaandmccislandersUnder = parseFloat(texasaandmccislandersO, 10);
  var texasaandmccislandersSoloUnder = parseFloat(texasaandmccislandersSoloO,10);
  var texasaandmccislandersHalftimeUnder = parseFloat(texasaandmccislandersHalftimeO,10);

  var utarlingtonmavericksUnder = parseFloat(utarlingtonmavericksO, 10);
  var utarlingtonmavericksSoloUnder = parseFloat(utarlingtonmavericksSoloO,10);
  var utarlingtonmavericksHalftimeUnder = parseFloat(utarlingtonmavericksHalftimeO,10);

  var texaslonghornsUnder = parseFloat(texaslonghornsO, 10);
  var texaslonghornsSoloUnder = parseFloat(texaslonghornsSoloO,10);
  var texaslonghornsHalftimeUnder = parseFloat(texaslonghornsHalftimeO,10);

  var tcuhornedfrogsUnder = parseFloat(tcuhornedfrogsO, 10);
  var tcuhornedfrogsSoloUnder = parseFloat(tcuhornedfrogsSoloO,10);
  var tcuhornedfrogsHalftimeUnder = parseFloat(tcuhornedfrogsHalftimeO,10);

  var utepminersUnder = parseFloat(utepminersO, 10);
  var utepminersSoloUnder = parseFloat(utepminersSoloO,10);
  var utepminersHalftimeUnder = parseFloat(utepminersHalftimeO,10);

  var utriograndevalleyvaquerosUnder = parseFloat(utriograndevalleyvaquerosO, 10);
  var utriograndevalleyvaquerosSoloUnder = parseFloat(utriograndevalleyvaquerosSoloO,10);
  var utriograndevalleyvaquerosHalftimeUnder = parseFloat(utriograndevalleyvaquerosHalftimeO,10);

  var utsaroadrunnersUnder = parseFloat(utsaroadrunnersO, 10);
  var utsaroadrunnersSoloUnder = parseFloat(utsaroadrunnersSoloO,10);
  var utsaroadrunnersHalftimeUnder = parseFloat(utsaroadrunnersHalftimeO,10);

  var texassoutherntigersUnder = parseFloat(texassoutherntigersO, 10);
  var texassoutherntigersSoloUnder = parseFloat(texassoutherntigersSoloO,10);
  var texassoutherntigersHalftimeUnder = parseFloat(texassoutherntigersHalftimeO,10);

  var texasstatebobcatsUnder = parseFloat(texasstatebobcatsO, 10);
  var texasstatebobcatsSoloUnder = parseFloat(texasstatebobcatsSoloO,10);
  var texasstatebobcatsHalftimeUnder = parseFloat(texasstatebobcatsHalftimeO,10);

  var texastechredraidersUnder = parseFloat(texastechredraidersO, 10);
  var texastechredraidersSoloUnder = parseFloat(texastechredraidersSoloO,10);
  var texastechredraidersHalftimeUnder = parseFloat(texastechredraidersHalftimeO,10);

  var toledorocketsUnder = parseFloat(toledorocketsO, 10);
  var toledorocketsSoloUnder = parseFloat(toledorocketsSoloO,10);
  var toledorocketsHalftimeUnder = parseFloat(toledorocketsHalftimeO,10);

  var towsontigersUnder = parseFloat(towsontigersO, 10);
  var towsontigersSoloUnder = parseFloat(towsontigersSoloO,10);
  var towsontigersHalftimeUnder = parseFloat(towsontigersHalftimeO,10);

  var troytrojansUnder = parseFloat(troytrojansO, 10);
  var troytrojansSoloUnder = parseFloat(troytrojansSoloO,10);
  var troytrojansHalftimeUnder = parseFloat(troytrojansHalftimeO,10);

  var tulanegreenwaveUnder = parseFloat(tulanegreenwaveO, 10);
  var tulanegreenwaveSoloUnder = parseFloat(tulanegreenwaveSoloO,10);
  var tulanegreenwaveHalftimeUnder = parseFloat(tulanegreenwaveHalftimeO,10);

  var tulsagoldenhurricaneUnder = parseFloat(tulsagoldenhurricaneO, 10);
  var tulsagoldenhurricaneSoloUnder = parseFloat(tulsagoldenhurricaneSoloO,10);
  var tulsagoldenhurricaneHalftimeUnder = parseFloat(tulsagoldenhurricaneHalftimeO,10);

  var airforcefalconsUnder = parseFloat(airforcefalconsO, 10);
  var airforcefalconsSoloUnder = parseFloat(airforcefalconsSoloO,10);
  var airforcefalconsHalftimeUnder = parseFloat(airforcefalconsHalftimeO,10);

  var armyblackknightsUnder = parseFloat(armyblackknightsO, 10);
  var armyblackknightsSoloUnder = parseFloat(armyblackknightsSoloO,10);
  var armyblackknightsHalftimeUnder = parseFloat(armyblackknightsHalftimeO,10);

  var navymidshipmenUnder = parseFloat(navymidshipmenO, 10);
  var navymidshipmenSoloUnder = parseFloat(navymidshipmenSoloO,10);
  var navymidshipmenHalftimeUnder = parseFloat(navymidshipmenHalftimeO,10);

  var utahutesUnder = parseFloat(utahutesO, 10);
  var utahutesSoloUnder = parseFloat(utahutesSoloO,10);
  var utahutesHalftimeUnder = parseFloat(utahutesHalftimeO,10);

  var utahstateaggiesUnder = parseFloat(utahstateaggiesO, 10);
  var utahstateaggiesSoloUnder = parseFloat(utahstateaggiesSoloO,10);
  var utahstateaggiesHalftimeUnder = parseFloat(utahstateaggiesHalftimeO,10);

  var utahvalleywolverinesUnder = parseFloat(utahvalleywolverinesO, 10);
  var utahvalleywolverinesSoloUnder = parseFloat(utahvalleywolverinesSoloO,10);
  var utahvalleywolverinesHalftimeUnder = parseFloat(utahvalleywolverinesHalftimeO,10);

  var valparaisocrusadersUnder = parseFloat(valparaisocrusadersO, 10);
  var valparaisocrusadersSoloUnder = parseFloat(valparaisocrusadersSoloO,10);
  var valparaisocrusadersHalftimeUnder = parseFloat(valparaisocrusadersHalftimeO,10);

  var vanderbiltcommodoresUnder = parseFloat(vanderbiltcommodoresO, 10);
  var vanderbiltcommodoresSoloUnder = parseFloat(vanderbiltcommodoresSoloO,10);
  var vanderbiltcommodoresHalftimeUnder = parseFloat(vanderbiltcommodoresHalftimeO,10);

  var vermontcatamountsUnder = parseFloat(vermontcatamountsO, 10);
  var vermontcatamountsSoloUnder = parseFloat(vermontcatamountsSoloO,10);
  var vermontcatamountsHalftimeUnder = parseFloat(vermontcatamountsHalftimeO,10);

  var villanovawildcatsUnder = parseFloat(villanovawildcatsO, 10);
  var villanovawildcatsSoloUnder = parseFloat(villanovawildcatsSoloO,10);
  var villanovawildcatsHalftimeUnder = parseFloat(villanovawildcatsHalftimeO,10);

  var virginiacavaliersUnder = parseFloat(virginiacavaliersO, 10);
  var virginiacavaliersSoloUnder = parseFloat(virginiacavaliersSoloO,10);
  var virginiacavaliersHalftimeUnder = parseFloat(virginiacavaliersHalftimeO,10);

  var vcuramsUnder = parseFloat(vcuramsO, 10);
  var vcuramsSoloUnder = parseFloat(vcuramsSoloO,10);
  var vcuramsHalftimeUnder = parseFloat(vcuramsHalftimeO,10);

  var vmikeydetsUnder = parseFloat(vmikeydetsO, 10);
  var vmikeydetsSoloUnder = parseFloat(vmikeydetsSoloO,10);
  var vmikeydetsHalftimeUnder = parseFloat(vmikeydetsHalftimeO,10);

  var virginiatechhokiesUnder = parseFloat(virginiatechhokiesO, 10);
  var virginiatechhokiesSoloUnder = parseFloat(virginiatechhokiesSoloO,10);
  var virginiatechhokiesHalftimeUnder = parseFloat(virginiatechhokiesHalftimeO,10);

  var wagnerseahawksUnder = parseFloat(wagnerseahawksO, 10);
  var wagnerseahawksSoloUnder = parseFloat(wagnerseahawksSoloO,10);
  var wagnerseahawksHalftimeUnder = parseFloat(wagnerseahawksHalftimeO,10);

  var wakeforestdemondeaconsUnder = parseFloat(wakeforestdemondeaconsO, 10);
  var wakeforestdemondeaconsSoloUnder = parseFloat(wakeforestdemondeaconsSoloO,10);
  var wakeforestdemondeaconsHalftimeUnder = parseFloat(wakeforestdemondeaconsHalftimeO,10);

  var washingtonhuskiesUnder = parseFloat(washingtonhuskiesO, 10);
  var washingtonhuskiesSoloUnder = parseFloat(washingtonhuskiesSoloO,10);
  var washingtonhuskiesHalftimeUnder = parseFloat(washingtonhuskiesHalftimeO,10);

  var washingtonstatecougarsUnder = parseFloat(washingtonstatecougarsO, 10);
  var washingtonstatecougarsSoloUnder = parseFloat(washingtonstatecougarsSoloO,10);
  var washingtonstatecougarsHalftimeUnder = parseFloat(washingtonstatecougarsHalftimeO,10);

  var weberstatewildcatsUnder = parseFloat(weberstatewildcatsO, 10);
  var weberstatewildcatsSoloUnder = parseFloat(weberstatewildcatsSoloO,10);
  var weberstatewildcatsHalftimeUnder = parseFloat(weberstatewildcatsHalftimeO,10);

  var westvirginiamountaineersUnder = parseFloat(westvirginiamountaineersO, 10);
  var westvirginiamountaineersSoloUnder = parseFloat(westvirginiamountaineersSoloO,10);
  var westvirginiamountaineersHalftimeUnder = parseFloat(westvirginiamountaineersHalftimeO,10);

  var westerncarolinacatamountsUnder = parseFloat(westerncarolinacatamountsO, 10);
  var westerncarolinacatamountsSoloUnder = parseFloat(westerncarolinacatamountsSoloO,10);
  var westerncarolinacatamountsHalftimeUnder = parseFloat(westerncarolinacatamountsHalftimeO,10);

  var westernillinoisleathernecksUnder = parseFloat(westernillinoisleathernecksO, 10);
  var westernillinoisleathernecksSoloUnder = parseFloat(westernillinoisleathernecksSoloO,10);
  var westernillinoisleathernecksHalftimeUnder = parseFloat(westernillinoisleathernecksHalftimeO,10);

  var westernkentuckyhilltoppersUnder = parseFloat(westernkentuckyhilltoppersO, 10);
  var westernkentuckyhilltoppersSoloUnder = parseFloat(westernkentuckyhilltoppersSoloO,10);
  var westernkentuckyhilltoppersHalftimeUnder = parseFloat(westernkentuckyhilltoppersHalftimeO,10);

  var westernmichiganbroncosUnder = parseFloat(westernmichiganbroncosO, 10);
  var westernmichiganbroncosSoloUnder = parseFloat(westernmichiganbroncosSoloO,10);
  var westernmichiganbroncosHalftimeUnder = parseFloat(westernmichiganbroncosHalftimeO,10);

  var wichitastateshockersUnder = parseFloat(wichitastateshockersO, 10);
  var wichitastateshockersSoloUnder = parseFloat(wichitastateshockersSoloO,10);
  var wichitastateshockersHalftimeUnder = parseFloat(wichitastateshockersHalftimeO,10);

  var williamandmarytribeUnder = parseFloat(williamandmarytribeO, 10);
  var williamandmarytribeSoloUnder = parseFloat(williamandmarytribeSoloO,10);
  var williamandmarytribeHalftimeUnder = parseFloat(williamandmarytribeHalftimeO,10);

  var winthropeaglesUnder = parseFloat(winthropeaglesO, 10);
  var winthropeaglesSoloUnder = parseFloat(winthropeaglesSoloO,10);
  var winthropeaglesHalftimeUnder = parseFloat(winthropeaglesHalftimeO,10);

  var greenbayphoenixUnder = parseFloat(greenbayphoenixO, 10);
  var greenbayphoenixSoloUnder = parseFloat(greenbayphoenixSoloO,10);
  var greenbayphoenixHalftimeUnder = parseFloat(greenbayphoenixHalftimeO,10);

  var wisconsinbadgersUnder = parseFloat(wisconsinbadgersO, 10);
  var wisconsinbadgersSoloUnder = parseFloat(wisconsinbadgersSoloO,10);
  var wisconsinbadgersHalftimeUnder = parseFloat(wisconsinbadgersHalftimeO,10);

  var milwaukeepanthersUnder = parseFloat(milwaukeepanthersO, 10);
  var milwaukeepanthersSoloUnder = parseFloat(milwaukeepanthersSoloO,10);
  var milwaukeepanthersHalftimeUnder = parseFloat(milwaukeepanthersHalftimeO,10);

  var woffordterriersUnder = parseFloat(woffordterriersO, 10);
  var woffordterriersSoloUnder = parseFloat(woffordterriersSoloO,10);
  var woffordterriersHalftimeUnder = parseFloat(woffordterriersHalftimeO,10);

  var wrightstateraidersUnder = parseFloat(wrightstateraidersO, 10);
  var wrightstateraidersSoloUnder = parseFloat(wrightstateraidersSoloO,10);
  var wrightstateraidersHalftimeUnder = parseFloat(wrightstateraidersHalftimeO,10);

  var wyomingcowboysUnder = parseFloat(wyomingcowboysO, 10);
  var wyomingcowboysSoloUnder = parseFloat(wyomingcowboysSoloO,10);
  var wyomingcowboysHalftimeUnder = parseFloat(wyomingcowboysHalftimeO,10);

  var xaviermusketeersUnder = parseFloat(xaviermusketeersO, 10);
  var xaviermusketeersSoloUnder = parseFloat(xaviermusketeersSoloO,10);
  var xaviermusketeersHalftimeUnder = parseFloat(xaviermusketeersHalftimeO,10);

  var yalebulldogsUnder = parseFloat(yalebulldogsO, 10);
  var yalebulldogsSoloUnder = parseFloat(yalebulldogsSoloO,10);
  var yalebulldogsHalftimeUnder = parseFloat(yalebulldogsHalftimeO,10);

  var youngstownstpenguinsUnder = parseFloat(youngstownstpenguinsO, 10);
  var youngstownstpenguinsSoloUnder = parseFloat(youngstownstpenguinsSoloO,10);
  var youngstownstpenguinsHalftimeUnder = parseFloat(youngstownstpenguinsHalftimeO,10);


  // Turn the over into under by subtracting by 100

  var abilenechristianwildcatsU = 100 - abilenechristianwildcatsUnder;
  var abilenechristianwildcatsSoloU = 100 - abilenechristianwildcatsSoloUnder;
  var abilenechristianwildcatsHalftimeU = 100 - abilenechristianwildcatsHalftimeUnder;

  var akronzipsU = 100 - akronzipsUnder;
  var akronzipsSoloU = 100 - akronzipsSoloUnder;
  var akronzipsHalftimeU = 100 - akronzipsHalftimeUnder;

  var alabamacrimsontideU = 100 - alabamacrimsontideUnder;
  var alabamacrimsontideSoloU = 100 - alabamacrimsontideSoloUnder;
  var alabamacrimsontideHalftimeU = 100 - alabamacrimsontideHalftimeUnder;

  var alabamaaandmbulldogsU = 100 - alabamaaandmbulldogsUnder;
  var alabamaaandmbulldogsSoloU = 100 - alabamaaandmbulldogsSoloUnder;
  var alabamaaandmbulldogsHalftimeU = 100 - alabamaaandmbulldogsHalftimeUnder;

  var uabblazersU = 100 - uabblazersUnder;
  var uabblazersSoloU = 100 - uabblazersSoloUnder;
  var uabblazersHalftimeU = 100 - uabblazersHalftimeUnder;

  var alabamastatehornetsU = 100 - alabamastatehornetsUnder;
  var alabamastatehornetsSoloU = 100 - alabamastatehornetsSoloUnder;
  var alabamastatehornetsHalftimeU = 100 - alabamastatehornetsHalftimeUnder;

  var albanygreatdanesU = 100 - albanygreatdanesUnder;
  var albanygreatdanesSoloU = 100 - albanygreatdanesSoloUnder;
  var albanygreatdanesHalftimeU = 100 - albanygreatdanesHalftimeUnder;

  var alcornstatebravesU = 100 - alcornstatebravesUnder;
  var alcornstatebravesSoloU = 100 - alcornstatebravesSoloUnder;
  var alcornstatebravesHalftimeU = 100 - alcornstatebravesHalftimeUnder;

  var americaneaglesU = 100 - americaneaglesUnder;
  var americaneaglesSoloU = 100 - americaneaglesSoloUnder;
  var americaneaglesHalftimeU = 100 - americaneaglesHalftimeUnder;

  var appalachianstatemountaineersU = 100 - appalachianstatemountaineersUnder;
  var appalachianstatemountaineersSoloU = 100 - appalachianstatemountaineersSoloUnder;
  var appalachianstatemountaineersHalftimeU = 100 - appalachianstatemountaineersHalftimeUnder;

  var arizonawildcatsU = 100 - arizonawildcatsUnder;
  var arizonawildcatsSoloU = 100 - arizonawildcatsSoloUnder;
  var arizonawildcatsHalftimeU = 100 - arizonawildcatsHalftimeUnder;

  var arizonastatesundevilsU = 100 - arizonastatesundevilsUnder;
  var arizonastatesundevilsSoloU = 100 - arizonastatesundevilsSoloUnder;
  var arizonastatesundevilsHalftimeU = 100 - arizonastatesundevilsHalftimeUnder;

  var arkansasrazorbacksU = 100 - arkansasrazorbacksUnder;
  var arkansasrazorbacksSoloU = 100 - arkansasrazorbacksSoloUnder;
  var arkansasrazorbacksHalftimeU = 100 - arkansasrazorbacksHalftimeUnder;

  var littlerocktrojansU = 100 - littlerocktrojansUnder;
  var littlerocktrojansSoloU = 100 - littlerocktrojansSoloUnder;
  var littlerocktrojansHalftimeU = 100 - littlerocktrojansHalftimeUnder;

  var arkansaspinebluffgoldenlionsU = 100 - arkansaspinebluffgoldenlionsUnder;
  var arkansaspinebluffgoldenlionsSoloU = 100 - arkansaspinebluffgoldenlionsSoloUnder;
  var arkansaspinebluffgoldenlionsHalftimeU = 100 - arkansaspinebluffgoldenlionsHalftimeUnder;

  var arkansasstredwolvesU = 100 - arkansasstredwolvesUnder;
  var arkansasstredwolvesSoloU = 100 - arkansasstredwolvesSoloUnder;
  var arkansasstredwolvesHalftimeU = 100 - arkansasstredwolvesHalftimeUnder;

  var auburntigersU = 100 - auburntigersUnder;
  var auburntigersSoloU = 100 - auburntigersSoloUnder;
  var auburntigersHalftimeU = 100 - auburntigersHalftimeUnder;

  var austinpeaygovernorsU = 100 - austinpeaygovernorsUnder;
  var austinpeaygovernorsSoloU = 100 - austinpeaygovernorsSoloUnder;
  var austinpeaygovernorsHalftimeU = 100 - austinpeaygovernorsHalftimeUnder;

  var ballstatecardinalsU = 100 - ballstatecardinalsUnder;
  var ballstatecardinalsSoloU = 100 - ballstatecardinalsSoloUnder;
  var ballstatecardinalsHalftimeU = 100 - ballstatecardinalsHalftimeUnder;

  var baylorbearsU = 100 - baylorbearsUnder;
  var baylorbearsSoloU = 100 - baylorbearsSoloUnder;
  var baylorbearsHalftimeU = 100 - baylorbearsHalftimeUnder;

  var belmontbruinsU = 100 - belmontbruinsUnder;
  var belmontbruinsSoloU = 100 - belmontbruinsSoloUnder;
  var belmontbruinsHalftimeU = 100 - belmontbruinsHalftimeUnder;

  var bethunecookmanwildcatsU = 100 - bethunecookmanwildcatsUnder;
  var bethunecookmanwildcatsSoloU = 100 - bethunecookmanwildcatsSoloUnder;
  var bethunecookmanwildcatsHalftimeU = 100 - bethunecookmanwildcatsHalftimeUnder;

  var binghamtonbearcatsU = 100 - binghamtonbearcatsUnder;
  var binghamtonbearcatsSoloU = 100 - binghamtonbearcatsSoloUnder;
  var binghamtonbearcatsHalftimeU = 100 - binghamtonbearcatsHalftimeUnder;

  var boisestatebroncosU = 100 - boisestatebroncosUnder;
  var boisestatebroncosSoloU = 100 - boisestatebroncosSoloUnder;
  var boisestatebroncosHalftimeU = 100 - boisestatebroncosHalftimeUnder;

  var bostoncollegeeaglesU = 100 - bostoncollegeeaglesUnder;
  var bostoncollegeeaglesSoloU = 100 - bostoncollegeeaglesSoloUnder;
  var bostoncollegeeaglesHalftimeU = 100 - bostoncollegeeaglesHalftimeUnder;

  var bostonunivterriersU = 100 - bostonunivterriersUnder;
  var bostonunivterriersSoloU = 100 - bostonunivterriersSoloUnder;
  var bostonunivterriersHalftimeU = 100 - bostonunivterriersHalftimeUnder;

  var bowlinggreenfalconsU = 100 - bowlinggreenfalconsUnder;
  var bowlinggreenfalconsSoloU = 100 - bowlinggreenfalconsSoloUnder;
  var bowlinggreenfalconsHalftimeU = 100 - bowlinggreenfalconsHalftimeUnder;

  var bradleybravesU = 100 - bradleybravesUnder;
  var bradleybravesSoloU = 100 - bradleybravesSoloUnder;
  var bradleybravesHalftimeU = 100 - bradleybravesHalftimeUnder;

  var byucougarsU = 100 - byucougarsUnder;
  var byucougarsSoloU = 100 - byucougarsSoloUnder;
  var byucougarsHalftimeU = 100 - byucougarsHalftimeUnder;

  var brownbearsU = 100 - brownbearsUnder;
  var brownbearsSoloU = 100 - brownbearsSoloUnder;
  var brownbearsHalftimeU = 100 - brownbearsHalftimeUnder;

  var bryantbulldogsU = 100 - bryantbulldogsUnder;
  var bryantbulldogsSoloU = 100 - bryantbulldogsSoloUnder;
  var bryantbulldogsHalftimeU = 100 - bryantbulldogsHalftimeUnder;

  var bucknellbisonU = 100 - bucknellbisonUnder;
  var bucknellbisonSoloU = 100 - bucknellbisonSoloUnder;
  var bucknellbisonHalftimeU = 100 - bucknellbisonHalftimeUnder;

  var buffalobullsU = 100 - buffalobullsUnder;
  var buffalobullsSoloU = 100 - buffalobullsSoloUnder;
  var buffalobullsHalftimeU = 100 - buffalobullsHalftimeUnder;

  var butlerbulldogsU = 100 - butlerbulldogsUnder;
  var butlerbulldogsSoloU = 100 - butlerbulldogsSoloUnder;
  var butlerbulldogsHalftimeU = 100 - butlerbulldogsHalftimeUnder;

  var californiagoldenbearsU = 100 - californiagoldenbearsUnder;
  var californiagoldenbearsSoloU = 100 - californiagoldenbearsSoloUnder;
  var californiagoldenbearsHalftimeU = 100 - californiagoldenbearsHalftimeUnder;

  var ucdavisaggiesU = 100 - ucdavisaggiesUnder;
  var ucdavisaggiesSoloU = 100 - ucdavisaggiesSoloUnder;
  var ucdavisaggiesHalftimeU = 100 - ucdavisaggiesHalftimeUnder;

  var ucirvineanteatersU = 100 - ucirvineanteatersUnder;
  var ucirvineanteatersSoloU = 100 - ucirvineanteatersSoloUnder;
  var ucirvineanteatersHalftimeU = 100 - ucirvineanteatersHalftimeUnder;

  var uclabruinsU = 100 - uclabruinsUnder;
  var uclabruinsSoloU = 100 - uclabruinsSoloUnder;
  var uclabruinsHalftimeU = 100 - uclabruinsHalftimeUnder;

  var calpolymustangsU = 100 - calpolymustangsUnder;
  var calpolymustangsSoloU = 100 - calpolymustangsSoloUnder;
  var calpolymustangsHalftimeU = 100 - calpolymustangsHalftimeUnder;

  var ucriversidehighlandersU = 100 - ucriversidehighlandersUnder;
  var ucriversidehighlandersSoloU = 100 - ucriversidehighlandersSoloUnder;
  var ucriversidehighlandersHalftimeU = 100 - ucriversidehighlandersHalftimeUnder;

  var ucsantabarbaragauchosU = 100 - ucsantabarbaragauchosUnder;
  var ucsantabarbaragauchosSoloU = 100 - ucsantabarbaragauchosSoloUnder;
  var ucsantabarbaragauchosHalftimeU = 100 - ucsantabarbaragauchosHalftimeUnder;

  var csubakersfieldroadrunnersU = 100 - csubakersfieldroadrunnersUnder;
  var csubakersfieldroadrunnersSoloU = 100 - csubakersfieldroadrunnersSoloUnder;
  var csubakersfieldroadrunnersHalftimeU = 100 - csubakersfieldroadrunnersHalftimeUnder;

  var fresnostatebulldogsU = 100 - fresnostatebulldogsUnder;
  var fresnostatebulldogsSoloU = 100 - fresnostatebulldogsSoloUnder;
  var fresnostatebulldogsHalftimeU = 100 - fresnostatebulldogsHalftimeUnder;

  var csufullertontitansU = 100 - csufullertontitansUnder;
  var csufullertontitansSoloU = 100 - csufullertontitansSoloUnder;
  var csufullertontitansHalftimeU = 100 - csufullertontitansHalftimeUnder;

  var longbeachstate49ersU = 100 - longbeachstate49ersUnder;
  var longbeachstate49ersSoloU = 100 - longbeachstate49ersSoloUnder;
  var longbeachstate49ersHalftimeU = 100 - longbeachstate49ersHalftimeUnder;

  var csunorthridgematadorsU = 100 - csunorthridgematadorsUnder;
  var csunorthridgematadorsSoloU = 100 - csunorthridgematadorsSoloUnder;
  var csunorthridgematadorsHalftimeU = 100 - csunorthridgematadorsHalftimeUnder;

  var sacramentostatehornetsU = 100 - sacramentostatehornetsUnder;
  var sacramentostatehornetsSoloU = 100 - sacramentostatehornetsSoloUnder;
  var sacramentostatehornetsHalftimeU = 100 - sacramentostatehornetsHalftimeUnder;

  var campbellfightingcamelsU = 100 - campbellfightingcamelsUnder;
  var campbellfightingcamelsSoloU = 100 - campbellfightingcamelsSoloUnder;
  var campbellfightingcamelsHalftimeU = 100 - campbellfightingcamelsHalftimeUnder;

  var canisiusgoldengriffinsU = 100 - canisiusgoldengriffinsUnder;
  var canisiusgoldengriffinsSoloU = 100 - canisiusgoldengriffinsSoloUnder;
  var canisiusgoldengriffinsHalftimeU = 100 - canisiusgoldengriffinsHalftimeUnder;

  var centralarkansasbearsU = 100 - centralarkansasbearsUnder;
  var centralarkansasbearsSoloU = 100 - centralarkansasbearsSoloUnder;
  var centralarkansasbearsHalftimeU = 100 - centralarkansasbearsHalftimeUnder;

  var centralconnecticutbluedevilsU = 100 - centralconnecticutbluedevilsUnder;
  var centralconnecticutbluedevilsSoloU = 100 - centralconnecticutbluedevilsSoloUnder;
  var centralconnecticutbluedevilsHalftimeU = 100 - centralconnecticutbluedevilsHalftimeUnder;

  var ucfknightsU = 100 - ucfknightsUnder;
  var ucfknightsSoloU = 100 - ucfknightsSoloUnder;
  var ucfknightsHalftimeU = 100 - ucfknightsHalftimeUnder;

  var centralmichiganchippewasU = 100 - centralmichiganchippewasUnder;
  var centralmichiganchippewasSoloU = 100 - centralmichiganchippewasSoloUnder;
  var centralmichiganchippewasHalftimeU = 100 - centralmichiganchippewasHalftimeUnder;

  var charlestoncougarsU = 100 - charlestoncougarsUnder;
  var charlestoncougarsSoloU = 100 - charlestoncougarsSoloUnder;
  var charlestoncougarsHalftimeU = 100 - charlestoncougarsHalftimeUnder;

  var charlestonsouthernbuccaneersU = 100 - charlestonsouthernbuccaneersUnder;
  var charlestonsouthernbuccaneersSoloU = 100 - charlestonsouthernbuccaneersSoloUnder;
  var charlestonsouthernbuccaneersHalftimeU = 100 - charlestonsouthernbuccaneersHalftimeUnder;

  var chicagostatecougarsU = 100 - chicagostatecougarsUnder;
  var chicagostatecougarsSoloU = 100 - chicagostatecougarsSoloUnder;
  var chicagostatecougarsHalftimeU = 100 - chicagostatecougarsHalftimeUnder;

  var cincinnatibearcatsU = 100 - cincinnatibearcatsUnder;
  var cincinnatibearcatsSoloU = 100 - cincinnatibearcatsSoloUnder;
  var cincinnatibearcatsHalftimeU = 100 - cincinnatibearcatsHalftimeUnder;

  var thecitadelbulldogsU = 100 - thecitadelbulldogsUnder;
  var thecitadelbulldogsSoloU = 100 - thecitadelbulldogsSoloUnder;
  var thecitadelbulldogsHalftimeU = 100 - thecitadelbulldogsHalftimeUnder;

  var clemsontigersU = 100 - clemsontigersUnder;
  var clemsontigersSoloU = 100 - clemsontigersSoloUnder;
  var clemsontigersHalftimeU = 100 - clemsontigersHalftimeUnder;

  var clevelandstatevikingsU = 100 - clevelandstatevikingsUnder;
  var clevelandstatevikingsSoloU = 100 - clevelandstatevikingsSoloUnder;
  var clevelandstatevikingsHalftimeU = 100 - clevelandstatevikingsHalftimeUnder;

  var coastalcarolinachanticleersU = 100 - coastalcarolinachanticleersUnder;
  var coastalcarolinachanticleersSoloU = 100 - coastalcarolinachanticleersSoloUnder;
  var coastalcarolinachanticleersHalftimeU = 100 - coastalcarolinachanticleersHalftimeUnder;

  var colgateraidersU = 100 - colgateraidersUnder;
  var colgateraidersSoloU = 100 - colgateraidersSoloUnder;
  var colgateraidersHalftimeU = 100 - colgateraidersHalftimeUnder;

  var coloradobuffaloesU = 100 - coloradobuffaloesUnder;
  var coloradobuffaloesSoloU = 100 - coloradobuffaloesSoloUnder;
  var coloradobuffaloesHalftimeU = 100 - coloradobuffaloesHalftimeUnder;

  var coloradostateramsU = 100 - coloradostateramsUnder;
  var coloradostateramsSoloU = 100 - coloradostateramsSoloUnder;
  var coloradostateramsHalftimeU = 100 - coloradostateramsHalftimeUnder;

  var columbialionsU = 100 - columbialionsUnder;
  var columbialionsSoloU = 100 - columbialionsSoloUnder;
  var columbialionsHalftimeU = 100 - columbialionsHalftimeUnder;

  var uconnhuskiesU = 100 - uconnhuskiesUnder;
  var uconnhuskiesSoloU = 100 - uconnhuskiesSoloUnder;
  var uconnhuskiesHalftimeU = 100 - uconnhuskiesHalftimeUnder;

  var coppinstateeaglesU = 100 - coppinstateeaglesUnder;
  var coppinstateeaglesSoloU = 100 - coppinstateeaglesSoloUnder;
  var coppinstateeaglesHalftimeU = 100 - coppinstateeaglesHalftimeUnder;

  var cornellbigredU = 100 - cornellbigredUnder;
  var cornellbigredSoloU = 100 - cornellbigredSoloUnder;
  var cornellbigredHalftimeU = 100 - cornellbigredHalftimeUnder;

  var creightonbluejaysU = 100 - creightonbluejaysUnder;
  var creightonbluejaysSoloU = 100 - creightonbluejaysSoloUnder;
  var creightonbluejaysHalftimeU = 100 - creightonbluejaysHalftimeUnder;

  var dartmouthbiggreenU = 100 - dartmouthbiggreenUnder;
  var dartmouthbiggreenSoloU = 100 - dartmouthbiggreenSoloUnder;
  var dartmouthbiggreenHalftimeU = 100 - dartmouthbiggreenHalftimeUnder;

  var davidsonwildcatsU = 100 - davidsonwildcatsUnder;
  var davidsonwildcatsSoloU = 100 - davidsonwildcatsSoloUnder;
  var davidsonwildcatsHalftimeU = 100 - davidsonwildcatsHalftimeUnder;

  var daytonflyersU = 100 - daytonflyersUnder;
  var daytonflyersSoloU = 100 - daytonflyersSoloUnder;
  var daytonflyersHalftimeU = 100 - daytonflyersHalftimeUnder;

  var delawarebluehensU = 100 - delawarebluehensUnder;
  var delawarebluehensSoloU = 100 - delawarebluehensSoloUnder;
  var delawarebluehensHalftimeU = 100 - delawarebluehensHalftimeUnder;

  var delawarestatehornetsU = 100 - delawarestatehornetsUnder;
  var delawarestatehornetsSoloU = 100 - delawarestatehornetsSoloUnder;
  var delawarestatehornetsHalftimeU = 100 - delawarestatehornetsHalftimeUnder;

  var denverpioneersU = 100 - denverpioneersUnder;
  var denverpioneersSoloU = 100 - denverpioneersSoloUnder;
  var denverpioneersHalftimeU = 100 - denverpioneersHalftimeUnder;

  var depaulbluedemonsU = 100 - depaulbluedemonsUnder;
  var depaulbluedemonsSoloU = 100 - depaulbluedemonsSoloUnder;
  var depaulbluedemonsHalftimeU = 100 - depaulbluedemonsHalftimeUnder;

  var detroitmercytitansU = 100 - detroitmercytitansUnder;
  var detroitmercytitansSoloU = 100 - detroitmercytitansSoloUnder;
  var detroitmercytitansHalftimeU = 100 - detroitmercytitansHalftimeUnder;

  var drakebulldogsU = 100 - drakebulldogsUnder;
  var drakebulldogsSoloU = 100 - drakebulldogsSoloUnder;
  var drakebulldogsHalftimeU = 100 - drakebulldogsHalftimeUnder;

  var drexeldragonsU = 100 - drexeldragonsUnder;
  var drexeldragonsSoloU = 100 - drexeldragonsSoloUnder;
  var drexeldragonsHalftimeU = 100 - drexeldragonsHalftimeUnder;

  var dukebluedevilsU = 100 - dukebluedevilsUnder;
  var dukebluedevilsSoloU = 100 - dukebluedevilsSoloUnder;
  var dukebluedevilsHalftimeU = 100 - dukebluedevilsHalftimeUnder;

  var duquesnedukesU = 100 - duquesnedukesUnder;
  var duquesnedukesSoloU = 100 - duquesnedukesSoloUnder;
  var duquesnedukesHalftimeU = 100 - duquesnedukesHalftimeUnder;

  var easttennesseestatebuccaneersU = 100 - easttennesseestatebuccaneersUnder;
  var easttennesseestatebuccaneersSoloU = 100 - easttennesseestatebuccaneersSoloUnder;
  var easttennesseestatebuccaneersHalftimeU = 100 - easttennesseestatebuccaneersHalftimeUnder;

  var easternillinoispanthersU = 100 - easternillinoispanthersUnder;
  var easternillinoispanthersSoloU = 100 - easternillinoispanthersSoloUnder;
  var easternillinoispanthersHalftimeU = 100 - easternillinoispanthersHalftimeUnder;

  var easternkentuckycolonelsU = 100 - easternkentuckycolonelsUnder;
  var easternkentuckycolonelsSoloU = 100 - easternkentuckycolonelsSoloUnder;
  var easternkentuckycolonelsHalftimeU = 100 - easternkentuckycolonelsHalftimeUnder;

  var easternmichiganeaglesU = 100 - easternmichiganeaglesUnder;
  var easternmichiganeaglesSoloU = 100 - easternmichiganeaglesSoloUnder;
  var easternmichiganeaglesHalftimeU = 100 - easternmichiganeaglesHalftimeUnder;

  var elonphoenixU = 100 - elonphoenixUnder;
  var elonphoenixSoloU = 100 - elonphoenixSoloUnder;
  var elonphoenixHalftimeU = 100 - elonphoenixHalftimeUnder;

  var evansvillepurpleacesU = 100 - evansvillepurpleacesUnder;
  var evansvillepurpleacesSoloU = 100 - evansvillepurpleacesSoloUnder;
  var evansvillepurpleacesHalftimeU = 100 - evansvillepurpleacesHalftimeUnder;

  var fairfieldstagsU = 100 - fairfieldstagsUnder;
  var fairfieldstagsSoloU = 100 - fairfieldstagsSoloUnder;
  var fairfieldstagsHalftimeU = 100 - fairfieldstagsHalftimeUnder;

  var fairleighdickinsonknightsU = 100 - fairleighdickinsonknightsUnder;
  var fairleighdickinsonknightsSoloU = 100 - fairleighdickinsonknightsSoloUnder;
  var fairleighdickinsonknightsHalftimeU = 100 - fairleighdickinsonknightsHalftimeUnder;

  var floridagatorsU = 100 - floridagatorsUnder;
  var floridagatorsSoloU = 100 - floridagatorsSoloUnder;
  var floridagatorsHalftimeU = 100 - floridagatorsHalftimeUnder;

  var floridaaandmrattlersU = 100 - floridaaandmrattlersUnder;
  var floridaaandmrattlersSoloU = 100 - floridaaandmrattlersSoloUnder;
  var floridaaandmrattlersHalftimeU = 100 - floridaaandmrattlersHalftimeUnder;

  var floridaatlanticowlsU = 100 - floridaatlanticowlsUnder;
  var floridaatlanticowlsSoloU = 100 - floridaatlanticowlsSoloUnder;
  var floridaatlanticowlsHalftimeU = 100 - floridaatlanticowlsHalftimeUnder;

  var floridagulfcoasteaglesU = 100 - floridagulfcoasteaglesUnder;
  var floridagulfcoasteaglesSoloU = 100 - floridagulfcoasteaglesSoloUnder;
  var floridagulfcoasteaglesHalftimeU = 100 - floridagulfcoasteaglesHalftimeUnder;

  var floridainternationalpanthersU = 100 - floridainternationalpanthersUnder;
  var floridainternationalpanthersSoloU = 100 - floridainternationalpanthersSoloUnder;
  var floridainternationalpanthersHalftimeU = 100 - floridainternationalpanthersHalftimeUnder;

  var floridastateseminolesU = 100 - floridastateseminolesUnder;
  var floridastateseminolesSoloU = 100 - floridastateseminolesSoloUnder;
  var floridastateseminolesHalftimeU = 100 - floridastateseminolesHalftimeUnder;

  var fordhamramsU = 100 - fordhamramsUnder;
  var fordhamramsSoloU = 100 - fordhamramsSoloUnder;
  var fordhamramsHalftimeU = 100 - fordhamramsHalftimeUnder;

  var furmanpaladinsU = 100 - furmanpaladinsUnder;
  var furmanpaladinsSoloU = 100 - furmanpaladinsSoloUnder;
  var furmanpaladinsHalftimeU = 100 - furmanpaladinsHalftimeUnder;

  var gardnerwebbbulldogsU = 100 - gardnerwebbbulldogsUnder;
  var gardnerwebbbulldogsSoloU = 100 - gardnerwebbbulldogsSoloUnder;
  var gardnerwebbbulldogsHalftimeU = 100 - gardnerwebbbulldogsHalftimeUnder;

  var georgemasonpatriotsU = 100 - georgemasonpatriotsUnder;
  var georgemasonpatriotsSoloU = 100 - georgemasonpatriotsSoloUnder;
  var georgemasonpatriotsHalftimeU = 100 - georgemasonpatriotsHalftimeUnder;

  var georgewashingtoncolonialsU = 100 - georgewashingtoncolonialsUnder;
  var georgewashingtoncolonialsSoloU = 100 - georgewashingtoncolonialsSoloUnder;
  var georgewashingtoncolonialsHalftimeU = 100 - georgewashingtoncolonialsHalftimeUnder;

  var georgetownhoyasU = 100 - georgetownhoyasUnder;
  var georgetownhoyasSoloU = 100 - georgetownhoyasSoloUnder;
  var georgetownhoyasHalftimeU = 100 - georgetownhoyasHalftimeUnder;

  var georgiabulldogsU = 100 - georgiabulldogsUnder;
  var georgiabulldogsSoloU = 100 - georgiabulldogsSoloUnder;
  var georgiabulldogsHalftimeU = 100 - georgiabulldogsHalftimeUnder;

  var georgiatechyellowjacketsU = 100 - georgiatechyellowjacketsUnder;
  var georgiatechyellowjacketsSoloU = 100 - georgiatechyellowjacketsSoloUnder;
  var georgiatechyellowjacketsHalftimeU = 100 - georgiatechyellowjacketsHalftimeUnder;

  var georgiasoutherneaglesU = 100 - georgiasoutherneaglesUnder;
  var georgiasoutherneaglesSoloU = 100 - georgiasoutherneaglesSoloUnder;
  var georgiasoutherneaglesHalftimeU = 100 - georgiasoutherneaglesHalftimeUnder;

  var georgiastatepanthersU = 100 - georgiastatepanthersUnder;
  var georgiastatepanthersSoloU = 100 - georgiastatepanthersSoloUnder;
  var georgiastatepanthersHalftimeU = 100 - georgiastatepanthersHalftimeUnder;

  var gonzagabulldogsU = 100 - gonzagabulldogsUnder;
  var gonzagabulldogsSoloU = 100 - gonzagabulldogsSoloUnder;
  var gonzagabulldogsHalftimeU = 100 - gonzagabulldogsHalftimeUnder;

  var gramblingtigersU = 100 - gramblingtigersUnder;
  var gramblingtigersSoloU = 100 - gramblingtigersSoloUnder;
  var gramblingtigersHalftimeU = 100 - gramblingtigersHalftimeUnder;

  var grandcanyonantelopesU = 100 - grandcanyonantelopesUnder;
  var grandcanyonantelopesSoloU = 100 - grandcanyonantelopesSoloUnder;
  var grandcanyonantelopesHalftimeU = 100 - grandcanyonantelopesHalftimeUnder;

  var hamptonpiratesU = 100 - hamptonpiratesUnder;
  var hamptonpiratesSoloU = 100 - hamptonpiratesSoloUnder;
  var hamptonpiratesHalftimeU = 100 - hamptonpiratesHalftimeUnder;

  var hartfordhawksU = 100 - hartfordhawksUnder;
  var hartfordhawksSoloU = 100 - hartfordhawksSoloUnder;
  var hartfordhawksHalftimeU = 100 - hartfordhawksHalftimeUnder;

  var harvardcrimsonU = 100 - harvardcrimsonUnder;
  var harvardcrimsonSoloU = 100 - harvardcrimsonSoloUnder;
  var harvardcrimsonHalftimeU = 100 - harvardcrimsonHalftimeUnder;

  var hawaiirainbowwarriorsU = 100 - hawaiirainbowwarriorsUnder;
  var hawaiirainbowwarriorsSoloU = 100 - hawaiirainbowwarriorsSoloUnder;
  var hawaiirainbowwarriorsHalftimeU = 100 - hawaiirainbowwarriorsHalftimeUnder;

  var highpointpanthersU = 100 - highpointpanthersUnder;
  var highpointpanthersSoloU = 100 - highpointpanthersSoloUnder;
  var highpointpanthersHalftimeU = 100 - highpointpanthersHalftimeUnder;

  var hofstraprideU = 100 - hofstraprideUnder;
  var hofstraprideSoloU = 100 - hofstraprideSoloUnder;
  var hofstraprideHalftimeU = 100 - hofstraprideHalftimeUnder;

  var holycrosscrusadersU = 100 - holycrosscrusadersUnder;
  var holycrosscrusadersSoloU = 100 - holycrosscrusadersSoloUnder;
  var holycrosscrusadersHalftimeU = 100 - holycrosscrusadersHalftimeUnder;

  var houstoncougarsU = 100 - houstoncougarsUnder;
  var houstoncougarsSoloU = 100 - houstoncougarsSoloUnder;
  var houstoncougarsHalftimeU = 100 - houstoncougarsHalftimeUnder;

  var houstonbaptisthuskiesU = 100 - houstonbaptisthuskiesUnder;
  var houstonbaptisthuskiesSoloU = 100 - houstonbaptisthuskiesSoloUnder;
  var houstonbaptisthuskiesHalftimeU = 100 - houstonbaptisthuskiesHalftimeUnder;

  var howardbisonU = 100 - howardbisonUnder;
  var howardbisonSoloU = 100 - howardbisonSoloUnder;
  var howardbisonHalftimeU = 100 - howardbisonHalftimeUnder;

  var idahovandalsU = 100 - idahovandalsUnder;
  var idahovandalsSoloU = 100 - idahovandalsSoloUnder;
  var idahovandalsHalftimeU = 100 - idahovandalsHalftimeUnder;

  var idahostatebengalsU = 100 - idahostatebengalsUnder;
  var idahostatebengalsSoloU = 100 - idahostatebengalsSoloUnder;
  var idahostatebengalsHalftimeU = 100 - idahostatebengalsHalftimeUnder;

  var uicflamesU = 100 - uicflamesUnder;
  var uicflamesSoloU = 100 - uicflamesSoloUnder;
  var uicflamesHalftimeU = 100 - uicflamesHalftimeUnder;

  var illinoisstateredbirdsU = 100 - illinoisstateredbirdsUnder;
  var illinoisstateredbirdsSoloU = 100 - illinoisstateredbirdsSoloUnder;
  var illinoisstateredbirdsHalftimeU = 100 - illinoisstateredbirdsHalftimeUnder;

  var illinoisfightingilliniU = 100 - illinoisfightingilliniUnder;
  var illinoisfightingilliniSoloU = 100 - illinoisfightingilliniSoloUnder;
  var illinoisfightingilliniHalftimeU = 100 - illinoisfightingilliniHalftimeUnder;

  var incarnatewordcardinalsU = 100 - incarnatewordcardinalsUnder;
  var incarnatewordcardinalsSoloU = 100 - incarnatewordcardinalsSoloUnder;
  var incarnatewordcardinalsHalftimeU = 100 - incarnatewordcardinalsHalftimeUnder;

  var indianahoosiersU = 100 - indianahoosiersUnder;
  var indianahoosiersSoloU = 100 - indianahoosiersSoloUnder;
  var indianahoosiersHalftimeU = 100 - indianahoosiersHalftimeUnder;

  var indianastatesycamoresU = 100 - indianastatesycamoresUnder;
  var indianastatesycamoresSoloU = 100 - indianastatesycamoresSoloUnder;
  var indianastatesycamoresHalftimeU = 100 - indianastatesycamoresHalftimeUnder;

  var iupuijaguarsU = 100 - iupuijaguarsUnder;
  var iupuijaguarsSoloU = 100 - iupuijaguarsSoloUnder;
  var iupuijaguarsHalftimeU = 100 - iupuijaguarsHalftimeUnder;

  var ionagaelsU = 100 - ionagaelsUnder;
  var ionagaelsSoloU = 100 - ionagaelsSoloUnder;
  var ionagaelsHalftimeU = 100 - ionagaelsHalftimeUnder;

  var iowahawkeyesU = 100 - iowahawkeyesUnder;
  var iowahawkeyesSoloU = 100 - iowahawkeyesSoloUnder;
  var iowahawkeyesHalftimeU = 100 - iowahawkeyesHalftimeUnder;

  var iowastatecyclonesU = 100 - iowastatecyclonesUnder;
  var iowastatecyclonesSoloU = 100 - iowastatecyclonesSoloUnder;
  var iowastatecyclonesHalftimeU = 100 - iowastatecyclonesHalftimeUnder;

  var jacksonstatetigersU = 100 - jacksonstatetigersUnder;
  var jacksonstatetigersSoloU = 100 - jacksonstatetigersSoloUnder;
  var jacksonstatetigersHalftimeU = 100 - jacksonstatetigersHalftimeUnder;

  var jacksonvilledolphinsU = 100 - jacksonvilledolphinsUnder;
  var jacksonvilledolphinsSoloU = 100 - jacksonvilledolphinsSoloUnder;
  var jacksonvilledolphinsHalftimeU = 100 - jacksonvilledolphinsHalftimeUnder;

  var jacksonvillestategamecocksU = 100 - jacksonvillestategamecocksUnder;
  var jacksonvillestategamecocksSoloU = 100 - jacksonvillestategamecocksSoloUnder;
  var jacksonvillestategamecocksHalftimeU = 100 - jacksonvillestategamecocksHalftimeUnder;

  var jamesmadisondukesU = 100 - jamesmadisondukesUnder;
  var jamesmadisondukesSoloU = 100 - jamesmadisondukesSoloUnder;
  var jamesmadisondukesHalftimeU = 100 - jamesmadisondukesHalftimeUnder;

  var kansasjayhawksU = 100 - kansasjayhawksUnder;
  var kansasjayhawksSoloU = 100 - kansasjayhawksSoloUnder;
  var kansasjayhawksHalftimeU = 100 - kansasjayhawksHalftimeUnder;

  var kansasstatewildcatsU = 100 - kansasstatewildcatsUnder;
  var kansasstatewildcatsSoloU = 100 - kansasstatewildcatsSoloUnder;
  var kansasstatewildcatsHalftimeU = 100 - kansasstatewildcatsHalftimeUnder;

  var kennesawstateowlsU = 100 - kennesawstateowlsUnder;
  var kennesawstateowlsSoloU = 100 - kennesawstateowlsSoloUnder;
  var kennesawstateowlsHalftimeU = 100 - kennesawstateowlsHalftimeUnder;

  var kentstategoldenflashesU = 100 - kentstategoldenflashesUnder;
  var kentstategoldenflashesSoloU = 100 - kentstategoldenflashesSoloUnder;
  var kentstategoldenflashesHalftimeU = 100 - kentstategoldenflashesHalftimeUnder;

  var kentuckywildcatsU = 100 - kentuckywildcatsUnder;
  var kentuckywildcatsSoloU = 100 - kentuckywildcatsSoloUnder;
  var kentuckywildcatsHalftimeU = 100 - kentuckywildcatsHalftimeUnder;

  var lasalleexplorersU = 100 - lasalleexplorersUnder;
  var lasalleexplorersSoloU = 100 - lasalleexplorersSoloUnder;
  var lasalleexplorersHalftimeU = 100 - lasalleexplorersHalftimeUnder;

  var lafayetteleopardsU = 100 - lafayetteleopardsUnder;
  var lafayetteleopardsSoloU = 100 - lafayetteleopardsSoloUnder;
  var lafayetteleopardsHalftimeU = 100 - lafayetteleopardsHalftimeUnder;

  var lamarcardinalsU = 100 - lamarcardinalsUnder;
  var lamarcardinalsSoloU = 100 - lamarcardinalsSoloUnder;
  var lamarcardinalsHalftimeU = 100 - lamarcardinalsHalftimeUnder;

  var lehighmountainhawksU = 100 - lehighmountainhawksUnder;
  var lehighmountainhawksSoloU = 100 - lehighmountainhawksSoloUnder;
  var lehighmountainhawksHalftimeU = 100 - lehighmountainhawksHalftimeUnder;

  var libertyflamesU = 100 - libertyflamesUnder;
  var libertyflamesSoloU = 100 - libertyflamesSoloUnder;
  var libertyflamesHalftimeU = 100 - libertyflamesHalftimeUnder;

  var lipscombbisonsU = 100 - lipscombbisonsUnder;
  var lipscombbisonsSoloU = 100 - lipscombbisonsSoloUnder;
  var lipscombbisonsHalftimeU = 100 - lipscombbisonsHalftimeUnder;

  var longislanduniversitysharksU = 100 - longislanduniversitysharksUnder;
  var longislanduniversitysharksSoloU = 100 - longislanduniversitysharksSoloUnder;
  var longislanduniversitysharksHalftimeU = 100 - longislanduniversitysharksHalftimeUnder;

  var longwoodlancersU = 100 - longwoodlancersUnder;
  var longwoodlancersSoloU = 100 - longwoodlancersSoloUnder;
  var longwoodlancersHalftimeU = 100 - longwoodlancersHalftimeUnder;

  var louisianaragincajunsU = 100 - louisianaragincajunsUnder;
  var louisianaragincajunsSoloU = 100 - louisianaragincajunsSoloUnder;
  var louisianaragincajunsHalftimeU = 100 - louisianaragincajunsHalftimeUnder;

  var ulmonroewarhawksU = 100 - ulmonroewarhawksUnder;
  var ulmonroewarhawksSoloU = 100 - ulmonroewarhawksSoloUnder;
  var ulmonroewarhawksHalftimeU = 100 - ulmonroewarhawksHalftimeUnder;

  var lsutigersU = 100 - lsutigersUnder;
  var lsutigersSoloU = 100 - lsutigersSoloUnder;
  var lsutigersHalftimeU = 100 - lsutigersHalftimeUnder;

  var louisianatechbulldogsU = 100 - louisianatechbulldogsUnder;
  var louisianatechbulldogsSoloU = 100 - louisianatechbulldogsSoloUnder;
  var louisianatechbulldogsHalftimeU = 100 - louisianatechbulldogsHalftimeUnder;

  var louisvillecardinalsU = 100 - louisvillecardinalsUnder;
  var louisvillecardinalsSoloU = 100 - louisvillecardinalsSoloUnder;
  var louisvillecardinalsHalftimeU = 100 - louisvillecardinalsHalftimeUnder;

  var loyolachicagoramblersU = 100 - loyolachicagoramblersUnder;
  var loyolachicagoramblersSoloU = 100 - loyolachicagoramblersSoloUnder;
  var loyolachicagoramblersHalftimeU = 100 - loyolachicagoramblersHalftimeUnder;

  var loyolamdgreyhoundsU = 100 - loyolamdgreyhoundsUnder;
  var loyolamdgreyhoundsSoloU = 100 - loyolamdgreyhoundsSoloUnder;
  var loyolamdgreyhoundsHalftimeU = 100 - loyolamdgreyhoundsHalftimeUnder;

  var loyolamarymountlionsU = 100 - loyolamarymountlionsUnder;
  var loyolamarymountlionsSoloU = 100 - loyolamarymountlionsSoloUnder;
  var loyolamarymountlionsHalftimeU = 100 - loyolamarymountlionsHalftimeUnder;

  var maineblackbearsU = 100 - maineblackbearsUnder;
  var maineblackbearsSoloU = 100 - maineblackbearsSoloUnder;
  var maineblackbearsHalftimeU = 100 - maineblackbearsHalftimeUnder;

  var manhattanjaspersU = 100 - manhattanjaspersUnder;
  var manhattanjaspersSoloU = 100 - manhattanjaspersSoloUnder;
  var manhattanjaspersHalftimeU = 100 - manhattanjaspersHalftimeUnder;

  var maristredfoxesU = 100 - maristredfoxesUnder;
  var maristredfoxesSoloU = 100 - maristredfoxesSoloUnder;
  var maristredfoxesHalftimeU = 100 - maristredfoxesHalftimeUnder;

  var marquettegoldeneaglesU = 100 - marquettegoldeneaglesUnder;
  var marquettegoldeneaglesSoloU = 100 - marquettegoldeneaglesSoloUnder;
  var marquettegoldeneaglesHalftimeU = 100 - marquettegoldeneaglesHalftimeUnder;

  var marshallthunderingherdU = 100 - marshallthunderingherdUnder;
  var marshallthunderingherdSoloU = 100 - marshallthunderingherdSoloUnder;
  var marshallthunderingherdHalftimeU = 100 - marshallthunderingherdHalftimeUnder;

  var umbcretrieversU = 100 - umbcretrieversUnder;
  var umbcretrieversSoloU = 100 - umbcretrieversSoloUnder;
  var umbcretrieversHalftimeU = 100 - umbcretrieversHalftimeUnder;

  var marylandterrapinsU = 100 - marylandterrapinsUnder;
  var marylandterrapinsSoloU = 100 - marylandterrapinsSoloUnder;
  var marylandterrapinsHalftimeU = 100 - marylandterrapinsHalftimeUnder;

  var marylandeasternshorehawksU = 100 - marylandeasternshorehawksUnder;
  var marylandeasternshorehawksSoloU = 100 - marylandeasternshorehawksSoloUnder;
  var marylandeasternshorehawksHalftimeU = 100 - marylandeasternshorehawksHalftimeUnder;

  var umassminutemenU = 100 - umassminutemenUnder;
  var umassminutemenSoloU = 100 - umassminutemenSoloUnder;
  var umassminutemenHalftimeU = 100 - umassminutemenHalftimeUnder;

  var umasslowellriverhawksU = 100 - umasslowellriverhawksUnder;
  var umasslowellriverhawksSoloU = 100 - umasslowellriverhawksSoloUnder;
  var umasslowellriverhawksHalftimeU = 100 - umasslowellriverhawksHalftimeUnder;

  var mcneesestatecowboysU = 100 - mcneesestatecowboysUnder;
  var mcneesestatecowboysSoloU = 100 - mcneesestatecowboysSoloUnder;
  var mcneesestatecowboysHalftimeU = 100 - mcneesestatecowboysHalftimeUnder;

  var memphistigersU = 100 - memphistigersUnder;
  var memphistigersSoloU = 100 - memphistigersSoloUnder;
  var memphistigersHalftimeU = 100 - memphistigersHalftimeUnder;

  var mercerbearsU = 100 - mercerbearsUnder;
  var mercerbearsSoloU = 100 - mercerbearsSoloUnder;
  var mercerbearsHalftimeU = 100 - mercerbearsHalftimeUnder;

  var miamihurricanesU = 100 - miamihurricanesUnder;
  var miamihurricanesSoloU = 100 - miamihurricanesSoloUnder;
  var miamihurricanesHalftimeU = 100 - miamihurricanesHalftimeUnder;

  var miamiohredhawksU = 100 - miamiohredhawksUnder;
  var miamiohredhawksSoloU = 100 - miamiohredhawksSoloUnder;
  var miamiohredhawksHalftimeU = 100 - miamiohredhawksHalftimeUnder;

  var michiganwolverinesU = 100 - michiganwolverinesUnder;
  var michiganwolverinesSoloU = 100 - michiganwolverinesSoloUnder;
  var michiganwolverinesHalftimeU = 100 - michiganwolverinesHalftimeUnder;

  var michiganstatespartansU = 100 - michiganstatespartansUnder;
  var michiganstatespartansSoloU = 100 - michiganstatespartansSoloUnder;
  var michiganstatespartansHalftimeU = 100 - michiganstatespartansHalftimeUnder;

  var middletennesseeblueraidersU = 100 - middletennesseeblueraidersUnder;
  var middletennesseeblueraidersSoloU = 100 - middletennesseeblueraidersSoloUnder;
  var middletennesseeblueraidersHalftimeU = 100 - middletennesseeblueraidersHalftimeUnder;

  var minnesotagoldengophersU = 100 - minnesotagoldengophersUnder;
  var minnesotagoldengophersSoloU = 100 - minnesotagoldengophersSoloUnder;
  var minnesotagoldengophersHalftimeU = 100 - minnesotagoldengophersHalftimeUnder;

  var olemissrebelsU = 100 - olemissrebelsUnder;
  var olemissrebelsSoloU = 100 - olemissrebelsSoloUnder;
  var olemissrebelsHalftimeU = 100 - olemissrebelsHalftimeUnder;

  var mississippistatebulldogsU = 100 - mississippistatebulldogsUnder;
  var mississippistatebulldogsSoloU = 100 - mississippistatebulldogsSoloUnder;
  var mississippistatebulldogsHalftimeU = 100 - mississippistatebulldogsHalftimeUnder;

  var mississippivalleystatedeltadevilsU = 100 - mississippivalleystatedeltadevilsUnder;
  var mississippivalleystatedeltadevilsSoloU = 100 - mississippivalleystatedeltadevilsSoloUnder;
  var mississippivalleystatedeltadevilsHalftimeU = 100 - mississippivalleystatedeltadevilsHalftimeUnder;

  var missouritigersU = 100 - missouritigersUnder;
  var missouritigersSoloU = 100 - missouritigersSoloUnder;
  var missouritigersHalftimeU = 100 - missouritigersHalftimeUnder;

  var umkckangaroosU = 100 - umkckangaroosUnder;
  var umkckangaroosSoloU = 100 - umkckangaroosSoloUnder;
  var umkckangaroosHalftimeU = 100 - umkckangaroosHalftimeUnder;

  var missouristatebearsU = 100 - missouristatebearsUnder;
  var missouristatebearsSoloU = 100 - missouristatebearsSoloUnder;
  var missouristatebearsHalftimeU = 100 - missouristatebearsHalftimeUnder;

  var monmouthhawksU = 100 - monmouthhawksUnder;
  var monmouthhawksSoloU = 100 - monmouthhawksSoloUnder;
  var monmouthhawksHalftimeU = 100 - monmouthhawksHalftimeUnder;

  var montanagrizzliesU = 100 - montanagrizzliesUnder;
  var montanagrizzliesSoloU = 100 - montanagrizzliesSoloUnder;
  var montanagrizzliesHalftimeU = 100 - montanagrizzliesHalftimeUnder;

  var montanastatebobcatsU = 100 - montanastatebobcatsUnder;
  var montanastatebobcatsSoloU = 100 - montanastatebobcatsSoloUnder;
  var montanastatebobcatsHalftimeU = 100 - montanastatebobcatsHalftimeUnder;

  var moreheadstateeaglesU = 100 - moreheadstateeaglesUnder;
  var moreheadstateeaglesSoloU = 100 - moreheadstateeaglesSoloUnder;
  var moreheadstateeaglesHalftimeU = 100 - moreheadstateeaglesHalftimeUnder;

  var morganstatebearsU = 100 - morganstatebearsUnder;
  var morganstatebearsSoloU = 100 - morganstatebearsSoloUnder;
  var morganstatebearsHalftimeU = 100 - morganstatebearsHalftimeUnder;

  var mtstmarysmountaineersU = 100 - mtstmarysmountaineersUnder;
  var mtstmarysmountaineersSoloU = 100 - mtstmarysmountaineersSoloUnder;
  var mtstmarysmountaineersHalftimeU = 100 - mtstmarysmountaineersHalftimeUnder;

  var murraystateracersU = 100 - murraystateracersUnder;
  var murraystateracersSoloU = 100 - murraystateracersSoloUnder;
  var murraystateracersHalftimeU = 100 - murraystateracersHalftimeUnder;

  var nebraskacornhuskersU = 100 - nebraskacornhuskersUnder;
  var nebraskacornhuskersSoloU = 100 - nebraskacornhuskersSoloUnder;
  var nebraskacornhuskersHalftimeU = 100 - nebraskacornhuskersHalftimeUnder;

  var omahamavericksU = 100 - omahamavericksUnder;
  var omahamavericksSoloU = 100 - omahamavericksSoloUnder;
  var omahamavericksHalftimeU = 100 - omahamavericksHalftimeUnder;

  var unlvrebelsU = 100 - unlvrebelsUnder;
  var unlvrebelsSoloU = 100 - unlvrebelsSoloUnder;
  var unlvrebelsHalftimeU = 100 - unlvrebelsHalftimeUnder;

  var nevadawolfpackU = 100 - nevadawolfpackUnder;
  var nevadawolfpackSoloU = 100 - nevadawolfpackSoloUnder;
  var nevadawolfpackHalftimeU = 100 - nevadawolfpackHalftimeUnder;

  var newhampshirewildcatsU = 100 - newhampshirewildcatsUnder;
  var newhampshirewildcatsSoloU = 100 - newhampshirewildcatsSoloUnder;
  var newhampshirewildcatsHalftimeU = 100 - newhampshirewildcatsHalftimeUnder;

  var njithighlandersU = 100 - njithighlandersUnder;
  var njithighlandersSoloU = 100 - njithighlandersSoloUnder;
  var njithighlandersHalftimeU = 100 - njithighlandersHalftimeUnder;

  var newmexicolobosU = 100 - newmexicolobosUnder;
  var newmexicolobosSoloU = 100 - newmexicolobosSoloUnder;
  var newmexicolobosHalftimeU = 100 - newmexicolobosHalftimeUnder;

  var newmexicostateaggiesU = 100 - newmexicostateaggiesUnder;
  var newmexicostateaggiesSoloU = 100 - newmexicostateaggiesSoloUnder;
  var newmexicostateaggiesHalftimeU = 100 - newmexicostateaggiesHalftimeUnder;

  var neworleansprivateersU = 100 - neworleansprivateersUnder;
  var neworleansprivateersSoloU = 100 - neworleansprivateersSoloUnder;
  var neworleansprivateersHalftimeU = 100 - neworleansprivateersHalftimeUnder;

  var niagarapurpleeaglesU = 100 - niagarapurpleeaglesUnder;
  var niagarapurpleeaglesSoloU = 100 - niagarapurpleeaglesSoloUnder;
  var niagarapurpleeaglesHalftimeU = 100 - niagarapurpleeaglesHalftimeUnder;

  var nichollscolonelsU = 100 - nichollscolonelsUnder;
  var nichollscolonelsSoloU = 100 - nichollscolonelsSoloUnder;
  var nichollscolonelsHalftimeU = 100 - nichollscolonelsHalftimeUnder;

  var norfolkstatespartansU = 100 - norfolkstatespartansUnder;
  var norfolkstatespartansSoloU = 100 - norfolkstatespartansSoloUnder;
  var norfolkstatespartansHalftimeU = 100 - norfolkstatespartansHalftimeUnder;

  var northcarolinaaandtaggiesU = 100 - northcarolinaaandtaggiesUnder;
  var northcarolinaaandtaggiesSoloU = 100 - northcarolinaaandtaggiesSoloUnder;
  var northcarolinaaandtaggiesHalftimeU = 100 - northcarolinaaandtaggiesHalftimeUnder;

  var uncashevillebulldogsU = 100 - uncashevillebulldogsUnder;
  var uncashevillebulldogsSoloU = 100 - uncashevillebulldogsSoloUnder;
  var uncashevillebulldogsHalftimeU = 100 - uncashevillebulldogsHalftimeUnder;

  var northcarolinacentraleaglesU = 100 - northcarolinacentraleaglesUnder;
  var northcarolinacentraleaglesSoloU = 100 - northcarolinacentraleaglesSoloUnder;
  var northcarolinacentraleaglesHalftimeU = 100 - northcarolinacentraleaglesHalftimeUnder;

  var northcarolinatarheelsU = 100 - northcarolinatarheelsUnder;
  var northcarolinatarheelsSoloU = 100 - northcarolinatarheelsSoloUnder;
  var northcarolinatarheelsHalftimeU = 100 - northcarolinatarheelsHalftimeUnder;

  var charlotte49ersU = 100 - charlotte49ersUnder;
  var charlotte49ersSoloU = 100 - charlotte49ersSoloUnder;
  var charlotte49ersHalftimeU = 100 - charlotte49ersHalftimeUnder;

  var uncgreensborospartansU = 100 - uncgreensborospartansUnder;
  var uncgreensborospartansSoloU = 100 - uncgreensborospartansSoloUnder;
  var uncgreensborospartansHalftimeU = 100 - uncgreensborospartansHalftimeUnder;

  var ncstatewolfpackU = 100 - ncstatewolfpackUnder;
  var ncstatewolfpackSoloU = 100 - ncstatewolfpackSoloUnder;
  var ncstatewolfpackHalftimeU = 100 - ncstatewolfpackHalftimeUnder;

  var uncwilmingtonseahawksU = 100 - uncwilmingtonseahawksUnder;
  var uncwilmingtonseahawksSoloU = 100 - uncwilmingtonseahawksSoloUnder;
  var uncwilmingtonseahawksHalftimeU = 100 - uncwilmingtonseahawksHalftimeUnder;

  var northdakotafightinghawksU = 100 - northdakotafightinghawksUnder;
  var northdakotafightinghawksSoloU = 100 - northdakotafightinghawksSoloUnder;
  var northdakotafightinghawksHalftimeU = 100 - northdakotafightinghawksHalftimeUnder;

  var northdakotastatebisonU = 100 - northdakotastatebisonUnder;
  var northdakotastatebisonSoloU = 100 - northdakotastatebisonSoloUnder;
  var northdakotastatebisonHalftimeU = 100 - northdakotastatebisonHalftimeUnder;

  var northfloridaospreysU = 100 - northfloridaospreysUnder;
  var northfloridaospreysSoloU = 100 - northfloridaospreysSoloUnder;
  var northfloridaospreysHalftimeU = 100 - northfloridaospreysHalftimeUnder;

  var northtexasmeangreenU = 100 - northtexasmeangreenUnder;
  var northtexasmeangreenSoloU = 100 - northtexasmeangreenSoloUnder;
  var northtexasmeangreenHalftimeU = 100 - northtexasmeangreenHalftimeUnder;

  var northeasternhuskiesU = 100 - northeasternhuskiesUnder;
  var northeasternhuskiesSoloU = 100 - northeasternhuskiesSoloUnder;
  var northeasternhuskiesHalftimeU = 100 - northeasternhuskiesHalftimeUnder;

  var northernarizonalumberjacksU = 100 - northernarizonalumberjacksUnder;
  var northernarizonalumberjacksSoloU = 100 - northernarizonalumberjacksSoloUnder;
  var northernarizonalumberjacksHalftimeU = 100 - northernarizonalumberjacksHalftimeUnder;

  var northerncoloradobearsU = 100 - northerncoloradobearsUnder;
  var northerncoloradobearsSoloU = 100 - northerncoloradobearsSoloUnder;
  var northerncoloradobearsHalftimeU = 100 - northerncoloradobearsHalftimeUnder;

  var northernillinoishuskiesU = 100 - northernillinoishuskiesUnder;
  var northernillinoishuskiesSoloU = 100 - northernillinoishuskiesSoloUnder;
  var northernillinoishuskiesHalftimeU = 100 - northernillinoishuskiesHalftimeUnder;

  var northerniowapanthersU = 100 - northerniowapanthersUnder;
  var northerniowapanthersSoloU = 100 - northerniowapanthersSoloUnder;
  var northerniowapanthersHalftimeU = 100 - northerniowapanthersHalftimeUnder;

  var northernkentuckynorseU = 100 - northernkentuckynorseUnder;
  var northernkentuckynorseSoloU = 100 - northernkentuckynorseSoloUnder;
  var northernkentuckynorseHalftimeU = 100 - northernkentuckynorseHalftimeUnder;

  var northwesternwildcatsU = 100 - northwesternwildcatsUnder;
  var northwesternwildcatsSoloU = 100 - northwesternwildcatsSoloUnder;
  var northwesternwildcatsHalftimeU = 100 - northwesternwildcatsHalftimeUnder;

  var northwesternstatedemonsU = 100 - northwesternstatedemonsUnder;
  var northwesternstatedemonsSoloU = 100 - northwesternstatedemonsSoloUnder;
  var northwesternstatedemonsHalftimeU = 100 - northwesternstatedemonsHalftimeUnder;

  var notredamefightingirishU = 100 - notredamefightingirishUnder;
  var notredamefightingirishSoloU = 100 - notredamefightingirishSoloUnder;
  var notredamefightingirishHalftimeU = 100 - notredamefightingirishHalftimeUnder;

  var oaklandgoldengrizzliesU = 100 - oaklandgoldengrizzliesUnder;
  var oaklandgoldengrizzliesSoloU = 100 - oaklandgoldengrizzliesSoloUnder;
  var oaklandgoldengrizzliesHalftimeU = 100 - oaklandgoldengrizzliesHalftimeUnder;

  var ohiobobcatsU = 100 - ohiobobcatsUnder;
  var ohiobobcatsSoloU = 100 - ohiobobcatsSoloUnder;
  var ohiobobcatsHalftimeU = 100 - ohiobobcatsHalftimeUnder;

  var ohiostatebuckeyesU = 100 - ohiostatebuckeyesUnder;
  var ohiostatebuckeyesSoloU = 100 - ohiostatebuckeyesSoloUnder;
  var ohiostatebuckeyesHalftimeU = 100 - ohiostatebuckeyesHalftimeUnder;

  var oklahomasoonersU = 100 - oklahomasoonersUnder;
  var oklahomasoonersSoloU = 100 - oklahomasoonersSoloUnder;
  var oklahomasoonersHalftimeU = 100 - oklahomasoonersHalftimeUnder;

  var oklahomastatecowboysU = 100 - oklahomastatecowboysUnder;
  var oklahomastatecowboysSoloU = 100 - oklahomastatecowboysSoloUnder;
  var oklahomastatecowboysHalftimeU = 100 - oklahomastatecowboysHalftimeUnder;

  var olddominionmonarchsU = 100 - olddominionmonarchsUnder;
  var olddominionmonarchsSoloU = 100 - olddominionmonarchsSoloUnder;
  var olddominionmonarchsHalftimeU = 100 - olddominionmonarchsHalftimeUnder;

  var oralrobertsgoldeneaglesU = 100 - oralrobertsgoldeneaglesUnder;
  var oralrobertsgoldeneaglesSoloU = 100 - oralrobertsgoldeneaglesSoloUnder;
  var oralrobertsgoldeneaglesHalftimeU = 100 - oralrobertsgoldeneaglesHalftimeUnder;

  var oregonducksU = 100 - oregonducksUnder;
  var oregonducksSoloU = 100 - oregonducksSoloUnder;
  var oregonducksHalftimeU = 100 - oregonducksHalftimeUnder;

  var oregonstatebeaversU = 100 - oregonstatebeaversUnder;
  var oregonstatebeaversSoloU = 100 - oregonstatebeaversSoloUnder;
  var oregonstatebeaversHalftimeU = 100 - oregonstatebeaversHalftimeUnder;

  var pacifictigersU = 100 - pacifictigersUnder;
  var pacifictigersSoloU = 100 - pacifictigersSoloUnder;
  var pacifictigersHalftimeU = 100 - pacifictigersHalftimeUnder;

  var pennsylvaniaquakersU = 100 - pennsylvaniaquakersUnder;
  var pennsylvaniaquakersSoloU = 100 - pennsylvaniaquakersSoloUnder;
  var pennsylvaniaquakersHalftimeU = 100 - pennsylvaniaquakersHalftimeUnder;

  var pennstatenittanylionsU = 100 - pennstatenittanylionsUnder;
  var pennstatenittanylionsSoloU = 100 - pennstatenittanylionsSoloUnder;
  var pennstatenittanylionsHalftimeU = 100 - pennstatenittanylionsHalftimeUnder;

  var pepperdinewavesU = 100 - pepperdinewavesUnder;
  var pepperdinewavesSoloU = 100 - pepperdinewavesSoloUnder;
  var pepperdinewavesHalftimeU = 100 - pepperdinewavesHalftimeUnder;

  var pittsburghpanthersU = 100 - pittsburghpanthersUnder;
  var pittsburghpanthersSoloU = 100 - pittsburghpanthersSoloUnder;
  var pittsburghpanthersHalftimeU = 100 - pittsburghpanthersHalftimeUnder;

  var portlandpilotsU = 100 - portlandpilotsUnder;
  var portlandpilotsSoloU = 100 - portlandpilotsSoloUnder;
  var portlandpilotsHalftimeU = 100 - portlandpilotsHalftimeUnder;

  var portlandstatevikingsU = 100 - portlandstatevikingsUnder;
  var portlandstatevikingsSoloU = 100 - portlandstatevikingsSoloUnder;
  var portlandstatevikingsHalftimeU = 100 - portlandstatevikingsHalftimeUnder;

  var prairieviewaandmpanthersU = 100 - prairieviewaandmpanthersUnder;
  var prairieviewaandmpanthersSoloU = 100 - prairieviewaandmpanthersSoloUnder;
  var prairieviewaandmpanthersHalftimeU = 100 - prairieviewaandmpanthersHalftimeUnder;

  var presbyterianbluehoseU = 100 - presbyterianbluehoseUnder;
  var presbyterianbluehoseSoloU = 100 - presbyterianbluehoseSoloUnder;
  var presbyterianbluehoseHalftimeU = 100 - presbyterianbluehoseHalftimeUnder;

  var princetontigersU = 100 - princetontigersUnder;
  var princetontigersSoloU = 100 - princetontigersSoloUnder;
  var princetontigersHalftimeU = 100 - princetontigersHalftimeUnder;

  var providencefriarsU = 100 - providencefriarsUnder;
  var providencefriarsSoloU = 100 - providencefriarsSoloUnder;
  var providencefriarsHalftimeU = 100 - providencefriarsHalftimeUnder;

  var purdueboilermakersU = 100 - purdueboilermakersUnder;
  var purdueboilermakersSoloU = 100 - purdueboilermakersSoloUnder;
  var purdueboilermakersHalftimeU = 100 - purdueboilermakersHalftimeUnder;

  var purduefortwaynemastodonsU = 100 - purduefortwaynemastodonsUnder;
  var purduefortwaynemastodonsSoloU = 100 - purduefortwaynemastodonsSoloUnder;
  var purduefortwaynemastodonsHalftimeU = 100 - purduefortwaynemastodonsHalftimeUnder;

  var quinnipiacbobcatsU = 100 - quinnipiacbobcatsUnder;
  var quinnipiacbobcatsSoloU = 100 - quinnipiacbobcatsSoloUnder;
  var quinnipiacbobcatsHalftimeU = 100 - quinnipiacbobcatsHalftimeUnder;

  var radfordhighlandersU = 100 - radfordhighlandersUnder;
  var radfordhighlandersSoloU = 100 - radfordhighlandersSoloUnder;
  var radfordhighlandersHalftimeU = 100 - radfordhighlandersHalftimeUnder;

  var rhodeislandramsU = 100 - rhodeislandramsUnder;
  var rhodeislandramsSoloU = 100 - rhodeislandramsSoloUnder;
  var rhodeislandramsHalftimeU = 100 - rhodeislandramsHalftimeUnder;

  var riceowlsU = 100 - riceowlsUnder;
  var riceowlsSoloU = 100 - riceowlsSoloUnder;
  var riceowlsHalftimeU = 100 - riceowlsHalftimeUnder;

  var richmondspidersU = 100 - richmondspidersUnder;
  var richmondspidersSoloU = 100 - richmondspidersSoloUnder;
  var richmondspidersHalftimeU = 100 - richmondspidersHalftimeUnder;

  var riderbroncsU = 100 - riderbroncsUnder;
  var riderbroncsSoloU = 100 - riderbroncsSoloUnder;
  var riderbroncsHalftimeU = 100 - riderbroncsHalftimeUnder;

  var robertmorriscolonialsU = 100 - robertmorriscolonialsUnder;
  var robertmorriscolonialsSoloU = 100 - robertmorriscolonialsSoloUnder;
  var robertmorriscolonialsHalftimeU = 100 - robertmorriscolonialsHalftimeUnder;

  var rutgersscarletknightsU = 100 - rutgersscarletknightsUnder;
  var rutgersscarletknightsSoloU = 100 - rutgersscarletknightsSoloUnder;
  var rutgersscarletknightsHalftimeU = 100 - rutgersscarletknightsHalftimeUnder;

  var sacredheartpioneersU = 100 - sacredheartpioneersUnder;
  var sacredheartpioneersSoloU = 100 - sacredheartpioneersSoloUnder;
  var sacredheartpioneersHalftimeU = 100 - sacredheartpioneersHalftimeUnder;

  var stbonaventurebonniesU = 100 - stbonaventurebonniesUnder;
  var stbonaventurebonniesSoloU = 100 - stbonaventurebonniesSoloUnder;
  var stbonaventurebonniesHalftimeU = 100 - stbonaventurebonniesHalftimeUnder;

  var stfrancisbknterriersU = 100 - stfrancisbknterriersUnder;
  var stfrancisbknterriersSoloU = 100 - stfrancisbknterriersSoloUnder;
  var stfrancisbknterriersHalftimeU = 100 - stfrancisbknterriersHalftimeUnder;

  var stfrancisparedflashU = 100 - stfrancisparedflashUnder;
  var stfrancisparedflashSoloU = 100 - stfrancisparedflashSoloUnder;
  var stfrancisparedflashHalftimeU = 100 - stfrancisparedflashHalftimeUnder;

  var stjohnsredstormU = 100 - stjohnsredstormUnder;
  var stjohnsredstormSoloU = 100 - stjohnsredstormSoloUnder;
  var stjohnsredstormHalftimeU = 100 - stjohnsredstormHalftimeUnder;

  var saintjosephshawksU = 100 - saintjosephshawksUnder;
  var saintjosephshawksSoloU = 100 - saintjosephshawksSoloUnder;
  var saintjosephshawksHalftimeU = 100 - saintjosephshawksHalftimeUnder;

  var saintlouisbillikensU = 100 - saintlouisbillikensUnder;
  var saintlouisbillikensSoloU = 100 - saintlouisbillikensSoloUnder;
  var saintlouisbillikensHalftimeU = 100 - saintlouisbillikensHalftimeUnder;

  var saintmarysgaelsU = 100 - saintmarysgaelsUnder;
  var saintmarysgaelsSoloU = 100 - saintmarysgaelsSoloUnder;
  var saintmarysgaelsHalftimeU = 100 - saintmarysgaelsHalftimeUnder;

  var saintpeterspeacocksU = 100 - saintpeterspeacocksUnder;
  var saintpeterspeacocksSoloU = 100 - saintpeterspeacocksSoloUnder;
  var saintpeterspeacocksHalftimeU = 100 - saintpeterspeacocksHalftimeUnder;

  var samhoustonbearkatsU = 100 - samhoustonbearkatsUnder;
  var samhoustonbearkatsSoloU = 100 - samhoustonbearkatsSoloUnder;
  var samhoustonbearkatsHalftimeU = 100 - samhoustonbearkatsHalftimeUnder;

  var samfordbulldogsU = 100 - samfordbulldogsUnder;
  var samfordbulldogsSoloU = 100 - samfordbulldogsSoloUnder;
  var samfordbulldogsHalftimeU = 100 - samfordbulldogsHalftimeUnder;

  var sandiegotorerosU = 100 - sandiegotorerosUnder;
  var sandiegotorerosSoloU = 100 - sandiegotorerosSoloUnder;
  var sandiegotorerosHalftimeU = 100 - sandiegotorerosHalftimeUnder;

  var sandiegostateaztecsU = 100 - sandiegostateaztecsUnder;
  var sandiegostateaztecsSoloU = 100 - sandiegostateaztecsSoloUnder;
  var sandiegostateaztecsHalftimeU = 100 - sandiegostateaztecsHalftimeUnder;

  var sanfranciscodonsU = 100 - sanfranciscodonsUnder;
  var sanfranciscodonsSoloU = 100 - sanfranciscodonsSoloUnder;
  var sanfranciscodonsHalftimeU = 100 - sanfranciscodonsHalftimeUnder;

  var sanjosestatespartansU = 100 - sanjosestatespartansUnder;
  var sanjosestatespartansSoloU = 100 - sanjosestatespartansSoloUnder;
  var sanjosestatespartansHalftimeU = 100 - sanjosestatespartansHalftimeUnder;

  var santaclarabroncosU = 100 - santaclarabroncosUnder;
  var santaclarabroncosSoloU = 100 - santaclarabroncosSoloUnder;
  var santaclarabroncosHalftimeU = 100 - santaclarabroncosHalftimeUnder;

  var seattleredhawksU = 100 - seattleredhawksUnder;
  var seattleredhawksSoloU = 100 - seattleredhawksSoloUnder;
  var seattleredhawksHalftimeU = 100 - seattleredhawksHalftimeUnder;

  var setonhallpiratesU = 100 - setonhallpiratesUnder;
  var setonhallpiratesSoloU = 100 - setonhallpiratesSoloUnder;
  var setonhallpiratesHalftimeU = 100 - setonhallpiratesHalftimeUnder;

  var sienasaintsU = 100 - sienasaintsUnder;
  var sienasaintsSoloU = 100 - sienasaintsSoloUnder;
  var sienasaintsHalftimeU = 100 - sienasaintsHalftimeUnder;

  var southalabamajaguarsU = 100 - southalabamajaguarsUnder;
  var southalabamajaguarsSoloU = 100 - southalabamajaguarsSoloUnder;
  var southalabamajaguarsHalftimeU = 100 - southalabamajaguarsHalftimeUnder;

  var southcarolinagamecocksU = 100 - southcarolinagamecocksUnder;
  var southcarolinagamecocksSoloU = 100 - southcarolinagamecocksSoloUnder;
  var southcarolinagamecocksHalftimeU = 100 - southcarolinagamecocksHalftimeUnder;

  var southcarolinastatebulldogsU = 100 - southcarolinastatebulldogsUnder;
  var southcarolinastatebulldogsSoloU = 100 - southcarolinastatebulldogsSoloUnder;
  var southcarolinastatebulldogsHalftimeU = 100 - southcarolinastatebulldogsHalftimeUnder;

  var southcarolinaupstatespartansU = 100 - southcarolinaupstatespartansUnder;
  var southcarolinaupstatespartansSoloU = 100 - southcarolinaupstatespartansSoloUnder;
  var southcarolinaupstatespartansHalftimeU = 100 - southcarolinaupstatespartansHalftimeUnder;

  var southdakotacoyotesU = 100 - southdakotacoyotesUnder;
  var southdakotacoyotesSoloU = 100 - southdakotacoyotesSoloUnder;
  var southdakotacoyotesHalftimeU = 100 - southdakotacoyotesHalftimeUnder;

  var southdakotastatejackrabbitsU = 100 - southdakotastatejackrabbitsUnder;
  var southdakotastatejackrabbitsSoloU = 100 - southdakotastatejackrabbitsSoloUnder;
  var southdakotastatejackrabbitsHalftimeU = 100 - southdakotastatejackrabbitsHalftimeUnder;

  var southfloridabullsU = 100 - southfloridabullsUnder;
  var southfloridabullsSoloU = 100 - southfloridabullsSoloUnder;
  var southfloridabullsHalftimeU = 100 - southfloridabullsHalftimeUnder;

  var semissouristredhawksU = 100 - semissouristredhawksUnder;
  var semissouristredhawksSoloU = 100 - semissouristredhawksSoloUnder;
  var semissouristredhawksHalftimeU = 100 - semissouristredhawksHalftimeUnder;

  var selouisianalionsU = 100 - selouisianalionsUnder;
  var selouisianalionsSoloU = 100 - selouisianalionsSoloUnder;
  var selouisianalionsHalftimeU = 100 - selouisianalionsHalftimeUnder;

  var southernjaguarsU = 100 - southernjaguarsUnder;
  var southernjaguarsSoloU = 100 - southernjaguarsSoloUnder;
  var southernjaguarsHalftimeU = 100 - southernjaguarsHalftimeUnder;

  var usctrojansU = 100 - usctrojansUnder;
  var usctrojansSoloU = 100 - usctrojansSoloUnder;
  var usctrojansHalftimeU = 100 - usctrojansHalftimeUnder;

  var southernillinoissalukisU = 100 - southernillinoissalukisUnder;
  var southernillinoissalukisSoloU = 100 - southernillinoissalukisSoloUnder;
  var southernillinoissalukisHalftimeU = 100 - southernillinoissalukisHalftimeUnder;

  var siuedwardsvillecougarsU = 100 - siuedwardsvillecougarsUnder;
  var siuedwardsvillecougarsSoloU = 100 - siuedwardsvillecougarsSoloUnder;
  var siuedwardsvillecougarsHalftimeU = 100 - siuedwardsvillecougarsHalftimeUnder;

  var smumustangsU = 100 - smumustangsUnder;
  var smumustangsSoloU = 100 - smumustangsSoloUnder;
  var smumustangsHalftimeU = 100 - smumustangsHalftimeUnder;

  var southernmissgoldeneaglesU = 100 - southernmissgoldeneaglesUnder;
  var southernmissgoldeneaglesSoloU = 100 - southernmissgoldeneaglesSoloUnder;
  var southernmissgoldeneaglesHalftimeU = 100 - southernmissgoldeneaglesHalftimeUnder;

  var southernutahthunderbirdsU = 100 - southernutahthunderbirdsUnder;
  var southernutahthunderbirdsSoloU = 100 - southernutahthunderbirdsSoloUnder;
  var southernutahthunderbirdsHalftimeU = 100 - southernutahthunderbirdsHalftimeUnder;

  var stanfordcardinalsU = 100 - stanfordcardinalsUnder;
  var stanfordcardinalsSoloU = 100 - stanfordcardinalsSoloUnder;
  var stanfordcardinalsHalftimeU = 100 - stanfordcardinalsHalftimeUnder;

  var stephenfaustinlumberjacksU = 100 - stephenfaustinlumberjacksUnder;
  var stephenfaustinlumberjacksSoloU = 100 - stephenfaustinlumberjacksSoloUnder;
  var stephenfaustinlumberjacksHalftimeU = 100 - stephenfaustinlumberjacksHalftimeUnder;

  var stetsonhattersU = 100 - stetsonhattersUnder;
  var stetsonhattersSoloU = 100 - stetsonhattersSoloUnder;
  var stetsonhattersHalftimeU = 100 - stetsonhattersHalftimeUnder;

  var stonybrookseawolvesU = 100 - stonybrookseawolvesUnder;
  var stonybrookseawolvesSoloU = 100 - stonybrookseawolvesSoloUnder;
  var stonybrookseawolvesHalftimeU = 100 - stonybrookseawolvesHalftimeUnder;

  var syracuseorangeU = 100 - syracuseorangeUnder;
  var syracuseorangeSoloU = 100 - syracuseorangeSoloUnder;
  var syracuseorangeHalftimeU = 100 - syracuseorangeHalftimeUnder;

  var templeowlsU = 100 - templeowlsUnder;
  var templeowlsSoloU = 100 - templeowlsSoloUnder;
  var templeowlsHalftimeU = 100 - templeowlsHalftimeUnder;

  var tennesseevolunteersU = 100 - tennesseevolunteersUnder;
  var tennesseevolunteersSoloU = 100 - tennesseevolunteersSoloUnder;
  var tennesseevolunteersHalftimeU = 100 - tennesseevolunteersHalftimeUnder;

  var chattanoogamocsU = 100 - chattanoogamocsUnder;
  var chattanoogamocsSoloU = 100 - chattanoogamocsSoloUnder;
  var chattanoogamocsHalftimeU = 100 - chattanoogamocsHalftimeUnder;

  var utmartinskyhawksU = 100 - utmartinskyhawksUnder;
  var utmartinskyhawksSoloU = 100 - utmartinskyhawksSoloUnder;
  var utmartinskyhawksHalftimeU = 100 - utmartinskyhawksHalftimeUnder;

  var tennesseestatetigersU = 100 - tennesseestatetigersUnder;
  var tennesseestatetigersSoloU = 100 - tennesseestatetigersSoloUnder;
  var tennesseestatetigersHalftimeU = 100 - tennesseestatetigersHalftimeUnder;

  var tennesseetechgoldeneaglesU = 100 - tennesseetechgoldeneaglesUnder;
  var tennesseetechgoldeneaglesSoloU = 100 - tennesseetechgoldeneaglesSoloUnder;
  var tennesseetechgoldeneaglesHalftimeU = 100 - tennesseetechgoldeneaglesHalftimeUnder;

  var texasaandmaggiesU = 100 - texasaandmaggiesUnder;
  var texasaandmaggiesSoloU = 100 - texasaandmaggiesSoloUnder;
  var texasaandmaggiesHalftimeU = 100 - texasaandmaggiesHalftimeUnder;

  var texasaandmccislandersU = 100 - texasaandmccislandersUnder;
  var texasaandmccislandersSoloU = 100 - texasaandmccislandersSoloUnder;
  var texasaandmccislandersHalftimeU = 100 - texasaandmccislandersHalftimeUnder;

  var utarlingtonmavericksU = 100 - utarlingtonmavericksUnder;
  var utarlingtonmavericksSoloU = 100 - utarlingtonmavericksSoloUnder;
  var utarlingtonmavericksHalftimeU = 100 - utarlingtonmavericksHalftimeUnder;

  var texaslonghornsU = 100 - texaslonghornsUnder;
  var texaslonghornsSoloU = 100 - texaslonghornsSoloUnder;
  var texaslonghornsHalftimeU = 100 - texaslonghornsHalftimeUnder;

  var tcuhornedfrogsU = 100 - tcuhornedfrogsUnder;
  var tcuhornedfrogsSoloU = 100 - tcuhornedfrogsSoloUnder;
  var tcuhornedfrogsHalftimeU = 100 - tcuhornedfrogsHalftimeUnder;

  var utepminersU = 100 - utepminersUnder;
  var utepminersSoloU = 100 - utepminersSoloUnder;
  var utepminersHalftimeU = 100 - utepminersHalftimeUnder;

  var utriograndevalleyvaquerosU = 100 - utriograndevalleyvaquerosUnder;
  var utriograndevalleyvaquerosSoloU = 100 - utriograndevalleyvaquerosSoloUnder;
  var utriograndevalleyvaquerosHalftimeU = 100 - utriograndevalleyvaquerosHalftimeUnder;

  var utsaroadrunnersU = 100 - utsaroadrunnersUnder;
  var utsaroadrunnersSoloU = 100 - utsaroadrunnersSoloUnder;
  var utsaroadrunnersHalftimeU = 100 - utsaroadrunnersHalftimeUnder;

  var texassoutherntigersU = 100 - texassoutherntigersUnder;
  var texassoutherntigersSoloU = 100 - texassoutherntigersSoloUnder;
  var texassoutherntigersHalftimeU = 100 - texassoutherntigersHalftimeUnder;

  var texasstatebobcatsU = 100 - texasstatebobcatsUnder;
  var texasstatebobcatsSoloU = 100 - texasstatebobcatsSoloUnder;
  var texasstatebobcatsHalftimeU = 100 - texasstatebobcatsHalftimeUnder;

  var texastechredraidersU = 100 - texastechredraidersUnder;
  var texastechredraidersSoloU = 100 - texastechredraidersSoloUnder;
  var texastechredraidersHalftimeU = 100 - texastechredraidersHalftimeUnder;

  var toledorocketsU = 100 - toledorocketsUnder;
  var toledorocketsSoloU = 100 - toledorocketsSoloUnder;
  var toledorocketsHalftimeU = 100 - toledorocketsHalftimeUnder;

  var towsontigersU = 100 - towsontigersUnder;
  var towsontigersSoloU = 100 - towsontigersSoloUnder;
  var towsontigersHalftimeU = 100 - towsontigersHalftimeUnder;

  var troytrojansU = 100 - troytrojansUnder;
  var troytrojansSoloU = 100 - troytrojansSoloUnder;
  var troytrojansHalftimeU = 100 - troytrojansHalftimeUnder;

  var tulanegreenwaveU = 100 - tulanegreenwaveUnder;
  var tulanegreenwaveSoloU = 100 - tulanegreenwaveSoloUnder;
  var tulanegreenwaveHalftimeU = 100 - tulanegreenwaveHalftimeUnder;

  var tulsagoldenhurricaneU = 100 - tulsagoldenhurricaneUnder;
  var tulsagoldenhurricaneSoloU = 100 - tulsagoldenhurricaneSoloUnder;
  var tulsagoldenhurricaneHalftimeU = 100 - tulsagoldenhurricaneHalftimeUnder;

  var airforcefalconsU = 100 - airforcefalconsUnder;
  var airforcefalconsSoloU = 100 - airforcefalconsSoloUnder;
  var airforcefalconsHalftimeU = 100 - airforcefalconsHalftimeUnder;

  var armyblackknightsU = 100 - armyblackknightsUnder;
  var armyblackknightsSoloU = 100 - armyblackknightsSoloUnder;
  var armyblackknightsHalftimeU = 100 - armyblackknightsHalftimeUnder;

  var navymidshipmenU = 100 - navymidshipmenUnder;
  var navymidshipmenSoloU = 100 - navymidshipmenSoloUnder;
  var navymidshipmenHalftimeU = 100 - navymidshipmenHalftimeUnder;

  var utahutesU = 100 - utahutesUnder;
  var utahutesSoloU = 100 - utahutesSoloUnder;
  var utahutesHalftimeU = 100 - utahutesHalftimeUnder;

  var utahstateaggiesU = 100 - utahstateaggiesUnder;
  var utahstateaggiesSoloU = 100 - utahstateaggiesSoloUnder;
  var utahstateaggiesHalftimeU = 100 - utahstateaggiesHalftimeUnder;

  var utahvalleywolverinesU = 100 - utahvalleywolverinesUnder;
  var utahvalleywolverinesSoloU = 100 - utahvalleywolverinesSoloUnder;
  var utahvalleywolverinesHalftimeU = 100 - utahvalleywolverinesHalftimeUnder;

  var valparaisocrusadersU = 100 - valparaisocrusadersUnder;
  var valparaisocrusadersSoloU = 100 - valparaisocrusadersSoloUnder;
  var valparaisocrusadersHalftimeU = 100 - valparaisocrusadersHalftimeUnder;

  var vanderbiltcommodoresU = 100 - vanderbiltcommodoresUnder;
  var vanderbiltcommodoresSoloU = 100 - vanderbiltcommodoresSoloUnder;
  var vanderbiltcommodoresHalftimeU = 100 - vanderbiltcommodoresHalftimeUnder;

  var vermontcatamountsU = 100 - vermontcatamountsUnder;
  var vermontcatamountsSoloU = 100 - vermontcatamountsSoloUnder;
  var vermontcatamountsHalftimeU = 100 - vermontcatamountsHalftimeUnder;

  var villanovawildcatsU = 100 - villanovawildcatsUnder;
  var villanovawildcatsSoloU = 100 - villanovawildcatsSoloUnder;
  var villanovawildcatsHalftimeU = 100 - villanovawildcatsHalftimeUnder;

  var virginiacavaliersU = 100 - virginiacavaliersUnder;
  var virginiacavaliersSoloU = 100 - virginiacavaliersSoloUnder;
  var virginiacavaliersHalftimeU = 100 - virginiacavaliersHalftimeUnder;

  var vcuramsU = 100 - vcuramsUnder;
  var vcuramsSoloU = 100 - vcuramsSoloUnder;
  var vcuramsHalftimeU = 100 - vcuramsHalftimeUnder;

  var vmikeydetsU = 100 - vmikeydetsUnder;
  var vmikeydetsSoloU = 100 - vmikeydetsSoloUnder;
  var vmikeydetsHalftimeU = 100 - vmikeydetsHalftimeUnder;

  var virginiatechhokiesU = 100 - virginiatechhokiesUnder;
  var virginiatechhokiesSoloU = 100 - virginiatechhokiesSoloUnder;
  var virginiatechhokiesHalftimeU = 100 - virginiatechhokiesHalftimeUnder;

  var wagnerseahawksU = 100 - wagnerseahawksUnder;
  var wagnerseahawksSoloU = 100 - wagnerseahawksSoloUnder;
  var wagnerseahawksHalftimeU = 100 - wagnerseahawksHalftimeUnder;

  var wakeforestdemondeaconsU = 100 - wakeforestdemondeaconsUnder;
  var wakeforestdemondeaconsSoloU = 100 - wakeforestdemondeaconsSoloUnder;
  var wakeforestdemondeaconsHalftimeU = 100 - wakeforestdemondeaconsHalftimeUnder;

  var washingtonhuskiesU = 100 - washingtonhuskiesUnder;
  var washingtonhuskiesSoloU = 100 - washingtonhuskiesSoloUnder;
  var washingtonhuskiesHalftimeU = 100 - washingtonhuskiesHalftimeUnder;

  var washingtonstatecougarsU = 100 - washingtonstatecougarsUnder;
  var washingtonstatecougarsSoloU = 100 - washingtonstatecougarsSoloUnder;
  var washingtonstatecougarsHalftimeU = 100 - washingtonstatecougarsHalftimeUnder;

  var weberstatewildcatsU = 100 - weberstatewildcatsUnder;
  var weberstatewildcatsSoloU = 100 - weberstatewildcatsSoloUnder;
  var weberstatewildcatsHalftimeU = 100 - weberstatewildcatsHalftimeUnder;

  var westvirginiamountaineersU = 100 - westvirginiamountaineersUnder;
  var westvirginiamountaineersSoloU = 100 - westvirginiamountaineersSoloUnder;
  var westvirginiamountaineersHalftimeU = 100 - westvirginiamountaineersHalftimeUnder;

  var westerncarolinacatamountsU = 100 - westerncarolinacatamountsUnder;
  var westerncarolinacatamountsSoloU = 100 - westerncarolinacatamountsSoloUnder;
  var westerncarolinacatamountsHalftimeU = 100 - westerncarolinacatamountsHalftimeUnder;

  var westernillinoisleathernecksU = 100 - westernillinoisleathernecksUnder;
  var westernillinoisleathernecksSoloU = 100 - westernillinoisleathernecksSoloUnder;
  var westernillinoisleathernecksHalftimeU = 100 - westernillinoisleathernecksHalftimeUnder;

  var westernkentuckyhilltoppersU = 100 - westernkentuckyhilltoppersUnder;
  var westernkentuckyhilltoppersSoloU = 100 - westernkentuckyhilltoppersSoloUnder;
  var westernkentuckyhilltoppersHalftimeU = 100 - westernkentuckyhilltoppersHalftimeUnder;

  var westernmichiganbroncosU = 100 - westernmichiganbroncosUnder;
  var westernmichiganbroncosSoloU = 100 - westernmichiganbroncosSoloUnder;
  var westernmichiganbroncosHalftimeU = 100 - westernmichiganbroncosHalftimeUnder;

  var wichitastateshockersU = 100 - wichitastateshockersUnder;
  var wichitastateshockersSoloU = 100 - wichitastateshockersSoloUnder;
  var wichitastateshockersHalftimeU = 100 - wichitastateshockersHalftimeUnder;

  var williamandmarytribeU = 100 - williamandmarytribeUnder;
  var williamandmarytribeSoloU = 100 - williamandmarytribeSoloUnder;
  var williamandmarytribeHalftimeU = 100 - williamandmarytribeHalftimeUnder;

  var winthropeaglesU = 100 - winthropeaglesUnder;
  var winthropeaglesSoloU = 100 - winthropeaglesSoloUnder;
  var winthropeaglesHalftimeU = 100 - winthropeaglesHalftimeUnder;

  var greenbayphoenixU = 100 - greenbayphoenixUnder;
  var greenbayphoenixSoloU = 100 - greenbayphoenixSoloUnder;
  var greenbayphoenixHalftimeU = 100 - greenbayphoenixHalftimeUnder;

  var wisconsinbadgersU = 100 - wisconsinbadgersUnder;
  var wisconsinbadgersSoloU = 100 - wisconsinbadgersSoloUnder;
  var wisconsinbadgersHalftimeU = 100 - wisconsinbadgersHalftimeUnder;

  var milwaukeepanthersU = 100 - milwaukeepanthersUnder;
  var milwaukeepanthersSoloU = 100 - milwaukeepanthersSoloUnder;
  var milwaukeepanthersHalftimeU = 100 - milwaukeepanthersHalftimeUnder;

  var woffordterriersU = 100 - woffordterriersUnder;
  var woffordterriersSoloU = 100 - woffordterriersSoloUnder;
  var woffordterriersHalftimeU = 100 - woffordterriersHalftimeUnder;

  var wrightstateraidersU = 100 - wrightstateraidersUnder;
  var wrightstateraidersSoloU = 100 - wrightstateraidersSoloUnder;
  var wrightstateraidersHalftimeU = 100 - wrightstateraidersHalftimeUnder;

  var wyomingcowboysU = 100 - wyomingcowboysUnder;
  var wyomingcowboysSoloU = 100 - wyomingcowboysSoloUnder;
  var wyomingcowboysHalftimeU = 100 - wyomingcowboysHalftimeUnder;

  var xaviermusketeersU = 100 - xaviermusketeersUnder;
  var xaviermusketeersSoloU = 100 - xaviermusketeersSoloUnder;
  var xaviermusketeersHalftimeU = 100 - xaviermusketeersHalftimeUnder;

  var yalebulldogsU = 100 - yalebulldogsUnder;
  var yalebulldogsSoloU = 100 - yalebulldogsSoloUnder;
  var yalebulldogsHalftimeU = 100 - yalebulldogsHalftimeUnder;

  var youngstownstpenguinsU = 100 - youngstownstpenguinsUnder;
  var youngstownstpenguinsSoloU = 100 - youngstownstpenguinsSoloUnder;
  var youngstownstpenguinsHalftimeU = 100 - youngstownstpenguinsHalftimeUnder;



  // Team stats in order by team index & stat index
  var statLists = new Array(9)
statLists["ATS"] = [abilenechristianwildcatscover,akronzipscover,alabamacrimsontidecover,alabamaaandmbulldogscover,uabblazerscover,alabamastatehornetscover,albanygreatdanescover, alcornstatebravescover, americaneaglescover, appalachianstatemountaineerscover, arizonawildcatscover, arizonastatesundevilscover, arkansasrazorbackscover, littlerocktrojanscover, arkansaspinebluffgoldenlionscover, arkansasstredwolvescover, auburntigerscover, austinpeaygovernorscover, ballstatecardinalscover, baylorbearscover, belmontbruinscover, bethunecookmanwildcatscover, binghamtonbearcatscover, boisestatebroncoscover,bostoncollegeeaglescover, bostonunivterrierscover, bowlinggreenfalconscover, bradleybravescover, byucougarscover, brownbearscover, bryantbulldogscover, bucknellbisoncover, buffalobullscover, butlerbulldogscover, californiagoldenbearscover, ucdavisaggiescover, ucirvineanteaterscover, uclabruinscover, calpolymustangscover, ucriversidehighlanderscover, ucsantabarbaragauchoscover, csubakersfieldroadrunnerscover, fresnostatebulldogscover, csufullertontitanscover, longbeachstate49erscover, csunorthridgematadorscover, sacramentostatehornetscover, campbellfightingcamelscover, canisiusgoldengriffinscover, centralarkansasbearscover, centralconnecticutbluedevilscover, ucfknightscover, centralmichiganchippewascover, charlestoncougarscover,charlestonsouthernbuccaneerscover, chicagostatecougarscover, cincinnatibearcatscover,thecitadelbulldogscover, clemsontigerscover, clevelandstatevikingscover, coastalcarolinachanticleerscover, colgateraiderscover, coloradobuffaloescover, coloradostateramscover, columbialionscover, uconnhuskiescover, coppinstateeaglescover, cornellbigredcover, creightonbluejayscover,dartmouthbiggreencover, davidsonwildcatscover, daytonflyerscover,delawarebluehenscover, delawarestatehornetscover, denverpioneerscover, depaulbluedemonscover, detroitmercytitanscover, drakebulldogscover, drexeldragonscover, dukebluedevilscover,duquesnedukescover, easttennesseestatebuccaneerscover, easternillinoispantherscover, easternkentuckycolonelscover, easternmichiganeaglescover, elonphoenixcover, evansvillepurpleacescover, fairfieldstagscover, fairleighdickinsonknightscover, floridagatorscover, floridaaandmrattlerscover, floridaatlanticowlscover, floridagulfcoasteaglescover, floridainternationalpantherscover, floridastateseminolescover, fordhamramscover, furmanpaladinscover, gardnerwebbbulldogscover, georgemasonpatriotscover, georgewashingtoncolonialscover, georgetownhoyascover, georgiabulldogscover, georgiatechyellowjacketscover, georgiasoutherneaglescover, georgiastatepantherscover, gonzagabulldogscover, gramblingtigerscover, grandcanyonantelopescover, hamptonpiratescover, hartfordhawkscover, harvardcrimsoncover, hawaiirainbowwarriorscover, highpointpantherscover, hofstrapridecover, holycrosscrusaderscover, houstoncougarscover, houstonbaptisthuskiescover, howardbisoncover, idahovandalscover, idahostatebengalscover, uicflamescover, illinoisstateredbirdscover, illinoisfightingillinicover, incarnatewordcardinalscover, indianahoosierscover, indianastatesycamorescover, iupuijaguarscover, ionagaelscover, iowahawkeyescover, iowastatecyclonescover, jacksonstatetigerscover, jacksonvilledolphinscover, jacksonvillestategamecockscover, jamesmadisondukescover, kansasjayhawkscover, kansasstatewildcatscover, kennesawstateowlscover, kentstategoldenflashescover, kentuckywildcatscover, lasalleexplorerscover, lafayetteleopardscover, lamarcardinalscover, lehighmountainhawkscover, libertyflamescover, lipscombbisonscover, longislanduniversitysharkscover, longwoodlancerscover, louisianaragincajunscover, ulmonroewarhawkscover, lsutigerscover, louisianatechbulldogscover, louisvillecardinalscover, loyolachicagoramblerscover, loyolamdgreyhoundscover, loyolamarymountlionscover, maineblackbearscover, manhattanjasperscover, maristredfoxescover, marquettegoldeneaglescover, marshallthunderingherdcover, umbcretrieverscover, marylandterrapinscover, umassminutemencover, umasslowellriverhawkscover, mcneesestatecowboyscover, memphistigerscover, mercerbearscover, miamihurricanescover, miamiohredhawkscover, michiganwolverinescover, michiganstatespartanscover, middletennesseeblueraiderscover, minnesotagoldengopherscover, olemissrebelscover, mississippistatebulldogscover, mississippivalleystatedeltadevilscover, missouritigerscover, umkckangarooscover, missouristatebearscover, monmouthhawkscover, montanagrizzliescover, montanastatebobcatscover, moreheadstateeaglescover, morganstatebearscover, mtstmarysmountaineerscover, murraystateracerscover, nebraskacornhuskerscover, omahamaverickscover, unlvrebelscover, nevadawolfpackcover, newhampshirewildcatscover, njithighlanderscover, newmexicoloboscover, newmexicostateaggiescover, neworleansprivateerscover, niagarapurpleeaglescover, nichollscolonelscover, norfolkstatespartanscover, northcarolinaaandtaggiescover, uncashevillebulldogscover, northcarolinacentraleaglescover, northcarolinatarheelscover, charlotte49erscover, uncgreensborospartanscover, ncstatewolfpackcover, uncwilmingtonseahawkscover, northdakotafightinghawkscover, northdakotastatebisoncover, northfloridaospreyscover, northtexasmeangreencover, northeasternhuskiescover, northernarizonalumberjackscover, northerncoloradobearscover, northernillinoishuskiescover, northerniowapantherscover, northernkentuckynorsecover, northwesternwildcatscover, northwesternstatedemonscover, notredamefightingirishcover, oaklandgoldengrizzliescover, ohiobobcatscover, ohiostatebuckeyescover, oklahomasoonerscover, oklahomastatecowboyscover, olddominionmonarchscover, oralrobertsgoldeneaglescover, oregonduckscover, oregonstatebeaverscover, pacifictigerscover, pennsylvaniaquakerscover, pennstatenittanylionscover, pepperdinewavescover, pittsburghpantherscover, portlandpilotscover, portlandstatevikingscover, prairieviewaandmpantherscover, presbyterianbluehosecover, princetontigerscover, providencefriarscover, purdueboilermakerscover, purduefortwaynemastodonscover, quinnipiacbobcatscover, radfordhighlanderscover, rhodeislandramscover, riceowlscover, richmondspiderscover, riderbroncscover, robertmorriscolonialscover, rutgersscarletknightscover, sacredheartpioneerscover, stbonaventurebonniescover, stfrancisbknterrierscover, stfrancisparedflashcover, stjohnsredstormcover, saintjosephshawkscover, saintlouisbillikenscover, saintmarysgaelscover, saintpeterspeacockscover, samhoustonbearkatscover, samfordbulldogscover, sandiegotoreroscover, sandiegostateaztecscover, sanfranciscodonscover, sanjosestatespartanscover, santaclarabroncoscover, seattleredhawkscover, setonhallpiratescover, sienasaintscover, southalabamajaguarscover, southcarolinagamecockscover, southcarolinastatebulldogscover, southcarolinaupstatespartanscover, southdakotacoyotescover, southdakotastatejackrabbitscover, southfloridabullscover, semissouristredhawkscover, selouisianalionscover, southernjaguarscover, usctrojanscover, southernillinoissalukiscover, siuedwardsvillecougarscover, smumustangscover, southernmissgoldeneaglescover, southernutahthunderbirdscover, stanfordcardinalscover, stephenfaustinlumberjackscover, stetsonhatterscover, stonybrookseawolvescover, syracuseorangecover, templeowlscover, tennesseevolunteerscover, chattanoogamocscover, utmartinskyhawkscover, tennesseestatetigerscover, tennesseetechgoldeneaglescover, texasaandmaggiescover, texasaandmccislanderscover, utarlingtonmaverickscover, texaslonghornscover, tcuhornedfrogscover, utepminerscover, utriograndevalleyvaqueroscover, utsaroadrunnerscover, texassoutherntigerscover, texasstatebobcatscover, texastechredraiderscover, toledorocketscover, towsontigerscover, troytrojanscover, tulanegreenwavecover, tulsagoldenhurricanecover, airforcefalconscover, armyblackknightscover, navymidshipmencover, utahutescover, utahstateaggiescover, utahvalleywolverinescover, valparaisocrusaderscover, vanderbiltcommodorescover, vermontcatamountscover, villanovawildcatscover, virginiacavalierscover, vcuramscover, vmikeydetscover, virginiatechhokiescover, wagnerseahawkscover, wakeforestdemondeaconscover, washingtonhuskiescover, washingtonstatecougarscover, weberstatewildcatscover, westvirginiamountaineerscover, westerncarolinacatamountscover, westernillinoisleatherneckscover, westernmichiganbroncoscover, wichitastateshockerscover, williamandmarytribecover, winthropeaglescover, greenbayphoenixcover, wisconsinbadgerscover, milwaukeepantherscover, woffordterrierscover, wrightstateraiderscover, wyomingcowboyscover, xaviermusketeerscover, yalebulldogscover, youngstownstpenguinscover]
statLists["ML"] = [abilenechristianwildcatsML,akronzipsML,alabamacrimsontideML,alabamaaandmbulldogsML,uabblazersML,alabamastatehornetsML,albanygreatdanesML, alcornstatebravesML, americaneaglesML, appalachianstatemountaineersML, arizonawildcatsML, arizonastatesundevilsML, arkansasrazorbacksML, littlerocktrojansML, arkansaspinebluffgoldenlionsML, arkansasstredwolvesML, auburntigersML, austinpeaygovernorsML, ballstatecardinalsML, baylorbearsML, belmontbruinsML, bethunecookmanwildcatsML, binghamtonbearcatsML, boisestatebroncosML,bostoncollegeeaglesML, bostonunivterriersML, bowlinggreenfalconsML, bradleybravesML, byucougarsML, brownbearsML, bryantbulldogsML, bucknellbisonML, buffalobullsML, butlerbulldogsML, californiagoldenbearsML, ucdavisaggiesML, ucirvineanteatersML, uclabruinsML, calpolymustangsML, ucriversidehighlandersML, ucsantabarbaragauchosML, csubakersfieldroadrunnersML, fresnostatebulldogsML, csufullertontitansML, longbeachstate49ersML, csunorthridgematadorsML, sacramentostatehornetsML, campbellfightingcamelsML, canisiusgoldengriffinsML, centralarkansasbearsML, centralconnecticutbluedevilsML, ucfknightsML, centralmichiganchippewasML, charlestoncougarsML,charlestonsouthernbuccaneersML, chicagostatecougarsML, cincinnatibearcatsML,thecitadelbulldogsML, clemsontigersML, clevelandstatevikingsML, coastalcarolinachanticleersML, colgateraidersML, coloradobuffaloesML, coloradostateramsML, columbialionsML, uconnhuskiesML, coppinstateeaglesML, cornellbigredML, creightonbluejaysML,dartmouthbiggreenML, davidsonwildcatsML, daytonflyersML,delawarebluehensML, delawarestatehornetsML, denverpioneersML, depaulbluedemonsML, detroitmercytitansML, drakebulldogsML, drexeldragonsML, dukebluedevilsML,duquesnedukesML, easttennesseestatebuccaneersML, easternillinoispanthersML, easternkentuckycolonelsML, easternmichiganeaglesML, elonphoenixML, evansvillepurpleacesML, fairfieldstagsML, fairleighdickinsonknightsML, floridagatorsML, floridaaandmrattlersML, floridaatlanticowlsML, floridagulfcoasteaglesML, floridainternationalpanthersML, floridastateseminolesML, fordhamramsML, furmanpaladinsML, gardnerwebbbulldogsML, georgemasonpatriotsML, georgewashingtoncolonialsML, georgetownhoyasML, georgiabulldogsML, georgiatechyellowjacketsML, georgiasoutherneaglesML, georgiastatepanthersML, gonzagabulldogsML, gramblingtigersML, grandcanyonantelopesML, hamptonpiratesML, hartfordhawksML, harvardcrimsonML, hawaiirainbowwarriorsML, highpointpanthersML, hofstraprideML, holycrosscrusadersML, houstoncougarsML, houstonbaptisthuskiesML, howardbisonML, idahovandalsML, idahostatebengalsML, uicflamesML, illinoisstateredbirdsML, illinoisfightingilliniML, incarnatewordcardinalsML, indianahoosiersML, indianastatesycamoresML, iupuijaguarsML, ionagaelsML, iowahawkeyesML, iowastatecyclonesML, jacksonstatetigersML, jacksonvilledolphinsML, jacksonvillestategamecocksML, jamesmadisondukesML, kansasjayhawksML, kansasstatewildcatsML, kennesawstateowlsML, kentstategoldenflashesML, kentuckywildcatsML, lasalleexplorersML, lafayetteleopardsML, lamarcardinalsML, lehighmountainhawksML, libertyflamesML, lipscombbisonsML, longislanduniversitysharksML, longwoodlancersML, louisianaragincajunsML, ulmonroewarhawksML, lsutigersML, louisianatechbulldogsML, louisvillecardinalsML, loyolachicagoramblersML, loyolamdgreyhoundsML, loyolamarymountlionsML, maineblackbearsML, manhattanjaspersML, maristredfoxesML, marquettegoldeneaglesML, marshallthunderingherdML, umbcretrieversML, marylandterrapinsML, umassminutemenML, umasslowellriverhawksML, mcneesestatecowboysML, memphistigersML, mercerbearsML, miamihurricanesML, miamiohredhawksML, michiganwolverinesML, michiganstatespartansML, middletennesseeblueraidersML, minnesotagoldengophersML, olemissrebelsML, mississippistatebulldogsML, mississippivalleystatedeltadevilsML, missouritigersML, umkckangaroosML, missouristatebearsML, monmouthhawksML, montanagrizzliesML, montanastatebobcatsML, moreheadstateeaglesML, morganstatebearsML, mtstmarysmountaineersML, murraystateracersML, nebraskacornhuskersML, omahamavericksML, unlvrebelsML, nevadawolfpackML, newhampshirewildcatsML, njithighlandersML, newmexicolobosML, newmexicostateaggiesML, neworleansprivateersML, niagarapurpleeaglesML, nichollscolonelsML, norfolkstatespartansML, northcarolinaaandtaggiesML, uncashevillebulldogsML, northcarolinacentraleaglesML, northcarolinatarheelsML, charlotte49ersML, uncgreensborospartansML, ncstatewolfpackML, uncwilmingtonseahawksML, northdakotafightinghawksML, northdakotastatebisonML, northfloridaospreysML, northtexasmeangreenML, northeasternhuskiesML, northernarizonalumberjacksML, northerncoloradobearsML, northernillinoishuskiesML, northerniowapanthersML, northernkentuckynorseML, northwesternwildcatsML, northwesternstatedemonsML, notredamefightingirishML, oaklandgoldengrizzliesML, ohiobobcatsML, ohiostatebuckeyesML, oklahomasoonersML, oklahomastatecowboysML, olddominionmonarchsML, oralrobertsgoldeneaglesML, oregonducksML, oregonstatebeaversML, pacifictigersML, pennsylvaniaquakersML, pennstatenittanylionsML, pepperdinewavesML, pittsburghpanthersML, portlandpilotsML, portlandstatevikingsML, prairieviewaandmpanthersML, presbyterianbluehoseML, princetontigersML, providencefriarsML, purdueboilermakersML, purduefortwaynemastodonsML, quinnipiacbobcatsML, radfordhighlandersML, rhodeislandramsML, riceowlsML, richmondspidersML, riderbroncsML, robertmorriscolonialsML, rutgersscarletknightsML, sacredheartpioneersML, stbonaventurebonniesML, stfrancisbknterriersML, stfrancisparedflashML, stjohnsredstormML, saintjosephshawksML, saintlouisbillikensML, saintmarysgaelsML, saintpeterspeacocksML, samhoustonbearkatsML, samfordbulldogsML, sandiegotorerosML, sandiegostateaztecsML, sanfranciscodonsML, sanjosestatespartansML, santaclarabroncosML, seattleredhawksML, setonhallpiratesML, sienasaintsML, southalabamajaguarsML, southcarolinagamecocksML, southcarolinastatebulldogsML, southcarolinaupstatespartansML, southdakotacoyotesML, southdakotastatejackrabbitsML, southfloridabullsML, semissouristredhawksML, selouisianalionsML, southernjaguarsML, usctrojansML, southernillinoissalukisML, siuedwardsvillecougarsML, smumustangsML, southernmissgoldeneaglesML, southernutahthunderbirdsML, stanfordcardinalsML, stephenfaustinlumberjacksML, stetsonhattersML, stonybrookseawolvesML, syracuseorangeML, templeowlsML, tennesseevolunteersML, chattanoogamocsML, utmartinskyhawksML, tennesseestatetigersML, tennesseetechgoldeneaglesML, texasaandmaggiesML, texasaandmccislandersML, utarlingtonmavericksML, texaslonghornsML, tcuhornedfrogsML, utepminersML, utriograndevalleyvaquerosML, utsaroadrunnersML, texassoutherntigersML, texasstatebobcatsML, texastechredraidersML, toledorocketsML, towsontigersML, troytrojansML, tulanegreenwaveML, tulsagoldenhurricaneML, airforcefalconsML, armyblackknightsML, navymidshipmenML, utahutesML, utahstateaggiesML, utahvalleywolverinesML, valparaisocrusadersML, vanderbiltcommodoresML, vermontcatamountsML, villanovawildcatsML, virginiacavaliersML, vcuramsML, vmikeydetsML, virginiatechhokiesML, wagnerseahawksML, wakeforestdemondeaconsML, washingtonhuskiesML, washingtonstatecougarsML, weberstatewildcatsML, westvirginiamountaineersML, westerncarolinacatamountsML, westernillinoisleathernecksML, westernmichiganbroncosML, wichitastateshockersML, williamandmarytribeML, winthropeaglesML, greenbayphoenixML, wisconsinbadgersML, milwaukeepanthersML, woffordterriersML, wrightstateraidersML, wyomingcowboysML, xaviermusketeersML, yalebulldogsML, youngstownstpenguinsML]
statLists["Over"] = [abilenechristianwildcatsO,akronzipsO,alabamacrimsontideO,alabamaaandmbulldogsO,uabblazersO,alabamastatehornetsO,albanygreatdanesO, alcornstatebravesO, americaneaglesO, appalachianstatemountaineersO, arizonawildcatsO, arizonastatesundevilsO, arkansasrazorbacksO, littlerocktrojansO, arkansaspinebluffgoldenlionsO, arkansasstredwolvesO, auburntigersO, austinpeaygovernorsO, ballstatecardinalsO, baylorbearsO, belmontbruinsO, bethunecookmanwildcatsO, binghamtonbearcatsO, boisestatebroncosO,bostoncollegeeaglesO, bostonunivterriersO, bowlinggreenfalconsO, bradleybravesO, byucougarsO, brownbearsO, bryantbulldogsO, bucknellbisonO, buffalobullsO, butlerbulldogsO, californiagoldenbearsO, ucdavisaggiesO, ucirvineanteatersO, uclabruinsO, calpolymustangsO, ucriversidehighlandersO, ucsantabarbaragauchosO, csubakersfieldroadrunnersO, fresnostatebulldogsO, csufullertontitansO, longbeachstate49ersO, csunorthridgematadorsO, sacramentostatehornetsO, campbellfightingcamelsO, canisiusgoldengriffinsO, centralarkansasbearsO, centralconnecticutbluedevilsO, ucfknightsO, centralmichiganchippewasO, charlestoncougarsO,charlestonsouthernbuccaneersO, chicagostatecougarsO, cincinnatibearcatsO,thecitadelbulldogsO, clemsontigersO, clevelandstatevikingsO, coastalcarolinachanticleersO, colgateraidersO, coloradobuffaloesO, coloradostateramsO, columbialionsO, uconnhuskiesO, coppinstateeaglesO, cornellbigredO, creightonbluejaysO,dartmouthbiggreenO, davidsonwildcatsO, daytonflyersO,delawarebluehensO, delawarestatehornetsO, denverpioneersO, depaulbluedemonsO, detroitmercytitansO, drakebulldogsO, drexeldragonsO, dukebluedevilsO,duquesnedukesO, easttennesseestatebuccaneersO, easternillinoispanthersO, easternkentuckycolonelsO, easternmichiganeaglesO, elonphoenixO, evansvillepurpleacesO, fairfieldstagsO, fairleighdickinsonknightsO, floridagatorsO, floridaaandmrattlersO, floridaatlanticowlsO, floridagulfcoasteaglesO, floridainternationalpanthersO, floridastateseminolesO, fordhamramsO, furmanpaladinsO, gardnerwebbbulldogsO, georgemasonpatriotsO, georgewashingtoncolonialsO, georgetownhoyasO, georgiabulldogsO, georgiatechyellowjacketsO, georgiasoutherneaglesO, georgiastatepanthersO, gonzagabulldogsO, gramblingtigersO, grandcanyonantelopesO, hamptonpiratesO, hartfordhawksO, harvardcrimsonO, hawaiirainbowwarriorsO, highpointpanthersO, hofstraprideO, holycrosscrusadersO, houstoncougarsO, houstonbaptisthuskiesO, howardbisonO, idahovandalsO, idahostatebengalsO, uicflamesO, illinoisstateredbirdsO, illinoisfightingilliniO, incarnatewordcardinalsO, indianahoosiersO, indianastatesycamoresO, iupuijaguarsO, ionagaelsO, iowahawkeyesO, iowastatecyclonesO, jacksonstatetigersO, jacksonvilledolphinsO, jacksonvillestategamecocksO, jamesmadisondukesO, kansasjayhawksO, kansasstatewildcatsO, kennesawstateowlsO, kentstategoldenflashesO, kentuckywildcatsO, lasalleexplorersO, lafayetteleopardsO, lamarcardinalsO, lehighmountainhawksO, libertyflamesO, lipscombbisonsO, longislanduniversitysharksO, longwoodlancersO, louisianaragincajunsO, ulmonroewarhawksO, lsutigersO, louisianatechbulldogsO, louisvillecardinalsO, loyolachicagoramblersO, loyolamdgreyhoundsO, loyolamarymountlionsO, maineblackbearsO, manhattanjaspersO, maristredfoxesO, marquettegoldeneaglesO, marshallthunderingherdO, umbcretrieversO, marylandterrapinsO, umassminutemenO, umasslowellriverhawksO, mcneesestatecowboysO, memphistigersO, mercerbearsO, miamihurricanesO, miamiohredhawksO, michiganwolverinesO, michiganstatespartansO, middletennesseeblueraidersO, minnesotagoldengophersO, olemissrebelsO, mississippistatebulldogsO, mississippivalleystatedeltadevilsO, missouritigersO, umkckangaroosO, missouristatebearsO, monmouthhawksO, montanagrizzliesO, montanastatebobcatsO, moreheadstateeaglesO, morganstatebearsO, mtstmarysmountaineersO, murraystateracersO, nebraskacornhuskersO, omahamavericksO, unlvrebelsO, nevadawolfpackO, newhampshirewildcatsO, njithighlandersO, newmexicolobosO, newmexicostateaggiesO, neworleansprivateersO, niagarapurpleeaglesO, nichollscolonelsO, norfolkstatespartansO, northcarolinaaandtaggiesO, uncashevillebulldogsO, northcarolinacentraleaglesO, northcarolinatarheelsO, charlotte49ersO, uncgreensborospartansO, ncstatewolfpackO, uncwilmingtonseahawksO, northdakotafightinghawksO, northdakotastatebisonO, northfloridaospreysO, northtexasmeangreenO, northeasternhuskiesO, northernarizonalumberjacksO, northerncoloradobearsO, northernillinoishuskiesO, northerniowapanthersO, northernkentuckynorseO, northwesternwildcatsO, northwesternstatedemonsO, notredamefightingirishO, oaklandgoldengrizzliesO, ohiobobcatsO, ohiostatebuckeyesO, oklahomasoonersO, oklahomastatecowboysO, olddominionmonarchsO, oralrobertsgoldeneaglesO, oregonducksO, oregonstatebeaversO, pacifictigersO, pennsylvaniaquakersO, pennstatenittanylionsO, pepperdinewavesO, pittsburghpanthersO, portlandpilotsO, portlandstatevikingsO, prairieviewaandmpanthersO, presbyterianbluehoseO, princetontigersO, providencefriarsO, purdueboilermakersO, purduefortwaynemastodonsO, quinnipiacbobcatsO, radfordhighlandersO, rhodeislandramsO, riceowlsO, richmondspidersO, riderbroncsO, robertmorriscolonialsO, rutgersscarletknightsO, sacredheartpioneersO, stbonaventurebonniesO, stfrancisbknterriersO, stfrancisparedflashO, stjohnsredstormO, saintjosephshawksO, saintlouisbillikensO, saintmarysgaelsO, saintpeterspeacocksO, samhoustonbearkatsO, samfordbulldogsO, sandiegotorerosO, sandiegostateaztecsO, sanfranciscodonsO, sanjosestatespartansO, santaclarabroncosO, seattleredhawksO, setonhallpiratesO, sienasaintsO, southalabamajaguarsO, southcarolinagamecocksO, southcarolinastatebulldogsO, southcarolinaupstatespartansO, southdakotacoyotesO, southdakotastatejackrabbitsO, southfloridabullsO, semissouristredhawksO, selouisianalionsO, southernjaguarsO, usctrojansO, southernillinoissalukisO, siuedwardsvillecougarsO, smumustangsO, southernmissgoldeneaglesO, southernutahthunderbirdsO, stanfordcardinalsO, stephenfaustinlumberjacksO, stetsonhattersO, stonybrookseawolvesO, syracuseorangeO, templeowlsO, tennesseevolunteersO, chattanoogamocsO, utmartinskyhawksO, tennesseestatetigersO, tennesseetechgoldeneaglesO, texasaandmaggiesO, texasaandmccislandersO, utarlingtonmavericksO, texaslonghornsO, tcuhornedfrogsO, utepminersO, utriograndevalleyvaquerosO, utsaroadrunnersO, texassoutherntigersO, texasstatebobcatsO, texastechredraidersO, toledorocketsO, towsontigersO, troytrojansO, tulanegreenwaveO, tulsagoldenhurricaneO, airforcefalconsO, armyblackknightsO, navymidshipmenO, utahutesO, utahstateaggiesO, utahvalleywolverinesO, valparaisocrusadersO, vanderbiltcommodoresO, vermontcatamountsO, villanovawildcatsO, virginiacavaliersO, vcuramsO, vmikeydetsO, virginiatechhokiesO, wagnerseahawksO, wakeforestdemondeaconsO, washingtonhuskiesO, washingtonstatecougarsO, weberstatewildcatsO, westvirginiamountaineersO, westerncarolinacatamountsO, westernillinoisleathernecksO, westernmichiganbroncosO, wichitastateshockersO, williamandmarytribeO, winthropeaglesO, greenbayphoenixO, wisconsinbadgersO, milwaukeepanthersO, woffordterriersO, wrightstateraidersO, wyomingcowboysO, xaviermusketeersO, yalebulldogsO, youngstownstpenguinsO]
statLists["Under"] = [abilenechristianwildcatsU,akronzipsU,alabamacrimsontideU,alabamaaandmbulldogsU,uabblazersU,alabamastatehornetsU,albanygreatdanesU, alcornstatebravesU, americaneaglesU, appalachianstatemountaineersU, arizonawildcatsU, arizonastatesundevilsU, arkansasrazorbacksU, littlerocktrojansU, arkansaspinebluffgoldenlionsU, arkansasstredwolvesU, auburntigersU, austinpeaygovernorsU, ballstatecardinalsU, baylorbearsU, belmontbruinsU, bethunecookmanwildcatsU, binghamtonbearcatsU, boisestatebroncosU,bostoncollegeeaglesU, bostonunivterriersU, bowlinggreenfalconsU, bradleybravesU, byucougarsU, brownbearsU, bryantbulldogsU, bucknellbisonU, buffalobullsU, butlerbulldogsU, californiagoldenbearsU, ucdavisaggiesU, ucirvineanteatersU, uclabruinsU, calpolymustangsU, ucriversidehighlandersU, ucsantabarbaragauchosU, csubakersfieldroadrunnersU, fresnostatebulldogsU, csufullertontitansU, longbeachstate49ersU, csunorthridgematadorsU, sacramentostatehornetsU, campbellfightingcamelsU, canisiusgoldengriffinsU, centralarkansasbearsU, centralconnecticutbluedevilsU, ucfknightsU, centralmichiganchippewasU, charlestoncougarsU,charlestonsouthernbuccaneersU, chicagostatecougarsU, cincinnatibearcatsU,thecitadelbulldogsU, clemsontigersU, clevelandstatevikingsU, coastalcarolinachanticleersU, colgateraidersU, coloradobuffaloesU, coloradostateramsU, columbialionsU, uconnhuskiesU, coppinstateeaglesU, cornellbigredU, creightonbluejaysU,dartmouthbiggreenU, davidsonwildcatsU, daytonflyersU,delawarebluehensU, delawarestatehornetsU, denverpioneersU, depaulbluedemonsU, detroitmercytitansU, drakebulldogsU, drexeldragonsU, dukebluedevilsU,duquesnedukesU, easttennesseestatebuccaneersU, easternillinoispanthersU, easternkentuckycolonelsU, easternmichiganeaglesU, elonphoenixU, evansvillepurpleacesU, fairfieldstagsU, fairleighdickinsonknightsU, floridagatorsU, floridaaandmrattlersU, floridaatlanticowlsU, floridagulfcoasteaglesU, floridainternationalpanthersU, floridastateseminolesU, fordhamramsU, furmanpaladinsU, gardnerwebbbulldogsU, georgemasonpatriotsU, georgewashingtoncolonialsU, georgetownhoyasU, georgiabulldogsU, georgiatechyellowjacketsU, georgiasoutherneaglesU, georgiastatepanthersU, gonzagabulldogsU, gramblingtigersU, grandcanyonantelopesU, hamptonpiratesU, hartfordhawksU, harvardcrimsonU, hawaiirainbowwarriorsU, highpointpanthersU, hofstraprideU, holycrosscrusadersU, houstoncougarsU, houstonbaptisthuskiesU, howardbisonU, idahovandalsU, idahostatebengalsU, uicflamesU, illinoisstateredbirdsU, illinoisfightingilliniU, incarnatewordcardinalsU, indianahoosiersU, indianastatesycamoresU, iupuijaguarsU, ionagaelsU, iowahawkeyesU, iowastatecyclonesU, jacksonstatetigersU, jacksonvilledolphinsU, jacksonvillestategamecocksU, jamesmadisondukesU, kansasjayhawksU, kansasstatewildcatsU, kennesawstateowlsU, kentstategoldenflashesU, kentuckywildcatsU, lasalleexplorersU, lafayetteleopardsU, lamarcardinalsU, lehighmountainhawksU, libertyflamesU, lipscombbisonsU, longislanduniversitysharksU, longwoodlancersU, louisianaragincajunsU, ulmonroewarhawksU, lsutigersU, louisianatechbulldogsU, louisvillecardinalsU, loyolachicagoramblersU, loyolamdgreyhoundsU, loyolamarymountlionsU, maineblackbearsU, manhattanjaspersU, maristredfoxesU, marquettegoldeneaglesU, marshallthunderingherdU, umbcretrieversU, marylandterrapinsU, umassminutemenU, umasslowellriverhawksU, mcneesestatecowboysU, memphistigersU, mercerbearsU, miamihurricanesU, miamiohredhawksU, michiganwolverinesU, michiganstatespartansU, middletennesseeblueraidersU, minnesotagoldengophersU, olemissrebelsU, mississippistatebulldogsU, mississippivalleystatedeltadevilsU, missouritigersU, umkckangaroosU, missouristatebearsU, monmouthhawksU, montanagrizzliesU, montanastatebobcatsU, moreheadstateeaglesU, morganstatebearsU, mtstmarysmountaineersU, murraystateracersU, nebraskacornhuskersU, omahamavericksU, unlvrebelsU, nevadawolfpackU, newhampshirewildcatsU, njithighlandersU, newmexicolobosU, newmexicostateaggiesU, neworleansprivateersU, niagarapurpleeaglesU, nichollscolonelsU, norfolkstatespartansU, northcarolinaaandtaggiesU, uncashevillebulldogsU, northcarolinacentraleaglesU, northcarolinatarheelsU, charlotte49ersU, uncgreensborospartansU, ncstatewolfpackU, uncwilmingtonseahawksU, northdakotafightinghawksU, northdakotastatebisonU, northfloridaospreysU, northtexasmeangreenU, northeasternhuskiesU, northernarizonalumberjacksU, northerncoloradobearsU, northernillinoishuskiesU, northerniowapanthersU, northernkentuckynorseU, northwesternwildcatsU, northwesternstatedemonsU, notredamefightingirishU, oaklandgoldengrizzliesU, ohiobobcatsU, ohiostatebuckeyesU, oklahomasoonersU, oklahomastatecowboysU, olddominionmonarchsU, oralrobertsgoldeneaglesU, oregonducksU, oregonstatebeaversU, pacifictigersU, pennsylvaniaquakersU, pennstatenittanylionsU, pepperdinewavesU, pittsburghpanthersU, portlandpilotsU, portlandstatevikingsU, prairieviewaandmpanthersU, presbyterianbluehoseU, princetontigersU, providencefriarsU, purdueboilermakersU, purduefortwaynemastodonsU, quinnipiacbobcatsU, radfordhighlandersU, rhodeislandramsU, riceowlsU, richmondspidersU, riderbroncsU, robertmorriscolonialsU, rutgersscarletknightsU, sacredheartpioneersU, stbonaventurebonniesU, stfrancisbknterriersU, stfrancisparedflashU, stjohnsredstormU, saintjosephshawksU, saintlouisbillikensU, saintmarysgaelsU, saintpeterspeacocksU, samhoustonbearkatsU, samfordbulldogsU, sandiegotorerosU, sandiegostateaztecsU, sanfranciscodonsU, sanjosestatespartansU, santaclarabroncosU, seattleredhawksU, setonhallpiratesU, sienasaintsU, southalabamajaguarsU, southcarolinagamecocksU, southcarolinastatebulldogsU, southcarolinaupstatespartansU, southdakotacoyotesU, southdakotastatejackrabbitsU, southfloridabullsU, semissouristredhawksU, selouisianalionsU, southernjaguarsU, usctrojansU, southernillinoissalukisU, siuedwardsvillecougarsU, smumustangsU, southernmissgoldeneaglesU, southernutahthunderbirdsU, stanfordcardinalsU, stephenfaustinlumberjacksU, stetsonhattersU, stonybrookseawolvesU, syracuseorangeU, templeowlsU, tennesseevolunteersU, chattanoogamocsU, utmartinskyhawksU, tennesseestatetigersU, tennesseetechgoldeneaglesU, texasaandmaggiesU, texasaandmccislandersU, utarlingtonmavericksU, texaslonghornsU, tcuhornedfrogsU, utepminersU, utriograndevalleyvaquerosU, utsaroadrunnersU, texassoutherntigersU, texasstatebobcatsU, texastechredraidersU, toledorocketsU, towsontigersU, troytrojansU, tulanegreenwaveU, tulsagoldenhurricaneU, airforcefalconsU, armyblackknightsU, navymidshipmenU, utahutesU, utahstateaggiesU, utahvalleywolverinesU, valparaisocrusadersU, vanderbiltcommodoresU, vermontcatamountsU, villanovawildcatsU, virginiacavaliersU, vcuramsU, vmikeydetsU, virginiatechhokiesU, wagnerseahawksU, wakeforestdemondeaconsU, washingtonhuskiesU, washingtonstatecougarsU, weberstatewildcatsU, westvirginiamountaineersU, westerncarolinacatamountsU, westernillinoisleathernecksU, westernmichiganbroncosU, wichitastateshockersU, williamandmarytribeU, winthropeaglesU, greenbayphoenixU, wisconsinbadgersU, milwaukeepanthersU, woffordterriersU, wrightstateraidersU, wyomingcowboysU, xaviermusketeersU, yalebulldogsU, youngstownstpenguinsU]
statLists["Solo Over"] = [abilenechristianwildcatsSoloO,akronzipsSoloO,alabamacrimsontideSoloO,alabamaaandmbulldogsSoloO,uabblazersSoloO,alabamastatehornetsSoloO,albanygreatdanesSoloO, alcornstatebravesSoloO, americaneaglesSoloO, appalachianstatemountaineersSoloO, arizonawildcatsSoloO, arizonastatesundevilsSoloO, arkansasrazorbacksSoloO, littlerocktrojansSoloO, arkansaspinebluffgoldenlionsSoloO, arkansasstredwolvesSoloO, auburntigersSoloO, austinpeaygovernorsSoloO, ballstatecardinalsSoloO, baylorbearsSoloO, belmontbruinsSoloO, bethunecookmanwildcatsSoloO, binghamtonbearcatsSoloO, boisestatebroncosSoloO,bostoncollegeeaglesSoloO, bostonunivterriersSoloO, bowlinggreenfalconsSoloO, bradleybravesSoloO, byucougarsSoloO, brownbearsSoloO, bryantbulldogsSoloO, bucknellbisonSoloO, buffalobullsSoloO, butlerbulldogsSoloO, californiagoldenbearsSoloO, ucdavisaggiesSoloO, ucirvineanteatersSoloO, uclabruinsSoloO, calpolymustangsSoloO, ucriversidehighlandersSoloO, ucsantabarbaragauchosSoloO, csubakersfieldroadrunnersSoloO, fresnostatebulldogsSoloO, csufullertontitansSoloO, longbeachstate49ersSoloO, csunorthridgematadorsSoloO, sacramentostatehornetsSoloO, campbellfightingcamelsSoloO, canisiusgoldengriffinsSoloO, centralarkansasbearsSoloO, centralconnecticutbluedevilsSoloO, ucfknightsSoloO, centralmichiganchippewasSoloO, charlestoncougarsSoloO,charlestonsouthernbuccaneersSoloO, chicagostatecougarsSoloO, cincinnatibearcatsSoloO,thecitadelbulldogsSoloO, clemsontigersSoloO, clevelandstatevikingsSoloO, coastalcarolinachanticleersSoloO, colgateraidersSoloO, coloradobuffaloesSoloO, coloradostateramsSoloO, columbialionsSoloO, uconnhuskiesSoloO, coppinstateeaglesSoloO, cornellbigredSoloO, creightonbluejaysSoloO,dartmouthbiggreenSoloO, davidsonwildcatsSoloO, daytonflyersSoloO,delawarebluehensSoloO, delawarestatehornetsSoloO, denverpioneersSoloO, depaulbluedemonsSoloO, detroitmercytitansSoloO, drakebulldogsSoloO, drexeldragonsSoloO, dukebluedevilsSoloO,duquesnedukesSoloO, easttennesseestatebuccaneersSoloO, easternillinoispanthersSoloO, easternkentuckycolonelsSoloO, easternmichiganeaglesSoloO, elonphoenixSoloO, evansvillepurpleacesSoloO, fairfieldstagsSoloO, fairleighdickinsonknightsSoloO, floridagatorsSoloO, floridaaandmrattlersSoloO, floridaatlanticowlsSoloO, floridagulfcoasteaglesSoloO, floridainternationalpanthersSoloO, floridastateseminolesSoloO, fordhamramsSoloO, furmanpaladinsSoloO, gardnerwebbbulldogsSoloO, georgemasonpatriotsSoloO, georgewashingtoncolonialsSoloO, georgetownhoyasSoloO, georgiabulldogsSoloO, georgiatechyellowjacketsSoloO, georgiasoutherneaglesSoloO, georgiastatepanthersSoloO, gonzagabulldogsSoloO, gramblingtigersSoloO, grandcanyonantelopesSoloO, hamptonpiratesSoloO, hartfordhawksSoloO, harvardcrimsonSoloO, hawaiirainbowwarriorsSoloO, highpointpanthersSoloO, hofstraprideSoloO, holycrosscrusadersSoloO, houstoncougarsSoloO, houstonbaptisthuskiesSoloO, howardbisonSoloO, idahovandalsSoloO, idahostatebengalsSoloO, uicflamesSoloO, illinoisstateredbirdsSoloO, illinoisfightingilliniSoloO, incarnatewordcardinalsSoloO, indianahoosiersSoloO, indianastatesycamoresSoloO, iupuijaguarsSoloO, ionagaelsSoloO, iowahawkeyesSoloO, iowastatecyclonesSoloO, jacksonstatetigersSoloO, jacksonvilledolphinsSoloO, jacksonvillestategamecocksSoloO, jamesmadisondukesSoloO, kansasjayhawksSoloO, kansasstatewildcatsSoloO, kennesawstateowlsSoloO, kentstategoldenflashesSoloO, kentuckywildcatsSoloO, lasalleexplorersSoloO, lafayetteleopardsSoloO, lamarcardinalsSoloO, lehighmountainhawksSoloO, libertyflamesSoloO, lipscombbisonsSoloO, longislanduniversitysharksSoloO, longwoodlancersSoloO, louisianaragincajunsSoloO, ulmonroewarhawksSoloO, lsutigersSoloO, louisianatechbulldogsSoloO, louisvillecardinalsSoloO, loyolachicagoramblersSoloO, loyolamdgreyhoundsSoloO, loyolamarymountlionsSoloO, maineblackbearsSoloO, manhattanjaspersSoloO, maristredfoxesSoloO, marquettegoldeneaglesSoloO, marshallthunderingherdSoloO, umbcretrieversSoloO, marylandterrapinsSoloO, umassminutemenSoloO, umasslowellriverhawksSoloO, mcneesestatecowboysSoloO, memphistigersSoloO, mercerbearsSoloO, miamihurricanesSoloO, miamiohredhawksSoloO, michiganwolverinesSoloO, michiganstatespartansSoloO, middletennesseeblueraidersSoloO, minnesotagoldengophersSoloO, olemissrebelsSoloO, mississippistatebulldogsSoloO, mississippivalleystatedeltadevilsSoloO, missouritigersSoloO, umkckangaroosSoloO, missouristatebearsSoloO, monmouthhawksSoloO, montanagrizzliesSoloO, montanastatebobcatsSoloO, moreheadstateeaglesSoloO, morganstatebearsSoloO, mtstmarysmountaineersSoloO, murraystateracersSoloO, nebraskacornhuskersSoloO, omahamavericksSoloO, unlvrebelsSoloO, nevadawolfpackSoloO, newhampshirewildcatsSoloO, njithighlandersSoloO, newmexicolobosSoloO, newmexicostateaggiesSoloO, neworleansprivateersSoloO, niagarapurpleeaglesSoloO, nichollscolonelsSoloO, norfolkstatespartansSoloO, northcarolinaaandtaggiesSoloO, uncashevillebulldogsSoloO, northcarolinacentraleaglesSoloO, northcarolinatarheelsSoloO, charlotte49ersSoloO, uncgreensborospartansSoloO, ncstatewolfpackSoloO, uncwilmingtonseahawksSoloO, northdakotafightinghawksSoloO, northdakotastatebisonSoloO, northfloridaospreysSoloO, northtexasmeangreenSoloO, northeasternhuskiesSoloO, northernarizonalumberjacksSoloO, northerncoloradobearsSoloO, northernillinoishuskiesSoloO, northerniowapanthersSoloO, northernkentuckynorseSoloO, northwesternwildcatsSoloO, northwesternstatedemonsSoloO, notredamefightingirishSoloO, oaklandgoldengrizzliesSoloO, ohiobobcatsSoloO, ohiostatebuckeyesSoloO, oklahomasoonersSoloO, oklahomastatecowboysSoloO, olddominionmonarchsSoloO, oralrobertsgoldeneaglesSoloO, oregonducksSoloO, oregonstatebeaversSoloO, pacifictigersSoloO, pennsylvaniaquakersSoloO, pennstatenittanylionsSoloO, pepperdinewavesSoloO, pittsburghpanthersSoloO, portlandpilotsSoloO, portlandstatevikingsSoloO, prairieviewaandmpanthersSoloO, presbyterianbluehoseSoloO, princetontigersSoloO, providencefriarsSoloO, purdueboilermakersSoloO, purduefortwaynemastodonsSoloO, quinnipiacbobcatsSoloO, radfordhighlandersSoloO, rhodeislandramsSoloO, riceowlsSoloO, richmondspidersSoloO, riderbroncsSoloO, robertmorriscolonialsSoloO, rutgersscarletknightsSoloO, sacredheartpioneersSoloO, stbonaventurebonniesSoloO, stfrancisbknterriersSoloO, stfrancisparedflashSoloO, stjohnsredstormSoloO, saintjosephshawksSoloO, saintlouisbillikensSoloO, saintmarysgaelsSoloO, saintpeterspeacocksSoloO, samhoustonbearkatsSoloO, samfordbulldogsSoloO, sandiegotorerosSoloO, sandiegostateaztecsSoloO, sanfranciscodonsSoloO, sanjosestatespartansSoloO, santaclarabroncosSoloO, seattleredhawksSoloO, setonhallpiratesSoloO, sienasaintsSoloO, southalabamajaguarsSoloO, southcarolinagamecocksSoloO, southcarolinastatebulldogsSoloO, southcarolinaupstatespartansSoloO, southdakotacoyotesSoloO, southdakotastatejackrabbitsSoloO, southfloridabullsSoloO, semissouristredhawksSoloO, selouisianalionsSoloO, southernjaguarsSoloO, usctrojansSoloO, southernillinoissalukisSoloO, siuedwardsvillecougarsSoloO, smumustangsSoloO, southernmissgoldeneaglesSoloO, southernutahthunderbirdsSoloO, stanfordcardinalsSoloO, stephenfaustinlumberjacksSoloO, stetsonhattersSoloO, stonybrookseawolvesSoloO, syracuseorangeSoloO, templeowlsSoloO, tennesseevolunteersSoloO, chattanoogamocsSoloO, utmartinskyhawksSoloO, tennesseestatetigersSoloO, tennesseetechgoldeneaglesSoloO, texasaandmaggiesSoloO, texasaandmccislandersSoloO, utarlingtonmavericksSoloO, texaslonghornsSoloO, tcuhornedfrogsSoloO, utepminersSoloO, utriograndevalleyvaquerosSoloO, utsaroadrunnersSoloO, texassoutherntigersSoloO, texasstatebobcatsSoloO, texastechredraidersSoloO, toledorocketsSoloO, towsontigersSoloO, troytrojansSoloO, tulanegreenwaveSoloO, tulsagoldenhurricaneSoloO, airforcefalconsSoloO, armyblackknightsSoloO, navymidshipmenSoloO, utahutesSoloO, utahstateaggiesSoloO, utahvalleywolverinesSoloO, valparaisocrusadersSoloO, vanderbiltcommodoresSoloO, vermontcatamountsSoloO, villanovawildcatsSoloO, virginiacavaliersSoloO, vcuramsSoloO, vmikeydetsSoloO, virginiatechhokiesSoloO, wagnerseahawksSoloO, wakeforestdemondeaconsSoloO, washingtonhuskiesSoloO, washingtonstatecougarsSoloO, weberstatewildcatsSoloO, westvirginiamountaineersSoloO, westerncarolinacatamountsSoloO, westernillinoisleathernecksSoloO, westernmichiganbroncosSoloO, wichitastateshockersSoloO, williamandmarytribeSoloO, winthropeaglesSoloO, greenbayphoenixSoloO, wisconsinbadgersSoloO, milwaukeepanthersSoloO, woffordterriersSoloO, wrightstateraidersSoloO, wyomingcowboysSoloO, xaviermusketeersSoloO, yalebulldogsSoloO, youngstownstpenguinsSoloO]
statLists["Solo Under"] = [abilenechristianwildcatsSoloU,akronzipsSoloU,alabamacrimsontideSoloU,alabamaaandmbulldogsSoloU,uabblazersSoloU,alabamastatehornetsSoloU,albanygreatdanesSoloU, alcornstatebravesSoloU, americaneaglesSoloU, appalachianstatemountaineersSoloU, arizonawildcatsSoloU, arizonastatesundevilsSoloU, arkansasrazorbacksSoloU, littlerocktrojansSoloU, arkansaspinebluffgoldenlionsSoloU, arkansasstredwolvesSoloU, auburntigersSoloU, austinpeaygovernorsSoloU, ballstatecardinalsSoloU, baylorbearsSoloU, belmontbruinsSoloU, bethunecookmanwildcatsSoloU, binghamtonbearcatsSoloU, boisestatebroncosSoloU,bostoncollegeeaglesSoloU, bostonunivterriersSoloU, bowlinggreenfalconsSoloU, bradleybravesSoloU, byucougarsSoloU, brownbearsSoloU, bryantbulldogsSoloU, bucknellbisonSoloU, buffalobullsSoloU, butlerbulldogsSoloU, californiagoldenbearsSoloU, ucdavisaggiesSoloU, ucirvineanteatersSoloU, uclabruinsSoloU, calpolymustangsSoloU, ucriversidehighlandersSoloU, ucsantabarbaragauchosSoloU, csubakersfieldroadrunnersSoloU, fresnostatebulldogsSoloU, csufullertontitansSoloU, longbeachstate49ersSoloU, csunorthridgematadorsSoloU, sacramentostatehornetsSoloU, campbellfightingcamelsSoloU, canisiusgoldengriffinsSoloU, centralarkansasbearsSoloU, centralconnecticutbluedevilsSoloU, ucfknightsSoloU, centralmichiganchippewasSoloU, charlestoncougarsSoloU,charlestonsouthernbuccaneersSoloU, chicagostatecougarsSoloU, cincinnatibearcatsSoloU,thecitadelbulldogsSoloU, clemsontigersSoloU, clevelandstatevikingsSoloU, coastalcarolinachanticleersSoloU, colgateraidersSoloU, coloradobuffaloesSoloU, coloradostateramsSoloU, columbialionsSoloU, uconnhuskiesSoloU, coppinstateeaglesSoloU, cornellbigredSoloU, creightonbluejaysSoloU,dartmouthbiggreenSoloU, davidsonwildcatsSoloU, daytonflyersSoloU,delawarebluehensSoloU, delawarestatehornetsSoloU, denverpioneersSoloU, depaulbluedemonsSoloU, detroitmercytitansSoloU, drakebulldogsSoloU, drexeldragonsSoloU, dukebluedevilsSoloU,duquesnedukesSoloU, easttennesseestatebuccaneersSoloU, easternillinoispanthersSoloU, easternkentuckycolonelsSoloU, easternmichiganeaglesSoloU, elonphoenixSoloU, evansvillepurpleacesSoloU, fairfieldstagsSoloU, fairleighdickinsonknightsSoloU, floridagatorsSoloU, floridaaandmrattlersSoloU, floridaatlanticowlsSoloU, floridagulfcoasteaglesSoloU, floridainternationalpanthersSoloU, floridastateseminolesSoloU, fordhamramsSoloU, furmanpaladinsSoloU, gardnerwebbbulldogsSoloU, georgemasonpatriotsSoloU, georgewashingtoncolonialsSoloU, georgetownhoyasSoloU, georgiabulldogsSoloU, georgiatechyellowjacketsSoloU, georgiasoutherneaglesSoloU, georgiastatepanthersSoloU, gonzagabulldogsSoloU, gramblingtigersSoloU, grandcanyonantelopesSoloU, hamptonpiratesSoloU, hartfordhawksSoloU, harvardcrimsonSoloU, hawaiirainbowwarriorsSoloU, highpointpanthersSoloU, hofstraprideSoloU, holycrosscrusadersSoloU, houstoncougarsSoloU, houstonbaptisthuskiesSoloU, howardbisonSoloU, idahovandalsSoloU, idahostatebengalsSoloU, uicflamesSoloU, illinoisstateredbirdsSoloU, illinoisfightingilliniSoloU, incarnatewordcardinalsSoloU, indianahoosiersSoloU, indianastatesycamoresSoloU, iupuijaguarsSoloU, ionagaelsSoloU, iowahawkeyesSoloU, iowastatecyclonesSoloU, jacksonstatetigersSoloU, jacksonvilledolphinsSoloU, jacksonvillestategamecocksSoloU, jamesmadisondukesSoloU, kansasjayhawksSoloU, kansasstatewildcatsSoloU, kennesawstateowlsSoloU, kentstategoldenflashesSoloU, kentuckywildcatsSoloU, lasalleexplorersSoloU, lafayetteleopardsSoloU, lamarcardinalsSoloU, lehighmountainhawksSoloU, libertyflamesSoloU, lipscombbisonsSoloU, longislanduniversitysharksSoloU, longwoodlancersSoloU, louisianaragincajunsSoloU, ulmonroewarhawksSoloU, lsutigersSoloU, louisianatechbulldogsSoloU, louisvillecardinalsSoloU, loyolachicagoramblersSoloU, loyolamdgreyhoundsSoloU, loyolamarymountlionsSoloU, maineblackbearsSoloU, manhattanjaspersSoloU, maristredfoxesSoloU, marquettegoldeneaglesSoloU, marshallthunderingherdSoloU, umbcretrieversSoloU, marylandterrapinsSoloU, umassminutemenSoloU, umasslowellriverhawksSoloU, mcneesestatecowboysSoloU, memphistigersSoloU, mercerbearsSoloU, miamihurricanesSoloU, miamiohredhawksSoloU, michiganwolverinesSoloU, michiganstatespartansSoloU, middletennesseeblueraidersSoloU, minnesotagoldengophersSoloU, olemissrebelsSoloU, mississippistatebulldogsSoloU, mississippivalleystatedeltadevilsSoloU, missouritigersSoloU, umkckangaroosSoloU, missouristatebearsSoloU, monmouthhawksSoloU, montanagrizzliesSoloU, montanastatebobcatsSoloU, moreheadstateeaglesSoloU, morganstatebearsSoloU, mtstmarysmountaineersSoloU, murraystateracersSoloU, nebraskacornhuskersSoloU, omahamavericksSoloU, unlvrebelsSoloU, nevadawolfpackSoloU, newhampshirewildcatsSoloU, njithighlandersSoloU, newmexicolobosSoloU, newmexicostateaggiesSoloU, neworleansprivateersSoloU, niagarapurpleeaglesSoloU, nichollscolonelsSoloU, norfolkstatespartansSoloU, northcarolinaaandtaggiesSoloU, uncashevillebulldogsSoloU, northcarolinacentraleaglesSoloU, northcarolinatarheelsSoloU, charlotte49ersSoloU, uncgreensborospartansSoloU, ncstatewolfpackSoloU, uncwilmingtonseahawksSoloU, northdakotafightinghawksSoloU, northdakotastatebisonSoloU, northfloridaospreysSoloU, northtexasmeangreenSoloU, northeasternhuskiesSoloU, northernarizonalumberjacksSoloU, northerncoloradobearsSoloU, northernillinoishuskiesSoloU, northerniowapanthersSoloU, northernkentuckynorseSoloU, northwesternwildcatsSoloU, northwesternstatedemonsSoloU, notredamefightingirishSoloU, oaklandgoldengrizzliesSoloU, ohiobobcatsSoloU, ohiostatebuckeyesSoloU, oklahomasoonersSoloU, oklahomastatecowboysSoloU, olddominionmonarchsSoloU, oralrobertsgoldeneaglesSoloU, oregonducksSoloU, oregonstatebeaversSoloU, pacifictigersSoloU, pennsylvaniaquakersSoloU, pennstatenittanylionsSoloU, pepperdinewavesSoloU, pittsburghpanthersSoloU, portlandpilotsSoloU, portlandstatevikingsSoloU, prairieviewaandmpanthersSoloU, presbyterianbluehoseSoloU, princetontigersSoloU, providencefriarsSoloU, purdueboilermakersSoloU, purduefortwaynemastodonsSoloU, quinnipiacbobcatsSoloU, radfordhighlandersSoloU, rhodeislandramsSoloU, riceowlsSoloU, richmondspidersSoloU, riderbroncsSoloU, robertmorriscolonialsSoloU, rutgersscarletknightsSoloU, sacredheartpioneersSoloU, stbonaventurebonniesSoloU, stfrancisbknterriersSoloU, stfrancisparedflashSoloU, stjohnsredstormSoloU, saintjosephshawksSoloU, saintlouisbillikensSoloU, saintmarysgaelsSoloU, saintpeterspeacocksSoloU, samhoustonbearkatsSoloU, samfordbulldogsSoloU, sandiegotorerosSoloU, sandiegostateaztecsSoloU, sanfranciscodonsSoloU, sanjosestatespartansSoloU, santaclarabroncosSoloU, seattleredhawksSoloU, setonhallpiratesSoloU, sienasaintsSoloU, southalabamajaguarsSoloU, southcarolinagamecocksSoloU, southcarolinastatebulldogsSoloU, southcarolinaupstatespartansSoloU, southdakotacoyotesSoloU, southdakotastatejackrabbitsSoloU, southfloridabullsSoloU, semissouristredhawksSoloU, selouisianalionsSoloU, southernjaguarsSoloU, usctrojansSoloU, southernillinoissalukisSoloU, siuedwardsvillecougarsSoloU, smumustangsSoloU, southernmissgoldeneaglesSoloU, southernutahthunderbirdsSoloU, stanfordcardinalsSoloU, stephenfaustinlumberjacksSoloU, stetsonhattersSoloU, stonybrookseawolvesSoloU, syracuseorangeSoloU, templeowlsSoloU, tennesseevolunteersSoloU, chattanoogamocsSoloU, utmartinskyhawksSoloU, tennesseestatetigersSoloU, tennesseetechgoldeneaglesSoloU, texasaandmaggiesSoloU, texasaandmccislandersSoloU, utarlingtonmavericksSoloU, texaslonghornsSoloU, tcuhornedfrogsSoloU, utepminersSoloU, utriograndevalleyvaquerosSoloU, utsaroadrunnersSoloU, texassoutherntigersSoloU, texasstatebobcatsSoloU, texastechredraidersSoloU, toledorocketsSoloU, towsontigersSoloU, troytrojansSoloU, tulanegreenwaveSoloU, tulsagoldenhurricaneSoloU, airforcefalconsSoloU, armyblackknightsSoloU, navymidshipmenSoloU, utahutesSoloU, utahstateaggiesSoloU, utahvalleywolverinesSoloU, valparaisocrusadersSoloU, vanderbiltcommodoresSoloU, vermontcatamountsSoloU, villanovawildcatsSoloU, virginiacavaliersSoloU, vcuramsSoloU, vmikeydetsSoloU, virginiatechhokiesSoloU, wagnerseahawksSoloU, wakeforestdemondeaconsSoloU, washingtonhuskiesSoloU, washingtonstatecougarsSoloU, weberstatewildcatsSoloU, westvirginiamountaineersSoloU, westerncarolinacatamountsSoloU, westernillinoisleathernecksSoloU, westernmichiganbroncosSoloU, wichitastateshockersSoloU, williamandmarytribeSoloU, winthropeaglesSoloU, greenbayphoenixSoloU, wisconsinbadgersSoloU, milwaukeepanthersSoloU, woffordterriersSoloU, wrightstateraidersSoloU, wyomingcowboysSoloU, xaviermusketeersSoloU, yalebulldogsSoloU, youngstownstpenguinsSoloU]
statLists["Halftime ATS"] = [abilenechristianwildcatsHalftime,akronzipsHalftime,alabamacrimsontideHalftime,alabamaaandmbulldogsHalftime,uabblazersHalftime,alabamastatehornetsHalftime,albanygreatdanesHalftime, alcornstatebravesHalftime, americaneaglesHalftime, appalachianstatemountaineersHalftime, arizonawildcatsHalftime, arizonastatesundevilsHalftime, arkansasrazorbacksHalftime, littlerocktrojansHalftime, arkansaspinebluffgoldenlionsHalftime, arkansasstredwolvesHalftime, auburntigersHalftime, austinpeaygovernorsHalftime, ballstatecardinalsHalftime, baylorbearsHalftime, belmontbruinsHalftime, bethunecookmanwildcatsHalftime, binghamtonbearcatsHalftime, boisestatebroncosHalftime,bostoncollegeeaglesHalftime, bostonunivterriersHalftime, bowlinggreenfalconsHalftime, bradleybravesHalftime, byucougarsHalftime, brownbearsHalftime, bryantbulldogsHalftime, bucknellbisonHalftime, buffalobullsHalftime, butlerbulldogsHalftime, californiagoldenbearsHalftime, ucdavisaggiesHalftime, ucirvineanteatersHalftime, uclabruinsHalftime, calpolymustangsHalftime, ucriversidehighlandersHalftime, ucsantabarbaragauchosHalftime, csubakersfieldroadrunnersHalftime, fresnostatebulldogsHalftime, csufullertontitansHalftime, longbeachstate49ersHalftime, csunorthridgematadorsHalftime, sacramentostatehornetsHalftime, campbellfightingcamelsHalftime, canisiusgoldengriffinsHalftime, centralarkansasbearsHalftime, centralconnecticutbluedevilsHalftime, ucfknightsHalftime, centralmichiganchippewasHalftime, charlestoncougarsHalftime,charlestonsouthernbuccaneersHalftime, chicagostatecougarsHalftime, cincinnatibearcatsHalftime,thecitadelbulldogsHalftime, clemsontigersHalftime, clevelandstatevikingsHalftime, coastalcarolinachanticleersHalftime, colgateraidersHalftime, coloradobuffaloesHalftime, coloradostateramsHalftime, columbialionsHalftime, uconnhuskiesHalftime, coppinstateeaglesHalftime, cornellbigredHalftime, creightonbluejaysHalftime,dartmouthbiggreenHalftime, davidsonwildcatsHalftime, daytonflyersHalftime,delawarebluehensHalftime, delawarestatehornetsHalftime, denverpioneersHalftime, depaulbluedemonsHalftime, detroitmercytitansHalftime, drakebulldogsHalftime, drexeldragonsHalftime, dukebluedevilsHalftime,duquesnedukesHalftime, easttennesseestatebuccaneersHalftime, easternillinoispanthersHalftime, easternkentuckycolonelsHalftime, easternmichiganeaglesHalftime, elonphoenixHalftime, evansvillepurpleacesHalftime, fairfieldstagsHalftime, fairleighdickinsonknightsHalftime, floridagatorsHalftime, floridaaandmrattlersHalftime, floridaatlanticowlsHalftime, floridagulfcoasteaglesHalftime, floridainternationalpanthersHalftime, floridastateseminolesHalftime, fordhamramsHalftime, furmanpaladinsHalftime, gardnerwebbbulldogsHalftime, georgemasonpatriotsHalftime, georgewashingtoncolonialsHalftime, georgetownhoyasHalftime, georgiabulldogsHalftime, georgiatechyellowjacketsHalftime, georgiasoutherneaglesHalftime, georgiastatepanthersHalftime, gonzagabulldogsHalftime, gramblingtigersHalftime, grandcanyonantelopesHalftime, hamptonpiratesHalftime, hartfordhawksHalftime, harvardcrimsonHalftime, hawaiirainbowwarriorsHalftime, highpointpanthersHalftime, hofstraprideHalftime, holycrosscrusadersHalftime, houstoncougarsHalftime, houstonbaptisthuskiesHalftime, howardbisonHalftime, idahovandalsHalftime, idahostatebengalsHalftime, uicflamesHalftime, illinoisstateredbirdsHalftime, illinoisfightingilliniHalftime, incarnatewordcardinalsHalftime, indianahoosiersHalftime, indianastatesycamoresHalftime, iupuijaguarsHalftime, ionagaelsHalftime, iowahawkeyesHalftime, iowastatecyclonesHalftime, jacksonstatetigersHalftime, jacksonvilledolphinsHalftime, jacksonvillestategamecocksHalftime, jamesmadisondukesHalftime, kansasjayhawksHalftime, kansasstatewildcatsHalftime, kennesawstateowlsHalftime, kentstategoldenflashesHalftime, kentuckywildcatsHalftime, lasalleexplorersHalftime, lafayetteleopardsHalftime, lamarcardinalsHalftime, lehighmountainhawksHalftime, libertyflamesHalftime, lipscombbisonsHalftime, longislanduniversitysharksHalftime, longwoodlancersHalftime, louisianaragincajunsHalftime, ulmonroewarhawksHalftime, lsutigersHalftime, louisianatechbulldogsHalftime, louisvillecardinalsHalftime, loyolachicagoramblersHalftime, loyolamdgreyhoundsHalftime, loyolamarymountlionsHalftime, maineblackbearsHalftime, manhattanjaspersHalftime, maristredfoxesHalftime, marquettegoldeneaglesHalftime, marshallthunderingherdHalftime, umbcretrieversHalftime, marylandterrapinsHalftime, umassminutemenHalftime, umasslowellriverhawksHalftime, mcneesestatecowboysHalftime, memphistigersHalftime, mercerbearsHalftime, miamihurricanesHalftime, miamiohredhawksHalftime, michiganwolverinesHalftime, michiganstatespartansHalftime, middletennesseeblueraidersHalftime, minnesotagoldengophersHalftime, olemissrebelsHalftime, mississippistatebulldogsHalftime, mississippivalleystatedeltadevilsHalftime, missouritigersHalftime, umkckangaroosHalftime, missouristatebearsHalftime, monmouthhawksHalftime, montanagrizzliesHalftime, montanastatebobcatsHalftime, moreheadstateeaglesHalftime, morganstatebearsHalftime, mtstmarysmountaineersHalftime, murraystateracersHalftime, nebraskacornhuskersHalftime, omahamavericksHalftime, unlvrebelsHalftime, nevadawolfpackHalftime, newhampshirewildcatsHalftime, njithighlandersHalftime, newmexicolobosHalftime, newmexicostateaggiesHalftime, neworleansprivateersHalftime, niagarapurpleeaglesHalftime, nichollscolonelsHalftime, norfolkstatespartansHalftime, northcarolinaaandtaggiesHalftime, uncashevillebulldogsHalftime, northcarolinacentraleaglesHalftime, northcarolinatarheelsHalftime, charlotte49ersHalftime, uncgreensborospartansHalftime, ncstatewolfpackHalftime, uncwilmingtonseahawksHalftime, northdakotafightinghawksHalftime, northdakotastatebisonHalftime, northfloridaospreysHalftime, northtexasmeangreenHalftime, northeasternhuskiesHalftime, northernarizonalumberjacksHalftime, northerncoloradobearsHalftime, northernillinoishuskiesHalftime, northerniowapanthersHalftime, northernkentuckynorseHalftime, northwesternwildcatsHalftime, northwesternstatedemonsHalftime, notredamefightingirishHalftime, oaklandgoldengrizzliesHalftime, ohiobobcatsHalftime, ohiostatebuckeyesHalftime, oklahomasoonersHalftime, oklahomastatecowboysHalftime, olddominionmonarchsHalftime, oralrobertsgoldeneaglesHalftime, oregonducksHalftime, oregonstatebeaversHalftime, pacifictigersHalftime, pennsylvaniaquakersHalftime, pennstatenittanylionsHalftime, pepperdinewavesHalftime, pittsburghpanthersHalftime, portlandpilotsHalftime, portlandstatevikingsHalftime, prairieviewaandmpanthersHalftime, presbyterianbluehoseHalftime, princetontigersHalftime, providencefriarsHalftime, purdueboilermakersHalftime, purduefortwaynemastodonsHalftime, quinnipiacbobcatsHalftime, radfordhighlandersHalftime, rhodeislandramsHalftime, riceowlsHalftime, richmondspidersHalftime, riderbroncsHalftime, robertmorriscolonialsHalftime, rutgersscarletknightsHalftime, sacredheartpioneersHalftime, stbonaventurebonniesHalftime, stfrancisbknterriersHalftime, stfrancisparedflashHalftime, stjohnsredstormHalftime, saintjosephshawksHalftime, saintlouisbillikensHalftime, saintmarysgaelsHalftime, saintpeterspeacocksHalftime, samhoustonbearkatsHalftime, samfordbulldogsHalftime, sandiegotorerosHalftime, sandiegostateaztecsHalftime, sanfranciscodonsHalftime, sanjosestatespartansHalftime, santaclarabroncosHalftime, seattleredhawksHalftime, setonhallpiratesHalftime, sienasaintsHalftime, southalabamajaguarsHalftime, southcarolinagamecocksHalftime, southcarolinastatebulldogsHalftime, southcarolinaupstatespartansHalftime, southdakotacoyotesHalftime, southdakotastatejackrabbitsHalftime, southfloridabullsHalftime, semissouristredhawksHalftime, selouisianalionsHalftime, southernjaguarsHalftime, usctrojansHalftime, southernillinoissalukisHalftime, siuedwardsvillecougarsHalftime, smumustangsHalftime, southernmissgoldeneaglesHalftime, southernutahthunderbirdsHalftime, stanfordcardinalsHalftime, stephenfaustinlumberjacksHalftime, stetsonhattersHalftime, stonybrookseawolvesHalftime, syracuseorangeHalftime, templeowlsHalftime, tennesseevolunteersHalftime, chattanoogamocsHalftime, utmartinskyhawksHalftime, tennesseestatetigersHalftime, tennesseetechgoldeneaglesHalftime, texasaandmaggiesHalftime, texasaandmccislandersHalftime, utarlingtonmavericksHalftime, texaslonghornsHalftime, tcuhornedfrogsHalftime, utepminersHalftime, utriograndevalleyvaquerosHalftime, utsaroadrunnersHalftime, texassoutherntigersHalftime, texasstatebobcatsHalftime, texastechredraidersHalftime, toledorocketsHalftime, towsontigersHalftime, troytrojansHalftime, tulanegreenwaveHalftime, tulsagoldenhurricaneHalftime, airforcefalconsHalftime, armyblackknightsHalftime, navymidshipmenHalftime, utahutesHalftime, utahstateaggiesHalftime, utahvalleywolverinesHalftime, valparaisocrusadersHalftime, vanderbiltcommodoresHalftime, vermontcatamountsHalftime, villanovawildcatsHalftime, virginiacavaliersHalftime, vcuramsHalftime, vmikeydetsHalftime, virginiatechhokiesHalftime, wagnerseahawksHalftime, wakeforestdemondeaconsHalftime, washingtonhuskiesHalftime, washingtonstatecougarsHalftime, weberstatewildcatsHalftime, westvirginiamountaineersHalftime, westerncarolinacatamountsHalftime, westernillinoisleathernecksHalftime, westernmichiganbroncosHalftime, wichitastateshockersHalftime, williamandmarytribeHalftime, winthropeaglesHalftime, greenbayphoenixHalftime, wisconsinbadgersHalftime, milwaukeepanthersHalftime, woffordterriersHalftime, wrightstateraidersHalftime, wyomingcowboysHalftime, xaviermusketeersHalftime, yalebulldogsHalftime, youngstownstpenguinsHalftime]
statLists["Halftime Over"] = [abilenechristianwildcatsHalftimeO,akronzipsHalftimeO,alabamacrimsontideHalftimeO,alabamaaandmbulldogsHalftimeO,uabblazersHalftimeO,alabamastatehornetsHalftimeO,albanygreatdanesHalftimeO, alcornstatebravesHalftimeO, americaneaglesHalftimeO, appalachianstatemountaineersHalftimeO, arizonawildcatsHalftimeO, arizonastatesundevilsHalftimeO, arkansasrazorbacksHalftimeO, littlerocktrojansHalftimeO, arkansaspinebluffgoldenlionsHalftimeO, arkansasstredwolvesHalftimeO, auburntigersHalftimeO, austinpeaygovernorsHalftimeO, ballstatecardinalsHalftimeO, baylorbearsHalftimeO, belmontbruinsHalftimeO, bethunecookmanwildcatsHalftimeO, binghamtonbearcatsHalftimeO, boisestatebroncosHalftimeO,bostoncollegeeaglesHalftimeO, bostonunivterriersHalftimeO, bowlinggreenfalconsHalftimeO, bradleybravesHalftimeO, byucougarsHalftimeO, brownbearsHalftimeO, bryantbulldogsHalftimeO, bucknellbisonHalftimeO, buffalobullsHalftimeO, butlerbulldogsHalftimeO, californiagoldenbearsHalftimeO, ucdavisaggiesHalftimeO, ucirvineanteatersHalftimeO, uclabruinsHalftimeO, calpolymustangsHalftimeO, ucriversidehighlandersHalftimeO, ucsantabarbaragauchosHalftimeO, csubakersfieldroadrunnersHalftimeO, fresnostatebulldogsHalftimeO, csufullertontitansHalftimeO, longbeachstate49ersHalftimeO, csunorthridgematadorsHalftimeO, sacramentostatehornetsHalftimeO, campbellfightingcamelsHalftimeO, canisiusgoldengriffinsHalftimeO, centralarkansasbearsHalftimeO, centralconnecticutbluedevilsHalftimeO, ucfknightsHalftimeO, centralmichiganchippewasHalftimeO, charlestoncougarsHalftimeO,charlestonsouthernbuccaneersHalftimeO, chicagostatecougarsHalftimeO, cincinnatibearcatsHalftimeO,thecitadelbulldogsHalftimeO, clemsontigersHalftimeO, clevelandstatevikingsHalftimeO, coastalcarolinachanticleersHalftimeO, colgateraidersHalftimeO, coloradobuffaloesHalftimeO, coloradostateramsHalftimeO, columbialionsHalftimeO, uconnhuskiesHalftimeO, coppinstateeaglesHalftimeO, cornellbigredHalftimeO, creightonbluejaysHalftimeO,dartmouthbiggreenHalftimeO, davidsonwildcatsHalftimeO, daytonflyersHalftimeO,delawarebluehensHalftimeO, delawarestatehornetsHalftimeO, denverpioneersHalftimeO, depaulbluedemonsHalftimeO, detroitmercytitansHalftimeO, drakebulldogsHalftimeO, drexeldragonsHalftimeO, dukebluedevilsHalftimeO,duquesnedukesHalftimeO, easttennesseestatebuccaneersHalftimeO, easternillinoispanthersHalftimeO, easternkentuckycolonelsHalftimeO, easternmichiganeaglesHalftimeO, elonphoenixHalftimeO, evansvillepurpleacesHalftimeO, fairfieldstagsHalftimeO, fairleighdickinsonknightsHalftimeO, floridagatorsHalftimeO, floridaaandmrattlersHalftimeO, floridaatlanticowlsHalftimeO, floridagulfcoasteaglesHalftimeO, floridainternationalpanthersHalftimeO, floridastateseminolesHalftimeO, fordhamramsHalftimeO, furmanpaladinsHalftimeO, gardnerwebbbulldogsHalftimeO, georgemasonpatriotsHalftimeO, georgewashingtoncolonialsHalftimeO, georgetownhoyasHalftimeO, georgiabulldogsHalftimeO, georgiatechyellowjacketsHalftimeO, georgiasoutherneaglesHalftimeO, georgiastatepanthersHalftimeO, gonzagabulldogsHalftimeO, gramblingtigersHalftimeO, grandcanyonantelopesHalftimeO, hamptonpiratesHalftimeO, hartfordhawksHalftimeO, harvardcrimsonHalftimeO, hawaiirainbowwarriorsHalftimeO, highpointpanthersHalftimeO, hofstraprideHalftimeO, holycrosscrusadersHalftimeO, houstoncougarsHalftimeO, houstonbaptisthuskiesHalftimeO, howardbisonHalftimeO, idahovandalsHalftimeO, idahostatebengalsHalftimeO, uicflamesHalftimeO, illinoisstateredbirdsHalftimeO, illinoisfightingilliniHalftimeO, incarnatewordcardinalsHalftimeO, indianahoosiersHalftimeO, indianastatesycamoresHalftimeO, iupuijaguarsHalftimeO, ionagaelsHalftimeO, iowahawkeyesHalftimeO, iowastatecyclonesHalftimeO, jacksonstatetigersHalftimeO, jacksonvilledolphinsHalftimeO, jacksonvillestategamecocksHalftimeO, jamesmadisondukesHalftimeO, kansasjayhawksHalftimeO, kansasstatewildcatsHalftimeO, kennesawstateowlsHalftimeO, kentstategoldenflashesHalftimeO, kentuckywildcatsHalftimeO, lasalleexplorersHalftimeO, lafayetteleopardsHalftimeO, lamarcardinalsHalftimeO, lehighmountainhawksHalftimeO, libertyflamesHalftimeO, lipscombbisonsHalftimeO, longislanduniversitysharksHalftimeO, longwoodlancersHalftimeO, louisianaragincajunsHalftimeO, ulmonroewarhawksHalftimeO, lsutigersHalftimeO, louisianatechbulldogsHalftimeO, louisvillecardinalsHalftimeO, loyolachicagoramblersHalftimeO, loyolamdgreyhoundsHalftimeO, loyolamarymountlionsHalftimeO, maineblackbearsHalftimeO, manhattanjaspersHalftimeO, maristredfoxesHalftimeO, marquettegoldeneaglesHalftimeO, marshallthunderingherdHalftimeO, umbcretrieversHalftimeO, marylandterrapinsHalftimeO, umassminutemenHalftimeO, umasslowellriverhawksHalftimeO, mcneesestatecowboysHalftimeO, memphistigersHalftimeO, mercerbearsHalftimeO, miamihurricanesHalftimeO, miamiohredhawksHalftimeO, michiganwolverinesHalftimeO, michiganstatespartansHalftimeO, middletennesseeblueraidersHalftimeO, minnesotagoldengophersHalftimeO, olemissrebelsHalftimeO, mississippistatebulldogsHalftimeO, mississippivalleystatedeltadevilsHalftimeO, missouritigersHalftimeO, umkckangaroosHalftimeO, missouristatebearsHalftimeO, monmouthhawksHalftimeO, montanagrizzliesHalftimeO, montanastatebobcatsHalftimeO, moreheadstateeaglesHalftimeO, morganstatebearsHalftimeO, mtstmarysmountaineersHalftimeO, murraystateracersHalftimeO, nebraskacornhuskersHalftimeO, omahamavericksHalftimeO, unlvrebelsHalftimeO, nevadawolfpackHalftimeO, newhampshirewildcatsHalftimeO, njithighlandersHalftimeO, newmexicolobosHalftimeO, newmexicostateaggiesHalftimeO, neworleansprivateersHalftimeO, niagarapurpleeaglesHalftimeO, nichollscolonelsHalftimeO, norfolkstatespartansHalftimeO, northcarolinaaandtaggiesHalftimeO, uncashevillebulldogsHalftimeO, northcarolinacentraleaglesHalftimeO, northcarolinatarheelsHalftimeO, charlotte49ersHalftimeO, uncgreensborospartansHalftimeO, ncstatewolfpackHalftimeO, uncwilmingtonseahawksHalftimeO, northdakotafightinghawksHalftimeO, northdakotastatebisonHalftimeO, northfloridaospreysHalftimeO, northtexasmeangreenHalftimeO, northeasternhuskiesHalftimeO, northernarizonalumberjacksHalftimeO, northerncoloradobearsHalftimeO, northernillinoishuskiesHalftimeO, northerniowapanthersHalftimeO, northernkentuckynorseHalftimeO, northwesternwildcatsHalftimeO, northwesternstatedemonsHalftimeO, notredamefightingirishHalftimeO, oaklandgoldengrizzliesHalftimeO, ohiobobcatsHalftimeO, ohiostatebuckeyesHalftimeO, oklahomasoonersHalftimeO, oklahomastatecowboysHalftimeO, olddominionmonarchsHalftimeO, oralrobertsgoldeneaglesHalftimeO, oregonducksHalftimeO, oregonstatebeaversHalftimeO, pacifictigersHalftimeO, pennsylvaniaquakersHalftimeO, pennstatenittanylionsHalftimeO, pepperdinewavesHalftimeO, pittsburghpanthersHalftimeO, portlandpilotsHalftimeO, portlandstatevikingsHalftimeO, prairieviewaandmpanthersHalftimeO, presbyterianbluehoseHalftimeO, princetontigersHalftimeO, providencefriarsHalftimeO, purdueboilermakersHalftimeO, purduefortwaynemastodonsHalftimeO, quinnipiacbobcatsHalftimeO, radfordhighlandersHalftimeO, rhodeislandramsHalftimeO, riceowlsHalftimeO, richmondspidersHalftimeO, riderbroncsHalftimeO, robertmorriscolonialsHalftimeO, rutgersscarletknightsHalftimeO, sacredheartpioneersHalftimeO, stbonaventurebonniesHalftimeO, stfrancisbknterriersHalftimeO, stfrancisparedflashHalftimeO, stjohnsredstormHalftimeO, saintjosephshawksHalftimeO, saintlouisbillikensHalftimeO, saintmarysgaelsHalftimeO, saintpeterspeacocksHalftimeO, samhoustonbearkatsHalftimeO, samfordbulldogsHalftimeO, sandiegotorerosHalftimeO, sandiegostateaztecsHalftimeO, sanfranciscodonsHalftimeO, sanjosestatespartansHalftimeO, santaclarabroncosHalftimeO, seattleredhawksHalftimeO, setonhallpiratesHalftimeO, sienasaintsHalftimeO, southalabamajaguarsHalftimeO, southcarolinagamecocksHalftimeO, southcarolinastatebulldogsHalftimeO, southcarolinaupstatespartansHalftimeO, southdakotacoyotesHalftimeO, southdakotastatejackrabbitsHalftimeO, southfloridabullsHalftimeO, semissouristredhawksHalftimeO, selouisianalionsHalftimeO, southernjaguarsHalftimeO, usctrojansHalftimeO, southernillinoissalukisHalftimeO, siuedwardsvillecougarsHalftimeO, smumustangsHalftimeO, southernmissgoldeneaglesHalftimeO, southernutahthunderbirdsHalftimeO, stanfordcardinalsHalftimeO, stephenfaustinlumberjacksHalftimeO, stetsonhattersHalftimeO, stonybrookseawolvesHalftimeO, syracuseorangeHalftimeO, templeowlsHalftimeO, tennesseevolunteersHalftimeO, chattanoogamocsHalftimeO, utmartinskyhawksHalftimeO, tennesseestatetigersHalftimeO, tennesseetechgoldeneaglesHalftimeO, texasaandmaggiesHalftimeO, texasaandmccislandersHalftimeO, utarlingtonmavericksHalftimeO, texaslonghornsHalftimeO, tcuhornedfrogsHalftimeO, utepminersHalftimeO, utriograndevalleyvaquerosHalftimeO, utsaroadrunnersHalftimeO, texassoutherntigersHalftimeO, texasstatebobcatsHalftimeO, texastechredraidersHalftimeO, toledorocketsHalftimeO, towsontigersHalftimeO, troytrojansHalftimeO, tulanegreenwaveHalftimeO, tulsagoldenhurricaneHalftimeO, airforcefalconsHalftimeO, armyblackknightsHalftimeO, navymidshipmenHalftimeO, utahutesHalftimeO, utahstateaggiesHalftimeO, utahvalleywolverinesHalftimeO, valparaisocrusadersHalftimeO, vanderbiltcommodoresHalftimeO, vermontcatamountsHalftimeO, villanovawildcatsHalftimeO, virginiacavaliersHalftimeO, vcuramsHalftimeO, vmikeydetsHalftimeO, virginiatechhokiesHalftimeO, wagnerseahawksHalftimeO, wakeforestdemondeaconsHalftimeO, washingtonhuskiesHalftimeO, washingtonstatecougarsHalftimeO, weberstatewildcatsHalftimeO, westvirginiamountaineersHalftimeO, westerncarolinacatamountsHalftimeO, westernillinoisleathernecksHalftimeO, westernmichiganbroncosHalftimeO, wichitastateshockersHalftimeO, williamandmarytribeHalftimeO, winthropeaglesHalftimeO, greenbayphoenixHalftimeO, wisconsinbadgersHalftimeO, milwaukeepanthersHalftimeO, woffordterriersHalftimeO, wrightstateraidersHalftimeO, wyomingcowboysHalftimeO, xaviermusketeersHalftimeO, yalebulldogsHalftimeO, youngstownstpenguinsHalftimeO]
statLists["Halftime Under"] = [abilenechristianwildcatsHalftimeU,akronzipsHalftimeU,alabamacrimsontideHalftimeU,alabamaaandmbulldogsHalftimeU,uabblazersHalftimeU,alabamastatehornetsHalftimeU,albanygreatdanesHalftimeU, alcornstatebravesHalftimeU, americaneaglesHalftimeU, appalachianstatemountaineersHalftimeU, arizonawildcatsHalftimeU, arizonastatesundevilsHalftimeU, arkansasrazorbacksHalftimeU, littlerocktrojansHalftimeU, arkansaspinebluffgoldenlionsHalftimeU, arkansasstredwolvesHalftimeU, auburntigersHalftimeU, austinpeaygovernorsHalftimeU, ballstatecardinalsHalftimeU, baylorbearsHalftimeU, belmontbruinsHalftimeU, bethunecookmanwildcatsHalftimeU, binghamtonbearcatsHalftimeU, boisestatebroncosHalftimeU,bostoncollegeeaglesHalftimeU, bostonunivterriersHalftimeU, bowlinggreenfalconsHalftimeU, bradleybravesHalftimeU, byucougarsHalftimeU, brownbearsHalftimeU, bryantbulldogsHalftimeU, bucknellbisonHalftimeU, buffalobullsHalftimeU, butlerbulldogsHalftimeU, californiagoldenbearsHalftimeU, ucdavisaggiesHalftimeU, ucirvineanteatersHalftimeU, uclabruinsHalftimeU, calpolymustangsHalftimeU, ucriversidehighlandersHalftimeU, ucsantabarbaragauchosHalftimeU, csubakersfieldroadrunnersHalftimeU, fresnostatebulldogsHalftimeU, csufullertontitansHalftimeU, longbeachstate49ersHalftimeU, csunorthridgematadorsHalftimeU, sacramentostatehornetsHalftimeU, campbellfightingcamelsHalftimeU, canisiusgoldengriffinsHalftimeU, centralarkansasbearsHalftimeU, centralconnecticutbluedevilsHalftimeU, ucfknightsHalftimeU, centralmichiganchippewasHalftimeU, charlestoncougarsHalftimeU,charlestonsouthernbuccaneersHalftimeU, chicagostatecougarsHalftimeU, cincinnatibearcatsHalftimeU,thecitadelbulldogsHalftimeU, clemsontigersHalftimeU, clevelandstatevikingsHalftimeU, coastalcarolinachanticleersHalftimeU, colgateraidersHalftimeU, coloradobuffaloesHalftimeU, coloradostateramsHalftimeU, columbialionsHalftimeU, uconnhuskiesHalftimeU, coppinstateeaglesHalftimeU, cornellbigredHalftimeU, creightonbluejaysHalftimeU,dartmouthbiggreenHalftimeU, davidsonwildcatsHalftimeU, daytonflyersHalftimeU,delawarebluehensHalftimeU, delawarestatehornetsHalftimeU, denverpioneersHalftimeU, depaulbluedemonsHalftimeU, detroitmercytitansHalftimeU, drakebulldogsHalftimeU, drexeldragonsHalftimeU, dukebluedevilsHalftimeU,duquesnedukesHalftimeU, easttennesseestatebuccaneersHalftimeU, easternillinoispanthersHalftimeU, easternkentuckycolonelsHalftimeU, easternmichiganeaglesHalftimeU, elonphoenixHalftimeU, evansvillepurpleacesHalftimeU, fairfieldstagsHalftimeU, fairleighdickinsonknightsHalftimeU, floridagatorsHalftimeU, floridaaandmrattlersHalftimeU, floridaatlanticowlsHalftimeU, floridagulfcoasteaglesHalftimeU, floridainternationalpanthersHalftimeU, floridastateseminolesHalftimeU, fordhamramsHalftimeU, furmanpaladinsHalftimeU, gardnerwebbbulldogsHalftimeU, georgemasonpatriotsHalftimeU, georgewashingtoncolonialsHalftimeU, georgetownhoyasHalftimeU, georgiabulldogsHalftimeU, georgiatechyellowjacketsHalftimeU, georgiasoutherneaglesHalftimeU, georgiastatepanthersHalftimeU, gonzagabulldogsHalftimeU, gramblingtigersHalftimeU, grandcanyonantelopesHalftimeU, hamptonpiratesHalftimeU, hartfordhawksHalftimeU, harvardcrimsonHalftimeU, hawaiirainbowwarriorsHalftimeU, highpointpanthersHalftimeU, hofstraprideHalftimeU, holycrosscrusadersHalftimeU, houstoncougarsHalftimeU, houstonbaptisthuskiesHalftimeU, howardbisonHalftimeU, idahovandalsHalftimeU, idahostatebengalsHalftimeU, uicflamesHalftimeU, illinoisstateredbirdsHalftimeU, illinoisfightingilliniHalftimeU, incarnatewordcardinalsHalftimeU, indianahoosiersHalftimeU, indianastatesycamoresHalftimeU, iupuijaguarsHalftimeU, ionagaelsHalftimeU, iowahawkeyesHalftimeU, iowastatecyclonesHalftimeU, jacksonstatetigersHalftimeU, jacksonvilledolphinsHalftimeU, jacksonvillestategamecocksHalftimeU, jamesmadisondukesHalftimeU, kansasjayhawksHalftimeU, kansasstatewildcatsHalftimeU, kennesawstateowlsHalftimeU, kentstategoldenflashesHalftimeU, kentuckywildcatsHalftimeU, lasalleexplorersHalftimeU, lafayetteleopardsHalftimeU, lamarcardinalsHalftimeU, lehighmountainhawksHalftimeU, libertyflamesHalftimeU, lipscombbisonsHalftimeU, longislanduniversitysharksHalftimeU, longwoodlancersHalftimeU, louisianaragincajunsHalftimeU, ulmonroewarhawksHalftimeU, lsutigersHalftimeU, louisianatechbulldogsHalftimeU, louisvillecardinalsHalftimeU, loyolachicagoramblersHalftimeU, loyolamdgreyhoundsHalftimeU, loyolamarymountlionsHalftimeU, maineblackbearsHalftimeU, manhattanjaspersHalftimeU, maristredfoxesHalftimeU, marquettegoldeneaglesHalftimeU, marshallthunderingherdHalftimeU, umbcretrieversHalftimeU, marylandterrapinsHalftimeU, umassminutemenHalftimeU, umasslowellriverhawksHalftimeU, mcneesestatecowboysHalftimeU, memphistigersHalftimeU, mercerbearsHalftimeU, miamihurricanesHalftimeU, miamiohredhawksHalftimeU, michiganwolverinesHalftimeU, michiganstatespartansHalftimeU, middletennesseeblueraidersHalftimeU, minnesotagoldengophersHalftimeU, olemissrebelsHalftimeU, mississippistatebulldogsHalftimeU, mississippivalleystatedeltadevilsHalftimeU, missouritigersHalftimeU, umkckangaroosHalftimeU, missouristatebearsHalftimeU, monmouthhawksHalftimeU, montanagrizzliesHalftimeU, montanastatebobcatsHalftimeU, moreheadstateeaglesHalftimeU, morganstatebearsHalftimeU, mtstmarysmountaineersHalftimeU, murraystateracersHalftimeU, nebraskacornhuskersHalftimeU, omahamavericksHalftimeU, unlvrebelsHalftimeU, nevadawolfpackHalftimeU, newhampshirewildcatsHalftimeU, njithighlandersHalftimeU, newmexicolobosHalftimeU, newmexicostateaggiesHalftimeU, neworleansprivateersHalftimeU, niagarapurpleeaglesHalftimeU, nichollscolonelsHalftimeU, norfolkstatespartansHalftimeU, northcarolinaaandtaggiesHalftimeU, uncashevillebulldogsHalftimeU, northcarolinacentraleaglesHalftimeU, northcarolinatarheelsHalftimeU, charlotte49ersHalftimeU, uncgreensborospartansHalftimeU, ncstatewolfpackHalftimeU, uncwilmingtonseahawksHalftimeU, northdakotafightinghawksHalftimeU, northdakotastatebisonHalftimeU, northfloridaospreysHalftimeU, northtexasmeangreenHalftimeU, northeasternhuskiesHalftimeU, northernarizonalumberjacksHalftimeU, northerncoloradobearsHalftimeU, northernillinoishuskiesHalftimeU, northerniowapanthersHalftimeU, northernkentuckynorseHalftimeU, northwesternwildcatsHalftimeU, northwesternstatedemonsHalftimeU, notredamefightingirishHalftimeU, oaklandgoldengrizzliesHalftimeU, ohiobobcatsHalftimeU, ohiostatebuckeyesHalftimeU, oklahomasoonersHalftimeU, oklahomastatecowboysHalftimeU, olddominionmonarchsHalftimeU, oralrobertsgoldeneaglesHalftimeU, oregonducksHalftimeU, oregonstatebeaversHalftimeU, pacifictigersHalftimeU, pennsylvaniaquakersHalftimeU, pennstatenittanylionsHalftimeU, pepperdinewavesHalftimeU, pittsburghpanthersHalftimeU, portlandpilotsHalftimeU, portlandstatevikingsHalftimeU, prairieviewaandmpanthersHalftimeU, presbyterianbluehoseHalftimeU, princetontigersHalftimeU, providencefriarsHalftimeU, purdueboilermakersHalftimeU, purduefortwaynemastodonsHalftimeU, quinnipiacbobcatsHalftimeU, radfordhighlandersHalftimeU, rhodeislandramsHalftimeU, riceowlsHalftimeU, richmondspidersHalftimeU, riderbroncsHalftimeU, robertmorriscolonialsHalftimeU, rutgersscarletknightsHalftimeU, sacredheartpioneersHalftimeU, stbonaventurebonniesHalftimeU, stfrancisbknterriersHalftimeU, stfrancisparedflashHalftimeU, stjohnsredstormHalftimeU, saintjosephshawksHalftimeU, saintlouisbillikensHalftimeU, saintmarysgaelsHalftimeU, saintpeterspeacocksHalftimeU, samhoustonbearkatsHalftimeU, samfordbulldogsHalftimeU, sandiegotorerosHalftimeU, sandiegostateaztecsHalftimeU, sanfranciscodonsHalftimeU, sanjosestatespartansHalftimeU, santaclarabroncosHalftimeU, seattleredhawksHalftimeU, setonhallpiratesHalftimeU, sienasaintsHalftimeU, southalabamajaguarsHalftimeU, southcarolinagamecocksHalftimeU, southcarolinastatebulldogsHalftimeU, southcarolinaupstatespartansHalftimeU, southdakotacoyotesHalftimeU, southdakotastatejackrabbitsHalftimeU, southfloridabullsHalftimeU, semissouristredhawksHalftimeU, selouisianalionsHalftimeU, southernjaguarsHalftimeU, usctrojansHalftimeU, southernillinoissalukisHalftimeU, siuedwardsvillecougarsHalftimeU, smumustangsHalftimeU, southernmissgoldeneaglesHalftimeU, southernutahthunderbirdsHalftimeU, stanfordcardinalsHalftimeU, stephenfaustinlumberjacksHalftimeU, stetsonhattersHalftimeU, stonybrookseawolvesHalftimeU, syracuseorangeHalftimeU, templeowlsHalftimeU, tennesseevolunteersHalftimeU, chattanoogamocsHalftimeU, utmartinskyhawksHalftimeU, tennesseestatetigersHalftimeU, tennesseetechgoldeneaglesHalftimeU, texasaandmaggiesHalftimeU, texasaandmccislandersHalftimeU, utarlingtonmavericksHalftimeU, texaslonghornsHalftimeU, tcuhornedfrogsHalftimeU, utepminersHalftimeU, utriograndevalleyvaquerosHalftimeU, utsaroadrunnersHalftimeU, texassoutherntigersHalftimeU, texasstatebobcatsHalftimeU, texastechredraidersHalftimeU, toledorocketsHalftimeU, towsontigersHalftimeU, troytrojansHalftimeU, tulanegreenwaveHalftimeU, tulsagoldenhurricaneHalftimeU, airforcefalconsHalftimeU, armyblackknightsHalftimeU, navymidshipmenHalftimeU, utahutesHalftimeU, utahstateaggiesHalftimeU, utahvalleywolverinesHalftimeU, valparaisocrusadersHalftimeU, vanderbiltcommodoresHalftimeU, vermontcatamountsHalftimeU, villanovawildcatsHalftimeU, virginiacavaliersHalftimeU, vcuramsHalftimeU, vmikeydetsHalftimeU, virginiatechhokiesHalftimeU, wagnerseahawksHalftimeU, wakeforestdemondeaconsHalftimeU, washingtonhuskiesHalftimeU, washingtonstatecougarsHalftimeU, weberstatewildcatsHalftimeU, westvirginiamountaineersHalftimeU, westerncarolinacatamountsHalftimeU, westernillinoisleathernecksHalftimeU, westernmichiganbroncosHalftimeU, wichitastateshockersHalftimeU, williamandmarytribeHalftimeU, winthropeaglesHalftimeU, greenbayphoenixHalftimeU, wisconsinbadgersHalftimeU, milwaukeepanthersHalftimeU, woffordterriersHalftimeU, wrightstateraidersHalftimeU, wyomingcowboysHalftimeU, xaviermusketeersHalftimeU, yalebulldogsHalftimeU, youngstownstpenguinsHalftimeU]

  // Stat index clicked by user is logged
  var statIndex = selectObj.selectedIndex;

  // Value of stat index is logged
  var statValue = selectObj.options[statIndex].value;

  // Actual number is retrieved from statList
  stat = statLists[statValue]

  // Remove extra characters extracted from back-end
  finalstat = stat[index - 1]

  finalstat = String(finalstat).replace(/[',()]/g, "");



  // HTML Element that has stat % passed through to front-end user


if (finalstat.includes("%")) {

  document.getElementById("stat").innerHTML = "This happens " + finalstat + " of the time";
  document.getElementById("stat").style.opacity = "1";

} else {

  document.getElementById("stat").innerHTML = "This happens " + finalstat + "% of the time";
  document.getElementById("stat").style.opacity = "1";
}
}

$(document).ready(function() {
    $('.Dropdown').select2({
      width: 'resolve',
});
});
